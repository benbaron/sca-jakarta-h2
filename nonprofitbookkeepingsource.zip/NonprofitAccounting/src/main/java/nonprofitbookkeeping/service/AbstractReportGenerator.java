package nonprofitbookkeeping.service;

/**
 * Compatibility alias for legacy references in the service package.
 */
public abstract class AbstractReportGenerator
	extends nonprofitbookkeeping.reports.jasper.AbstractReportGenerator
{
}
