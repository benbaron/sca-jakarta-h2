
package nonprofitbookkeeping.service;

/**
 * Compatibility alias for reports runtime context used by service tests.
 */
public class ReportContext
	extends nonprofitbookkeeping.reports.jasper.runtime.ReportContext
{
}
