package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet BALANCE_3 */
public class BALANCE_3Bean
{

    private java.lang.Double balance_3_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.Double balance_3_r17c7;
    private java.lang.Double contents_c_14;
    private java.lang.String start_2_5a;
    private java.lang.Double end_2_5a;
    private java.lang.Double diff_if_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19;
    private java.lang.String start_2;
    private java.lang.Double if_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19_2;
    private java.lang.Double h19_g19_if_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23;
    private java.lang.Double start_5a;
    private java.lang.Double if_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23_asset_dtl_5a_f35_asset_dtl_5c_e33;
    private java.lang.Double h20_g20_asset_dtl_5a_g35_asset_dtl_5c_f33;
    private java.lang.Double asset_dtl_5a_f35_asset_dtl_5c_e33_6;
    private java.lang.Double asset_dtl_5a_g35_asset_dtl_5c_f33_inventory_dtl_6_m17_inventory_dtl_6b_m17;
    private java.lang.Double h21_g21_inventory_dtl_6_m27_inventory_dtl_6b_m27;
    private java.lang.Double inventory_dtl_6_m17_inventory_dtl_6b_m17_7;
    private java.lang.Double inventory_dtl_6_m27_inventory_dtl_6b_m27_regalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32;
    private java.lang.Double h22_g22_regalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32;
    private java.lang.Double regalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32_8;
    private java.lang.Double regalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32_depr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51;
    private java.lang.Double h23_g23_depr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54;
    private java.lang.Double depr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51_8;
    private java.lang.Double depr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54_1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51;
    private java.lang.Double h24_g24_depr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1;
    private java.lang.Double _1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51_5a;
    private java.lang.Double depr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1_asset_dtl_5a_f46_asset_dtl_5c_e44;
    private java.lang.Double h25_g25_asset_dtl_5a_g46_asset_dtl_5c_f44;
    private java.lang.Double asset_dtl_5a_f46_asset_dtl_5c_e44_5a;
    private java.lang.Double asset_dtl_5a_g46_asset_dtl_5c_f44_asset_dtl_5a_f60_asset_dtl_5c_e58;
    private java.lang.Double h26_g26_asset_dtl_5a_g60_asset_dtl_5c_f58;
    private java.lang.Double asset_dtl_5a_f60_asset_dtl_5c_e58_add_a_through_f_subtract_g_then_add_h_and_i;
    private java.lang.Double asset_dtl_5a_g60_asset_dtl_5c_f58_sum_g19_g27;
    private java.lang.Double h27_g27_sum_h19_h27;
    private java.lang.String sum_g19_g27_15;
    private java.lang.Double sum_h19_h27_15;
    private java.lang.Double sum_i19_i27_newsletter_15_e16;
    private java.lang.Double sum_g19_g27_5b;
    private java.lang.Double newsletter_15_e16_liability_dtl_5b_e31_liability_dtl_5d_e29;
    private java.lang.Double h31_g31_liability_dtl_5b_f31_liability_dtl_5d_f29;
    private java.lang.Double liability_dtl_5b_e31_liability_dtl_5d_e29_5b;
    private java.lang.Double liability_dtl_5b_f31_liability_dtl_5d_f29_liability_dtl_5b_e44_liability_dtl_5d_e47;
    private java.lang.Double h32_g32_liability_dtl_5b_f44_liability_dtl_5d_f47;
    private java.lang.Double liability_dtl_5b_e44_liability_dtl_5d_e47_5b;
    private java.lang.Double liability_dtl_5b_f44_liability_dtl_5d_f47_liability_dtl_5b_e56_liability_dtl_5d_e56;
    private java.lang.Double h33_g33_liability_dtl_5b_f56_liability_dtl_5d_f56;
    private java.lang.Double liability_dtl_5b_e56_liability_dtl_5d_e56_add_a_through_d;
    private java.lang.Double liability_dtl_5b_f56_liability_dtl_5d_f56_sum_g31_g34;
    private java.lang.Double h34_g34_sum_h31_h34;
    private java.lang.Double sum_g31_g34_line_i_i_minus_line_ii_d;
    private java.lang.Double sum_h31_h34_round_g28_g35_2;
    private java.lang.Double round_g28_g35_2_a;
    private java.lang.Double h37_g37_b;
    private java.lang.Double print_exchequer;
    private java.lang.Double if_contents_c_10_contents_c_10_seneschal;

    public java.lang.Double getBalance_3_r2c3()
    {
        return balance_3_r2c3;
    }

    public void setBalance_3_r2c3(java.lang.Double v)
    {
        this.balance_3_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.Double getBalance_3_r17c7()
    {
        return balance_3_r17c7;
    }

    public void setBalance_3_r17c7(java.lang.Double v)
    {
        this.balance_3_r17c7 = v;
    }

    public java.lang.Double getContents_c_14()
    {
        return contents_c_14;
    }

    public void setContents_c_14(java.lang.Double v)
    {
        this.contents_c_14 = v;
    }

    public java.lang.String getStart_2_5a()
    {
        return start_2_5a;
    }

    public void setStart_2_5a(java.lang.String v)
    {
        this.start_2_5a = v;
    }

    public java.lang.Double getEnd_2_5a()
    {
        return end_2_5a;
    }

    public void setEnd_2_5a(java.lang.Double v)
    {
        this.end_2_5a = v;
    }

    public java.lang.Double getDiff_if_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19()
    {
        return diff_if_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19;
    }

    public void setDiff_if_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19(java.lang.Double v)
    {
        this.diff_if_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19 = v;
    }

    public java.lang.String getStart_2()
    {
        return start_2;
    }

    public void setStart_2(java.lang.String v)
    {
        this.start_2 = v;
    }

    public java.lang.Double getIf_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19_2()
    {
        return if_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19_2;
    }

    public void setIf_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19_2(java.lang.Double v)
    {
        this.if_primary_account_2a_f_38_yes_if_primary_account_2a_h_37_primary_account_2a_h_36_primary_account_2a_h_37_0_0_secondary_accounts_2b_i22_secondary_accounts_2c_i22_secondary_accounts_2d_i22_asset_dtl_5a_g19_2 = v;
    }

    public java.lang.Double getH19_g19_if_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23()
    {
        return h19_g19_if_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23;
    }

    public void setH19_g19_if_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23(java.lang.Double v)
    {
        this.h19_g19_if_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23 = v;
    }

    public java.lang.Double getStart_5a()
    {
        return start_5a;
    }

    public void setStart_5a(java.lang.Double v)
    {
        this.start_5a = v;
    }

    public java.lang.Double getIf_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23_asset_dtl_5a_f35_asset_dtl_5c_e33()
    {
        return if_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23_asset_dtl_5a_f35_asset_dtl_5c_e33;
    }

    public void setIf_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23_asset_dtl_5a_f35_asset_dtl_5c_e33(java.lang.Double v)
    {
        this.if_primary_account_2a_f38_yes_if_primary_account_2a_h37_primary_account_2a_h36_primary_account_2a_h37_0_0_secondary_accounts_2b_i23_secondary_accounts_2c_i23_secondary_accounts_2d_i23_asset_dtl_5a_f35_asset_dtl_5c_e33 = v;
    }

    public java.lang.Double getH20_g20_asset_dtl_5a_g35_asset_dtl_5c_f33()
    {
        return h20_g20_asset_dtl_5a_g35_asset_dtl_5c_f33;
    }

    public void setH20_g20_asset_dtl_5a_g35_asset_dtl_5c_f33(java.lang.Double v)
    {
        this.h20_g20_asset_dtl_5a_g35_asset_dtl_5c_f33 = v;
    }

    public java.lang.Double getAsset_dtl_5a_f35_asset_dtl_5c_e33_6()
    {
        return asset_dtl_5a_f35_asset_dtl_5c_e33_6;
    }

    public void setAsset_dtl_5a_f35_asset_dtl_5c_e33_6(java.lang.Double v)
    {
        this.asset_dtl_5a_f35_asset_dtl_5c_e33_6 = v;
    }

    public java.lang.Double getAsset_dtl_5a_g35_asset_dtl_5c_f33_inventory_dtl_6_m17_inventory_dtl_6b_m17()
    {
        return asset_dtl_5a_g35_asset_dtl_5c_f33_inventory_dtl_6_m17_inventory_dtl_6b_m17;
    }

    public void setAsset_dtl_5a_g35_asset_dtl_5c_f33_inventory_dtl_6_m17_inventory_dtl_6b_m17(java.lang.Double v)
    {
        this.asset_dtl_5a_g35_asset_dtl_5c_f33_inventory_dtl_6_m17_inventory_dtl_6b_m17 = v;
    }

    public java.lang.Double getH21_g21_inventory_dtl_6_m27_inventory_dtl_6b_m27()
    {
        return h21_g21_inventory_dtl_6_m27_inventory_dtl_6b_m27;
    }

    public void setH21_g21_inventory_dtl_6_m27_inventory_dtl_6b_m27(java.lang.Double v)
    {
        this.h21_g21_inventory_dtl_6_m27_inventory_dtl_6b_m27 = v;
    }

    public java.lang.Double getInventory_dtl_6_m17_inventory_dtl_6b_m17_7()
    {
        return inventory_dtl_6_m17_inventory_dtl_6b_m17_7;
    }

    public void setInventory_dtl_6_m17_inventory_dtl_6b_m17_7(java.lang.Double v)
    {
        this.inventory_dtl_6_m17_inventory_dtl_6b_m17_7 = v;
    }

    public java.lang.Double getInventory_dtl_6_m27_inventory_dtl_6b_m27_regalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32()
    {
        return inventory_dtl_6_m27_inventory_dtl_6b_m27_regalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32;
    }

    public void setInventory_dtl_6_m27_inventory_dtl_6b_m27_regalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32(java.lang.Double v)
    {
        this.inventory_dtl_6_m27_inventory_dtl_6b_m27_regalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32 = v;
    }

    public java.lang.Double getH22_g22_regalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32()
    {
        return h22_g22_regalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32;
    }

    public void setH22_g22_regalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32(java.lang.Double v)
    {
        this.h22_g22_regalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32 = v;
    }

    public java.lang.Double getRegalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32_8()
    {
        return regalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32_8;
    }

    public void setRegalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32_8(java.lang.Double v)
    {
        this.regalia_sales_dtl_7_f32_regalia_sales_dtl_7b_f32_8 = v;
    }

    public java.lang.Double getRegalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32_depr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51()
    {
        return regalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32_depr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51;
    }

    public void setRegalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32_depr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51(java.lang.Double v)
    {
        this.regalia_sales_dtl_7_i32_regalia_sales_dtl_7b_i32_depr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51 = v;
    }

    public java.lang.Double getH23_g23_depr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54()
    {
        return h23_g23_depr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54;
    }

    public void setH23_g23_depr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54(java.lang.Double v)
    {
        this.h23_g23_depr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54 = v;
    }

    public java.lang.Double getDepr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51_8()
    {
        return depr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51_8;
    }

    public void setDepr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51_8(java.lang.Double v)
    {
        this.depr_dtl_8_i47_depr_dtl_8b_i54_depr_dtl_8c_i54_regalia_sales_dtl_7_f49_regalia_sales_dtl_7_f50_regalia_sales_dtl_7_f51_regalia_sales_dtl_7b_f49_regalia_sales_dtl_7b_f50_regalia_sales_dtl_7b_f51_8 = v;
    }

    public java.lang.Double getDepr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54_1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51()
    {
        return depr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54_1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51;
    }

    public void setDepr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54_1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51(java.lang.Double v)
    {
        this.depr_dtl_8_j47_depr_dtl_8b_j54_depr_dtl_8c_j54_1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51 = v;
    }

    public java.lang.Double getH24_g24_depr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1()
    {
        return h24_g24_depr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1;
    }

    public void setH24_g24_depr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1(java.lang.Double v)
    {
        this.h24_g24_depr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1 = v;
    }

    public java.lang.Double get_1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51_5a()
    {
        return _1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51_5a;
    }

    public void set_1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51_5a(java.lang.Double v)
    {
        this._1_depr_dtl_8_k47_depr_dtl_8b_k54_depr_dtl_8c_k54_regalia_sales_dtl_7_g49_regalia_sales_dtl_7_g50_regalia_sales_dtl_7_g51_regalia_sales_dtl_7b_g49_regalia_sales_dtl_7b_g50_regalia_sales_dtl_7b_g51_5a = v;
    }

    public java.lang.Double getDepr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1_asset_dtl_5a_f46_asset_dtl_5c_e44()
    {
        return depr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1_asset_dtl_5a_f46_asset_dtl_5c_e44;
    }

    public void setDepr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1_asset_dtl_5a_f46_asset_dtl_5c_e44(java.lang.Double v)
    {
        this.depr_dtl_8_m47_1_depr_dtl_8b_m54_1_depr_dtl_8c_m54_1_asset_dtl_5a_f46_asset_dtl_5c_e44 = v;
    }

    public java.lang.Double getH25_g25_asset_dtl_5a_g46_asset_dtl_5c_f44()
    {
        return h25_g25_asset_dtl_5a_g46_asset_dtl_5c_f44;
    }

    public void setH25_g25_asset_dtl_5a_g46_asset_dtl_5c_f44(java.lang.Double v)
    {
        this.h25_g25_asset_dtl_5a_g46_asset_dtl_5c_f44 = v;
    }

    public java.lang.Double getAsset_dtl_5a_f46_asset_dtl_5c_e44_5a()
    {
        return asset_dtl_5a_f46_asset_dtl_5c_e44_5a;
    }

    public void setAsset_dtl_5a_f46_asset_dtl_5c_e44_5a(java.lang.Double v)
    {
        this.asset_dtl_5a_f46_asset_dtl_5c_e44_5a = v;
    }

    public java.lang.Double getAsset_dtl_5a_g46_asset_dtl_5c_f44_asset_dtl_5a_f60_asset_dtl_5c_e58()
    {
        return asset_dtl_5a_g46_asset_dtl_5c_f44_asset_dtl_5a_f60_asset_dtl_5c_e58;
    }

    public void setAsset_dtl_5a_g46_asset_dtl_5c_f44_asset_dtl_5a_f60_asset_dtl_5c_e58(java.lang.Double v)
    {
        this.asset_dtl_5a_g46_asset_dtl_5c_f44_asset_dtl_5a_f60_asset_dtl_5c_e58 = v;
    }

    public java.lang.Double getH26_g26_asset_dtl_5a_g60_asset_dtl_5c_f58()
    {
        return h26_g26_asset_dtl_5a_g60_asset_dtl_5c_f58;
    }

    public void setH26_g26_asset_dtl_5a_g60_asset_dtl_5c_f58(java.lang.Double v)
    {
        this.h26_g26_asset_dtl_5a_g60_asset_dtl_5c_f58 = v;
    }

    public java.lang.Double getAsset_dtl_5a_f60_asset_dtl_5c_e58_add_a_through_f_subtract_g_then_add_h_and_i()
    {
        return asset_dtl_5a_f60_asset_dtl_5c_e58_add_a_through_f_subtract_g_then_add_h_and_i;
    }

    public void setAsset_dtl_5a_f60_asset_dtl_5c_e58_add_a_through_f_subtract_g_then_add_h_and_i(java.lang.Double v)
    {
        this.asset_dtl_5a_f60_asset_dtl_5c_e58_add_a_through_f_subtract_g_then_add_h_and_i = v;
    }

    public java.lang.Double getAsset_dtl_5a_g60_asset_dtl_5c_f58_sum_g19_g27()
    {
        return asset_dtl_5a_g60_asset_dtl_5c_f58_sum_g19_g27;
    }

    public void setAsset_dtl_5a_g60_asset_dtl_5c_f58_sum_g19_g27(java.lang.Double v)
    {
        this.asset_dtl_5a_g60_asset_dtl_5c_f58_sum_g19_g27 = v;
    }

    public java.lang.Double getH27_g27_sum_h19_h27()
    {
        return h27_g27_sum_h19_h27;
    }

    public void setH27_g27_sum_h19_h27(java.lang.Double v)
    {
        this.h27_g27_sum_h19_h27 = v;
    }

    public java.lang.String getSum_g19_g27_15()
    {
        return sum_g19_g27_15;
    }

    public void setSum_g19_g27_15(java.lang.String v)
    {
        this.sum_g19_g27_15 = v;
    }

    public java.lang.Double getSum_h19_h27_15()
    {
        return sum_h19_h27_15;
    }

    public void setSum_h19_h27_15(java.lang.Double v)
    {
        this.sum_h19_h27_15 = v;
    }

    public java.lang.Double getSum_i19_i27_newsletter_15_e16()
    {
        return sum_i19_i27_newsletter_15_e16;
    }

    public void setSum_i19_i27_newsletter_15_e16(java.lang.Double v)
    {
        this.sum_i19_i27_newsletter_15_e16 = v;
    }

    public java.lang.Double getSum_g19_g27_5b()
    {
        return sum_g19_g27_5b;
    }

    public void setSum_g19_g27_5b(java.lang.Double v)
    {
        this.sum_g19_g27_5b = v;
    }

    public java.lang.Double getNewsletter_15_e16_liability_dtl_5b_e31_liability_dtl_5d_e29()
    {
        return newsletter_15_e16_liability_dtl_5b_e31_liability_dtl_5d_e29;
    }

    public void setNewsletter_15_e16_liability_dtl_5b_e31_liability_dtl_5d_e29(java.lang.Double v)
    {
        this.newsletter_15_e16_liability_dtl_5b_e31_liability_dtl_5d_e29 = v;
    }

    public java.lang.Double getH31_g31_liability_dtl_5b_f31_liability_dtl_5d_f29()
    {
        return h31_g31_liability_dtl_5b_f31_liability_dtl_5d_f29;
    }

    public void setH31_g31_liability_dtl_5b_f31_liability_dtl_5d_f29(java.lang.Double v)
    {
        this.h31_g31_liability_dtl_5b_f31_liability_dtl_5d_f29 = v;
    }

    public java.lang.Double getLiability_dtl_5b_e31_liability_dtl_5d_e29_5b()
    {
        return liability_dtl_5b_e31_liability_dtl_5d_e29_5b;
    }

    public void setLiability_dtl_5b_e31_liability_dtl_5d_e29_5b(java.lang.Double v)
    {
        this.liability_dtl_5b_e31_liability_dtl_5d_e29_5b = v;
    }

    public java.lang.Double getLiability_dtl_5b_f31_liability_dtl_5d_f29_liability_dtl_5b_e44_liability_dtl_5d_e47()
    {
        return liability_dtl_5b_f31_liability_dtl_5d_f29_liability_dtl_5b_e44_liability_dtl_5d_e47;
    }

    public void setLiability_dtl_5b_f31_liability_dtl_5d_f29_liability_dtl_5b_e44_liability_dtl_5d_e47(java.lang.Double v)
    {
        this.liability_dtl_5b_f31_liability_dtl_5d_f29_liability_dtl_5b_e44_liability_dtl_5d_e47 = v;
    }

    public java.lang.Double getH32_g32_liability_dtl_5b_f44_liability_dtl_5d_f47()
    {
        return h32_g32_liability_dtl_5b_f44_liability_dtl_5d_f47;
    }

    public void setH32_g32_liability_dtl_5b_f44_liability_dtl_5d_f47(java.lang.Double v)
    {
        this.h32_g32_liability_dtl_5b_f44_liability_dtl_5d_f47 = v;
    }

    public java.lang.Double getLiability_dtl_5b_e44_liability_dtl_5d_e47_5b()
    {
        return liability_dtl_5b_e44_liability_dtl_5d_e47_5b;
    }

    public void setLiability_dtl_5b_e44_liability_dtl_5d_e47_5b(java.lang.Double v)
    {
        this.liability_dtl_5b_e44_liability_dtl_5d_e47_5b = v;
    }

    public java.lang.Double getLiability_dtl_5b_f44_liability_dtl_5d_f47_liability_dtl_5b_e56_liability_dtl_5d_e56()
    {
        return liability_dtl_5b_f44_liability_dtl_5d_f47_liability_dtl_5b_e56_liability_dtl_5d_e56;
    }

    public void setLiability_dtl_5b_f44_liability_dtl_5d_f47_liability_dtl_5b_e56_liability_dtl_5d_e56(java.lang.Double v)
    {
        this.liability_dtl_5b_f44_liability_dtl_5d_f47_liability_dtl_5b_e56_liability_dtl_5d_e56 = v;
    }

    public java.lang.Double getH33_g33_liability_dtl_5b_f56_liability_dtl_5d_f56()
    {
        return h33_g33_liability_dtl_5b_f56_liability_dtl_5d_f56;
    }

    public void setH33_g33_liability_dtl_5b_f56_liability_dtl_5d_f56(java.lang.Double v)
    {
        this.h33_g33_liability_dtl_5b_f56_liability_dtl_5d_f56 = v;
    }

    public java.lang.Double getLiability_dtl_5b_e56_liability_dtl_5d_e56_add_a_through_d()
    {
        return liability_dtl_5b_e56_liability_dtl_5d_e56_add_a_through_d;
    }

    public void setLiability_dtl_5b_e56_liability_dtl_5d_e56_add_a_through_d(java.lang.Double v)
    {
        this.liability_dtl_5b_e56_liability_dtl_5d_e56_add_a_through_d = v;
    }

    public java.lang.Double getLiability_dtl_5b_f56_liability_dtl_5d_f56_sum_g31_g34()
    {
        return liability_dtl_5b_f56_liability_dtl_5d_f56_sum_g31_g34;
    }

    public void setLiability_dtl_5b_f56_liability_dtl_5d_f56_sum_g31_g34(java.lang.Double v)
    {
        this.liability_dtl_5b_f56_liability_dtl_5d_f56_sum_g31_g34 = v;
    }

    public java.lang.Double getH34_g34_sum_h31_h34()
    {
        return h34_g34_sum_h31_h34;
    }

    public void setH34_g34_sum_h31_h34(java.lang.Double v)
    {
        this.h34_g34_sum_h31_h34 = v;
    }

    public java.lang.Double getSum_g31_g34_line_i_i_minus_line_ii_d()
    {
        return sum_g31_g34_line_i_i_minus_line_ii_d;
    }

    public void setSum_g31_g34_line_i_i_minus_line_ii_d(java.lang.Double v)
    {
        this.sum_g31_g34_line_i_i_minus_line_ii_d = v;
    }

    public java.lang.Double getSum_h31_h34_round_g28_g35_2()
    {
        return sum_h31_h34_round_g28_g35_2;
    }

    public void setSum_h31_h34_round_g28_g35_2(java.lang.Double v)
    {
        this.sum_h31_h34_round_g28_g35_2 = v;
    }

    public java.lang.Double getRound_g28_g35_2_a()
    {
        return round_g28_g35_2_a;
    }

    public void setRound_g28_g35_2_a(java.lang.Double v)
    {
        this.round_g28_g35_2_a = v;
    }

    public java.lang.Double getH37_g37_b()
    {
        return h37_g37_b;
    }

    public void setH37_g37_b(java.lang.Double v)
    {
        this.h37_g37_b = v;
    }

    public java.lang.Double getPrint_exchequer()
    {
        return print_exchequer;
    }

    public void setPrint_exchequer(java.lang.Double v)
    {
        this.print_exchequer = v;
    }

    public java.lang.Double getIf_contents_c_10_contents_c_10_seneschal()
    {
        return if_contents_c_10_contents_c_10_seneschal;
    }

    public void setIf_contents_c_10_contents_c_10_seneschal(java.lang.Double v)
    {
        this.if_contents_c_10_contents_c_10_seneschal = v;
    }

    public BALANCE_3Bean()
    {
    }

}
