package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet INCOME_DTL_11b */
public class INCOME_DTL_11bBean
{

    private java.lang.Double income_dtl_11b_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String income_detail_part_2;
    private java.lang.String do_not_include_cash_box_start_up_money_in_event_income;
    private java.lang.String do_not_include_cash_box_start_up_money_in_event_income_2;
    private java.lang.String do_not_include_cash_box_start_up_money_in_event_income_3;
    private java.lang.String event_name;
    private java.lang.String income_dtl_11b_r12c4;
    private java.lang.String a_gross_gate_income_nmr;
    private java.lang.String b_total_refunds;
    private java.lang.Double a_b_adj_gross_income;
    private java.lang.String event_name_2;
    private java.lang.String income_dtl_11b_r13c4;
    private java.lang.String a_gross_gate_income_nmr_2;
    private java.lang.String b_total_refunds_2;
    private java.lang.Double e12_f12;
    private java.lang.String event_name_3;
    private java.lang.String income_dtl_11b_r14c4;
    private java.lang.String a_gross_gate_income_nmr_3;
    private java.lang.String b_total_refunds_3;
    private java.lang.Double e13_f13;
    private java.lang.String event_name_4;
    private java.lang.String income_dtl_11b_r15c4;
    private java.lang.String a_gross_gate_income_nmr_4;
    private java.lang.String b_total_refunds_4;
    private java.lang.Double e14_f14;
    private java.lang.String event_name_5;
    private java.lang.String income_dtl_11b_r16c4;
    private java.lang.String a_gross_gate_income_nmr_5;
    private java.lang.String b_total_refunds_5;
    private java.lang.Double e15_f15;
    private java.lang.String event_name_6;
    private java.lang.String income_dtl_11b_r17c4;
    private java.lang.String a_gross_gate_income_nmr_6;
    private java.lang.String b_total_refunds_6;
    private java.lang.Double e16_f16;
    private java.lang.String event_name_7;
    private java.lang.String income_dtl_11b_r18c4;
    private java.lang.String a_gross_gate_income_nmr_7;
    private java.lang.String b_total_refunds_7;
    private java.lang.Double e17_f17;
    private java.lang.String event_name_8;
    private java.lang.String income_dtl_11b_r19c4;
    private java.lang.String a_gross_gate_income_nmr_8;
    private java.lang.String b_total_refunds_8;
    private java.lang.Double e18_f18;
    private java.lang.String event_name_9;
    private java.lang.String income_dtl_11b_r20c4;
    private java.lang.String a_gross_gate_income_nmr_9;
    private java.lang.String b_total_refunds_9;
    private java.lang.Double e19_f19;
    private java.lang.String event_name_10;
    private java.lang.String income_dtl_11b_r21c4;
    private java.lang.String a_gross_gate_income_nmr_10;
    private java.lang.String b_total_refunds_10;
    private java.lang.Double e20_f20;
    private java.lang.String event_name_11;
    private java.lang.String income_dtl_11b_r22c4;
    private java.lang.String a_gross_gate_income_nmr_11;
    private java.lang.String b_total_refunds_11;
    private java.lang.Double e21_f21;
    private java.lang.String event_name_12;
    private java.lang.String income_dtl_11b_r23c4;
    private java.lang.String a_gross_gate_income_nmr_12;
    private java.lang.String b_total_refunds_12;
    private java.lang.Double e22_f22;
    private java.lang.String event_name_13;
    private java.lang.String income_dtl_11b_r24c4;
    private java.lang.String a_gross_gate_income_nmr_13;
    private java.lang.String b_total_refunds_13;
    private java.lang.Double e23_f23;
    private java.lang.String event_name_14;
    private java.lang.String income_dtl_11b_r25c4;
    private java.lang.String a_gross_gate_income_nmr_14;
    private java.lang.String b_total_refunds_14;
    private java.lang.Double e24_f24;
    private java.lang.String event_name_15;
    private java.lang.String income_dtl_11b_r26c4;
    private java.lang.String a_gross_gate_income_nmr_15;
    private java.lang.String b_total_refunds_15;
    private java.lang.Double e25_f25;
    private java.lang.Double e26_f26_total_a;
    private java.lang.String paypal_scars_income_event_name;
    private java.lang.String paypal_scars;
    private java.lang.String gross;
    private java.lang.String transaction_fees;
    private java.lang.Double actual_amount_received;
    private java.lang.String paypal_scars_income_event_name_2;
    private java.lang.String paypal_scars_2;
    private java.lang.String gross_2;
    private java.lang.String transaction_fees_2;
    private java.lang.Double e29_f29;
    private java.lang.String paypal_scars_income_event_name_3;
    private java.lang.String paypal_scars_3;
    private java.lang.String gross_3;
    private java.lang.String transaction_fees_3;
    private java.lang.Double e30_f30;
    private java.lang.String paypal_scars_income_event_name_4;
    private java.lang.String paypal_scars_4;
    private java.lang.String gross_4;
    private java.lang.String transaction_fees_4;
    private java.lang.Double e31_f31;
    private java.lang.String paypal_scars_income_event_name_5;
    private java.lang.String paypal_scars_5;
    private java.lang.String gross_5;
    private java.lang.String transaction_fees_5;
    private java.lang.Double e32_f32;
    private java.lang.String paypal_scars_income_event_name_6;
    private java.lang.String paypal_scars_6;
    private java.lang.String gross_6;
    private java.lang.String transaction_fees_6;
    private java.lang.Double e33_f33;
    private java.lang.String paypal_scars_income_event_name_7;
    private java.lang.String paypal_scars_7;
    private java.lang.String gross_7;
    private java.lang.String transaction_fees_7;
    private java.lang.Double e34_f34;
    private java.lang.Double e35_f35_total_b;
    private java.lang.Double sum_g29_g35_show_total_a_b_on_pg_4_line_3b;
    private java.lang.String _7_net_advertising_income_publication_issue_event;
    private java.lang.String paypal_scars_8;
    private java.lang.String a_gross_income;
    private java.lang.String b_advertising_cost;
    private java.lang.Double a_b_net_income;
    private java.lang.String _7_net_advertising_income_publication_issue_event_2;
    private java.lang.String paypal_scars_9;
    private java.lang.String a_gross_income_2;
    private java.lang.String b_advertising_cost_2;
    private java.lang.Double e40_f40;
    private java.lang.String _7_net_advertising_income_publication_issue_event_3;
    private java.lang.String paypal_scars_10;
    private java.lang.String a_gross_income_3;
    private java.lang.String b_advertising_cost_3;
    private java.lang.Double e41_f41;
    private java.lang.Double a_gross_income_show_totals_on_pg_4_line_9;
    private java.lang.Double b_advertising_cost_sum_e40_e42;
    private java.lang.Double e42_f42_sum_f40_f42;
    private java.lang.String show_totals_on_pg_4_line_9;
    private java.lang.String paypal_scars_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks;
    private java.lang.String sum_e40_e42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks;
    private java.lang.String sum_f40_f42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks;
    private java.lang.String sum_g40_g42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks;
    private java.lang.String _10_other_income_description;
    private java.lang.String paypal_scars_11;
    private java.lang.String sum_e40_e42;
    private java.lang.String sum_f40_f42;
    private java.lang.String amount;
    private java.lang.String _10_other_income_description_2;
    private java.lang.String paypal_scars_12;
    private java.lang.String sum_e40_e42_2;
    private java.lang.String sum_f40_f42_2;
    private java.lang.String amount_2;
    private java.lang.String _10_other_income_description_3;
    private java.lang.String paypal_scars_13;
    private java.lang.String sum_e40_e42_3;
    private java.lang.String sum_f40_f42_3;
    private java.lang.String amount_3;
    private java.lang.String _10_other_income_description_4;
    private java.lang.String paypal_scars_14;
    private java.lang.String sum_e40_e42_4;
    private java.lang.String sum_f40_f42_4;
    private java.lang.String amount_4;
    private java.lang.String _10_other_income_description_5;
    private java.lang.String paypal_scars_15;
    private java.lang.String sum_e40_e42_5;
    private java.lang.String sum_f40_f42_5;
    private java.lang.String amount_5;
    private java.lang.String _10_other_income_description_6;
    private java.lang.String paypal_scars_16;
    private java.lang.String sum_e40_e42_6;
    private java.lang.String sum_f40_f42_6;
    private java.lang.String amount_6;
    private java.lang.String _10_other_income_description_7;
    private java.lang.String paypal_scars_17;
    private java.lang.String sum_e40_e42_7;
    private java.lang.String sum_f40_f42_7;
    private java.lang.String amount_7;
    private java.lang.Double amount_show_total_on_pg_4_line_10;

    public java.lang.Double getIncome_dtl_11b_r2c3()
    {
        return income_dtl_11b_r2c3;
    }

    public void setIncome_dtl_11b_r2c3(java.lang.Double v)
    {
        this.income_dtl_11b_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getIncome_detail_part_2()
    {
        return income_detail_part_2;
    }

    public void setIncome_detail_part_2(java.lang.String v)
    {
        this.income_detail_part_2 = v;
    }

    public java.lang.String getDo_not_include_cash_box_start_up_money_in_event_income()
    {
        return do_not_include_cash_box_start_up_money_in_event_income;
    }

    public void setDo_not_include_cash_box_start_up_money_in_event_income(java.lang.String v)
    {
        this.do_not_include_cash_box_start_up_money_in_event_income = v;
    }

    public java.lang.String getDo_not_include_cash_box_start_up_money_in_event_income_2()
    {
        return do_not_include_cash_box_start_up_money_in_event_income_2;
    }

    public void setDo_not_include_cash_box_start_up_money_in_event_income_2(java.lang.String v)
    {
        this.do_not_include_cash_box_start_up_money_in_event_income_2 = v;
    }

    public java.lang.String getDo_not_include_cash_box_start_up_money_in_event_income_3()
    {
        return do_not_include_cash_box_start_up_money_in_event_income_3;
    }

    public void setDo_not_include_cash_box_start_up_money_in_event_income_3(java.lang.String v)
    {
        this.do_not_include_cash_box_start_up_money_in_event_income_3 = v;
    }

    public java.lang.String getEvent_name()
    {
        return event_name;
    }

    public void setEvent_name(java.lang.String v)
    {
        this.event_name = v;
    }

    public java.lang.String getIncome_dtl_11b_r12c4()
    {
        return income_dtl_11b_r12c4;
    }

    public void setIncome_dtl_11b_r12c4(java.lang.String v)
    {
        this.income_dtl_11b_r12c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr()
    {
        return a_gross_gate_income_nmr;
    }

    public void setA_gross_gate_income_nmr(java.lang.String v)
    {
        this.a_gross_gate_income_nmr = v;
    }

    public java.lang.String getB_total_refunds()
    {
        return b_total_refunds;
    }

    public void setB_total_refunds(java.lang.String v)
    {
        this.b_total_refunds = v;
    }

    public java.lang.Double getA_b_adj_gross_income()
    {
        return a_b_adj_gross_income;
    }

    public void setA_b_adj_gross_income(java.lang.Double v)
    {
        this.a_b_adj_gross_income = v;
    }

    public java.lang.String getEvent_name_2()
    {
        return event_name_2;
    }

    public void setEvent_name_2(java.lang.String v)
    {
        this.event_name_2 = v;
    }

    public java.lang.String getIncome_dtl_11b_r13c4()
    {
        return income_dtl_11b_r13c4;
    }

    public void setIncome_dtl_11b_r13c4(java.lang.String v)
    {
        this.income_dtl_11b_r13c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_2()
    {
        return a_gross_gate_income_nmr_2;
    }

    public void setA_gross_gate_income_nmr_2(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_2 = v;
    }

    public java.lang.String getB_total_refunds_2()
    {
        return b_total_refunds_2;
    }

    public void setB_total_refunds_2(java.lang.String v)
    {
        this.b_total_refunds_2 = v;
    }

    public java.lang.Double getE12_f12()
    {
        return e12_f12;
    }

    public void setE12_f12(java.lang.Double v)
    {
        this.e12_f12 = v;
    }

    public java.lang.String getEvent_name_3()
    {
        return event_name_3;
    }

    public void setEvent_name_3(java.lang.String v)
    {
        this.event_name_3 = v;
    }

    public java.lang.String getIncome_dtl_11b_r14c4()
    {
        return income_dtl_11b_r14c4;
    }

    public void setIncome_dtl_11b_r14c4(java.lang.String v)
    {
        this.income_dtl_11b_r14c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_3()
    {
        return a_gross_gate_income_nmr_3;
    }

    public void setA_gross_gate_income_nmr_3(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_3 = v;
    }

    public java.lang.String getB_total_refunds_3()
    {
        return b_total_refunds_3;
    }

    public void setB_total_refunds_3(java.lang.String v)
    {
        this.b_total_refunds_3 = v;
    }

    public java.lang.Double getE13_f13()
    {
        return e13_f13;
    }

    public void setE13_f13(java.lang.Double v)
    {
        this.e13_f13 = v;
    }

    public java.lang.String getEvent_name_4()
    {
        return event_name_4;
    }

    public void setEvent_name_4(java.lang.String v)
    {
        this.event_name_4 = v;
    }

    public java.lang.String getIncome_dtl_11b_r15c4()
    {
        return income_dtl_11b_r15c4;
    }

    public void setIncome_dtl_11b_r15c4(java.lang.String v)
    {
        this.income_dtl_11b_r15c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_4()
    {
        return a_gross_gate_income_nmr_4;
    }

    public void setA_gross_gate_income_nmr_4(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_4 = v;
    }

    public java.lang.String getB_total_refunds_4()
    {
        return b_total_refunds_4;
    }

    public void setB_total_refunds_4(java.lang.String v)
    {
        this.b_total_refunds_4 = v;
    }

    public java.lang.Double getE14_f14()
    {
        return e14_f14;
    }

    public void setE14_f14(java.lang.Double v)
    {
        this.e14_f14 = v;
    }

    public java.lang.String getEvent_name_5()
    {
        return event_name_5;
    }

    public void setEvent_name_5(java.lang.String v)
    {
        this.event_name_5 = v;
    }

    public java.lang.String getIncome_dtl_11b_r16c4()
    {
        return income_dtl_11b_r16c4;
    }

    public void setIncome_dtl_11b_r16c4(java.lang.String v)
    {
        this.income_dtl_11b_r16c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_5()
    {
        return a_gross_gate_income_nmr_5;
    }

    public void setA_gross_gate_income_nmr_5(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_5 = v;
    }

    public java.lang.String getB_total_refunds_5()
    {
        return b_total_refunds_5;
    }

    public void setB_total_refunds_5(java.lang.String v)
    {
        this.b_total_refunds_5 = v;
    }

    public java.lang.Double getE15_f15()
    {
        return e15_f15;
    }

    public void setE15_f15(java.lang.Double v)
    {
        this.e15_f15 = v;
    }

    public java.lang.String getEvent_name_6()
    {
        return event_name_6;
    }

    public void setEvent_name_6(java.lang.String v)
    {
        this.event_name_6 = v;
    }

    public java.lang.String getIncome_dtl_11b_r17c4()
    {
        return income_dtl_11b_r17c4;
    }

    public void setIncome_dtl_11b_r17c4(java.lang.String v)
    {
        this.income_dtl_11b_r17c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_6()
    {
        return a_gross_gate_income_nmr_6;
    }

    public void setA_gross_gate_income_nmr_6(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_6 = v;
    }

    public java.lang.String getB_total_refunds_6()
    {
        return b_total_refunds_6;
    }

    public void setB_total_refunds_6(java.lang.String v)
    {
        this.b_total_refunds_6 = v;
    }

    public java.lang.Double getE16_f16()
    {
        return e16_f16;
    }

    public void setE16_f16(java.lang.Double v)
    {
        this.e16_f16 = v;
    }

    public java.lang.String getEvent_name_7()
    {
        return event_name_7;
    }

    public void setEvent_name_7(java.lang.String v)
    {
        this.event_name_7 = v;
    }

    public java.lang.String getIncome_dtl_11b_r18c4()
    {
        return income_dtl_11b_r18c4;
    }

    public void setIncome_dtl_11b_r18c4(java.lang.String v)
    {
        this.income_dtl_11b_r18c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_7()
    {
        return a_gross_gate_income_nmr_7;
    }

    public void setA_gross_gate_income_nmr_7(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_7 = v;
    }

    public java.lang.String getB_total_refunds_7()
    {
        return b_total_refunds_7;
    }

    public void setB_total_refunds_7(java.lang.String v)
    {
        this.b_total_refunds_7 = v;
    }

    public java.lang.Double getE17_f17()
    {
        return e17_f17;
    }

    public void setE17_f17(java.lang.Double v)
    {
        this.e17_f17 = v;
    }

    public java.lang.String getEvent_name_8()
    {
        return event_name_8;
    }

    public void setEvent_name_8(java.lang.String v)
    {
        this.event_name_8 = v;
    }

    public java.lang.String getIncome_dtl_11b_r19c4()
    {
        return income_dtl_11b_r19c4;
    }

    public void setIncome_dtl_11b_r19c4(java.lang.String v)
    {
        this.income_dtl_11b_r19c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_8()
    {
        return a_gross_gate_income_nmr_8;
    }

    public void setA_gross_gate_income_nmr_8(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_8 = v;
    }

    public java.lang.String getB_total_refunds_8()
    {
        return b_total_refunds_8;
    }

    public void setB_total_refunds_8(java.lang.String v)
    {
        this.b_total_refunds_8 = v;
    }

    public java.lang.Double getE18_f18()
    {
        return e18_f18;
    }

    public void setE18_f18(java.lang.Double v)
    {
        this.e18_f18 = v;
    }

    public java.lang.String getEvent_name_9()
    {
        return event_name_9;
    }

    public void setEvent_name_9(java.lang.String v)
    {
        this.event_name_9 = v;
    }

    public java.lang.String getIncome_dtl_11b_r20c4()
    {
        return income_dtl_11b_r20c4;
    }

    public void setIncome_dtl_11b_r20c4(java.lang.String v)
    {
        this.income_dtl_11b_r20c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_9()
    {
        return a_gross_gate_income_nmr_9;
    }

    public void setA_gross_gate_income_nmr_9(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_9 = v;
    }

    public java.lang.String getB_total_refunds_9()
    {
        return b_total_refunds_9;
    }

    public void setB_total_refunds_9(java.lang.String v)
    {
        this.b_total_refunds_9 = v;
    }

    public java.lang.Double getE19_f19()
    {
        return e19_f19;
    }

    public void setE19_f19(java.lang.Double v)
    {
        this.e19_f19 = v;
    }

    public java.lang.String getEvent_name_10()
    {
        return event_name_10;
    }

    public void setEvent_name_10(java.lang.String v)
    {
        this.event_name_10 = v;
    }

    public java.lang.String getIncome_dtl_11b_r21c4()
    {
        return income_dtl_11b_r21c4;
    }

    public void setIncome_dtl_11b_r21c4(java.lang.String v)
    {
        this.income_dtl_11b_r21c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_10()
    {
        return a_gross_gate_income_nmr_10;
    }

    public void setA_gross_gate_income_nmr_10(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_10 = v;
    }

    public java.lang.String getB_total_refunds_10()
    {
        return b_total_refunds_10;
    }

    public void setB_total_refunds_10(java.lang.String v)
    {
        this.b_total_refunds_10 = v;
    }

    public java.lang.Double getE20_f20()
    {
        return e20_f20;
    }

    public void setE20_f20(java.lang.Double v)
    {
        this.e20_f20 = v;
    }

    public java.lang.String getEvent_name_11()
    {
        return event_name_11;
    }

    public void setEvent_name_11(java.lang.String v)
    {
        this.event_name_11 = v;
    }

    public java.lang.String getIncome_dtl_11b_r22c4()
    {
        return income_dtl_11b_r22c4;
    }

    public void setIncome_dtl_11b_r22c4(java.lang.String v)
    {
        this.income_dtl_11b_r22c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_11()
    {
        return a_gross_gate_income_nmr_11;
    }

    public void setA_gross_gate_income_nmr_11(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_11 = v;
    }

    public java.lang.String getB_total_refunds_11()
    {
        return b_total_refunds_11;
    }

    public void setB_total_refunds_11(java.lang.String v)
    {
        this.b_total_refunds_11 = v;
    }

    public java.lang.Double getE21_f21()
    {
        return e21_f21;
    }

    public void setE21_f21(java.lang.Double v)
    {
        this.e21_f21 = v;
    }

    public java.lang.String getEvent_name_12()
    {
        return event_name_12;
    }

    public void setEvent_name_12(java.lang.String v)
    {
        this.event_name_12 = v;
    }

    public java.lang.String getIncome_dtl_11b_r23c4()
    {
        return income_dtl_11b_r23c4;
    }

    public void setIncome_dtl_11b_r23c4(java.lang.String v)
    {
        this.income_dtl_11b_r23c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_12()
    {
        return a_gross_gate_income_nmr_12;
    }

    public void setA_gross_gate_income_nmr_12(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_12 = v;
    }

    public java.lang.String getB_total_refunds_12()
    {
        return b_total_refunds_12;
    }

    public void setB_total_refunds_12(java.lang.String v)
    {
        this.b_total_refunds_12 = v;
    }

    public java.lang.Double getE22_f22()
    {
        return e22_f22;
    }

    public void setE22_f22(java.lang.Double v)
    {
        this.e22_f22 = v;
    }

    public java.lang.String getEvent_name_13()
    {
        return event_name_13;
    }

    public void setEvent_name_13(java.lang.String v)
    {
        this.event_name_13 = v;
    }

    public java.lang.String getIncome_dtl_11b_r24c4()
    {
        return income_dtl_11b_r24c4;
    }

    public void setIncome_dtl_11b_r24c4(java.lang.String v)
    {
        this.income_dtl_11b_r24c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_13()
    {
        return a_gross_gate_income_nmr_13;
    }

    public void setA_gross_gate_income_nmr_13(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_13 = v;
    }

    public java.lang.String getB_total_refunds_13()
    {
        return b_total_refunds_13;
    }

    public void setB_total_refunds_13(java.lang.String v)
    {
        this.b_total_refunds_13 = v;
    }

    public java.lang.Double getE23_f23()
    {
        return e23_f23;
    }

    public void setE23_f23(java.lang.Double v)
    {
        this.e23_f23 = v;
    }

    public java.lang.String getEvent_name_14()
    {
        return event_name_14;
    }

    public void setEvent_name_14(java.lang.String v)
    {
        this.event_name_14 = v;
    }

    public java.lang.String getIncome_dtl_11b_r25c4()
    {
        return income_dtl_11b_r25c4;
    }

    public void setIncome_dtl_11b_r25c4(java.lang.String v)
    {
        this.income_dtl_11b_r25c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_14()
    {
        return a_gross_gate_income_nmr_14;
    }

    public void setA_gross_gate_income_nmr_14(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_14 = v;
    }

    public java.lang.String getB_total_refunds_14()
    {
        return b_total_refunds_14;
    }

    public void setB_total_refunds_14(java.lang.String v)
    {
        this.b_total_refunds_14 = v;
    }

    public java.lang.Double getE24_f24()
    {
        return e24_f24;
    }

    public void setE24_f24(java.lang.Double v)
    {
        this.e24_f24 = v;
    }

    public java.lang.String getEvent_name_15()
    {
        return event_name_15;
    }

    public void setEvent_name_15(java.lang.String v)
    {
        this.event_name_15 = v;
    }

    public java.lang.String getIncome_dtl_11b_r26c4()
    {
        return income_dtl_11b_r26c4;
    }

    public void setIncome_dtl_11b_r26c4(java.lang.String v)
    {
        this.income_dtl_11b_r26c4 = v;
    }

    public java.lang.String getA_gross_gate_income_nmr_15()
    {
        return a_gross_gate_income_nmr_15;
    }

    public void setA_gross_gate_income_nmr_15(java.lang.String v)
    {
        this.a_gross_gate_income_nmr_15 = v;
    }

    public java.lang.String getB_total_refunds_15()
    {
        return b_total_refunds_15;
    }

    public void setB_total_refunds_15(java.lang.String v)
    {
        this.b_total_refunds_15 = v;
    }

    public java.lang.Double getE25_f25()
    {
        return e25_f25;
    }

    public void setE25_f25(java.lang.Double v)
    {
        this.e25_f25 = v;
    }

    public java.lang.Double getE26_f26_total_a()
    {
        return e26_f26_total_a;
    }

    public void setE26_f26_total_a(java.lang.Double v)
    {
        this.e26_f26_total_a = v;
    }

    public java.lang.String getPaypal_scars_income_event_name()
    {
        return paypal_scars_income_event_name;
    }

    public void setPaypal_scars_income_event_name(java.lang.String v)
    {
        this.paypal_scars_income_event_name = v;
    }

    public java.lang.String getPaypal_scars()
    {
        return paypal_scars;
    }

    public void setPaypal_scars(java.lang.String v)
    {
        this.paypal_scars = v;
    }

    public java.lang.String getGross()
    {
        return gross;
    }

    public void setGross(java.lang.String v)
    {
        this.gross = v;
    }

    public java.lang.String getTransaction_fees()
    {
        return transaction_fees;
    }

    public void setTransaction_fees(java.lang.String v)
    {
        this.transaction_fees = v;
    }

    public java.lang.Double getActual_amount_received()
    {
        return actual_amount_received;
    }

    public void setActual_amount_received(java.lang.Double v)
    {
        this.actual_amount_received = v;
    }

    public java.lang.String getPaypal_scars_income_event_name_2()
    {
        return paypal_scars_income_event_name_2;
    }

    public void setPaypal_scars_income_event_name_2(java.lang.String v)
    {
        this.paypal_scars_income_event_name_2 = v;
    }

    public java.lang.String getPaypal_scars_2()
    {
        return paypal_scars_2;
    }

    public void setPaypal_scars_2(java.lang.String v)
    {
        this.paypal_scars_2 = v;
    }

    public java.lang.String getGross_2()
    {
        return gross_2;
    }

    public void setGross_2(java.lang.String v)
    {
        this.gross_2 = v;
    }

    public java.lang.String getTransaction_fees_2()
    {
        return transaction_fees_2;
    }

    public void setTransaction_fees_2(java.lang.String v)
    {
        this.transaction_fees_2 = v;
    }

    public java.lang.Double getE29_f29()
    {
        return e29_f29;
    }

    public void setE29_f29(java.lang.Double v)
    {
        this.e29_f29 = v;
    }

    public java.lang.String getPaypal_scars_income_event_name_3()
    {
        return paypal_scars_income_event_name_3;
    }

    public void setPaypal_scars_income_event_name_3(java.lang.String v)
    {
        this.paypal_scars_income_event_name_3 = v;
    }

    public java.lang.String getPaypal_scars_3()
    {
        return paypal_scars_3;
    }

    public void setPaypal_scars_3(java.lang.String v)
    {
        this.paypal_scars_3 = v;
    }

    public java.lang.String getGross_3()
    {
        return gross_3;
    }

    public void setGross_3(java.lang.String v)
    {
        this.gross_3 = v;
    }

    public java.lang.String getTransaction_fees_3()
    {
        return transaction_fees_3;
    }

    public void setTransaction_fees_3(java.lang.String v)
    {
        this.transaction_fees_3 = v;
    }

    public java.lang.Double getE30_f30()
    {
        return e30_f30;
    }

    public void setE30_f30(java.lang.Double v)
    {
        this.e30_f30 = v;
    }

    public java.lang.String getPaypal_scars_income_event_name_4()
    {
        return paypal_scars_income_event_name_4;
    }

    public void setPaypal_scars_income_event_name_4(java.lang.String v)
    {
        this.paypal_scars_income_event_name_4 = v;
    }

    public java.lang.String getPaypal_scars_4()
    {
        return paypal_scars_4;
    }

    public void setPaypal_scars_4(java.lang.String v)
    {
        this.paypal_scars_4 = v;
    }

    public java.lang.String getGross_4()
    {
        return gross_4;
    }

    public void setGross_4(java.lang.String v)
    {
        this.gross_4 = v;
    }

    public java.lang.String getTransaction_fees_4()
    {
        return transaction_fees_4;
    }

    public void setTransaction_fees_4(java.lang.String v)
    {
        this.transaction_fees_4 = v;
    }

    public java.lang.Double getE31_f31()
    {
        return e31_f31;
    }

    public void setE31_f31(java.lang.Double v)
    {
        this.e31_f31 = v;
    }

    public java.lang.String getPaypal_scars_income_event_name_5()
    {
        return paypal_scars_income_event_name_5;
    }

    public void setPaypal_scars_income_event_name_5(java.lang.String v)
    {
        this.paypal_scars_income_event_name_5 = v;
    }

    public java.lang.String getPaypal_scars_5()
    {
        return paypal_scars_5;
    }

    public void setPaypal_scars_5(java.lang.String v)
    {
        this.paypal_scars_5 = v;
    }

    public java.lang.String getGross_5()
    {
        return gross_5;
    }

    public void setGross_5(java.lang.String v)
    {
        this.gross_5 = v;
    }

    public java.lang.String getTransaction_fees_5()
    {
        return transaction_fees_5;
    }

    public void setTransaction_fees_5(java.lang.String v)
    {
        this.transaction_fees_5 = v;
    }

    public java.lang.Double getE32_f32()
    {
        return e32_f32;
    }

    public void setE32_f32(java.lang.Double v)
    {
        this.e32_f32 = v;
    }

    public java.lang.String getPaypal_scars_income_event_name_6()
    {
        return paypal_scars_income_event_name_6;
    }

    public void setPaypal_scars_income_event_name_6(java.lang.String v)
    {
        this.paypal_scars_income_event_name_6 = v;
    }

    public java.lang.String getPaypal_scars_6()
    {
        return paypal_scars_6;
    }

    public void setPaypal_scars_6(java.lang.String v)
    {
        this.paypal_scars_6 = v;
    }

    public java.lang.String getGross_6()
    {
        return gross_6;
    }

    public void setGross_6(java.lang.String v)
    {
        this.gross_6 = v;
    }

    public java.lang.String getTransaction_fees_6()
    {
        return transaction_fees_6;
    }

    public void setTransaction_fees_6(java.lang.String v)
    {
        this.transaction_fees_6 = v;
    }

    public java.lang.Double getE33_f33()
    {
        return e33_f33;
    }

    public void setE33_f33(java.lang.Double v)
    {
        this.e33_f33 = v;
    }

    public java.lang.String getPaypal_scars_income_event_name_7()
    {
        return paypal_scars_income_event_name_7;
    }

    public void setPaypal_scars_income_event_name_7(java.lang.String v)
    {
        this.paypal_scars_income_event_name_7 = v;
    }

    public java.lang.String getPaypal_scars_7()
    {
        return paypal_scars_7;
    }

    public void setPaypal_scars_7(java.lang.String v)
    {
        this.paypal_scars_7 = v;
    }

    public java.lang.String getGross_7()
    {
        return gross_7;
    }

    public void setGross_7(java.lang.String v)
    {
        this.gross_7 = v;
    }

    public java.lang.String getTransaction_fees_7()
    {
        return transaction_fees_7;
    }

    public void setTransaction_fees_7(java.lang.String v)
    {
        this.transaction_fees_7 = v;
    }

    public java.lang.Double getE34_f34()
    {
        return e34_f34;
    }

    public void setE34_f34(java.lang.Double v)
    {
        this.e34_f34 = v;
    }

    public java.lang.Double getE35_f35_total_b()
    {
        return e35_f35_total_b;
    }

    public void setE35_f35_total_b(java.lang.Double v)
    {
        this.e35_f35_total_b = v;
    }

    public java.lang.Double getSum_g29_g35_show_total_a_b_on_pg_4_line_3b()
    {
        return sum_g29_g35_show_total_a_b_on_pg_4_line_3b;
    }

    public void setSum_g29_g35_show_total_a_b_on_pg_4_line_3b(java.lang.Double v)
    {
        this.sum_g29_g35_show_total_a_b_on_pg_4_line_3b = v;
    }

    public java.lang.String get_7_net_advertising_income_publication_issue_event()
    {
        return _7_net_advertising_income_publication_issue_event;
    }

    public void set_7_net_advertising_income_publication_issue_event(java.lang.String v)
    {
        this._7_net_advertising_income_publication_issue_event = v;
    }

    public java.lang.String getPaypal_scars_8()
    {
        return paypal_scars_8;
    }

    public void setPaypal_scars_8(java.lang.String v)
    {
        this.paypal_scars_8 = v;
    }

    public java.lang.String getA_gross_income()
    {
        return a_gross_income;
    }

    public void setA_gross_income(java.lang.String v)
    {
        this.a_gross_income = v;
    }

    public java.lang.String getB_advertising_cost()
    {
        return b_advertising_cost;
    }

    public void setB_advertising_cost(java.lang.String v)
    {
        this.b_advertising_cost = v;
    }

    public java.lang.Double getA_b_net_income()
    {
        return a_b_net_income;
    }

    public void setA_b_net_income(java.lang.Double v)
    {
        this.a_b_net_income = v;
    }

    public java.lang.String get_7_net_advertising_income_publication_issue_event_2()
    {
        return _7_net_advertising_income_publication_issue_event_2;
    }

    public void set_7_net_advertising_income_publication_issue_event_2(java.lang.String v)
    {
        this._7_net_advertising_income_publication_issue_event_2 = v;
    }

    public java.lang.String getPaypal_scars_9()
    {
        return paypal_scars_9;
    }

    public void setPaypal_scars_9(java.lang.String v)
    {
        this.paypal_scars_9 = v;
    }

    public java.lang.String getA_gross_income_2()
    {
        return a_gross_income_2;
    }

    public void setA_gross_income_2(java.lang.String v)
    {
        this.a_gross_income_2 = v;
    }

    public java.lang.String getB_advertising_cost_2()
    {
        return b_advertising_cost_2;
    }

    public void setB_advertising_cost_2(java.lang.String v)
    {
        this.b_advertising_cost_2 = v;
    }

    public java.lang.Double getE40_f40()
    {
        return e40_f40;
    }

    public void setE40_f40(java.lang.Double v)
    {
        this.e40_f40 = v;
    }

    public java.lang.String get_7_net_advertising_income_publication_issue_event_3()
    {
        return _7_net_advertising_income_publication_issue_event_3;
    }

    public void set_7_net_advertising_income_publication_issue_event_3(java.lang.String v)
    {
        this._7_net_advertising_income_publication_issue_event_3 = v;
    }

    public java.lang.String getPaypal_scars_10()
    {
        return paypal_scars_10;
    }

    public void setPaypal_scars_10(java.lang.String v)
    {
        this.paypal_scars_10 = v;
    }

    public java.lang.String getA_gross_income_3()
    {
        return a_gross_income_3;
    }

    public void setA_gross_income_3(java.lang.String v)
    {
        this.a_gross_income_3 = v;
    }

    public java.lang.String getB_advertising_cost_3()
    {
        return b_advertising_cost_3;
    }

    public void setB_advertising_cost_3(java.lang.String v)
    {
        this.b_advertising_cost_3 = v;
    }

    public java.lang.Double getE41_f41()
    {
        return e41_f41;
    }

    public void setE41_f41(java.lang.Double v)
    {
        this.e41_f41 = v;
    }

    public java.lang.Double getA_gross_income_show_totals_on_pg_4_line_9()
    {
        return a_gross_income_show_totals_on_pg_4_line_9;
    }

    public void setA_gross_income_show_totals_on_pg_4_line_9(java.lang.Double v)
    {
        this.a_gross_income_show_totals_on_pg_4_line_9 = v;
    }

    public java.lang.Double getB_advertising_cost_sum_e40_e42()
    {
        return b_advertising_cost_sum_e40_e42;
    }

    public void setB_advertising_cost_sum_e40_e42(java.lang.Double v)
    {
        this.b_advertising_cost_sum_e40_e42 = v;
    }

    public java.lang.Double getE42_f42_sum_f40_f42()
    {
        return e42_f42_sum_f40_f42;
    }

    public void setE42_f42_sum_f40_f42(java.lang.Double v)
    {
        this.e42_f42_sum_f40_f42 = v;
    }

    public java.lang.String getShow_totals_on_pg_4_line_9()
    {
        return show_totals_on_pg_4_line_9;
    }

    public void setShow_totals_on_pg_4_line_9(java.lang.String v)
    {
        this.show_totals_on_pg_4_line_9 = v;
    }

    public java.lang.String getPaypal_scars_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks()
    {
        return paypal_scars_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks;
    }

    public void setPaypal_scars_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks(java.lang.String v)
    {
        this.paypal_scars_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks = v;
    }

    public java.lang.String getSum_e40_e42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks()
    {
        return sum_e40_e42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks;
    }

    public void setSum_e40_e42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks(java.lang.String v)
    {
        this.sum_e40_e42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks = v;
    }

    public java.lang.String getSum_f40_f42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks()
    {
        return sum_f40_f42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks;
    }

    public void setSum_f40_f42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks(java.lang.String v)
    {
        this.sum_f40_f42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks = v;
    }

    public java.lang.String getSum_g40_g42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks()
    {
        return sum_g40_g42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks;
    }

    public void setSum_g40_g42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks(java.lang.String v)
    {
        this.sum_g40_g42_contact_your_kingdom_exchequer_before_using_this_section_for_anything_other_than_stale_checks = v;
    }

    public java.lang.String get_10_other_income_description()
    {
        return _10_other_income_description;
    }

    public void set_10_other_income_description(java.lang.String v)
    {
        this._10_other_income_description = v;
    }

    public java.lang.String getPaypal_scars_11()
    {
        return paypal_scars_11;
    }

    public void setPaypal_scars_11(java.lang.String v)
    {
        this.paypal_scars_11 = v;
    }

    public java.lang.String getSum_e40_e42()
    {
        return sum_e40_e42;
    }

    public void setSum_e40_e42(java.lang.String v)
    {
        this.sum_e40_e42 = v;
    }

    public java.lang.String getSum_f40_f42()
    {
        return sum_f40_f42;
    }

    public void setSum_f40_f42(java.lang.String v)
    {
        this.sum_f40_f42 = v;
    }

    public java.lang.String getAmount()
    {
        return amount;
    }

    public void setAmount(java.lang.String v)
    {
        this.amount = v;
    }

    public java.lang.String get_10_other_income_description_2()
    {
        return _10_other_income_description_2;
    }

    public void set_10_other_income_description_2(java.lang.String v)
    {
        this._10_other_income_description_2 = v;
    }

    public java.lang.String getPaypal_scars_12()
    {
        return paypal_scars_12;
    }

    public void setPaypal_scars_12(java.lang.String v)
    {
        this.paypal_scars_12 = v;
    }

    public java.lang.String getSum_e40_e42_2()
    {
        return sum_e40_e42_2;
    }

    public void setSum_e40_e42_2(java.lang.String v)
    {
        this.sum_e40_e42_2 = v;
    }

    public java.lang.String getSum_f40_f42_2()
    {
        return sum_f40_f42_2;
    }

    public void setSum_f40_f42_2(java.lang.String v)
    {
        this.sum_f40_f42_2 = v;
    }

    public java.lang.String getAmount_2()
    {
        return amount_2;
    }

    public void setAmount_2(java.lang.String v)
    {
        this.amount_2 = v;
    }

    public java.lang.String get_10_other_income_description_3()
    {
        return _10_other_income_description_3;
    }

    public void set_10_other_income_description_3(java.lang.String v)
    {
        this._10_other_income_description_3 = v;
    }

    public java.lang.String getPaypal_scars_13()
    {
        return paypal_scars_13;
    }

    public void setPaypal_scars_13(java.lang.String v)
    {
        this.paypal_scars_13 = v;
    }

    public java.lang.String getSum_e40_e42_3()
    {
        return sum_e40_e42_3;
    }

    public void setSum_e40_e42_3(java.lang.String v)
    {
        this.sum_e40_e42_3 = v;
    }

    public java.lang.String getSum_f40_f42_3()
    {
        return sum_f40_f42_3;
    }

    public void setSum_f40_f42_3(java.lang.String v)
    {
        this.sum_f40_f42_3 = v;
    }

    public java.lang.String getAmount_3()
    {
        return amount_3;
    }

    public void setAmount_3(java.lang.String v)
    {
        this.amount_3 = v;
    }

    public java.lang.String get_10_other_income_description_4()
    {
        return _10_other_income_description_4;
    }

    public void set_10_other_income_description_4(java.lang.String v)
    {
        this._10_other_income_description_4 = v;
    }

    public java.lang.String getPaypal_scars_14()
    {
        return paypal_scars_14;
    }

    public void setPaypal_scars_14(java.lang.String v)
    {
        this.paypal_scars_14 = v;
    }

    public java.lang.String getSum_e40_e42_4()
    {
        return sum_e40_e42_4;
    }

    public void setSum_e40_e42_4(java.lang.String v)
    {
        this.sum_e40_e42_4 = v;
    }

    public java.lang.String getSum_f40_f42_4()
    {
        return sum_f40_f42_4;
    }

    public void setSum_f40_f42_4(java.lang.String v)
    {
        this.sum_f40_f42_4 = v;
    }

    public java.lang.String getAmount_4()
    {
        return amount_4;
    }

    public void setAmount_4(java.lang.String v)
    {
        this.amount_4 = v;
    }

    public java.lang.String get_10_other_income_description_5()
    {
        return _10_other_income_description_5;
    }

    public void set_10_other_income_description_5(java.lang.String v)
    {
        this._10_other_income_description_5 = v;
    }

    public java.lang.String getPaypal_scars_15()
    {
        return paypal_scars_15;
    }

    public void setPaypal_scars_15(java.lang.String v)
    {
        this.paypal_scars_15 = v;
    }

    public java.lang.String getSum_e40_e42_5()
    {
        return sum_e40_e42_5;
    }

    public void setSum_e40_e42_5(java.lang.String v)
    {
        this.sum_e40_e42_5 = v;
    }

    public java.lang.String getSum_f40_f42_5()
    {
        return sum_f40_f42_5;
    }

    public void setSum_f40_f42_5(java.lang.String v)
    {
        this.sum_f40_f42_5 = v;
    }

    public java.lang.String getAmount_5()
    {
        return amount_5;
    }

    public void setAmount_5(java.lang.String v)
    {
        this.amount_5 = v;
    }

    public java.lang.String get_10_other_income_description_6()
    {
        return _10_other_income_description_6;
    }

    public void set_10_other_income_description_6(java.lang.String v)
    {
        this._10_other_income_description_6 = v;
    }

    public java.lang.String getPaypal_scars_16()
    {
        return paypal_scars_16;
    }

    public void setPaypal_scars_16(java.lang.String v)
    {
        this.paypal_scars_16 = v;
    }

    public java.lang.String getSum_e40_e42_6()
    {
        return sum_e40_e42_6;
    }

    public void setSum_e40_e42_6(java.lang.String v)
    {
        this.sum_e40_e42_6 = v;
    }

    public java.lang.String getSum_f40_f42_6()
    {
        return sum_f40_f42_6;
    }

    public void setSum_f40_f42_6(java.lang.String v)
    {
        this.sum_f40_f42_6 = v;
    }

    public java.lang.String getAmount_6()
    {
        return amount_6;
    }

    public void setAmount_6(java.lang.String v)
    {
        this.amount_6 = v;
    }

    public java.lang.String get_10_other_income_description_7()
    {
        return _10_other_income_description_7;
    }

    public void set_10_other_income_description_7(java.lang.String v)
    {
        this._10_other_income_description_7 = v;
    }

    public java.lang.String getPaypal_scars_17()
    {
        return paypal_scars_17;
    }

    public void setPaypal_scars_17(java.lang.String v)
    {
        this.paypal_scars_17 = v;
    }

    public java.lang.String getSum_e40_e42_7()
    {
        return sum_e40_e42_7;
    }

    public void setSum_e40_e42_7(java.lang.String v)
    {
        this.sum_e40_e42_7 = v;
    }

    public java.lang.String getSum_f40_f42_7()
    {
        return sum_f40_f42_7;
    }

    public void setSum_f40_f42_7(java.lang.String v)
    {
        this.sum_f40_f42_7 = v;
    }

    public java.lang.String getAmount_7()
    {
        return amount_7;
    }

    public void setAmount_7(java.lang.String v)
    {
        this.amount_7 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_10()
    {
        return amount_show_total_on_pg_4_line_10;
    }

    public void setAmount_show_total_on_pg_4_line_10(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_10 = v;
    }

    public INCOME_DTL_11bBean()
    {
    }

}
