package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet EXPENSE_DTL_12b */
public class EXPENSE_DTL_12bBean
{

    private java.lang.Double expense_dtl_12b_r2c3;
    private java.lang.Double expense_dtl_12b_r3c2;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String organization_or_person_ar;
    private java.lang.String ar;
    private java.lang.String ar_2;
    private java.lang.String check_ar;
    private java.lang.String check_date_ar;
    private java.lang.String amount_ar;
    private java.lang.String organization_or_person_ar_2;
    private java.lang.String ar_3;
    private java.lang.String ar_4;
    private java.lang.String check_ar_2;
    private java.lang.String check_date_ar_2;
    private java.lang.String amount_ar_2;
    private java.lang.String organization_or_person_ar_3;
    private java.lang.String ar_5;
    private java.lang.String ar_6;
    private java.lang.String check_ar_3;
    private java.lang.String check_date_ar_3;
    private java.lang.String amount_ar_3;
    private java.lang.String organization_or_person_ar_4;
    private java.lang.String ar_7;
    private java.lang.String ar_8;
    private java.lang.String check_ar_4;
    private java.lang.String check_date_ar_4;
    private java.lang.String amount_ar_4;
    private java.lang.Double amount_show_total_on_pg_4_line_20;
    private java.lang.String ar_9;
    private java.lang.String organization_or_person_contact_your_kingdom_exchequer_before_using_this_section;
    private java.lang.String contact_your_kingdom_exchequer_before_using_this_section;
    private java.lang.String contact_your_kingdom_exchequer_before_using_this_section_2;
    private java.lang.String check_contact_your_kingdom_exchequer_before_using_this_section;
    private java.lang.String show_total_on_pg_4_line_20_contact_your_kingdom_exchequer_before_using_this_section;
    private java.lang.String sum_i12_i15_contact_your_kingdom_exchequer_before_using_this_section;
    private java.lang.String reason;
    private java.lang.String organization_or_person;
    private java.lang.String expense_dtl_12b_r21c5;
    private java.lang.String expense_dtl_12b_r21c6;
    private java.lang.String check;
    private java.lang.String paid_to;
    private java.lang.String amount;
    private java.lang.String reason_2;
    private java.lang.String organization_or_person_2;
    private java.lang.String expense_dtl_12b_r22c5;
    private java.lang.String expense_dtl_12b_r22c6;
    private java.lang.String check_2;
    private java.lang.String paid_to_2;
    private java.lang.String amount_2;
    private java.lang.String reason_3;
    private java.lang.String organization_or_person_3;
    private java.lang.String expense_dtl_12b_r23c5;
    private java.lang.String expense_dtl_12b_r23c6;
    private java.lang.String check_3;
    private java.lang.String paid_to_3;
    private java.lang.String amount_3;
    private java.lang.String reason_4;
    private java.lang.String organization_or_person_4;
    private java.lang.String expense_dtl_12b_r24c5;
    private java.lang.String expense_dtl_12b_r24c6;
    private java.lang.String check_4;
    private java.lang.String paid_to_4;
    private java.lang.String amount_4;
    private java.lang.String reason_5;
    private java.lang.String organization_or_person_5;
    private java.lang.String expense_dtl_12b_r25c5;
    private java.lang.String expense_dtl_12b_r25c6;
    private java.lang.String check_5;
    private java.lang.String paid_to_5;
    private java.lang.String amount_5;
    private java.lang.String reason_6;
    private java.lang.String organization_or_person_6;
    private java.lang.String expense_dtl_12b_r26c5;
    private java.lang.String expense_dtl_12b_r26c6;
    private java.lang.String check_6;
    private java.lang.String paid_to_6;
    private java.lang.String amount_6;
    private java.lang.Double amount_show_total_on_pg_4_line_28;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name;
    private java.lang.String organization_or_person_7;
    private java.lang.String reason_7;
    private java.lang.String check_7;
    private java.lang.String check_date;
    private java.lang.String fed_id_number;
    private java.lang.String amount_7;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_2;
    private java.lang.String organization_or_person_8;
    private java.lang.String reason_8;
    private java.lang.String check_8;
    private java.lang.String check_date_2;
    private java.lang.String fed_id_number_2;
    private java.lang.String amount_8;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_3;
    private java.lang.String organization_or_person_9;
    private java.lang.String reason_9;
    private java.lang.String check_9;
    private java.lang.String check_date_3;
    private java.lang.String fed_id_number_3;
    private java.lang.String amount_9;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_4;
    private java.lang.String organization_or_person_10;
    private java.lang.String reason_10;
    private java.lang.String check_10;
    private java.lang.String check_date_4;
    private java.lang.String fed_id_number_4;
    private java.lang.String amount_10;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_5;
    private java.lang.String organization_or_person_11;
    private java.lang.String reason_11;
    private java.lang.String check_11;
    private java.lang.String check_date_5;
    private java.lang.String fed_id_number_5;
    private java.lang.String amount_11;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_6;
    private java.lang.String organization_or_person_12;
    private java.lang.String reason_12;
    private java.lang.String check_12;
    private java.lang.String check_date_6;
    private java.lang.String fed_id_number_6;
    private java.lang.String amount_12;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_7;
    private java.lang.String organization_or_person_13;
    private java.lang.String reason_13;
    private java.lang.String check_13;
    private java.lang.String check_date_7;
    private java.lang.String fed_id_number_7;
    private java.lang.String amount_13;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_8;
    private java.lang.String organization_or_person_14;
    private java.lang.String reason_14;
    private java.lang.String check_14;
    private java.lang.String check_date_8;
    private java.lang.String fed_id_number_8;
    private java.lang.String amount_14;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_9;
    private java.lang.String organization_or_person_15;
    private java.lang.String reason_15;
    private java.lang.String check_15;
    private java.lang.String check_date_9;
    private java.lang.String fed_id_number_9;
    private java.lang.String amount_15;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_10;
    private java.lang.String organization_or_person_16;
    private java.lang.String reason_16;
    private java.lang.String check_16;
    private java.lang.String check_date_10;
    private java.lang.String fed_id_number_10;
    private java.lang.String amount_16;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_11;
    private java.lang.String organization_or_person_17;
    private java.lang.String reason_17;
    private java.lang.String check_17;
    private java.lang.String check_date_11;
    private java.lang.String fed_id_number_11;
    private java.lang.String amount_17;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_12;
    private java.lang.String organization_or_person_18;
    private java.lang.String reason_18;
    private java.lang.String check_18;
    private java.lang.String check_date_12;
    private java.lang.String fed_id_number_12;
    private java.lang.String amount_18;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_13;
    private java.lang.String organization_or_person_19;
    private java.lang.String reason_19;
    private java.lang.String check_19;
    private java.lang.String check_date_13;
    private java.lang.String fed_id_number_13;
    private java.lang.String amount_19;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_14;
    private java.lang.String organization_or_person_20;
    private java.lang.String reason_20;
    private java.lang.String check_20;
    private java.lang.String check_date_14;
    private java.lang.String fed_id_number_14;
    private java.lang.String amount_20;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_15;
    private java.lang.String organization_or_person_21;
    private java.lang.String reason_21;
    private java.lang.String check_21;
    private java.lang.String check_date_15;
    private java.lang.String fed_id_number_15;
    private java.lang.String amount_21;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_16;
    private java.lang.String organization_or_person_22;
    private java.lang.String reason_22;
    private java.lang.String check_22;
    private java.lang.String check_date_16;
    private java.lang.String fed_id_number_16;
    private java.lang.String amount_22;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_17;
    private java.lang.String organization_or_person_23;
    private java.lang.String reason_23;
    private java.lang.String check_23;
    private java.lang.String check_date_17;
    private java.lang.String fed_id_number_17;
    private java.lang.String amount_23;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_18;
    private java.lang.String organization_or_person_24;
    private java.lang.String reason_24;
    private java.lang.String check_24;
    private java.lang.String check_date_18;
    private java.lang.String fed_id_number_18;
    private java.lang.String amount_24;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_19;
    private java.lang.String organization_or_person_25;
    private java.lang.String reason_25;
    private java.lang.String check_25;
    private java.lang.String check_date_19;
    private java.lang.String fed_id_number_19;
    private java.lang.String amount_25;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_20;
    private java.lang.String organization_or_person_26;
    private java.lang.String reason_26;
    private java.lang.String check_26;
    private java.lang.String check_date_20;
    private java.lang.String fed_id_number_20;
    private java.lang.String amount_26;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_21;
    private java.lang.String organization_or_person_27;
    private java.lang.String reason_27;
    private java.lang.String check_27;
    private java.lang.String check_date_21;
    private java.lang.String fed_id_number_21;
    private java.lang.String amount_27;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_22;
    private java.lang.String organization_or_person_28;
    private java.lang.String reason_28;
    private java.lang.String check_28;
    private java.lang.String check_date_22;
    private java.lang.String fed_id_number_22;
    private java.lang.String amount_28;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_23;
    private java.lang.String organization_or_person_29;
    private java.lang.String reason_29;
    private java.lang.String check_29;
    private java.lang.String check_date_23;
    private java.lang.String fed_id_number_23;
    private java.lang.String amount_29;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_24;
    private java.lang.String organization_or_person_30;
    private java.lang.String reason_30;
    private java.lang.String check_30;
    private java.lang.String check_date_24;
    private java.lang.String fed_id_number_24;
    private java.lang.String amount_30;
    private java.lang.String _501_c_3_nonprofit_organizations_organization_name_25;
    private java.lang.String organization_or_person_31;
    private java.lang.String reason_31;
    private java.lang.String check_31;
    private java.lang.String check_date_25;
    private java.lang.String fed_id_number_25;
    private java.lang.String amount_31;
    private java.lang.Double amount_show_total_on_pg_4_line_29;

    public java.lang.Double getExpense_dtl_12b_r2c3()
    {
        return expense_dtl_12b_r2c3;
    }

    public void setExpense_dtl_12b_r2c3(java.lang.Double v)
    {
        this.expense_dtl_12b_r2c3 = v;
    }

    public java.lang.Double getExpense_dtl_12b_r3c2()
    {
        return expense_dtl_12b_r3c2;
    }

    public void setExpense_dtl_12b_r3c2(java.lang.Double v)
    {
        this.expense_dtl_12b_r3c2 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getOrganization_or_person_ar()
    {
        return organization_or_person_ar;
    }

    public void setOrganization_or_person_ar(java.lang.String v)
    {
        this.organization_or_person_ar = v;
    }

    public java.lang.String getAr()
    {
        return ar;
    }

    public void setAr(java.lang.String v)
    {
        this.ar = v;
    }

    public java.lang.String getAr_2()
    {
        return ar_2;
    }

    public void setAr_2(java.lang.String v)
    {
        this.ar_2 = v;
    }

    public java.lang.String getCheck_ar()
    {
        return check_ar;
    }

    public void setCheck_ar(java.lang.String v)
    {
        this.check_ar = v;
    }

    public java.lang.String getCheck_date_ar()
    {
        return check_date_ar;
    }

    public void setCheck_date_ar(java.lang.String v)
    {
        this.check_date_ar = v;
    }

    public java.lang.String getAmount_ar()
    {
        return amount_ar;
    }

    public void setAmount_ar(java.lang.String v)
    {
        this.amount_ar = v;
    }

    public java.lang.String getOrganization_or_person_ar_2()
    {
        return organization_or_person_ar_2;
    }

    public void setOrganization_or_person_ar_2(java.lang.String v)
    {
        this.organization_or_person_ar_2 = v;
    }

    public java.lang.String getAr_3()
    {
        return ar_3;
    }

    public void setAr_3(java.lang.String v)
    {
        this.ar_3 = v;
    }

    public java.lang.String getAr_4()
    {
        return ar_4;
    }

    public void setAr_4(java.lang.String v)
    {
        this.ar_4 = v;
    }

    public java.lang.String getCheck_ar_2()
    {
        return check_ar_2;
    }

    public void setCheck_ar_2(java.lang.String v)
    {
        this.check_ar_2 = v;
    }

    public java.lang.String getCheck_date_ar_2()
    {
        return check_date_ar_2;
    }

    public void setCheck_date_ar_2(java.lang.String v)
    {
        this.check_date_ar_2 = v;
    }

    public java.lang.String getAmount_ar_2()
    {
        return amount_ar_2;
    }

    public void setAmount_ar_2(java.lang.String v)
    {
        this.amount_ar_2 = v;
    }

    public java.lang.String getOrganization_or_person_ar_3()
    {
        return organization_or_person_ar_3;
    }

    public void setOrganization_or_person_ar_3(java.lang.String v)
    {
        this.organization_or_person_ar_3 = v;
    }

    public java.lang.String getAr_5()
    {
        return ar_5;
    }

    public void setAr_5(java.lang.String v)
    {
        this.ar_5 = v;
    }

    public java.lang.String getAr_6()
    {
        return ar_6;
    }

    public void setAr_6(java.lang.String v)
    {
        this.ar_6 = v;
    }

    public java.lang.String getCheck_ar_3()
    {
        return check_ar_3;
    }

    public void setCheck_ar_3(java.lang.String v)
    {
        this.check_ar_3 = v;
    }

    public java.lang.String getCheck_date_ar_3()
    {
        return check_date_ar_3;
    }

    public void setCheck_date_ar_3(java.lang.String v)
    {
        this.check_date_ar_3 = v;
    }

    public java.lang.String getAmount_ar_3()
    {
        return amount_ar_3;
    }

    public void setAmount_ar_3(java.lang.String v)
    {
        this.amount_ar_3 = v;
    }

    public java.lang.String getOrganization_or_person_ar_4()
    {
        return organization_or_person_ar_4;
    }

    public void setOrganization_or_person_ar_4(java.lang.String v)
    {
        this.organization_or_person_ar_4 = v;
    }

    public java.lang.String getAr_7()
    {
        return ar_7;
    }

    public void setAr_7(java.lang.String v)
    {
        this.ar_7 = v;
    }

    public java.lang.String getAr_8()
    {
        return ar_8;
    }

    public void setAr_8(java.lang.String v)
    {
        this.ar_8 = v;
    }

    public java.lang.String getCheck_ar_4()
    {
        return check_ar_4;
    }

    public void setCheck_ar_4(java.lang.String v)
    {
        this.check_ar_4 = v;
    }

    public java.lang.String getCheck_date_ar_4()
    {
        return check_date_ar_4;
    }

    public void setCheck_date_ar_4(java.lang.String v)
    {
        this.check_date_ar_4 = v;
    }

    public java.lang.String getAmount_ar_4()
    {
        return amount_ar_4;
    }

    public void setAmount_ar_4(java.lang.String v)
    {
        this.amount_ar_4 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_20()
    {
        return amount_show_total_on_pg_4_line_20;
    }

    public void setAmount_show_total_on_pg_4_line_20(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_20 = v;
    }

    public java.lang.String getAr_9()
    {
        return ar_9;
    }

    public void setAr_9(java.lang.String v)
    {
        this.ar_9 = v;
    }

    public java.lang.String getOrganization_or_person_contact_your_kingdom_exchequer_before_using_this_section()
    {
        return organization_or_person_contact_your_kingdom_exchequer_before_using_this_section;
    }

    public void setOrganization_or_person_contact_your_kingdom_exchequer_before_using_this_section(java.lang.String v)
    {
        this.organization_or_person_contact_your_kingdom_exchequer_before_using_this_section = v;
    }

    public java.lang.String getContact_your_kingdom_exchequer_before_using_this_section()
    {
        return contact_your_kingdom_exchequer_before_using_this_section;
    }

    public void setContact_your_kingdom_exchequer_before_using_this_section(java.lang.String v)
    {
        this.contact_your_kingdom_exchequer_before_using_this_section = v;
    }

    public java.lang.String getContact_your_kingdom_exchequer_before_using_this_section_2()
    {
        return contact_your_kingdom_exchequer_before_using_this_section_2;
    }

    public void setContact_your_kingdom_exchequer_before_using_this_section_2(java.lang.String v)
    {
        this.contact_your_kingdom_exchequer_before_using_this_section_2 = v;
    }

    public java.lang.String getCheck_contact_your_kingdom_exchequer_before_using_this_section()
    {
        return check_contact_your_kingdom_exchequer_before_using_this_section;
    }

    public void setCheck_contact_your_kingdom_exchequer_before_using_this_section(java.lang.String v)
    {
        this.check_contact_your_kingdom_exchequer_before_using_this_section = v;
    }

    public java.lang.String getShow_total_on_pg_4_line_20_contact_your_kingdom_exchequer_before_using_this_section()
    {
        return show_total_on_pg_4_line_20_contact_your_kingdom_exchequer_before_using_this_section;
    }

    public void setShow_total_on_pg_4_line_20_contact_your_kingdom_exchequer_before_using_this_section(java.lang.String v)
    {
        this.show_total_on_pg_4_line_20_contact_your_kingdom_exchequer_before_using_this_section = v;
    }

    public java.lang.String getSum_i12_i15_contact_your_kingdom_exchequer_before_using_this_section()
    {
        return sum_i12_i15_contact_your_kingdom_exchequer_before_using_this_section;
    }

    public void setSum_i12_i15_contact_your_kingdom_exchequer_before_using_this_section(java.lang.String v)
    {
        this.sum_i12_i15_contact_your_kingdom_exchequer_before_using_this_section = v;
    }

    public java.lang.String getReason()
    {
        return reason;
    }

    public void setReason(java.lang.String v)
    {
        this.reason = v;
    }

    public java.lang.String getOrganization_or_person()
    {
        return organization_or_person;
    }

    public void setOrganization_or_person(java.lang.String v)
    {
        this.organization_or_person = v;
    }

    public java.lang.String getExpense_dtl_12b_r21c5()
    {
        return expense_dtl_12b_r21c5;
    }

    public void setExpense_dtl_12b_r21c5(java.lang.String v)
    {
        this.expense_dtl_12b_r21c5 = v;
    }

    public java.lang.String getExpense_dtl_12b_r21c6()
    {
        return expense_dtl_12b_r21c6;
    }

    public void setExpense_dtl_12b_r21c6(java.lang.String v)
    {
        this.expense_dtl_12b_r21c6 = v;
    }

    public java.lang.String getCheck()
    {
        return check;
    }

    public void setCheck(java.lang.String v)
    {
        this.check = v;
    }

    public java.lang.String getPaid_to()
    {
        return paid_to;
    }

    public void setPaid_to(java.lang.String v)
    {
        this.paid_to = v;
    }

    public java.lang.String getAmount()
    {
        return amount;
    }

    public void setAmount(java.lang.String v)
    {
        this.amount = v;
    }

    public java.lang.String getReason_2()
    {
        return reason_2;
    }

    public void setReason_2(java.lang.String v)
    {
        this.reason_2 = v;
    }

    public java.lang.String getOrganization_or_person_2()
    {
        return organization_or_person_2;
    }

    public void setOrganization_or_person_2(java.lang.String v)
    {
        this.organization_or_person_2 = v;
    }

    public java.lang.String getExpense_dtl_12b_r22c5()
    {
        return expense_dtl_12b_r22c5;
    }

    public void setExpense_dtl_12b_r22c5(java.lang.String v)
    {
        this.expense_dtl_12b_r22c5 = v;
    }

    public java.lang.String getExpense_dtl_12b_r22c6()
    {
        return expense_dtl_12b_r22c6;
    }

    public void setExpense_dtl_12b_r22c6(java.lang.String v)
    {
        this.expense_dtl_12b_r22c6 = v;
    }

    public java.lang.String getCheck_2()
    {
        return check_2;
    }

    public void setCheck_2(java.lang.String v)
    {
        this.check_2 = v;
    }

    public java.lang.String getPaid_to_2()
    {
        return paid_to_2;
    }

    public void setPaid_to_2(java.lang.String v)
    {
        this.paid_to_2 = v;
    }

    public java.lang.String getAmount_2()
    {
        return amount_2;
    }

    public void setAmount_2(java.lang.String v)
    {
        this.amount_2 = v;
    }

    public java.lang.String getReason_3()
    {
        return reason_3;
    }

    public void setReason_3(java.lang.String v)
    {
        this.reason_3 = v;
    }

    public java.lang.String getOrganization_or_person_3()
    {
        return organization_or_person_3;
    }

    public void setOrganization_or_person_3(java.lang.String v)
    {
        this.organization_or_person_3 = v;
    }

    public java.lang.String getExpense_dtl_12b_r23c5()
    {
        return expense_dtl_12b_r23c5;
    }

    public void setExpense_dtl_12b_r23c5(java.lang.String v)
    {
        this.expense_dtl_12b_r23c5 = v;
    }

    public java.lang.String getExpense_dtl_12b_r23c6()
    {
        return expense_dtl_12b_r23c6;
    }

    public void setExpense_dtl_12b_r23c6(java.lang.String v)
    {
        this.expense_dtl_12b_r23c6 = v;
    }

    public java.lang.String getCheck_3()
    {
        return check_3;
    }

    public void setCheck_3(java.lang.String v)
    {
        this.check_3 = v;
    }

    public java.lang.String getPaid_to_3()
    {
        return paid_to_3;
    }

    public void setPaid_to_3(java.lang.String v)
    {
        this.paid_to_3 = v;
    }

    public java.lang.String getAmount_3()
    {
        return amount_3;
    }

    public void setAmount_3(java.lang.String v)
    {
        this.amount_3 = v;
    }

    public java.lang.String getReason_4()
    {
        return reason_4;
    }

    public void setReason_4(java.lang.String v)
    {
        this.reason_4 = v;
    }

    public java.lang.String getOrganization_or_person_4()
    {
        return organization_or_person_4;
    }

    public void setOrganization_or_person_4(java.lang.String v)
    {
        this.organization_or_person_4 = v;
    }

    public java.lang.String getExpense_dtl_12b_r24c5()
    {
        return expense_dtl_12b_r24c5;
    }

    public void setExpense_dtl_12b_r24c5(java.lang.String v)
    {
        this.expense_dtl_12b_r24c5 = v;
    }

    public java.lang.String getExpense_dtl_12b_r24c6()
    {
        return expense_dtl_12b_r24c6;
    }

    public void setExpense_dtl_12b_r24c6(java.lang.String v)
    {
        this.expense_dtl_12b_r24c6 = v;
    }

    public java.lang.String getCheck_4()
    {
        return check_4;
    }

    public void setCheck_4(java.lang.String v)
    {
        this.check_4 = v;
    }

    public java.lang.String getPaid_to_4()
    {
        return paid_to_4;
    }

    public void setPaid_to_4(java.lang.String v)
    {
        this.paid_to_4 = v;
    }

    public java.lang.String getAmount_4()
    {
        return amount_4;
    }

    public void setAmount_4(java.lang.String v)
    {
        this.amount_4 = v;
    }

    public java.lang.String getReason_5()
    {
        return reason_5;
    }

    public void setReason_5(java.lang.String v)
    {
        this.reason_5 = v;
    }

    public java.lang.String getOrganization_or_person_5()
    {
        return organization_or_person_5;
    }

    public void setOrganization_or_person_5(java.lang.String v)
    {
        this.organization_or_person_5 = v;
    }

    public java.lang.String getExpense_dtl_12b_r25c5()
    {
        return expense_dtl_12b_r25c5;
    }

    public void setExpense_dtl_12b_r25c5(java.lang.String v)
    {
        this.expense_dtl_12b_r25c5 = v;
    }

    public java.lang.String getExpense_dtl_12b_r25c6()
    {
        return expense_dtl_12b_r25c6;
    }

    public void setExpense_dtl_12b_r25c6(java.lang.String v)
    {
        this.expense_dtl_12b_r25c6 = v;
    }

    public java.lang.String getCheck_5()
    {
        return check_5;
    }

    public void setCheck_5(java.lang.String v)
    {
        this.check_5 = v;
    }

    public java.lang.String getPaid_to_5()
    {
        return paid_to_5;
    }

    public void setPaid_to_5(java.lang.String v)
    {
        this.paid_to_5 = v;
    }

    public java.lang.String getAmount_5()
    {
        return amount_5;
    }

    public void setAmount_5(java.lang.String v)
    {
        this.amount_5 = v;
    }

    public java.lang.String getReason_6()
    {
        return reason_6;
    }

    public void setReason_6(java.lang.String v)
    {
        this.reason_6 = v;
    }

    public java.lang.String getOrganization_or_person_6()
    {
        return organization_or_person_6;
    }

    public void setOrganization_or_person_6(java.lang.String v)
    {
        this.organization_or_person_6 = v;
    }

    public java.lang.String getExpense_dtl_12b_r26c5()
    {
        return expense_dtl_12b_r26c5;
    }

    public void setExpense_dtl_12b_r26c5(java.lang.String v)
    {
        this.expense_dtl_12b_r26c5 = v;
    }

    public java.lang.String getExpense_dtl_12b_r26c6()
    {
        return expense_dtl_12b_r26c6;
    }

    public void setExpense_dtl_12b_r26c6(java.lang.String v)
    {
        this.expense_dtl_12b_r26c6 = v;
    }

    public java.lang.String getCheck_6()
    {
        return check_6;
    }

    public void setCheck_6(java.lang.String v)
    {
        this.check_6 = v;
    }

    public java.lang.String getPaid_to_6()
    {
        return paid_to_6;
    }

    public void setPaid_to_6(java.lang.String v)
    {
        this.paid_to_6 = v;
    }

    public java.lang.String getAmount_6()
    {
        return amount_6;
    }

    public void setAmount_6(java.lang.String v)
    {
        this.amount_6 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_28()
    {
        return amount_show_total_on_pg_4_line_28;
    }

    public void setAmount_show_total_on_pg_4_line_28(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_28 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name()
    {
        return _501_c_3_nonprofit_organizations_organization_name;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name = v;
    }

    public java.lang.String getOrganization_or_person_7()
    {
        return organization_or_person_7;
    }

    public void setOrganization_or_person_7(java.lang.String v)
    {
        this.organization_or_person_7 = v;
    }

    public java.lang.String getReason_7()
    {
        return reason_7;
    }

    public void setReason_7(java.lang.String v)
    {
        this.reason_7 = v;
    }

    public java.lang.String getCheck_7()
    {
        return check_7;
    }

    public void setCheck_7(java.lang.String v)
    {
        this.check_7 = v;
    }

    public java.lang.String getCheck_date()
    {
        return check_date;
    }

    public void setCheck_date(java.lang.String v)
    {
        this.check_date = v;
    }

    public java.lang.String getFed_id_number()
    {
        return fed_id_number;
    }

    public void setFed_id_number(java.lang.String v)
    {
        this.fed_id_number = v;
    }

    public java.lang.String getAmount_7()
    {
        return amount_7;
    }

    public void setAmount_7(java.lang.String v)
    {
        this.amount_7 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_2()
    {
        return _501_c_3_nonprofit_organizations_organization_name_2;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_2(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_2 = v;
    }

    public java.lang.String getOrganization_or_person_8()
    {
        return organization_or_person_8;
    }

    public void setOrganization_or_person_8(java.lang.String v)
    {
        this.organization_or_person_8 = v;
    }

    public java.lang.String getReason_8()
    {
        return reason_8;
    }

    public void setReason_8(java.lang.String v)
    {
        this.reason_8 = v;
    }

    public java.lang.String getCheck_8()
    {
        return check_8;
    }

    public void setCheck_8(java.lang.String v)
    {
        this.check_8 = v;
    }

    public java.lang.String getCheck_date_2()
    {
        return check_date_2;
    }

    public void setCheck_date_2(java.lang.String v)
    {
        this.check_date_2 = v;
    }

    public java.lang.String getFed_id_number_2()
    {
        return fed_id_number_2;
    }

    public void setFed_id_number_2(java.lang.String v)
    {
        this.fed_id_number_2 = v;
    }

    public java.lang.String getAmount_8()
    {
        return amount_8;
    }

    public void setAmount_8(java.lang.String v)
    {
        this.amount_8 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_3()
    {
        return _501_c_3_nonprofit_organizations_organization_name_3;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_3(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_3 = v;
    }

    public java.lang.String getOrganization_or_person_9()
    {
        return organization_or_person_9;
    }

    public void setOrganization_or_person_9(java.lang.String v)
    {
        this.organization_or_person_9 = v;
    }

    public java.lang.String getReason_9()
    {
        return reason_9;
    }

    public void setReason_9(java.lang.String v)
    {
        this.reason_9 = v;
    }

    public java.lang.String getCheck_9()
    {
        return check_9;
    }

    public void setCheck_9(java.lang.String v)
    {
        this.check_9 = v;
    }

    public java.lang.String getCheck_date_3()
    {
        return check_date_3;
    }

    public void setCheck_date_3(java.lang.String v)
    {
        this.check_date_3 = v;
    }

    public java.lang.String getFed_id_number_3()
    {
        return fed_id_number_3;
    }

    public void setFed_id_number_3(java.lang.String v)
    {
        this.fed_id_number_3 = v;
    }

    public java.lang.String getAmount_9()
    {
        return amount_9;
    }

    public void setAmount_9(java.lang.String v)
    {
        this.amount_9 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_4()
    {
        return _501_c_3_nonprofit_organizations_organization_name_4;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_4(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_4 = v;
    }

    public java.lang.String getOrganization_or_person_10()
    {
        return organization_or_person_10;
    }

    public void setOrganization_or_person_10(java.lang.String v)
    {
        this.organization_or_person_10 = v;
    }

    public java.lang.String getReason_10()
    {
        return reason_10;
    }

    public void setReason_10(java.lang.String v)
    {
        this.reason_10 = v;
    }

    public java.lang.String getCheck_10()
    {
        return check_10;
    }

    public void setCheck_10(java.lang.String v)
    {
        this.check_10 = v;
    }

    public java.lang.String getCheck_date_4()
    {
        return check_date_4;
    }

    public void setCheck_date_4(java.lang.String v)
    {
        this.check_date_4 = v;
    }

    public java.lang.String getFed_id_number_4()
    {
        return fed_id_number_4;
    }

    public void setFed_id_number_4(java.lang.String v)
    {
        this.fed_id_number_4 = v;
    }

    public java.lang.String getAmount_10()
    {
        return amount_10;
    }

    public void setAmount_10(java.lang.String v)
    {
        this.amount_10 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_5()
    {
        return _501_c_3_nonprofit_organizations_organization_name_5;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_5(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_5 = v;
    }

    public java.lang.String getOrganization_or_person_11()
    {
        return organization_or_person_11;
    }

    public void setOrganization_or_person_11(java.lang.String v)
    {
        this.organization_or_person_11 = v;
    }

    public java.lang.String getReason_11()
    {
        return reason_11;
    }

    public void setReason_11(java.lang.String v)
    {
        this.reason_11 = v;
    }

    public java.lang.String getCheck_11()
    {
        return check_11;
    }

    public void setCheck_11(java.lang.String v)
    {
        this.check_11 = v;
    }

    public java.lang.String getCheck_date_5()
    {
        return check_date_5;
    }

    public void setCheck_date_5(java.lang.String v)
    {
        this.check_date_5 = v;
    }

    public java.lang.String getFed_id_number_5()
    {
        return fed_id_number_5;
    }

    public void setFed_id_number_5(java.lang.String v)
    {
        this.fed_id_number_5 = v;
    }

    public java.lang.String getAmount_11()
    {
        return amount_11;
    }

    public void setAmount_11(java.lang.String v)
    {
        this.amount_11 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_6()
    {
        return _501_c_3_nonprofit_organizations_organization_name_6;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_6(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_6 = v;
    }

    public java.lang.String getOrganization_or_person_12()
    {
        return organization_or_person_12;
    }

    public void setOrganization_or_person_12(java.lang.String v)
    {
        this.organization_or_person_12 = v;
    }

    public java.lang.String getReason_12()
    {
        return reason_12;
    }

    public void setReason_12(java.lang.String v)
    {
        this.reason_12 = v;
    }

    public java.lang.String getCheck_12()
    {
        return check_12;
    }

    public void setCheck_12(java.lang.String v)
    {
        this.check_12 = v;
    }

    public java.lang.String getCheck_date_6()
    {
        return check_date_6;
    }

    public void setCheck_date_6(java.lang.String v)
    {
        this.check_date_6 = v;
    }

    public java.lang.String getFed_id_number_6()
    {
        return fed_id_number_6;
    }

    public void setFed_id_number_6(java.lang.String v)
    {
        this.fed_id_number_6 = v;
    }

    public java.lang.String getAmount_12()
    {
        return amount_12;
    }

    public void setAmount_12(java.lang.String v)
    {
        this.amount_12 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_7()
    {
        return _501_c_3_nonprofit_organizations_organization_name_7;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_7(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_7 = v;
    }

    public java.lang.String getOrganization_or_person_13()
    {
        return organization_or_person_13;
    }

    public void setOrganization_or_person_13(java.lang.String v)
    {
        this.organization_or_person_13 = v;
    }

    public java.lang.String getReason_13()
    {
        return reason_13;
    }

    public void setReason_13(java.lang.String v)
    {
        this.reason_13 = v;
    }

    public java.lang.String getCheck_13()
    {
        return check_13;
    }

    public void setCheck_13(java.lang.String v)
    {
        this.check_13 = v;
    }

    public java.lang.String getCheck_date_7()
    {
        return check_date_7;
    }

    public void setCheck_date_7(java.lang.String v)
    {
        this.check_date_7 = v;
    }

    public java.lang.String getFed_id_number_7()
    {
        return fed_id_number_7;
    }

    public void setFed_id_number_7(java.lang.String v)
    {
        this.fed_id_number_7 = v;
    }

    public java.lang.String getAmount_13()
    {
        return amount_13;
    }

    public void setAmount_13(java.lang.String v)
    {
        this.amount_13 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_8()
    {
        return _501_c_3_nonprofit_organizations_organization_name_8;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_8(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_8 = v;
    }

    public java.lang.String getOrganization_or_person_14()
    {
        return organization_or_person_14;
    }

    public void setOrganization_or_person_14(java.lang.String v)
    {
        this.organization_or_person_14 = v;
    }

    public java.lang.String getReason_14()
    {
        return reason_14;
    }

    public void setReason_14(java.lang.String v)
    {
        this.reason_14 = v;
    }

    public java.lang.String getCheck_14()
    {
        return check_14;
    }

    public void setCheck_14(java.lang.String v)
    {
        this.check_14 = v;
    }

    public java.lang.String getCheck_date_8()
    {
        return check_date_8;
    }

    public void setCheck_date_8(java.lang.String v)
    {
        this.check_date_8 = v;
    }

    public java.lang.String getFed_id_number_8()
    {
        return fed_id_number_8;
    }

    public void setFed_id_number_8(java.lang.String v)
    {
        this.fed_id_number_8 = v;
    }

    public java.lang.String getAmount_14()
    {
        return amount_14;
    }

    public void setAmount_14(java.lang.String v)
    {
        this.amount_14 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_9()
    {
        return _501_c_3_nonprofit_organizations_organization_name_9;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_9(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_9 = v;
    }

    public java.lang.String getOrganization_or_person_15()
    {
        return organization_or_person_15;
    }

    public void setOrganization_or_person_15(java.lang.String v)
    {
        this.organization_or_person_15 = v;
    }

    public java.lang.String getReason_15()
    {
        return reason_15;
    }

    public void setReason_15(java.lang.String v)
    {
        this.reason_15 = v;
    }

    public java.lang.String getCheck_15()
    {
        return check_15;
    }

    public void setCheck_15(java.lang.String v)
    {
        this.check_15 = v;
    }

    public java.lang.String getCheck_date_9()
    {
        return check_date_9;
    }

    public void setCheck_date_9(java.lang.String v)
    {
        this.check_date_9 = v;
    }

    public java.lang.String getFed_id_number_9()
    {
        return fed_id_number_9;
    }

    public void setFed_id_number_9(java.lang.String v)
    {
        this.fed_id_number_9 = v;
    }

    public java.lang.String getAmount_15()
    {
        return amount_15;
    }

    public void setAmount_15(java.lang.String v)
    {
        this.amount_15 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_10()
    {
        return _501_c_3_nonprofit_organizations_organization_name_10;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_10(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_10 = v;
    }

    public java.lang.String getOrganization_or_person_16()
    {
        return organization_or_person_16;
    }

    public void setOrganization_or_person_16(java.lang.String v)
    {
        this.organization_or_person_16 = v;
    }

    public java.lang.String getReason_16()
    {
        return reason_16;
    }

    public void setReason_16(java.lang.String v)
    {
        this.reason_16 = v;
    }

    public java.lang.String getCheck_16()
    {
        return check_16;
    }

    public void setCheck_16(java.lang.String v)
    {
        this.check_16 = v;
    }

    public java.lang.String getCheck_date_10()
    {
        return check_date_10;
    }

    public void setCheck_date_10(java.lang.String v)
    {
        this.check_date_10 = v;
    }

    public java.lang.String getFed_id_number_10()
    {
        return fed_id_number_10;
    }

    public void setFed_id_number_10(java.lang.String v)
    {
        this.fed_id_number_10 = v;
    }

    public java.lang.String getAmount_16()
    {
        return amount_16;
    }

    public void setAmount_16(java.lang.String v)
    {
        this.amount_16 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_11()
    {
        return _501_c_3_nonprofit_organizations_organization_name_11;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_11(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_11 = v;
    }

    public java.lang.String getOrganization_or_person_17()
    {
        return organization_or_person_17;
    }

    public void setOrganization_or_person_17(java.lang.String v)
    {
        this.organization_or_person_17 = v;
    }

    public java.lang.String getReason_17()
    {
        return reason_17;
    }

    public void setReason_17(java.lang.String v)
    {
        this.reason_17 = v;
    }

    public java.lang.String getCheck_17()
    {
        return check_17;
    }

    public void setCheck_17(java.lang.String v)
    {
        this.check_17 = v;
    }

    public java.lang.String getCheck_date_11()
    {
        return check_date_11;
    }

    public void setCheck_date_11(java.lang.String v)
    {
        this.check_date_11 = v;
    }

    public java.lang.String getFed_id_number_11()
    {
        return fed_id_number_11;
    }

    public void setFed_id_number_11(java.lang.String v)
    {
        this.fed_id_number_11 = v;
    }

    public java.lang.String getAmount_17()
    {
        return amount_17;
    }

    public void setAmount_17(java.lang.String v)
    {
        this.amount_17 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_12()
    {
        return _501_c_3_nonprofit_organizations_organization_name_12;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_12(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_12 = v;
    }

    public java.lang.String getOrganization_or_person_18()
    {
        return organization_or_person_18;
    }

    public void setOrganization_or_person_18(java.lang.String v)
    {
        this.organization_or_person_18 = v;
    }

    public java.lang.String getReason_18()
    {
        return reason_18;
    }

    public void setReason_18(java.lang.String v)
    {
        this.reason_18 = v;
    }

    public java.lang.String getCheck_18()
    {
        return check_18;
    }

    public void setCheck_18(java.lang.String v)
    {
        this.check_18 = v;
    }

    public java.lang.String getCheck_date_12()
    {
        return check_date_12;
    }

    public void setCheck_date_12(java.lang.String v)
    {
        this.check_date_12 = v;
    }

    public java.lang.String getFed_id_number_12()
    {
        return fed_id_number_12;
    }

    public void setFed_id_number_12(java.lang.String v)
    {
        this.fed_id_number_12 = v;
    }

    public java.lang.String getAmount_18()
    {
        return amount_18;
    }

    public void setAmount_18(java.lang.String v)
    {
        this.amount_18 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_13()
    {
        return _501_c_3_nonprofit_organizations_organization_name_13;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_13(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_13 = v;
    }

    public java.lang.String getOrganization_or_person_19()
    {
        return organization_or_person_19;
    }

    public void setOrganization_or_person_19(java.lang.String v)
    {
        this.organization_or_person_19 = v;
    }

    public java.lang.String getReason_19()
    {
        return reason_19;
    }

    public void setReason_19(java.lang.String v)
    {
        this.reason_19 = v;
    }

    public java.lang.String getCheck_19()
    {
        return check_19;
    }

    public void setCheck_19(java.lang.String v)
    {
        this.check_19 = v;
    }

    public java.lang.String getCheck_date_13()
    {
        return check_date_13;
    }

    public void setCheck_date_13(java.lang.String v)
    {
        this.check_date_13 = v;
    }

    public java.lang.String getFed_id_number_13()
    {
        return fed_id_number_13;
    }

    public void setFed_id_number_13(java.lang.String v)
    {
        this.fed_id_number_13 = v;
    }

    public java.lang.String getAmount_19()
    {
        return amount_19;
    }

    public void setAmount_19(java.lang.String v)
    {
        this.amount_19 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_14()
    {
        return _501_c_3_nonprofit_organizations_organization_name_14;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_14(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_14 = v;
    }

    public java.lang.String getOrganization_or_person_20()
    {
        return organization_or_person_20;
    }

    public void setOrganization_or_person_20(java.lang.String v)
    {
        this.organization_or_person_20 = v;
    }

    public java.lang.String getReason_20()
    {
        return reason_20;
    }

    public void setReason_20(java.lang.String v)
    {
        this.reason_20 = v;
    }

    public java.lang.String getCheck_20()
    {
        return check_20;
    }

    public void setCheck_20(java.lang.String v)
    {
        this.check_20 = v;
    }

    public java.lang.String getCheck_date_14()
    {
        return check_date_14;
    }

    public void setCheck_date_14(java.lang.String v)
    {
        this.check_date_14 = v;
    }

    public java.lang.String getFed_id_number_14()
    {
        return fed_id_number_14;
    }

    public void setFed_id_number_14(java.lang.String v)
    {
        this.fed_id_number_14 = v;
    }

    public java.lang.String getAmount_20()
    {
        return amount_20;
    }

    public void setAmount_20(java.lang.String v)
    {
        this.amount_20 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_15()
    {
        return _501_c_3_nonprofit_organizations_organization_name_15;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_15(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_15 = v;
    }

    public java.lang.String getOrganization_or_person_21()
    {
        return organization_or_person_21;
    }

    public void setOrganization_or_person_21(java.lang.String v)
    {
        this.organization_or_person_21 = v;
    }

    public java.lang.String getReason_21()
    {
        return reason_21;
    }

    public void setReason_21(java.lang.String v)
    {
        this.reason_21 = v;
    }

    public java.lang.String getCheck_21()
    {
        return check_21;
    }

    public void setCheck_21(java.lang.String v)
    {
        this.check_21 = v;
    }

    public java.lang.String getCheck_date_15()
    {
        return check_date_15;
    }

    public void setCheck_date_15(java.lang.String v)
    {
        this.check_date_15 = v;
    }

    public java.lang.String getFed_id_number_15()
    {
        return fed_id_number_15;
    }

    public void setFed_id_number_15(java.lang.String v)
    {
        this.fed_id_number_15 = v;
    }

    public java.lang.String getAmount_21()
    {
        return amount_21;
    }

    public void setAmount_21(java.lang.String v)
    {
        this.amount_21 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_16()
    {
        return _501_c_3_nonprofit_organizations_organization_name_16;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_16(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_16 = v;
    }

    public java.lang.String getOrganization_or_person_22()
    {
        return organization_or_person_22;
    }

    public void setOrganization_or_person_22(java.lang.String v)
    {
        this.organization_or_person_22 = v;
    }

    public java.lang.String getReason_22()
    {
        return reason_22;
    }

    public void setReason_22(java.lang.String v)
    {
        this.reason_22 = v;
    }

    public java.lang.String getCheck_22()
    {
        return check_22;
    }

    public void setCheck_22(java.lang.String v)
    {
        this.check_22 = v;
    }

    public java.lang.String getCheck_date_16()
    {
        return check_date_16;
    }

    public void setCheck_date_16(java.lang.String v)
    {
        this.check_date_16 = v;
    }

    public java.lang.String getFed_id_number_16()
    {
        return fed_id_number_16;
    }

    public void setFed_id_number_16(java.lang.String v)
    {
        this.fed_id_number_16 = v;
    }

    public java.lang.String getAmount_22()
    {
        return amount_22;
    }

    public void setAmount_22(java.lang.String v)
    {
        this.amount_22 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_17()
    {
        return _501_c_3_nonprofit_organizations_organization_name_17;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_17(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_17 = v;
    }

    public java.lang.String getOrganization_or_person_23()
    {
        return organization_or_person_23;
    }

    public void setOrganization_or_person_23(java.lang.String v)
    {
        this.organization_or_person_23 = v;
    }

    public java.lang.String getReason_23()
    {
        return reason_23;
    }

    public void setReason_23(java.lang.String v)
    {
        this.reason_23 = v;
    }

    public java.lang.String getCheck_23()
    {
        return check_23;
    }

    public void setCheck_23(java.lang.String v)
    {
        this.check_23 = v;
    }

    public java.lang.String getCheck_date_17()
    {
        return check_date_17;
    }

    public void setCheck_date_17(java.lang.String v)
    {
        this.check_date_17 = v;
    }

    public java.lang.String getFed_id_number_17()
    {
        return fed_id_number_17;
    }

    public void setFed_id_number_17(java.lang.String v)
    {
        this.fed_id_number_17 = v;
    }

    public java.lang.String getAmount_23()
    {
        return amount_23;
    }

    public void setAmount_23(java.lang.String v)
    {
        this.amount_23 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_18()
    {
        return _501_c_3_nonprofit_organizations_organization_name_18;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_18(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_18 = v;
    }

    public java.lang.String getOrganization_or_person_24()
    {
        return organization_or_person_24;
    }

    public void setOrganization_or_person_24(java.lang.String v)
    {
        this.organization_or_person_24 = v;
    }

    public java.lang.String getReason_24()
    {
        return reason_24;
    }

    public void setReason_24(java.lang.String v)
    {
        this.reason_24 = v;
    }

    public java.lang.String getCheck_24()
    {
        return check_24;
    }

    public void setCheck_24(java.lang.String v)
    {
        this.check_24 = v;
    }

    public java.lang.String getCheck_date_18()
    {
        return check_date_18;
    }

    public void setCheck_date_18(java.lang.String v)
    {
        this.check_date_18 = v;
    }

    public java.lang.String getFed_id_number_18()
    {
        return fed_id_number_18;
    }

    public void setFed_id_number_18(java.lang.String v)
    {
        this.fed_id_number_18 = v;
    }

    public java.lang.String getAmount_24()
    {
        return amount_24;
    }

    public void setAmount_24(java.lang.String v)
    {
        this.amount_24 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_19()
    {
        return _501_c_3_nonprofit_organizations_organization_name_19;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_19(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_19 = v;
    }

    public java.lang.String getOrganization_or_person_25()
    {
        return organization_or_person_25;
    }

    public void setOrganization_or_person_25(java.lang.String v)
    {
        this.organization_or_person_25 = v;
    }

    public java.lang.String getReason_25()
    {
        return reason_25;
    }

    public void setReason_25(java.lang.String v)
    {
        this.reason_25 = v;
    }

    public java.lang.String getCheck_25()
    {
        return check_25;
    }

    public void setCheck_25(java.lang.String v)
    {
        this.check_25 = v;
    }

    public java.lang.String getCheck_date_19()
    {
        return check_date_19;
    }

    public void setCheck_date_19(java.lang.String v)
    {
        this.check_date_19 = v;
    }

    public java.lang.String getFed_id_number_19()
    {
        return fed_id_number_19;
    }

    public void setFed_id_number_19(java.lang.String v)
    {
        this.fed_id_number_19 = v;
    }

    public java.lang.String getAmount_25()
    {
        return amount_25;
    }

    public void setAmount_25(java.lang.String v)
    {
        this.amount_25 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_20()
    {
        return _501_c_3_nonprofit_organizations_organization_name_20;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_20(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_20 = v;
    }

    public java.lang.String getOrganization_or_person_26()
    {
        return organization_or_person_26;
    }

    public void setOrganization_or_person_26(java.lang.String v)
    {
        this.organization_or_person_26 = v;
    }

    public java.lang.String getReason_26()
    {
        return reason_26;
    }

    public void setReason_26(java.lang.String v)
    {
        this.reason_26 = v;
    }

    public java.lang.String getCheck_26()
    {
        return check_26;
    }

    public void setCheck_26(java.lang.String v)
    {
        this.check_26 = v;
    }

    public java.lang.String getCheck_date_20()
    {
        return check_date_20;
    }

    public void setCheck_date_20(java.lang.String v)
    {
        this.check_date_20 = v;
    }

    public java.lang.String getFed_id_number_20()
    {
        return fed_id_number_20;
    }

    public void setFed_id_number_20(java.lang.String v)
    {
        this.fed_id_number_20 = v;
    }

    public java.lang.String getAmount_26()
    {
        return amount_26;
    }

    public void setAmount_26(java.lang.String v)
    {
        this.amount_26 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_21()
    {
        return _501_c_3_nonprofit_organizations_organization_name_21;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_21(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_21 = v;
    }

    public java.lang.String getOrganization_or_person_27()
    {
        return organization_or_person_27;
    }

    public void setOrganization_or_person_27(java.lang.String v)
    {
        this.organization_or_person_27 = v;
    }

    public java.lang.String getReason_27()
    {
        return reason_27;
    }

    public void setReason_27(java.lang.String v)
    {
        this.reason_27 = v;
    }

    public java.lang.String getCheck_27()
    {
        return check_27;
    }

    public void setCheck_27(java.lang.String v)
    {
        this.check_27 = v;
    }

    public java.lang.String getCheck_date_21()
    {
        return check_date_21;
    }

    public void setCheck_date_21(java.lang.String v)
    {
        this.check_date_21 = v;
    }

    public java.lang.String getFed_id_number_21()
    {
        return fed_id_number_21;
    }

    public void setFed_id_number_21(java.lang.String v)
    {
        this.fed_id_number_21 = v;
    }

    public java.lang.String getAmount_27()
    {
        return amount_27;
    }

    public void setAmount_27(java.lang.String v)
    {
        this.amount_27 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_22()
    {
        return _501_c_3_nonprofit_organizations_organization_name_22;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_22(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_22 = v;
    }

    public java.lang.String getOrganization_or_person_28()
    {
        return organization_or_person_28;
    }

    public void setOrganization_or_person_28(java.lang.String v)
    {
        this.organization_or_person_28 = v;
    }

    public java.lang.String getReason_28()
    {
        return reason_28;
    }

    public void setReason_28(java.lang.String v)
    {
        this.reason_28 = v;
    }

    public java.lang.String getCheck_28()
    {
        return check_28;
    }

    public void setCheck_28(java.lang.String v)
    {
        this.check_28 = v;
    }

    public java.lang.String getCheck_date_22()
    {
        return check_date_22;
    }

    public void setCheck_date_22(java.lang.String v)
    {
        this.check_date_22 = v;
    }

    public java.lang.String getFed_id_number_22()
    {
        return fed_id_number_22;
    }

    public void setFed_id_number_22(java.lang.String v)
    {
        this.fed_id_number_22 = v;
    }

    public java.lang.String getAmount_28()
    {
        return amount_28;
    }

    public void setAmount_28(java.lang.String v)
    {
        this.amount_28 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_23()
    {
        return _501_c_3_nonprofit_organizations_organization_name_23;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_23(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_23 = v;
    }

    public java.lang.String getOrganization_or_person_29()
    {
        return organization_or_person_29;
    }

    public void setOrganization_or_person_29(java.lang.String v)
    {
        this.organization_or_person_29 = v;
    }

    public java.lang.String getReason_29()
    {
        return reason_29;
    }

    public void setReason_29(java.lang.String v)
    {
        this.reason_29 = v;
    }

    public java.lang.String getCheck_29()
    {
        return check_29;
    }

    public void setCheck_29(java.lang.String v)
    {
        this.check_29 = v;
    }

    public java.lang.String getCheck_date_23()
    {
        return check_date_23;
    }

    public void setCheck_date_23(java.lang.String v)
    {
        this.check_date_23 = v;
    }

    public java.lang.String getFed_id_number_23()
    {
        return fed_id_number_23;
    }

    public void setFed_id_number_23(java.lang.String v)
    {
        this.fed_id_number_23 = v;
    }

    public java.lang.String getAmount_29()
    {
        return amount_29;
    }

    public void setAmount_29(java.lang.String v)
    {
        this.amount_29 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_24()
    {
        return _501_c_3_nonprofit_organizations_organization_name_24;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_24(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_24 = v;
    }

    public java.lang.String getOrganization_or_person_30()
    {
        return organization_or_person_30;
    }

    public void setOrganization_or_person_30(java.lang.String v)
    {
        this.organization_or_person_30 = v;
    }

    public java.lang.String getReason_30()
    {
        return reason_30;
    }

    public void setReason_30(java.lang.String v)
    {
        this.reason_30 = v;
    }

    public java.lang.String getCheck_30()
    {
        return check_30;
    }

    public void setCheck_30(java.lang.String v)
    {
        this.check_30 = v;
    }

    public java.lang.String getCheck_date_24()
    {
        return check_date_24;
    }

    public void setCheck_date_24(java.lang.String v)
    {
        this.check_date_24 = v;
    }

    public java.lang.String getFed_id_number_24()
    {
        return fed_id_number_24;
    }

    public void setFed_id_number_24(java.lang.String v)
    {
        this.fed_id_number_24 = v;
    }

    public java.lang.String getAmount_30()
    {
        return amount_30;
    }

    public void setAmount_30(java.lang.String v)
    {
        this.amount_30 = v;
    }

    public java.lang.String get_501_c_3_nonprofit_organizations_organization_name_25()
    {
        return _501_c_3_nonprofit_organizations_organization_name_25;
    }

    public void set_501_c_3_nonprofit_organizations_organization_name_25(java.lang.String v)
    {
        this._501_c_3_nonprofit_organizations_organization_name_25 = v;
    }

    public java.lang.String getOrganization_or_person_31()
    {
        return organization_or_person_31;
    }

    public void setOrganization_or_person_31(java.lang.String v)
    {
        this.organization_or_person_31 = v;
    }

    public java.lang.String getReason_31()
    {
        return reason_31;
    }

    public void setReason_31(java.lang.String v)
    {
        this.reason_31 = v;
    }

    public java.lang.String getCheck_31()
    {
        return check_31;
    }

    public void setCheck_31(java.lang.String v)
    {
        this.check_31 = v;
    }

    public java.lang.String getCheck_date_25()
    {
        return check_date_25;
    }

    public void setCheck_date_25(java.lang.String v)
    {
        this.check_date_25 = v;
    }

    public java.lang.String getFed_id_number_25()
    {
        return fed_id_number_25;
    }

    public void setFed_id_number_25(java.lang.String v)
    {
        this.fed_id_number_25 = v;
    }

    public java.lang.String getAmount_31()
    {
        return amount_31;
    }

    public void setAmount_31(java.lang.String v)
    {
        this.amount_31 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_29()
    {
        return amount_show_total_on_pg_4_line_29;
    }

    public void setAmount_show_total_on_pg_4_line_29(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_29 = v;
    }

    public EXPENSE_DTL_12bBean()
    {
    }

}
