package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet DEPR_DTL_8 */
public class DEPR_DTL_8Bean
{

    private java.lang.Double depr_dtl_8_r2c4;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String oa_ar_or_fr;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description;
    private java.lang.String qty;
    private java.lang.String purchase_year;
    private java.lang.Double a_this_year_from_grid_below;
    private java.lang.Double prior_cost_or_value_if_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0;
    private java.lang.Double c_start_accum_deprec_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0;
    private java.lang.Double d_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0;
    private java.lang.Double end_accum_deprec_c_d_if_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_2;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_2;
    private java.lang.String qty_2;
    private java.lang.String purchase_year_2;
    private java.lang.Double if_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0;
    private java.lang.Double if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0_if_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0;
    private java.lang.Double if_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0;
    private java.lang.Double if_h14_0_k14_l14_if_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_3;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_3;
    private java.lang.String qty_3;
    private java.lang.String purchase_year_3;
    private java.lang.Double if_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0;
    private java.lang.Double if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0_if_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0;
    private java.lang.Double if_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0;
    private java.lang.Double if_h15_0_k15_l15_if_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_4;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_4;
    private java.lang.String qty_4;
    private java.lang.String purchase_year_4;
    private java.lang.Double if_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0;
    private java.lang.Double if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0_if_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0;
    private java.lang.Double if_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0;
    private java.lang.Double if_h16_0_k16_l16_if_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_5;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_5;
    private java.lang.String qty_5;
    private java.lang.String purchase_year_5;
    private java.lang.Double if_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0;
    private java.lang.Double if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0_if_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0;
    private java.lang.Double if_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0;
    private java.lang.Double if_h17_0_k17_l17_if_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_6;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_6;
    private java.lang.String qty_6;
    private java.lang.String purchase_year_6;
    private java.lang.Double if_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0;
    private java.lang.Double if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0_if_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0;
    private java.lang.Double if_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0;
    private java.lang.Double if_h18_0_k18_l18_if_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_7;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_7;
    private java.lang.String qty_7;
    private java.lang.String purchase_year_7;
    private java.lang.Double if_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0;
    private java.lang.Double if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0_if_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0;
    private java.lang.Double if_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0;
    private java.lang.Double if_h19_0_k19_l19_if_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_8;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_8;
    private java.lang.String qty_8;
    private java.lang.String purchase_year_8;
    private java.lang.Double if_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0;
    private java.lang.Double if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0_if_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0;
    private java.lang.Double if_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0;
    private java.lang.Double if_h20_0_k20_l20_if_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_9;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_9;
    private java.lang.String qty_9;
    private java.lang.String purchase_year_9;
    private java.lang.Double if_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0;
    private java.lang.Double if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0_if_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0;
    private java.lang.Double if_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0;
    private java.lang.Double if_h21_0_k21_l21_if_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2;
    private java.lang.String oa_ar_or_fr_10;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_10;
    private java.lang.String qty_10;
    private java.lang.String purchase_year_10;
    private java.lang.Double if_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0;
    private java.lang.Double if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0_if_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0;
    private java.lang.Double if_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0;
    private java.lang.Double if_h22_0_k22_l22_if_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2;
    private java.lang.Double if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0_5_year_total;
    private java.lang.Double b_current_cost_or_value_sum_i14_i23;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0_sum_j14_j23;
    private java.lang.Double if_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2_sum_k14_k23;
    private java.lang.Double if_h23_0_k23_l23_sum_l14_l23;
    private java.lang.Double if_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0_year_purchased;
    private java.lang.Double sum_i14_i23_if_contents_c_11_year_now_contents_c_11;
    private java.lang.Double sum_j14_j23_h26_1;
    private java.lang.Double sum_k14_k23_i26_1;
    private java.lang.Double sum_l14_l23_j26_1;
    private java.lang.Double sum_m14_m23_k26_1;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_11;
    private java.lang.String qty_11;
    private java.lang.String purchase_year_11;
    private java.lang.Double a_this_year_from_grid_below_2;
    private java.lang.Double prior_cost_or_value_if_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0;
    private java.lang.Double c_start_accum_deprec_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0;
    private java.lang.Double d_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0;
    private java.lang.Double end_accum_deprec_c_d_if_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_2;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_12;
    private java.lang.String qty_12;
    private java.lang.String purchase_year_12;
    private java.lang.Double if_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0;
    private java.lang.Double if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0_if_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0;
    private java.lang.Double if_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0;
    private java.lang.Double if_h32_0_k32_l32_if_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_3;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_13;
    private java.lang.String qty_13;
    private java.lang.String purchase_year_13;
    private java.lang.Double if_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0;
    private java.lang.Double if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0_if_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0;
    private java.lang.Double if_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0;
    private java.lang.Double if_h33_0_k33_l33_if_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_4;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_14;
    private java.lang.String qty_14;
    private java.lang.String purchase_year_14;
    private java.lang.Double if_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0;
    private java.lang.Double if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0_if_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0;
    private java.lang.Double if_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0;
    private java.lang.Double if_h34_0_k34_l34_if_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_5;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_15;
    private java.lang.String qty_15;
    private java.lang.String purchase_year_15;
    private java.lang.Double if_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0;
    private java.lang.Double if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0_if_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0;
    private java.lang.Double if_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0;
    private java.lang.Double if_h35_0_k35_l35_if_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_6;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_16;
    private java.lang.String qty_16;
    private java.lang.String purchase_year_16;
    private java.lang.Double if_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0;
    private java.lang.Double if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0_if_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0;
    private java.lang.Double if_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0;
    private java.lang.Double if_h36_0_k36_l36_if_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_7;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_17;
    private java.lang.String qty_17;
    private java.lang.String purchase_year_17;
    private java.lang.Double if_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0;
    private java.lang.Double if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0_if_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0;
    private java.lang.Double if_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0;
    private java.lang.Double if_h37_0_k37_l37_if_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_8;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_18;
    private java.lang.String qty_18;
    private java.lang.String purchase_year_18;
    private java.lang.Double if_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0;
    private java.lang.Double if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0_if_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0;
    private java.lang.Double if_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0;
    private java.lang.Double if_h38_0_k38_l38_if_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_9;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_19;
    private java.lang.String qty_19;
    private java.lang.String purchase_year_19;
    private java.lang.Double if_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0;
    private java.lang.Double if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0_if_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0;
    private java.lang.Double if_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0;
    private java.lang.Double if_h39_0_k39_l39_if_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2;
    private java.lang.String seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_10;
    private java.lang.String equipment_purchases_or_value_2000_each_item_description_20;
    private java.lang.String qty_20;
    private java.lang.String purchase_year_20;
    private java.lang.Double if_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0;
    private java.lang.Double if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0_if_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0;
    private java.lang.String b_current_cost_or_value_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0;
    private java.lang.Double if_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0;
    private java.lang.Double if_h40_0_k40_l40_if_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2;
    private java.lang.Double if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0_7_year_total;
    private java.lang.Double b_current_cost_or_value_sum_i32_i41;
    private java.lang.Double if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0_sum_j32_j41;
    private java.lang.Double if_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2_sum_k32_k41;
    private java.lang.Double if_h41_0_k41_l41_sum_l32_l41;
    private java.lang.Double _7_year_total_year_purchased;
    private java.lang.Double note_depreciation_this_year_d_is_only_calculated_during_4th_quarter_for_the_year_if_contents_c_11_year_now_contents_c_11;
    private java.lang.Double if_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0_f44_1;
    private java.lang.Double sum_i32_i41_g44_1;
    private java.lang.Double sum_j32_j41_h44_1;
    private java.lang.Double sum_k32_k41_i44_1;
    private java.lang.Double sum_l32_l41_j44_1;
    private java.lang.Double sum_m32_m41_k44_1;
    private java.lang.Double _0_1249_5_year_total_7_year_total;
    private java.lang.Double _0_0893_i24_i42;
    private java.lang.Double _0_0892_j24_j42;
    private java.lang.Double _0_0893_k24_k42;
    private java.lang.Double _0_0446_l24_l42;

    public java.lang.Double getDepr_dtl_8_r2c4()
    {
        return depr_dtl_8_r2c4;
    }

    public void setDepr_dtl_8_r2c4(java.lang.Double v)
    {
        this.depr_dtl_8_r2c4 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getOa_ar_or_fr()
    {
        return oa_ar_or_fr;
    }

    public void setOa_ar_or_fr(java.lang.String v)
    {
        this.oa_ar_or_fr = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description()
    {
        return equipment_purchases_or_value_2000_each_item_description;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description = v;
    }

    public java.lang.String getQty()
    {
        return qty;
    }

    public void setQty(java.lang.String v)
    {
        this.qty = v;
    }

    public java.lang.String getPurchase_year()
    {
        return purchase_year;
    }

    public void setPurchase_year(java.lang.String v)
    {
        this.purchase_year = v;
    }

    public java.lang.Double getA_this_year_from_grid_below()
    {
        return a_this_year_from_grid_below;
    }

    public void setA_this_year_from_grid_below(java.lang.Double v)
    {
        this.a_this_year_from_grid_below = v;
    }

    public java.lang.Double getPrior_cost_or_value_if_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0()
    {
        return prior_cost_or_value_if_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0;
    }

    public void setPrior_cost_or_value_if_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0(java.lang.Double v)
    {
        this.prior_cost_or_value_if_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0 = v;
    }

    public java.lang.Double getC_start_accum_deprec_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0()
    {
        return c_start_accum_deprec_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0;
    }

    public void setC_start_accum_deprec_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0(java.lang.Double v)
    {
        this.c_start_accum_deprec_if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0 = v;
    }

    public java.lang.Double getD_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0()
    {
        return d_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0;
    }

    public void setD_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0(java.lang.Double v)
    {
        this.d_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0 = v;
    }

    public java.lang.Double getEnd_accum_deprec_c_d_if_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2()
    {
        return end_accum_deprec_c_d_if_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2;
    }

    public void setEnd_accum_deprec_c_d_if_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.end_accum_deprec_c_d_if_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_2()
    {
        return oa_ar_or_fr_2;
    }

    public void setOa_ar_or_fr_2(java.lang.String v)
    {
        this.oa_ar_or_fr_2 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_2()
    {
        return equipment_purchases_or_value_2000_each_item_description_2;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_2(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_2 = v;
    }

    public java.lang.String getQty_2()
    {
        return qty_2;
    }

    public void setQty_2(java.lang.String v)
    {
        this.qty_2 = v;
    }

    public java.lang.String getPurchase_year_2()
    {
        return purchase_year_2;
    }

    public void setPurchase_year_2(java.lang.String v)
    {
        this.purchase_year_2 = v;
    }

    public java.lang.Double getIf_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0()
    {
        return if_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0;
    }

    public void setIf_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0(java.lang.Double v)
    {
        this.if_g14_0_if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_offset_contents_b_75_0_contents_c_11_g14_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0_if_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0()
    {
        return if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0_if_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0;
    }

    public void setIf_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0_if_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g14_0_g14_contents_c_11_contents_c_12_1_contents_c_12_a14_j14_if_and_g14_0_g14_contents_c_11_j14_0_if_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g14_6_contents_c_11_g14_0_round_offset_contents_b_73_0_contents_c_11_g14_1_j14_2_if_and_contents_c_11_0_j14_0_j14_0_if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0 = v;
    }

    public java.lang.Double getIf_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0()
    {
        return if_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0;
    }

    public void setIf_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0(java.lang.Double v)
    {
        this.if_h14_0_round_h14_j14_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0 = v;
    }

    public java.lang.Double getIf_h14_0_k14_l14_if_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2()
    {
        return if_h14_0_k14_l14_if_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h14_0_k14_l14_if_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h14_0_k14_l14_if_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_3()
    {
        return oa_ar_or_fr_3;
    }

    public void setOa_ar_or_fr_3(java.lang.String v)
    {
        this.oa_ar_or_fr_3 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_3()
    {
        return equipment_purchases_or_value_2000_each_item_description_3;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_3(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_3 = v;
    }

    public java.lang.String getQty_3()
    {
        return qty_3;
    }

    public void setQty_3(java.lang.String v)
    {
        this.qty_3 = v;
    }

    public java.lang.String getPurchase_year_3()
    {
        return purchase_year_3;
    }

    public void setPurchase_year_3(java.lang.String v)
    {
        this.purchase_year_3 = v;
    }

    public java.lang.Double getIf_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0()
    {
        return if_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0;
    }

    public void setIf_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0(java.lang.Double v)
    {
        this.if_g15_0_if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_offset_contents_b_75_0_contents_c_11_g15_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0_if_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0()
    {
        return if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0_if_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0;
    }

    public void setIf_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0_if_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g15_0_g15_contents_c_11_contents_c_12_1_contents_c_12_a15_j15_if_and_g15_0_g15_contents_c_11_j15_0_if_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g15_6_contents_c_11_g15_0_round_offset_contents_b_73_0_contents_c_11_g15_1_j15_2_if_and_contents_c_11_0_j15_0_j15_0_if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0 = v;
    }

    public java.lang.Double getIf_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0()
    {
        return if_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0;
    }

    public void setIf_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0(java.lang.Double v)
    {
        this.if_h15_0_round_h15_j15_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0 = v;
    }

    public java.lang.Double getIf_h15_0_k15_l15_if_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2()
    {
        return if_h15_0_k15_l15_if_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h15_0_k15_l15_if_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h15_0_k15_l15_if_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_4()
    {
        return oa_ar_or_fr_4;
    }

    public void setOa_ar_or_fr_4(java.lang.String v)
    {
        this.oa_ar_or_fr_4 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_4()
    {
        return equipment_purchases_or_value_2000_each_item_description_4;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_4(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_4 = v;
    }

    public java.lang.String getQty_4()
    {
        return qty_4;
    }

    public void setQty_4(java.lang.String v)
    {
        this.qty_4 = v;
    }

    public java.lang.String getPurchase_year_4()
    {
        return purchase_year_4;
    }

    public void setPurchase_year_4(java.lang.String v)
    {
        this.purchase_year_4 = v;
    }

    public java.lang.Double getIf_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0()
    {
        return if_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0;
    }

    public void setIf_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0(java.lang.Double v)
    {
        this.if_g16_0_if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_offset_contents_b_75_0_contents_c_11_g16_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0_if_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0()
    {
        return if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0_if_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0;
    }

    public void setIf_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0_if_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g16_0_g16_contents_c_11_contents_c_12_1_contents_c_12_a16_j16_if_and_g16_0_g16_contents_c_11_j16_0_if_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g16_6_contents_c_11_g16_0_round_offset_contents_b_73_0_contents_c_11_g16_1_j16_2_if_and_contents_c_11_0_j16_0_j16_0_if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0 = v;
    }

    public java.lang.Double getIf_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0()
    {
        return if_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0;
    }

    public void setIf_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0(java.lang.Double v)
    {
        this.if_h16_0_round_h16_j16_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0 = v;
    }

    public java.lang.Double getIf_h16_0_k16_l16_if_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2()
    {
        return if_h16_0_k16_l16_if_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h16_0_k16_l16_if_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h16_0_k16_l16_if_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_5()
    {
        return oa_ar_or_fr_5;
    }

    public void setOa_ar_or_fr_5(java.lang.String v)
    {
        this.oa_ar_or_fr_5 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_5()
    {
        return equipment_purchases_or_value_2000_each_item_description_5;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_5(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_5 = v;
    }

    public java.lang.String getQty_5()
    {
        return qty_5;
    }

    public void setQty_5(java.lang.String v)
    {
        this.qty_5 = v;
    }

    public java.lang.String getPurchase_year_5()
    {
        return purchase_year_5;
    }

    public void setPurchase_year_5(java.lang.String v)
    {
        this.purchase_year_5 = v;
    }

    public java.lang.Double getIf_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0()
    {
        return if_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0;
    }

    public void setIf_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0(java.lang.Double v)
    {
        this.if_g17_0_if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_offset_contents_b_75_0_contents_c_11_g17_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0_if_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0()
    {
        return if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0_if_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0;
    }

    public void setIf_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0_if_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g17_0_g17_contents_c_11_contents_c_12_1_contents_c_12_a17_j17_if_and_g17_0_g17_contents_c_11_j17_0_if_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g17_6_contents_c_11_g17_0_round_offset_contents_b_73_0_contents_c_11_g17_1_j17_2_if_and_contents_c_11_0_j17_0_j17_0_if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0 = v;
    }

    public java.lang.Double getIf_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0()
    {
        return if_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0;
    }

    public void setIf_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0(java.lang.Double v)
    {
        this.if_h17_0_round_h17_j17_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0 = v;
    }

    public java.lang.Double getIf_h17_0_k17_l17_if_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2()
    {
        return if_h17_0_k17_l17_if_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h17_0_k17_l17_if_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h17_0_k17_l17_if_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_6()
    {
        return oa_ar_or_fr_6;
    }

    public void setOa_ar_or_fr_6(java.lang.String v)
    {
        this.oa_ar_or_fr_6 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_6()
    {
        return equipment_purchases_or_value_2000_each_item_description_6;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_6(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_6 = v;
    }

    public java.lang.String getQty_6()
    {
        return qty_6;
    }

    public void setQty_6(java.lang.String v)
    {
        this.qty_6 = v;
    }

    public java.lang.String getPurchase_year_6()
    {
        return purchase_year_6;
    }

    public void setPurchase_year_6(java.lang.String v)
    {
        this.purchase_year_6 = v;
    }

    public java.lang.Double getIf_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0()
    {
        return if_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0;
    }

    public void setIf_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0(java.lang.Double v)
    {
        this.if_g18_0_if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_offset_contents_b_75_0_contents_c_11_g18_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0_if_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0()
    {
        return if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0_if_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0;
    }

    public void setIf_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0_if_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g18_0_g18_contents_c_11_contents_c_12_1_contents_c_12_a18_j18_if_and_g18_0_g18_contents_c_11_j18_0_if_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g18_6_contents_c_11_g18_0_round_offset_contents_b_73_0_contents_c_11_g18_1_j18_2_if_and_contents_c_11_0_j18_0_j18_0_if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0 = v;
    }

    public java.lang.Double getIf_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0()
    {
        return if_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0;
    }

    public void setIf_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0(java.lang.Double v)
    {
        this.if_h18_0_round_h18_j18_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0 = v;
    }

    public java.lang.Double getIf_h18_0_k18_l18_if_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2()
    {
        return if_h18_0_k18_l18_if_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h18_0_k18_l18_if_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h18_0_k18_l18_if_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_7()
    {
        return oa_ar_or_fr_7;
    }

    public void setOa_ar_or_fr_7(java.lang.String v)
    {
        this.oa_ar_or_fr_7 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_7()
    {
        return equipment_purchases_or_value_2000_each_item_description_7;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_7(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_7 = v;
    }

    public java.lang.String getQty_7()
    {
        return qty_7;
    }

    public void setQty_7(java.lang.String v)
    {
        this.qty_7 = v;
    }

    public java.lang.String getPurchase_year_7()
    {
        return purchase_year_7;
    }

    public void setPurchase_year_7(java.lang.String v)
    {
        this.purchase_year_7 = v;
    }

    public java.lang.Double getIf_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0()
    {
        return if_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0;
    }

    public void setIf_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0(java.lang.Double v)
    {
        this.if_g19_0_if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_offset_contents_b_75_0_contents_c_11_g19_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0_if_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0()
    {
        return if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0_if_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0;
    }

    public void setIf_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0_if_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g19_0_g19_contents_c_11_contents_c_12_1_contents_c_12_a19_j19_if_and_g19_0_g19_contents_c_11_j19_0_if_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g19_6_contents_c_11_g19_0_round_offset_contents_b_73_0_contents_c_11_g19_1_j19_2_if_and_contents_c_11_0_j19_0_j19_0_if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0 = v;
    }

    public java.lang.Double getIf_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0()
    {
        return if_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0;
    }

    public void setIf_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0(java.lang.Double v)
    {
        this.if_h19_0_round_h19_j19_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0 = v;
    }

    public java.lang.Double getIf_h19_0_k19_l19_if_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2()
    {
        return if_h19_0_k19_l19_if_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h19_0_k19_l19_if_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h19_0_k19_l19_if_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_8()
    {
        return oa_ar_or_fr_8;
    }

    public void setOa_ar_or_fr_8(java.lang.String v)
    {
        this.oa_ar_or_fr_8 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_8()
    {
        return equipment_purchases_or_value_2000_each_item_description_8;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_8(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_8 = v;
    }

    public java.lang.String getQty_8()
    {
        return qty_8;
    }

    public void setQty_8(java.lang.String v)
    {
        this.qty_8 = v;
    }

    public java.lang.String getPurchase_year_8()
    {
        return purchase_year_8;
    }

    public void setPurchase_year_8(java.lang.String v)
    {
        this.purchase_year_8 = v;
    }

    public java.lang.Double getIf_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0()
    {
        return if_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0;
    }

    public void setIf_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0(java.lang.Double v)
    {
        this.if_g20_0_if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_offset_contents_b_75_0_contents_c_11_g20_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0_if_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0()
    {
        return if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0_if_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0;
    }

    public void setIf_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0_if_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g20_0_g20_contents_c_11_contents_c_12_1_contents_c_12_a20_j20_if_and_g20_0_g20_contents_c_11_j20_0_if_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g20_6_contents_c_11_g20_0_round_offset_contents_b_73_0_contents_c_11_g20_1_j20_2_if_and_contents_c_11_0_j20_0_j20_0_if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0 = v;
    }

    public java.lang.Double getIf_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0()
    {
        return if_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0;
    }

    public void setIf_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0(java.lang.Double v)
    {
        this.if_h20_0_round_h20_j20_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0 = v;
    }

    public java.lang.Double getIf_h20_0_k20_l20_if_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2()
    {
        return if_h20_0_k20_l20_if_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h20_0_k20_l20_if_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h20_0_k20_l20_if_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_9()
    {
        return oa_ar_or_fr_9;
    }

    public void setOa_ar_or_fr_9(java.lang.String v)
    {
        this.oa_ar_or_fr_9 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_9()
    {
        return equipment_purchases_or_value_2000_each_item_description_9;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_9(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_9 = v;
    }

    public java.lang.String getQty_9()
    {
        return qty_9;
    }

    public void setQty_9(java.lang.String v)
    {
        this.qty_9 = v;
    }

    public java.lang.String getPurchase_year_9()
    {
        return purchase_year_9;
    }

    public void setPurchase_year_9(java.lang.String v)
    {
        this.purchase_year_9 = v;
    }

    public java.lang.Double getIf_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0()
    {
        return if_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0;
    }

    public void setIf_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0(java.lang.Double v)
    {
        this.if_g21_0_if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_offset_contents_b_75_0_contents_c_11_g21_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0_if_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0()
    {
        return if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0_if_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0;
    }

    public void setIf_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0_if_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g21_0_g21_contents_c_11_contents_c_12_1_contents_c_12_a21_j21_if_and_g21_0_g21_contents_c_11_j21_0_if_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g21_6_contents_c_11_g21_0_round_offset_contents_b_73_0_contents_c_11_g21_1_j21_2_if_and_contents_c_11_0_j21_0_j21_0_if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0 = v;
    }

    public java.lang.Double getIf_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0()
    {
        return if_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0;
    }

    public void setIf_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0(java.lang.Double v)
    {
        this.if_h21_0_round_h21_j21_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0 = v;
    }

    public java.lang.Double getIf_h21_0_k21_l21_if_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2()
    {
        return if_h21_0_k21_l21_if_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h21_0_k21_l21_if_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h21_0_k21_l21_if_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getOa_ar_or_fr_10()
    {
        return oa_ar_or_fr_10;
    }

    public void setOa_ar_or_fr_10(java.lang.String v)
    {
        this.oa_ar_or_fr_10 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_10()
    {
        return equipment_purchases_or_value_2000_each_item_description_10;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_10(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_10 = v;
    }

    public java.lang.String getQty_10()
    {
        return qty_10;
    }

    public void setQty_10(java.lang.String v)
    {
        this.qty_10 = v;
    }

    public java.lang.String getPurchase_year_10()
    {
        return purchase_year_10;
    }

    public void setPurchase_year_10(java.lang.String v)
    {
        this.purchase_year_10 = v;
    }

    public java.lang.Double getIf_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0()
    {
        return if_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0;
    }

    public void setIf_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0(java.lang.Double v)
    {
        this.if_g22_0_if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_offset_contents_b_75_0_contents_c_11_g22_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0_if_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0()
    {
        return if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0_if_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0;
    }

    public void setIf_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0_if_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g22_0_g22_contents_c_11_contents_c_12_1_contents_c_12_a22_j22_if_and_g22_0_g22_contents_c_11_j22_0_if_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g22_6_contents_c_11_g22_0_round_offset_contents_b_73_0_contents_c_11_g22_1_j22_2_if_and_contents_c_11_0_j22_0_j22_0_if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0 = v;
    }

    public java.lang.Double getIf_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0()
    {
        return if_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0;
    }

    public void setIf_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0(java.lang.Double v)
    {
        this.if_h22_0_round_h22_j22_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0 = v;
    }

    public java.lang.Double getIf_h22_0_k22_l22_if_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2()
    {
        return if_h22_0_k22_l22_if_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h22_0_k22_l22_if_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h22_0_k22_l22_if_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0_5_year_total()
    {
        return if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0_5_year_total;
    }

    public void setIf_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0_5_year_total(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g23_0_g23_contents_c_11_contents_c_12_1_contents_c_12_a23_j23_if_and_g23_0_g23_contents_c_11_j23_0_5_year_total = v;
    }

    public java.lang.Double getB_current_cost_or_value_sum_i14_i23()
    {
        return b_current_cost_or_value_sum_i14_i23;
    }

    public void setB_current_cost_or_value_sum_i14_i23(java.lang.Double v)
    {
        this.b_current_cost_or_value_sum_i14_i23 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0_sum_j14_j23()
    {
        return if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0_sum_j14_j23;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0_sum_j14_j23(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_round_offset_contents_b_73_0_contents_c_11_g23_1_j23_2_if_and_contents_c_11_0_j23_0_j23_0_sum_j14_j23 = v;
    }

    public java.lang.Double getIf_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2_sum_k14_k23()
    {
        return if_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2_sum_k14_k23;
    }

    public void setIf_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2_sum_k14_k23(java.lang.Double v)
    {
        this.if_h23_0_round_h23_j23_if_contents_c_12_4_1_0_2_sum_k14_k23 = v;
    }

    public java.lang.Double getIf_h23_0_k23_l23_sum_l14_l23()
    {
        return if_h23_0_k23_l23_sum_l14_l23;
    }

    public void setIf_h23_0_k23_l23_sum_l14_l23(java.lang.Double v)
    {
        this.if_h23_0_k23_l23_sum_l14_l23 = v;
    }

    public java.lang.Double getIf_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0_year_purchased()
    {
        return if_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0_year_purchased;
    }

    public void setIf_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0_year_purchased(java.lang.Double v)
    {
        this.if_g23_0_if_and_contents_c_11_0_contents_c_11_g23_6_contents_c_11_g23_0_offset_contents_b_75_0_contents_c_11_g23_0_year_purchased = v;
    }

    public java.lang.Double getSum_i14_i23_if_contents_c_11_year_now_contents_c_11()
    {
        return sum_i14_i23_if_contents_c_11_year_now_contents_c_11;
    }

    public void setSum_i14_i23_if_contents_c_11_year_now_contents_c_11(java.lang.Double v)
    {
        this.sum_i14_i23_if_contents_c_11_year_now_contents_c_11 = v;
    }

    public java.lang.Double getSum_j14_j23_h26_1()
    {
        return sum_j14_j23_h26_1;
    }

    public void setSum_j14_j23_h26_1(java.lang.Double v)
    {
        this.sum_j14_j23_h26_1 = v;
    }

    public java.lang.Double getSum_k14_k23_i26_1()
    {
        return sum_k14_k23_i26_1;
    }

    public void setSum_k14_k23_i26_1(java.lang.Double v)
    {
        this.sum_k14_k23_i26_1 = v;
    }

    public java.lang.Double getSum_l14_l23_j26_1()
    {
        return sum_l14_l23_j26_1;
    }

    public void setSum_l14_l23_j26_1(java.lang.Double v)
    {
        this.sum_l14_l23_j26_1 = v;
    }

    public java.lang.Double getSum_m14_m23_k26_1()
    {
        return sum_m14_m23_k26_1;
    }

    public void setSum_m14_m23_k26_1(java.lang.Double v)
    {
        this.sum_m14_m23_k26_1 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_11()
    {
        return equipment_purchases_or_value_2000_each_item_description_11;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_11(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_11 = v;
    }

    public java.lang.String getQty_11()
    {
        return qty_11;
    }

    public void setQty_11(java.lang.String v)
    {
        this.qty_11 = v;
    }

    public java.lang.String getPurchase_year_11()
    {
        return purchase_year_11;
    }

    public void setPurchase_year_11(java.lang.String v)
    {
        this.purchase_year_11 = v;
    }

    public java.lang.Double getA_this_year_from_grid_below_2()
    {
        return a_this_year_from_grid_below_2;
    }

    public void setA_this_year_from_grid_below_2(java.lang.Double v)
    {
        this.a_this_year_from_grid_below_2 = v;
    }

    public java.lang.Double getPrior_cost_or_value_if_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0()
    {
        return prior_cost_or_value_if_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0;
    }

    public void setPrior_cost_or_value_if_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0(java.lang.Double v)
    {
        this.prior_cost_or_value_if_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0 = v;
    }

    public java.lang.Double getC_start_accum_deprec_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0()
    {
        return c_start_accum_deprec_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0;
    }

    public void setC_start_accum_deprec_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0(java.lang.Double v)
    {
        this.c_start_accum_deprec_if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0 = v;
    }

    public java.lang.Double getD_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0()
    {
        return d_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0;
    }

    public void setD_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0(java.lang.Double v)
    {
        this.d_depr_this_year_a_x_b_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0 = v;
    }

    public java.lang.Double getEnd_accum_deprec_c_d_if_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2()
    {
        return end_accum_deprec_c_d_if_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2;
    }

    public void setEnd_accum_deprec_c_d_if_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.end_accum_deprec_c_d_if_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_2()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_2;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_2(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_2 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_12()
    {
        return equipment_purchases_or_value_2000_each_item_description_12;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_12(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_12 = v;
    }

    public java.lang.String getQty_12()
    {
        return qty_12;
    }

    public void setQty_12(java.lang.String v)
    {
        this.qty_12 = v;
    }

    public java.lang.String getPurchase_year_12()
    {
        return purchase_year_12;
    }

    public void setPurchase_year_12(java.lang.String v)
    {
        this.purchase_year_12 = v;
    }

    public java.lang.Double getIf_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0()
    {
        return if_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0;
    }

    public void setIf_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0(java.lang.Double v)
    {
        this.if_g32_0_if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_offset_contents_b_79_0_contents_c_11_g32_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0_if_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0()
    {
        return if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0_if_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0;
    }

    public void setIf_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0_if_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g32_0_g32_contents_c_11_contents_c_12_1_contents_c_12_a32_j32_if_and_g32_0_g32_contents_c_11_j32_0_if_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g32_9_contents_c_11_g32_0_round_offset_contents_b_77_0_contents_c_11_g32_1_j32_2_if_and_contents_c_11_0_j32_0_j32_0_if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0 = v;
    }

    public java.lang.Double getIf_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0()
    {
        return if_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0;
    }

    public void setIf_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0(java.lang.Double v)
    {
        this.if_h32_0_round_h32_j32_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0 = v;
    }

    public java.lang.Double getIf_h32_0_k32_l32_if_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2()
    {
        return if_h32_0_k32_l32_if_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h32_0_k32_l32_if_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h32_0_k32_l32_if_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_3()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_3;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_3(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_3 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_13()
    {
        return equipment_purchases_or_value_2000_each_item_description_13;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_13(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_13 = v;
    }

    public java.lang.String getQty_13()
    {
        return qty_13;
    }

    public void setQty_13(java.lang.String v)
    {
        this.qty_13 = v;
    }

    public java.lang.String getPurchase_year_13()
    {
        return purchase_year_13;
    }

    public void setPurchase_year_13(java.lang.String v)
    {
        this.purchase_year_13 = v;
    }

    public java.lang.Double getIf_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0()
    {
        return if_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0;
    }

    public void setIf_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0(java.lang.Double v)
    {
        this.if_g33_0_if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_offset_contents_b_79_0_contents_c_11_g33_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0_if_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0()
    {
        return if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0_if_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0;
    }

    public void setIf_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0_if_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g33_0_g33_contents_c_11_contents_c_12_1_contents_c_12_a33_j33_if_and_g33_0_g33_contents_c_11_j33_0_if_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g33_9_contents_c_11_g33_0_round_offset_contents_b_77_0_contents_c_11_g33_1_j33_2_if_and_contents_c_11_0_j33_0_j33_0_if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0 = v;
    }

    public java.lang.Double getIf_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0()
    {
        return if_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0;
    }

    public void setIf_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0(java.lang.Double v)
    {
        this.if_h33_0_round_h33_j33_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0 = v;
    }

    public java.lang.Double getIf_h33_0_k33_l33_if_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2()
    {
        return if_h33_0_k33_l33_if_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h33_0_k33_l33_if_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h33_0_k33_l33_if_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_4()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_4;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_4(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_4 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_14()
    {
        return equipment_purchases_or_value_2000_each_item_description_14;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_14(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_14 = v;
    }

    public java.lang.String getQty_14()
    {
        return qty_14;
    }

    public void setQty_14(java.lang.String v)
    {
        this.qty_14 = v;
    }

    public java.lang.String getPurchase_year_14()
    {
        return purchase_year_14;
    }

    public void setPurchase_year_14(java.lang.String v)
    {
        this.purchase_year_14 = v;
    }

    public java.lang.Double getIf_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0()
    {
        return if_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0;
    }

    public void setIf_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0(java.lang.Double v)
    {
        this.if_g34_0_if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_offset_contents_b_79_0_contents_c_11_g34_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0_if_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0()
    {
        return if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0_if_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0;
    }

    public void setIf_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0_if_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g34_0_g34_contents_c_11_contents_c_12_1_contents_c_12_a34_j34_if_and_g34_0_g34_contents_c_11_j34_0_if_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g34_9_contents_c_11_g34_0_round_offset_contents_b_77_0_contents_c_11_g34_1_j34_2_if_and_contents_c_11_0_j34_0_j34_0_if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0 = v;
    }

    public java.lang.Double getIf_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0()
    {
        return if_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0;
    }

    public void setIf_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0(java.lang.Double v)
    {
        this.if_h34_0_round_h34_j34_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0 = v;
    }

    public java.lang.Double getIf_h34_0_k34_l34_if_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2()
    {
        return if_h34_0_k34_l34_if_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h34_0_k34_l34_if_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h34_0_k34_l34_if_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_5()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_5;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_5(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_5 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_15()
    {
        return equipment_purchases_or_value_2000_each_item_description_15;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_15(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_15 = v;
    }

    public java.lang.String getQty_15()
    {
        return qty_15;
    }

    public void setQty_15(java.lang.String v)
    {
        this.qty_15 = v;
    }

    public java.lang.String getPurchase_year_15()
    {
        return purchase_year_15;
    }

    public void setPurchase_year_15(java.lang.String v)
    {
        this.purchase_year_15 = v;
    }

    public java.lang.Double getIf_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0()
    {
        return if_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0;
    }

    public void setIf_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0(java.lang.Double v)
    {
        this.if_g35_0_if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_offset_contents_b_79_0_contents_c_11_g35_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0_if_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0()
    {
        return if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0_if_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0;
    }

    public void setIf_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0_if_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g35_0_g35_contents_c_11_contents_c_12_1_contents_c_12_a35_j35_if_and_g35_0_g35_contents_c_11_j35_0_if_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g35_9_contents_c_11_g35_0_round_offset_contents_b_77_0_contents_c_11_g35_1_j35_2_if_and_contents_c_11_0_j35_0_j35_0_if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0 = v;
    }

    public java.lang.Double getIf_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0()
    {
        return if_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0;
    }

    public void setIf_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0(java.lang.Double v)
    {
        this.if_h35_0_round_h35_j35_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0 = v;
    }

    public java.lang.Double getIf_h35_0_k35_l35_if_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2()
    {
        return if_h35_0_k35_l35_if_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h35_0_k35_l35_if_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h35_0_k35_l35_if_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_6()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_6;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_6(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_6 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_16()
    {
        return equipment_purchases_or_value_2000_each_item_description_16;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_16(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_16 = v;
    }

    public java.lang.String getQty_16()
    {
        return qty_16;
    }

    public void setQty_16(java.lang.String v)
    {
        this.qty_16 = v;
    }

    public java.lang.String getPurchase_year_16()
    {
        return purchase_year_16;
    }

    public void setPurchase_year_16(java.lang.String v)
    {
        this.purchase_year_16 = v;
    }

    public java.lang.Double getIf_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0()
    {
        return if_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0;
    }

    public void setIf_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0(java.lang.Double v)
    {
        this.if_g36_0_if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_offset_contents_b_79_0_contents_c_11_g36_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0_if_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0()
    {
        return if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0_if_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0;
    }

    public void setIf_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0_if_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g36_0_g36_contents_c_11_contents_c_12_1_contents_c_12_a36_j36_if_and_g36_0_g36_contents_c_11_j36_0_if_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g36_9_contents_c_11_g36_0_round_offset_contents_b_77_0_contents_c_11_g36_1_j36_2_if_and_contents_c_11_0_j36_0_j36_0_if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0 = v;
    }

    public java.lang.Double getIf_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0()
    {
        return if_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0;
    }

    public void setIf_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0(java.lang.Double v)
    {
        this.if_h36_0_round_h36_j36_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0 = v;
    }

    public java.lang.Double getIf_h36_0_k36_l36_if_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2()
    {
        return if_h36_0_k36_l36_if_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h36_0_k36_l36_if_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h36_0_k36_l36_if_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_7()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_7;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_7(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_7 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_17()
    {
        return equipment_purchases_or_value_2000_each_item_description_17;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_17(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_17 = v;
    }

    public java.lang.String getQty_17()
    {
        return qty_17;
    }

    public void setQty_17(java.lang.String v)
    {
        this.qty_17 = v;
    }

    public java.lang.String getPurchase_year_17()
    {
        return purchase_year_17;
    }

    public void setPurchase_year_17(java.lang.String v)
    {
        this.purchase_year_17 = v;
    }

    public java.lang.Double getIf_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0()
    {
        return if_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0;
    }

    public void setIf_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0(java.lang.Double v)
    {
        this.if_g37_0_if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_offset_contents_b_79_0_contents_c_11_g37_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0_if_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0()
    {
        return if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0_if_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0;
    }

    public void setIf_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0_if_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g37_0_g37_contents_c_11_contents_c_12_1_contents_c_12_a37_j37_if_and_g37_0_g37_contents_c_11_j37_0_if_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g37_9_contents_c_11_g37_0_round_offset_contents_b_77_0_contents_c_11_g37_1_j37_2_if_and_contents_c_11_0_j37_0_j37_0_if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0 = v;
    }

    public java.lang.Double getIf_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0()
    {
        return if_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0;
    }

    public void setIf_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0(java.lang.Double v)
    {
        this.if_h37_0_round_h37_j37_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0 = v;
    }

    public java.lang.Double getIf_h37_0_k37_l37_if_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2()
    {
        return if_h37_0_k37_l37_if_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h37_0_k37_l37_if_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h37_0_k37_l37_if_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_8()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_8;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_8(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_8 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_18()
    {
        return equipment_purchases_or_value_2000_each_item_description_18;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_18(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_18 = v;
    }

    public java.lang.String getQty_18()
    {
        return qty_18;
    }

    public void setQty_18(java.lang.String v)
    {
        this.qty_18 = v;
    }

    public java.lang.String getPurchase_year_18()
    {
        return purchase_year_18;
    }

    public void setPurchase_year_18(java.lang.String v)
    {
        this.purchase_year_18 = v;
    }

    public java.lang.Double getIf_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0()
    {
        return if_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0;
    }

    public void setIf_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0(java.lang.Double v)
    {
        this.if_g38_0_if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_offset_contents_b_79_0_contents_c_11_g38_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0_if_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0()
    {
        return if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0_if_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0;
    }

    public void setIf_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0_if_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g38_0_g38_contents_c_11_contents_c_12_1_contents_c_12_a38_j38_if_and_g38_0_g38_contents_c_11_j38_0_if_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g38_9_contents_c_11_g38_0_round_offset_contents_b_77_0_contents_c_11_g38_1_j38_2_if_and_contents_c_11_0_j38_0_j38_0_if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0 = v;
    }

    public java.lang.Double getIf_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0()
    {
        return if_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0;
    }

    public void setIf_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0(java.lang.Double v)
    {
        this.if_h38_0_round_h38_j38_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0 = v;
    }

    public java.lang.Double getIf_h38_0_k38_l38_if_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2()
    {
        return if_h38_0_k38_l38_if_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h38_0_k38_l38_if_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h38_0_k38_l38_if_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_9()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_9;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_9(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_9 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_19()
    {
        return equipment_purchases_or_value_2000_each_item_description_19;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_19(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_19 = v;
    }

    public java.lang.String getQty_19()
    {
        return qty_19;
    }

    public void setQty_19(java.lang.String v)
    {
        this.qty_19 = v;
    }

    public java.lang.String getPurchase_year_19()
    {
        return purchase_year_19;
    }

    public void setPurchase_year_19(java.lang.String v)
    {
        this.purchase_year_19 = v;
    }

    public java.lang.Double getIf_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0()
    {
        return if_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0;
    }

    public void setIf_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0(java.lang.Double v)
    {
        this.if_g39_0_if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_offset_contents_b_79_0_contents_c_11_g39_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0_if_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0()
    {
        return if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0_if_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0;
    }

    public void setIf_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0_if_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g39_0_g39_contents_c_11_contents_c_12_1_contents_c_12_a39_j39_if_and_g39_0_g39_contents_c_11_j39_0_if_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g39_9_contents_c_11_g39_0_round_offset_contents_b_77_0_contents_c_11_g39_1_j39_2_if_and_contents_c_11_0_j39_0_j39_0_if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0 = v;
    }

    public java.lang.Double getIf_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0()
    {
        return if_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0;
    }

    public void setIf_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0(java.lang.Double v)
    {
        this.if_h39_0_round_h39_j39_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0 = v;
    }

    public java.lang.Double getIf_h39_0_k39_l39_if_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2()
    {
        return if_h39_0_k39_l39_if_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h39_0_k39_l39_if_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h39_0_k39_l39_if_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.String getSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_10()
    {
        return seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_10;
    }

    public void setSeven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_10(java.lang.String v)
    {
        this.seven_year_assets_are_all_assets_except_electronic_equipment_and_trailers_thrones_pavilions_cooking_equipment_crowns_etc_are_all_7_year_assets_10 = v;
    }

    public java.lang.String getEquipment_purchases_or_value_2000_each_item_description_20()
    {
        return equipment_purchases_or_value_2000_each_item_description_20;
    }

    public void setEquipment_purchases_or_value_2000_each_item_description_20(java.lang.String v)
    {
        this.equipment_purchases_or_value_2000_each_item_description_20 = v;
    }

    public java.lang.String getQty_20()
    {
        return qty_20;
    }

    public void setQty_20(java.lang.String v)
    {
        this.qty_20 = v;
    }

    public java.lang.String getPurchase_year_20()
    {
        return purchase_year_20;
    }

    public void setPurchase_year_20(java.lang.String v)
    {
        this.purchase_year_20 = v;
    }

    public java.lang.Double getIf_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0()
    {
        return if_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0;
    }

    public void setIf_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0(java.lang.Double v)
    {
        this.if_g40_0_if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_offset_contents_b_79_0_contents_c_11_g40_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0_if_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0()
    {
        return if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0_if_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0;
    }

    public void setIf_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0_if_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g40_0_g40_contents_c_11_contents_c_12_1_contents_c_12_a40_j40_if_and_g40_0_g40_contents_c_11_j40_0_if_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0 = v;
    }

    public java.lang.String getB_current_cost_or_value_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0()
    {
        return b_current_cost_or_value_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0;
    }

    public void setB_current_cost_or_value_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0(java.lang.String v)
    {
        this.b_current_cost_or_value_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0()
    {
        return if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g40_9_contents_c_11_g40_0_round_offset_contents_b_77_0_contents_c_11_g40_1_j40_2_if_and_contents_c_11_0_j40_0_j40_0_if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0 = v;
    }

    public java.lang.Double getIf_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0()
    {
        return if_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0;
    }

    public void setIf_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0(java.lang.Double v)
    {
        this.if_h40_0_round_h40_j40_if_contents_c_12_4_1_0_2_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0 = v;
    }

    public java.lang.Double getIf_h40_0_k40_l40_if_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2()
    {
        return if_h40_0_k40_l40_if_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2;
    }

    public void setIf_h40_0_k40_l40_if_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2(java.lang.Double v)
    {
        this.if_h40_0_k40_l40_if_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2 = v;
    }

    public java.lang.Double getIf_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0_7_year_total()
    {
        return if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0_7_year_total;
    }

    public void setIf_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0_7_year_total(java.lang.Double v)
    {
        this.if_and_contents_c_13_sequential_g41_0_g41_contents_c_11_contents_c_12_1_contents_c_12_a41_j41_if_and_g41_0_g41_contents_c_11_j41_0_7_year_total = v;
    }

    public java.lang.Double getB_current_cost_or_value_sum_i32_i41()
    {
        return b_current_cost_or_value_sum_i32_i41;
    }

    public void setB_current_cost_or_value_sum_i32_i41(java.lang.Double v)
    {
        this.b_current_cost_or_value_sum_i32_i41 = v;
    }

    public java.lang.Double getIf_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0_sum_j32_j41()
    {
        return if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0_sum_j32_j41;
    }

    public void setIf_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0_sum_j32_j41(java.lang.Double v)
    {
        this.if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_round_offset_contents_b_77_0_contents_c_11_g41_1_j41_2_if_and_contents_c_11_0_j41_0_j41_0_sum_j32_j41 = v;
    }

    public java.lang.Double getIf_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2_sum_k32_k41()
    {
        return if_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2_sum_k32_k41;
    }

    public void setIf_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2_sum_k32_k41(java.lang.Double v)
    {
        this.if_h41_0_round_h41_j41_if_contents_c_12_4_1_0_2_sum_k32_k41 = v;
    }

    public java.lang.Double getIf_h41_0_k41_l41_sum_l32_l41()
    {
        return if_h41_0_k41_l41_sum_l32_l41;
    }

    public void setIf_h41_0_k41_l41_sum_l32_l41(java.lang.Double v)
    {
        this.if_h41_0_k41_l41_sum_l32_l41 = v;
    }

    public java.lang.Double get_7_year_total_year_purchased()
    {
        return _7_year_total_year_purchased;
    }

    public void set_7_year_total_year_purchased(java.lang.Double v)
    {
        this._7_year_total_year_purchased = v;
    }

    public java.lang.Double getNote_depreciation_this_year_d_is_only_calculated_during_4th_quarter_for_the_year_if_contents_c_11_year_now_contents_c_11()
    {
        return note_depreciation_this_year_d_is_only_calculated_during_4th_quarter_for_the_year_if_contents_c_11_year_now_contents_c_11;
    }

    public void setNote_depreciation_this_year_d_is_only_calculated_during_4th_quarter_for_the_year_if_contents_c_11_year_now_contents_c_11(java.lang.Double v)
    {
        this.note_depreciation_this_year_d_is_only_calculated_during_4th_quarter_for_the_year_if_contents_c_11_year_now_contents_c_11 = v;
    }

    public java.lang.Double getIf_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0_f44_1()
    {
        return if_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0_f44_1;
    }

    public void setIf_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0_f44_1(java.lang.Double v)
    {
        this.if_g41_0_if_and_contents_c_11_0_contents_c_11_g41_9_contents_c_11_g41_0_offset_contents_b_79_0_contents_c_11_g41_0_f44_1 = v;
    }

    public java.lang.Double getSum_i32_i41_g44_1()
    {
        return sum_i32_i41_g44_1;
    }

    public void setSum_i32_i41_g44_1(java.lang.Double v)
    {
        this.sum_i32_i41_g44_1 = v;
    }

    public java.lang.Double getSum_j32_j41_h44_1()
    {
        return sum_j32_j41_h44_1;
    }

    public void setSum_j32_j41_h44_1(java.lang.Double v)
    {
        this.sum_j32_j41_h44_1 = v;
    }

    public java.lang.Double getSum_k32_k41_i44_1()
    {
        return sum_k32_k41_i44_1;
    }

    public void setSum_k32_k41_i44_1(java.lang.Double v)
    {
        this.sum_k32_k41_i44_1 = v;
    }

    public java.lang.Double getSum_l32_l41_j44_1()
    {
        return sum_l32_l41_j44_1;
    }

    public void setSum_l32_l41_j44_1(java.lang.Double v)
    {
        this.sum_l32_l41_j44_1 = v;
    }

    public java.lang.Double getSum_m32_m41_k44_1()
    {
        return sum_m32_m41_k44_1;
    }

    public void setSum_m32_m41_k44_1(java.lang.Double v)
    {
        this.sum_m32_m41_k44_1 = v;
    }

    public java.lang.Double get_0_1249_5_year_total_7_year_total()
    {
        return _0_1249_5_year_total_7_year_total;
    }

    public void set_0_1249_5_year_total_7_year_total(java.lang.Double v)
    {
        this._0_1249_5_year_total_7_year_total = v;
    }

    public java.lang.Double get_0_0893_i24_i42()
    {
        return _0_0893_i24_i42;
    }

    public void set_0_0893_i24_i42(java.lang.Double v)
    {
        this._0_0893_i24_i42 = v;
    }

    public java.lang.Double get_0_0892_j24_j42()
    {
        return _0_0892_j24_j42;
    }

    public void set_0_0892_j24_j42(java.lang.Double v)
    {
        this._0_0892_j24_j42 = v;
    }

    public java.lang.Double get_0_0893_k24_k42()
    {
        return _0_0893_k24_k42;
    }

    public void set_0_0893_k24_k42(java.lang.Double v)
    {
        this._0_0893_k24_k42 = v;
    }

    public java.lang.Double get_0_0446_l24_l42()
    {
        return _0_0446_l24_l42;
    }

    public void set_0_0446_l24_l42(java.lang.Double v)
    {
        this._0_0446_l24_l42 = v;
    }

    public DEPR_DTL_8Bean()
    {
    }

}
