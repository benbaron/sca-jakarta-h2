package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet LIABILITY_DTL_5b */
public class LIABILITY_DTL_5bBean
{

    private java.lang.Double liability_dtl_5b_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String deferred_revenue_event;
    private java.lang.String event;
    private java.lang.String prior_amount;
    private java.lang.String current_amount;
    private java.lang.String deferred_revenue_event_2;
    private java.lang.String event_2;
    private java.lang.String prior_amount_2;
    private java.lang.String current_amount_2;
    private java.lang.String deferred_revenue_event_3;
    private java.lang.String event_3;
    private java.lang.String prior_amount_3;
    private java.lang.String current_amount_3;
    private java.lang.String deferred_revenue_event_4;
    private java.lang.String event_4;
    private java.lang.String prior_amount_4;
    private java.lang.String current_amount_4;
    private java.lang.String deferred_revenue_event_5;
    private java.lang.String event_5;
    private java.lang.String prior_amount_5;
    private java.lang.String current_amount_5;
    private java.lang.String deferred_revenue_event_6;
    private java.lang.String event_6;
    private java.lang.String prior_amount_6;
    private java.lang.String current_amount_6;
    private java.lang.String deferred_revenue_event_7;
    private java.lang.String event_7;
    private java.lang.String prior_amount_7;
    private java.lang.String current_amount_7;
    private java.lang.String deferred_revenue_event_8;
    private java.lang.String event_8;
    private java.lang.String prior_amount_8;
    private java.lang.String current_amount_8;
    private java.lang.String deferred_revenue_event_9;
    private java.lang.String event_9;
    private java.lang.String prior_amount_9;
    private java.lang.String current_amount_9;
    private java.lang.String deferred_revenue_event_10;
    private java.lang.String event_10;
    private java.lang.String prior_amount_10;
    private java.lang.String current_amount_10;
    private java.lang.String deferred_revenue_event_11;
    private java.lang.String event_11;
    private java.lang.String prior_amount_11;
    private java.lang.String current_amount_11;
    private java.lang.String deferred_revenue_event_12;
    private java.lang.String event_12;
    private java.lang.String prior_amount_12;
    private java.lang.String current_amount_12;
    private java.lang.String deferred_revenue_event_13;
    private java.lang.String event_13;
    private java.lang.String prior_amount_13;
    private java.lang.String current_amount_13;
    private java.lang.String deferred_revenue_event_14;
    private java.lang.String event_14;
    private java.lang.String prior_amount_14;
    private java.lang.String current_amount_14;
    private java.lang.String deferred_revenue_event_15;
    private java.lang.String event_15;
    private java.lang.String prior_amount_15;
    private java.lang.String current_amount_15;
    private java.lang.Double prior_amount_total;
    private java.lang.Double current_amount_sum_e16_e30;
    private java.lang.String payables_owed_to;
    private java.lang.String reason;
    private java.lang.String prior_amount_16;
    private java.lang.String current_amount_16;
    private java.lang.String payables_owed_to_2;
    private java.lang.String reason_2;
    private java.lang.String prior_amount_17;
    private java.lang.String current_amount_17;
    private java.lang.String payables_owed_to_3;
    private java.lang.String reason_3;
    private java.lang.String prior_amount_18;
    private java.lang.String current_amount_18;
    private java.lang.String payables_owed_to_4;
    private java.lang.String reason_4;
    private java.lang.String prior_amount_19;
    private java.lang.String current_amount_19;
    private java.lang.String payables_owed_to_5;
    private java.lang.String reason_5;
    private java.lang.String prior_amount_20;
    private java.lang.String current_amount_20;
    private java.lang.String payables_owed_to_6;
    private java.lang.String reason_6;
    private java.lang.String prior_amount_21;
    private java.lang.String current_amount_21;
    private java.lang.String payables_owed_to_7;
    private java.lang.String reason_7;
    private java.lang.String prior_amount_22;
    private java.lang.String current_amount_22;
    private java.lang.Double prior_amount_total_2;
    private java.lang.Double current_amount_sum_e37_e43;
    private java.lang.String other_liabilities_owed_to;
    private java.lang.String reason_8;
    private java.lang.String prior_amount_23;
    private java.lang.String current_amount_23;
    private java.lang.String other_liabilities_owed_to_2;
    private java.lang.String reason_9;
    private java.lang.String prior_amount_24;
    private java.lang.String current_amount_24;
    private java.lang.String other_liabilities_owed_to_3;
    private java.lang.String reason_10;
    private java.lang.String prior_amount_25;
    private java.lang.String current_amount_25;
    private java.lang.String other_liabilities_owed_to_4;
    private java.lang.String reason_11;
    private java.lang.String prior_amount_26;
    private java.lang.String current_amount_26;
    private java.lang.String other_liabilities_owed_to_5;
    private java.lang.String reason_12;
    private java.lang.String prior_amount_27;
    private java.lang.String current_amount_27;
    private java.lang.String other_liabilities_owed_to_6;
    private java.lang.String reason_13;
    private java.lang.String prior_amount_28;
    private java.lang.String current_amount_28;
    private java.lang.String other_liabilities_owed_to_7;
    private java.lang.String reason_14;
    private java.lang.String prior_amount_29;
    private java.lang.String current_amount_29;
    private java.lang.Double prior_amount_total_3;
    private java.lang.Double current_amount_sum_e49_e55;

    public java.lang.Double getLiability_dtl_5b_r2c3()
    {
        return liability_dtl_5b_r2c3;
    }

    public void setLiability_dtl_5b_r2c3(java.lang.Double v)
    {
        this.liability_dtl_5b_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getDeferred_revenue_event()
    {
        return deferred_revenue_event;
    }

    public void setDeferred_revenue_event(java.lang.String v)
    {
        this.deferred_revenue_event = v;
    }

    public java.lang.String getEvent()
    {
        return event;
    }

    public void setEvent(java.lang.String v)
    {
        this.event = v;
    }

    public java.lang.String getPrior_amount()
    {
        return prior_amount;
    }

    public void setPrior_amount(java.lang.String v)
    {
        this.prior_amount = v;
    }

    public java.lang.String getCurrent_amount()
    {
        return current_amount;
    }

    public void setCurrent_amount(java.lang.String v)
    {
        this.current_amount = v;
    }

    public java.lang.String getDeferred_revenue_event_2()
    {
        return deferred_revenue_event_2;
    }

    public void setDeferred_revenue_event_2(java.lang.String v)
    {
        this.deferred_revenue_event_2 = v;
    }

    public java.lang.String getEvent_2()
    {
        return event_2;
    }

    public void setEvent_2(java.lang.String v)
    {
        this.event_2 = v;
    }

    public java.lang.String getPrior_amount_2()
    {
        return prior_amount_2;
    }

    public void setPrior_amount_2(java.lang.String v)
    {
        this.prior_amount_2 = v;
    }

    public java.lang.String getCurrent_amount_2()
    {
        return current_amount_2;
    }

    public void setCurrent_amount_2(java.lang.String v)
    {
        this.current_amount_2 = v;
    }

    public java.lang.String getDeferred_revenue_event_3()
    {
        return deferred_revenue_event_3;
    }

    public void setDeferred_revenue_event_3(java.lang.String v)
    {
        this.deferred_revenue_event_3 = v;
    }

    public java.lang.String getEvent_3()
    {
        return event_3;
    }

    public void setEvent_3(java.lang.String v)
    {
        this.event_3 = v;
    }

    public java.lang.String getPrior_amount_3()
    {
        return prior_amount_3;
    }

    public void setPrior_amount_3(java.lang.String v)
    {
        this.prior_amount_3 = v;
    }

    public java.lang.String getCurrent_amount_3()
    {
        return current_amount_3;
    }

    public void setCurrent_amount_3(java.lang.String v)
    {
        this.current_amount_3 = v;
    }

    public java.lang.String getDeferred_revenue_event_4()
    {
        return deferred_revenue_event_4;
    }

    public void setDeferred_revenue_event_4(java.lang.String v)
    {
        this.deferred_revenue_event_4 = v;
    }

    public java.lang.String getEvent_4()
    {
        return event_4;
    }

    public void setEvent_4(java.lang.String v)
    {
        this.event_4 = v;
    }

    public java.lang.String getPrior_amount_4()
    {
        return prior_amount_4;
    }

    public void setPrior_amount_4(java.lang.String v)
    {
        this.prior_amount_4 = v;
    }

    public java.lang.String getCurrent_amount_4()
    {
        return current_amount_4;
    }

    public void setCurrent_amount_4(java.lang.String v)
    {
        this.current_amount_4 = v;
    }

    public java.lang.String getDeferred_revenue_event_5()
    {
        return deferred_revenue_event_5;
    }

    public void setDeferred_revenue_event_5(java.lang.String v)
    {
        this.deferred_revenue_event_5 = v;
    }

    public java.lang.String getEvent_5()
    {
        return event_5;
    }

    public void setEvent_5(java.lang.String v)
    {
        this.event_5 = v;
    }

    public java.lang.String getPrior_amount_5()
    {
        return prior_amount_5;
    }

    public void setPrior_amount_5(java.lang.String v)
    {
        this.prior_amount_5 = v;
    }

    public java.lang.String getCurrent_amount_5()
    {
        return current_amount_5;
    }

    public void setCurrent_amount_5(java.lang.String v)
    {
        this.current_amount_5 = v;
    }

    public java.lang.String getDeferred_revenue_event_6()
    {
        return deferred_revenue_event_6;
    }

    public void setDeferred_revenue_event_6(java.lang.String v)
    {
        this.deferred_revenue_event_6 = v;
    }

    public java.lang.String getEvent_6()
    {
        return event_6;
    }

    public void setEvent_6(java.lang.String v)
    {
        this.event_6 = v;
    }

    public java.lang.String getPrior_amount_6()
    {
        return prior_amount_6;
    }

    public void setPrior_amount_6(java.lang.String v)
    {
        this.prior_amount_6 = v;
    }

    public java.lang.String getCurrent_amount_6()
    {
        return current_amount_6;
    }

    public void setCurrent_amount_6(java.lang.String v)
    {
        this.current_amount_6 = v;
    }

    public java.lang.String getDeferred_revenue_event_7()
    {
        return deferred_revenue_event_7;
    }

    public void setDeferred_revenue_event_7(java.lang.String v)
    {
        this.deferred_revenue_event_7 = v;
    }

    public java.lang.String getEvent_7()
    {
        return event_7;
    }

    public void setEvent_7(java.lang.String v)
    {
        this.event_7 = v;
    }

    public java.lang.String getPrior_amount_7()
    {
        return prior_amount_7;
    }

    public void setPrior_amount_7(java.lang.String v)
    {
        this.prior_amount_7 = v;
    }

    public java.lang.String getCurrent_amount_7()
    {
        return current_amount_7;
    }

    public void setCurrent_amount_7(java.lang.String v)
    {
        this.current_amount_7 = v;
    }

    public java.lang.String getDeferred_revenue_event_8()
    {
        return deferred_revenue_event_8;
    }

    public void setDeferred_revenue_event_8(java.lang.String v)
    {
        this.deferred_revenue_event_8 = v;
    }

    public java.lang.String getEvent_8()
    {
        return event_8;
    }

    public void setEvent_8(java.lang.String v)
    {
        this.event_8 = v;
    }

    public java.lang.String getPrior_amount_8()
    {
        return prior_amount_8;
    }

    public void setPrior_amount_8(java.lang.String v)
    {
        this.prior_amount_8 = v;
    }

    public java.lang.String getCurrent_amount_8()
    {
        return current_amount_8;
    }

    public void setCurrent_amount_8(java.lang.String v)
    {
        this.current_amount_8 = v;
    }

    public java.lang.String getDeferred_revenue_event_9()
    {
        return deferred_revenue_event_9;
    }

    public void setDeferred_revenue_event_9(java.lang.String v)
    {
        this.deferred_revenue_event_9 = v;
    }

    public java.lang.String getEvent_9()
    {
        return event_9;
    }

    public void setEvent_9(java.lang.String v)
    {
        this.event_9 = v;
    }

    public java.lang.String getPrior_amount_9()
    {
        return prior_amount_9;
    }

    public void setPrior_amount_9(java.lang.String v)
    {
        this.prior_amount_9 = v;
    }

    public java.lang.String getCurrent_amount_9()
    {
        return current_amount_9;
    }

    public void setCurrent_amount_9(java.lang.String v)
    {
        this.current_amount_9 = v;
    }

    public java.lang.String getDeferred_revenue_event_10()
    {
        return deferred_revenue_event_10;
    }

    public void setDeferred_revenue_event_10(java.lang.String v)
    {
        this.deferred_revenue_event_10 = v;
    }

    public java.lang.String getEvent_10()
    {
        return event_10;
    }

    public void setEvent_10(java.lang.String v)
    {
        this.event_10 = v;
    }

    public java.lang.String getPrior_amount_10()
    {
        return prior_amount_10;
    }

    public void setPrior_amount_10(java.lang.String v)
    {
        this.prior_amount_10 = v;
    }

    public java.lang.String getCurrent_amount_10()
    {
        return current_amount_10;
    }

    public void setCurrent_amount_10(java.lang.String v)
    {
        this.current_amount_10 = v;
    }

    public java.lang.String getDeferred_revenue_event_11()
    {
        return deferred_revenue_event_11;
    }

    public void setDeferred_revenue_event_11(java.lang.String v)
    {
        this.deferred_revenue_event_11 = v;
    }

    public java.lang.String getEvent_11()
    {
        return event_11;
    }

    public void setEvent_11(java.lang.String v)
    {
        this.event_11 = v;
    }

    public java.lang.String getPrior_amount_11()
    {
        return prior_amount_11;
    }

    public void setPrior_amount_11(java.lang.String v)
    {
        this.prior_amount_11 = v;
    }

    public java.lang.String getCurrent_amount_11()
    {
        return current_amount_11;
    }

    public void setCurrent_amount_11(java.lang.String v)
    {
        this.current_amount_11 = v;
    }

    public java.lang.String getDeferred_revenue_event_12()
    {
        return deferred_revenue_event_12;
    }

    public void setDeferred_revenue_event_12(java.lang.String v)
    {
        this.deferred_revenue_event_12 = v;
    }

    public java.lang.String getEvent_12()
    {
        return event_12;
    }

    public void setEvent_12(java.lang.String v)
    {
        this.event_12 = v;
    }

    public java.lang.String getPrior_amount_12()
    {
        return prior_amount_12;
    }

    public void setPrior_amount_12(java.lang.String v)
    {
        this.prior_amount_12 = v;
    }

    public java.lang.String getCurrent_amount_12()
    {
        return current_amount_12;
    }

    public void setCurrent_amount_12(java.lang.String v)
    {
        this.current_amount_12 = v;
    }

    public java.lang.String getDeferred_revenue_event_13()
    {
        return deferred_revenue_event_13;
    }

    public void setDeferred_revenue_event_13(java.lang.String v)
    {
        this.deferred_revenue_event_13 = v;
    }

    public java.lang.String getEvent_13()
    {
        return event_13;
    }

    public void setEvent_13(java.lang.String v)
    {
        this.event_13 = v;
    }

    public java.lang.String getPrior_amount_13()
    {
        return prior_amount_13;
    }

    public void setPrior_amount_13(java.lang.String v)
    {
        this.prior_amount_13 = v;
    }

    public java.lang.String getCurrent_amount_13()
    {
        return current_amount_13;
    }

    public void setCurrent_amount_13(java.lang.String v)
    {
        this.current_amount_13 = v;
    }

    public java.lang.String getDeferred_revenue_event_14()
    {
        return deferred_revenue_event_14;
    }

    public void setDeferred_revenue_event_14(java.lang.String v)
    {
        this.deferred_revenue_event_14 = v;
    }

    public java.lang.String getEvent_14()
    {
        return event_14;
    }

    public void setEvent_14(java.lang.String v)
    {
        this.event_14 = v;
    }

    public java.lang.String getPrior_amount_14()
    {
        return prior_amount_14;
    }

    public void setPrior_amount_14(java.lang.String v)
    {
        this.prior_amount_14 = v;
    }

    public java.lang.String getCurrent_amount_14()
    {
        return current_amount_14;
    }

    public void setCurrent_amount_14(java.lang.String v)
    {
        this.current_amount_14 = v;
    }

    public java.lang.String getDeferred_revenue_event_15()
    {
        return deferred_revenue_event_15;
    }

    public void setDeferred_revenue_event_15(java.lang.String v)
    {
        this.deferred_revenue_event_15 = v;
    }

    public java.lang.String getEvent_15()
    {
        return event_15;
    }

    public void setEvent_15(java.lang.String v)
    {
        this.event_15 = v;
    }

    public java.lang.String getPrior_amount_15()
    {
        return prior_amount_15;
    }

    public void setPrior_amount_15(java.lang.String v)
    {
        this.prior_amount_15 = v;
    }

    public java.lang.String getCurrent_amount_15()
    {
        return current_amount_15;
    }

    public void setCurrent_amount_15(java.lang.String v)
    {
        this.current_amount_15 = v;
    }

    public java.lang.Double getPrior_amount_total()
    {
        return prior_amount_total;
    }

    public void setPrior_amount_total(java.lang.Double v)
    {
        this.prior_amount_total = v;
    }

    public java.lang.Double getCurrent_amount_sum_e16_e30()
    {
        return current_amount_sum_e16_e30;
    }

    public void setCurrent_amount_sum_e16_e30(java.lang.Double v)
    {
        this.current_amount_sum_e16_e30 = v;
    }

    public java.lang.String getPayables_owed_to()
    {
        return payables_owed_to;
    }

    public void setPayables_owed_to(java.lang.String v)
    {
        this.payables_owed_to = v;
    }

    public java.lang.String getReason()
    {
        return reason;
    }

    public void setReason(java.lang.String v)
    {
        this.reason = v;
    }

    public java.lang.String getPrior_amount_16()
    {
        return prior_amount_16;
    }

    public void setPrior_amount_16(java.lang.String v)
    {
        this.prior_amount_16 = v;
    }

    public java.lang.String getCurrent_amount_16()
    {
        return current_amount_16;
    }

    public void setCurrent_amount_16(java.lang.String v)
    {
        this.current_amount_16 = v;
    }

    public java.lang.String getPayables_owed_to_2()
    {
        return payables_owed_to_2;
    }

    public void setPayables_owed_to_2(java.lang.String v)
    {
        this.payables_owed_to_2 = v;
    }

    public java.lang.String getReason_2()
    {
        return reason_2;
    }

    public void setReason_2(java.lang.String v)
    {
        this.reason_2 = v;
    }

    public java.lang.String getPrior_amount_17()
    {
        return prior_amount_17;
    }

    public void setPrior_amount_17(java.lang.String v)
    {
        this.prior_amount_17 = v;
    }

    public java.lang.String getCurrent_amount_17()
    {
        return current_amount_17;
    }

    public void setCurrent_amount_17(java.lang.String v)
    {
        this.current_amount_17 = v;
    }

    public java.lang.String getPayables_owed_to_3()
    {
        return payables_owed_to_3;
    }

    public void setPayables_owed_to_3(java.lang.String v)
    {
        this.payables_owed_to_3 = v;
    }

    public java.lang.String getReason_3()
    {
        return reason_3;
    }

    public void setReason_3(java.lang.String v)
    {
        this.reason_3 = v;
    }

    public java.lang.String getPrior_amount_18()
    {
        return prior_amount_18;
    }

    public void setPrior_amount_18(java.lang.String v)
    {
        this.prior_amount_18 = v;
    }

    public java.lang.String getCurrent_amount_18()
    {
        return current_amount_18;
    }

    public void setCurrent_amount_18(java.lang.String v)
    {
        this.current_amount_18 = v;
    }

    public java.lang.String getPayables_owed_to_4()
    {
        return payables_owed_to_4;
    }

    public void setPayables_owed_to_4(java.lang.String v)
    {
        this.payables_owed_to_4 = v;
    }

    public java.lang.String getReason_4()
    {
        return reason_4;
    }

    public void setReason_4(java.lang.String v)
    {
        this.reason_4 = v;
    }

    public java.lang.String getPrior_amount_19()
    {
        return prior_amount_19;
    }

    public void setPrior_amount_19(java.lang.String v)
    {
        this.prior_amount_19 = v;
    }

    public java.lang.String getCurrent_amount_19()
    {
        return current_amount_19;
    }

    public void setCurrent_amount_19(java.lang.String v)
    {
        this.current_amount_19 = v;
    }

    public java.lang.String getPayables_owed_to_5()
    {
        return payables_owed_to_5;
    }

    public void setPayables_owed_to_5(java.lang.String v)
    {
        this.payables_owed_to_5 = v;
    }

    public java.lang.String getReason_5()
    {
        return reason_5;
    }

    public void setReason_5(java.lang.String v)
    {
        this.reason_5 = v;
    }

    public java.lang.String getPrior_amount_20()
    {
        return prior_amount_20;
    }

    public void setPrior_amount_20(java.lang.String v)
    {
        this.prior_amount_20 = v;
    }

    public java.lang.String getCurrent_amount_20()
    {
        return current_amount_20;
    }

    public void setCurrent_amount_20(java.lang.String v)
    {
        this.current_amount_20 = v;
    }

    public java.lang.String getPayables_owed_to_6()
    {
        return payables_owed_to_6;
    }

    public void setPayables_owed_to_6(java.lang.String v)
    {
        this.payables_owed_to_6 = v;
    }

    public java.lang.String getReason_6()
    {
        return reason_6;
    }

    public void setReason_6(java.lang.String v)
    {
        this.reason_6 = v;
    }

    public java.lang.String getPrior_amount_21()
    {
        return prior_amount_21;
    }

    public void setPrior_amount_21(java.lang.String v)
    {
        this.prior_amount_21 = v;
    }

    public java.lang.String getCurrent_amount_21()
    {
        return current_amount_21;
    }

    public void setCurrent_amount_21(java.lang.String v)
    {
        this.current_amount_21 = v;
    }

    public java.lang.String getPayables_owed_to_7()
    {
        return payables_owed_to_7;
    }

    public void setPayables_owed_to_7(java.lang.String v)
    {
        this.payables_owed_to_7 = v;
    }

    public java.lang.String getReason_7()
    {
        return reason_7;
    }

    public void setReason_7(java.lang.String v)
    {
        this.reason_7 = v;
    }

    public java.lang.String getPrior_amount_22()
    {
        return prior_amount_22;
    }

    public void setPrior_amount_22(java.lang.String v)
    {
        this.prior_amount_22 = v;
    }

    public java.lang.String getCurrent_amount_22()
    {
        return current_amount_22;
    }

    public void setCurrent_amount_22(java.lang.String v)
    {
        this.current_amount_22 = v;
    }

    public java.lang.Double getPrior_amount_total_2()
    {
        return prior_amount_total_2;
    }

    public void setPrior_amount_total_2(java.lang.Double v)
    {
        this.prior_amount_total_2 = v;
    }

    public java.lang.Double getCurrent_amount_sum_e37_e43()
    {
        return current_amount_sum_e37_e43;
    }

    public void setCurrent_amount_sum_e37_e43(java.lang.Double v)
    {
        this.current_amount_sum_e37_e43 = v;
    }

    public java.lang.String getOther_liabilities_owed_to()
    {
        return other_liabilities_owed_to;
    }

    public void setOther_liabilities_owed_to(java.lang.String v)
    {
        this.other_liabilities_owed_to = v;
    }

    public java.lang.String getReason_8()
    {
        return reason_8;
    }

    public void setReason_8(java.lang.String v)
    {
        this.reason_8 = v;
    }

    public java.lang.String getPrior_amount_23()
    {
        return prior_amount_23;
    }

    public void setPrior_amount_23(java.lang.String v)
    {
        this.prior_amount_23 = v;
    }

    public java.lang.String getCurrent_amount_23()
    {
        return current_amount_23;
    }

    public void setCurrent_amount_23(java.lang.String v)
    {
        this.current_amount_23 = v;
    }

    public java.lang.String getOther_liabilities_owed_to_2()
    {
        return other_liabilities_owed_to_2;
    }

    public void setOther_liabilities_owed_to_2(java.lang.String v)
    {
        this.other_liabilities_owed_to_2 = v;
    }

    public java.lang.String getReason_9()
    {
        return reason_9;
    }

    public void setReason_9(java.lang.String v)
    {
        this.reason_9 = v;
    }

    public java.lang.String getPrior_amount_24()
    {
        return prior_amount_24;
    }

    public void setPrior_amount_24(java.lang.String v)
    {
        this.prior_amount_24 = v;
    }

    public java.lang.String getCurrent_amount_24()
    {
        return current_amount_24;
    }

    public void setCurrent_amount_24(java.lang.String v)
    {
        this.current_amount_24 = v;
    }

    public java.lang.String getOther_liabilities_owed_to_3()
    {
        return other_liabilities_owed_to_3;
    }

    public void setOther_liabilities_owed_to_3(java.lang.String v)
    {
        this.other_liabilities_owed_to_3 = v;
    }

    public java.lang.String getReason_10()
    {
        return reason_10;
    }

    public void setReason_10(java.lang.String v)
    {
        this.reason_10 = v;
    }

    public java.lang.String getPrior_amount_25()
    {
        return prior_amount_25;
    }

    public void setPrior_amount_25(java.lang.String v)
    {
        this.prior_amount_25 = v;
    }

    public java.lang.String getCurrent_amount_25()
    {
        return current_amount_25;
    }

    public void setCurrent_amount_25(java.lang.String v)
    {
        this.current_amount_25 = v;
    }

    public java.lang.String getOther_liabilities_owed_to_4()
    {
        return other_liabilities_owed_to_4;
    }

    public void setOther_liabilities_owed_to_4(java.lang.String v)
    {
        this.other_liabilities_owed_to_4 = v;
    }

    public java.lang.String getReason_11()
    {
        return reason_11;
    }

    public void setReason_11(java.lang.String v)
    {
        this.reason_11 = v;
    }

    public java.lang.String getPrior_amount_26()
    {
        return prior_amount_26;
    }

    public void setPrior_amount_26(java.lang.String v)
    {
        this.prior_amount_26 = v;
    }

    public java.lang.String getCurrent_amount_26()
    {
        return current_amount_26;
    }

    public void setCurrent_amount_26(java.lang.String v)
    {
        this.current_amount_26 = v;
    }

    public java.lang.String getOther_liabilities_owed_to_5()
    {
        return other_liabilities_owed_to_5;
    }

    public void setOther_liabilities_owed_to_5(java.lang.String v)
    {
        this.other_liabilities_owed_to_5 = v;
    }

    public java.lang.String getReason_12()
    {
        return reason_12;
    }

    public void setReason_12(java.lang.String v)
    {
        this.reason_12 = v;
    }

    public java.lang.String getPrior_amount_27()
    {
        return prior_amount_27;
    }

    public void setPrior_amount_27(java.lang.String v)
    {
        this.prior_amount_27 = v;
    }

    public java.lang.String getCurrent_amount_27()
    {
        return current_amount_27;
    }

    public void setCurrent_amount_27(java.lang.String v)
    {
        this.current_amount_27 = v;
    }

    public java.lang.String getOther_liabilities_owed_to_6()
    {
        return other_liabilities_owed_to_6;
    }

    public void setOther_liabilities_owed_to_6(java.lang.String v)
    {
        this.other_liabilities_owed_to_6 = v;
    }

    public java.lang.String getReason_13()
    {
        return reason_13;
    }

    public void setReason_13(java.lang.String v)
    {
        this.reason_13 = v;
    }

    public java.lang.String getPrior_amount_28()
    {
        return prior_amount_28;
    }

    public void setPrior_amount_28(java.lang.String v)
    {
        this.prior_amount_28 = v;
    }

    public java.lang.String getCurrent_amount_28()
    {
        return current_amount_28;
    }

    public void setCurrent_amount_28(java.lang.String v)
    {
        this.current_amount_28 = v;
    }

    public java.lang.String getOther_liabilities_owed_to_7()
    {
        return other_liabilities_owed_to_7;
    }

    public void setOther_liabilities_owed_to_7(java.lang.String v)
    {
        this.other_liabilities_owed_to_7 = v;
    }

    public java.lang.String getReason_14()
    {
        return reason_14;
    }

    public void setReason_14(java.lang.String v)
    {
        this.reason_14 = v;
    }

    public java.lang.String getPrior_amount_29()
    {
        return prior_amount_29;
    }

    public void setPrior_amount_29(java.lang.String v)
    {
        this.prior_amount_29 = v;
    }

    public java.lang.String getCurrent_amount_29()
    {
        return current_amount_29;
    }

    public void setCurrent_amount_29(java.lang.String v)
    {
        this.current_amount_29 = v;
    }

    public java.lang.Double getPrior_amount_total_3()
    {
        return prior_amount_total_3;
    }

    public void setPrior_amount_total_3(java.lang.Double v)
    {
        this.prior_amount_total_3 = v;
    }

    public java.lang.Double getCurrent_amount_sum_e49_e55()
    {
        return current_amount_sum_e49_e55;
    }

    public void setCurrent_amount_sum_e49_e55(java.lang.Double v)
    {
        this.current_amount_sum_e49_e55 = v;
    }

    public LIABILITY_DTL_5bBean()
    {
    }

}
