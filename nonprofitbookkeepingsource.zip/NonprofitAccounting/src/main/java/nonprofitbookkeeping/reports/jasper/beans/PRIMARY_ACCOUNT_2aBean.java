package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet PRIMARY_ACCOUNT_2a */
public class PRIMARY_ACCOUNT_2aBean
{

    private java.lang.Double primary_account_2a_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String bank_name;
    private java.lang.String bank_name_2;
    private java.lang.String bank_name_3;
    private java.lang.String bank_name_4;
    private java.lang.String bank_account_title;
    private java.lang.String bank_account_title_2;
    private java.lang.String bank_account_title_3;
    private java.lang.String bank_account_title_4;
    private java.lang.String bank_account_type;
    private java.lang.String bank_s_signature_requirement;
    private java.lang.String bank_account_number;
    private java.lang.String no_statement_ending_date;
    private java.lang.String statement_ending_date_bank_branch_phone_number_and_name_of_contact;
    private java.lang.String bank_branch_phone_number_and_name_of_contact;
    private java.lang.String no_bank_branch_phone_number_and_name_of_contact;
    private java.lang.Double no;
    private java.lang.String contents_c14_1_balance_from_bank_statement_at_end_of_period;
    private java.lang.String deposit_date;
    private java.lang.String amount_of_deposit;
    private java.lang.String deposit_date_2;
    private java.lang.String primary_account_2a_r21c7;
    private java.lang.String amount_of_deposit_2;
    private java.lang.String deposit_date_3;
    private java.lang.String primary_account_2a_r22c4;
    private java.lang.String amount_of_deposit_3;
    private java.lang.String deposit_date_4;
    private java.lang.String primary_account_2a_r22c7;
    private java.lang.String amount_of_deposit_4;
    private java.lang.String deposit_date_5;
    private java.lang.String amount_of_deposit_5;
    private java.lang.String deposit_date_6;
    private java.lang.String primary_account_2a_r23c7;
    private java.lang.String amount_of_deposit_6;
    private java.lang.Double amount_of_deposit_total;
    private java.lang.String check_number;
    private java.lang.String date;
    private java.lang.String check_amount;
    private java.lang.String check_number_2;
    private java.lang.String date_2;
    private java.lang.String check_amount_2;
    private java.lang.String check_number_3;
    private java.lang.String date_3;
    private java.lang.String check_amount_3;
    private java.lang.String check_number_4;
    private java.lang.String date_4;
    private java.lang.String check_amount_4;
    private java.lang.String check_number_5;
    private java.lang.String date_5;
    private java.lang.String check_amount_5;
    private java.lang.String check_number_6;
    private java.lang.String date_6;
    private java.lang.String check_amount_6;
    private java.lang.String check_number_7;
    private java.lang.String date_7;
    private java.lang.String check_amount_7;
    private java.lang.String check_number_8;
    private java.lang.String date_8;
    private java.lang.String check_amount_8;
    private java.lang.String check_number_9;
    private java.lang.String date_9;
    private java.lang.String check_amount_9;
    private java.lang.String check_number_10;
    private java.lang.String date_10;
    private java.lang.String check_amount_10;
    private java.lang.String check_number_11;
    private java.lang.String date_11;
    private java.lang.String check_amount_11;
    private java.lang.String check_number_12;
    private java.lang.String date_12;
    private java.lang.String check_amount_12;
    private java.lang.String check_number_13;
    private java.lang.String date_13;
    private java.lang.String check_amount_13;
    private java.lang.String check_number_14;
    private java.lang.String date_14;
    private java.lang.String check_amount_14;
    private java.lang.String check_number_15;
    private java.lang.String date_15;
    private java.lang.String check_amount_15;
    private java.lang.String check_number_16;
    private java.lang.String date_16;
    private java.lang.String check_amount_16;
    private java.lang.Double check_amount_total;
    private java.lang.Double date_4_adjusted_account_balance_line_1_line_2_line_3;
    private java.lang.Double round_sum_e27_e34_2_round_sum_h27_h34_2_h_36_h_37;
    private java.lang.String round_h19_h24_h35_2_5_ending_ledger_or_register_balance;
    private java.lang.String total_6_does_this_account_earn_interest_yes_or_no;
    private java.lang.String round_h19_h24_h35_2_all_persons_below_are_on_the_signature_card_as_of_date;
    private java.lang.Double legal_name_print_exchequer;
    private java.lang.Double address_contact_info_1_d11;
    private java.lang.Double member_exp_mm_yyyy_contact_info_1_d12;
    private java.lang.Double contact_info_1_d12;
    private java.lang.Double contact_info_1_h15_if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13;
    private java.lang.String exchequer;
    private java.lang.String contact_info_1_d11;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end;
    private java.lang.String contact_info_1_h16;
    private java.lang.String exchequer_2;
    private java.lang.String contact_info_1_d11_2;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_2;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_2;
    private java.lang.String contact_info_1_h16_2;
    private java.lang.String exchequer_3;
    private java.lang.String contact_info_1_d11_3;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_3;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_3;
    private java.lang.String contact_info_1_h16_3;
    private java.lang.String exchequer_4;
    private java.lang.String contact_info_1_d11_4;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_4;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_4;
    private java.lang.String contact_info_1_h16_4;
    private java.lang.String exchequer_5;
    private java.lang.String contact_info_1_d11_5;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_5;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_5;
    private java.lang.String contact_info_1_h16_5;
    private java.lang.String exchequer_6;
    private java.lang.String contact_info_1_d11_6;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_6;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_6;
    private java.lang.String contact_info_1_h16_6;
    private java.lang.String exchequer_7;
    private java.lang.String contact_info_1_d11_7;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_7;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_7;
    private java.lang.String contact_info_1_h16_7;
    private java.lang.String exchequer_8;
    private java.lang.String contact_info_1_d11_8;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_8;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_8;
    private java.lang.String contact_info_1_h16_8;
    private java.lang.String exchequer_9;
    private java.lang.String contact_info_1_d11_9;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_9;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_9;
    private java.lang.String contact_info_1_h16_9;
    private java.lang.String exchequer_10;
    private java.lang.String contact_info_1_d11_10;
    private java.lang.String if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_10;
    private java.lang.String yes_add_line_5_to_pg_3_line_i_b_end_10;
    private java.lang.String contact_info_1_h16_10;
    private java.lang.Double other;

    public java.lang.Double getPrimary_account_2a_r2c3()
    {
        return primary_account_2a_r2c3;
    }

    public void setPrimary_account_2a_r2c3(java.lang.Double v)
    {
        this.primary_account_2a_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getBank_name()
    {
        return bank_name;
    }

    public void setBank_name(java.lang.String v)
    {
        this.bank_name = v;
    }

    public java.lang.String getBank_name_2()
    {
        return bank_name_2;
    }

    public void setBank_name_2(java.lang.String v)
    {
        this.bank_name_2 = v;
    }

    public java.lang.String getBank_name_3()
    {
        return bank_name_3;
    }

    public void setBank_name_3(java.lang.String v)
    {
        this.bank_name_3 = v;
    }

    public java.lang.String getBank_name_4()
    {
        return bank_name_4;
    }

    public void setBank_name_4(java.lang.String v)
    {
        this.bank_name_4 = v;
    }

    public java.lang.String getBank_account_title()
    {
        return bank_account_title;
    }

    public void setBank_account_title(java.lang.String v)
    {
        this.bank_account_title = v;
    }

    public java.lang.String getBank_account_title_2()
    {
        return bank_account_title_2;
    }

    public void setBank_account_title_2(java.lang.String v)
    {
        this.bank_account_title_2 = v;
    }

    public java.lang.String getBank_account_title_3()
    {
        return bank_account_title_3;
    }

    public void setBank_account_title_3(java.lang.String v)
    {
        this.bank_account_title_3 = v;
    }

    public java.lang.String getBank_account_title_4()
    {
        return bank_account_title_4;
    }

    public void setBank_account_title_4(java.lang.String v)
    {
        this.bank_account_title_4 = v;
    }

    public java.lang.String getBank_account_type()
    {
        return bank_account_type;
    }

    public void setBank_account_type(java.lang.String v)
    {
        this.bank_account_type = v;
    }

    public java.lang.String getBank_s_signature_requirement()
    {
        return bank_s_signature_requirement;
    }

    public void setBank_s_signature_requirement(java.lang.String v)
    {
        this.bank_s_signature_requirement = v;
    }

    public java.lang.String getBank_account_number()
    {
        return bank_account_number;
    }

    public void setBank_account_number(java.lang.String v)
    {
        this.bank_account_number = v;
    }

    public java.lang.String getNo_statement_ending_date()
    {
        return no_statement_ending_date;
    }

    public void setNo_statement_ending_date(java.lang.String v)
    {
        this.no_statement_ending_date = v;
    }

    public java.lang.String getStatement_ending_date_bank_branch_phone_number_and_name_of_contact()
    {
        return statement_ending_date_bank_branch_phone_number_and_name_of_contact;
    }

    public void setStatement_ending_date_bank_branch_phone_number_and_name_of_contact(java.lang.String v)
    {
        this.statement_ending_date_bank_branch_phone_number_and_name_of_contact = v;
    }

    public java.lang.String getBank_branch_phone_number_and_name_of_contact()
    {
        return bank_branch_phone_number_and_name_of_contact;
    }

    public void setBank_branch_phone_number_and_name_of_contact(java.lang.String v)
    {
        this.bank_branch_phone_number_and_name_of_contact = v;
    }

    public java.lang.String getNo_bank_branch_phone_number_and_name_of_contact()
    {
        return no_bank_branch_phone_number_and_name_of_contact;
    }

    public void setNo_bank_branch_phone_number_and_name_of_contact(java.lang.String v)
    {
        this.no_bank_branch_phone_number_and_name_of_contact = v;
    }

    public java.lang.Double getNo()
    {
        return no;
    }

    public void setNo(java.lang.Double v)
    {
        this.no = v;
    }

    public java.lang.String getContents_c14_1_balance_from_bank_statement_at_end_of_period()
    {
        return contents_c14_1_balance_from_bank_statement_at_end_of_period;
    }

    public void setContents_c14_1_balance_from_bank_statement_at_end_of_period(java.lang.String v)
    {
        this.contents_c14_1_balance_from_bank_statement_at_end_of_period = v;
    }

    public java.lang.String getDeposit_date()
    {
        return deposit_date;
    }

    public void setDeposit_date(java.lang.String v)
    {
        this.deposit_date = v;
    }

    public java.lang.String getAmount_of_deposit()
    {
        return amount_of_deposit;
    }

    public void setAmount_of_deposit(java.lang.String v)
    {
        this.amount_of_deposit = v;
    }

    public java.lang.String getDeposit_date_2()
    {
        return deposit_date_2;
    }

    public void setDeposit_date_2(java.lang.String v)
    {
        this.deposit_date_2 = v;
    }

    public java.lang.String getPrimary_account_2a_r21c7()
    {
        return primary_account_2a_r21c7;
    }

    public void setPrimary_account_2a_r21c7(java.lang.String v)
    {
        this.primary_account_2a_r21c7 = v;
    }

    public java.lang.String getAmount_of_deposit_2()
    {
        return amount_of_deposit_2;
    }

    public void setAmount_of_deposit_2(java.lang.String v)
    {
        this.amount_of_deposit_2 = v;
    }

    public java.lang.String getDeposit_date_3()
    {
        return deposit_date_3;
    }

    public void setDeposit_date_3(java.lang.String v)
    {
        this.deposit_date_3 = v;
    }

    public java.lang.String getPrimary_account_2a_r22c4()
    {
        return primary_account_2a_r22c4;
    }

    public void setPrimary_account_2a_r22c4(java.lang.String v)
    {
        this.primary_account_2a_r22c4 = v;
    }

    public java.lang.String getAmount_of_deposit_3()
    {
        return amount_of_deposit_3;
    }

    public void setAmount_of_deposit_3(java.lang.String v)
    {
        this.amount_of_deposit_3 = v;
    }

    public java.lang.String getDeposit_date_4()
    {
        return deposit_date_4;
    }

    public void setDeposit_date_4(java.lang.String v)
    {
        this.deposit_date_4 = v;
    }

    public java.lang.String getPrimary_account_2a_r22c7()
    {
        return primary_account_2a_r22c7;
    }

    public void setPrimary_account_2a_r22c7(java.lang.String v)
    {
        this.primary_account_2a_r22c7 = v;
    }

    public java.lang.String getAmount_of_deposit_4()
    {
        return amount_of_deposit_4;
    }

    public void setAmount_of_deposit_4(java.lang.String v)
    {
        this.amount_of_deposit_4 = v;
    }

    public java.lang.String getDeposit_date_5()
    {
        return deposit_date_5;
    }

    public void setDeposit_date_5(java.lang.String v)
    {
        this.deposit_date_5 = v;
    }

    public java.lang.String getAmount_of_deposit_5()
    {
        return amount_of_deposit_5;
    }

    public void setAmount_of_deposit_5(java.lang.String v)
    {
        this.amount_of_deposit_5 = v;
    }

    public java.lang.String getDeposit_date_6()
    {
        return deposit_date_6;
    }

    public void setDeposit_date_6(java.lang.String v)
    {
        this.deposit_date_6 = v;
    }

    public java.lang.String getPrimary_account_2a_r23c7()
    {
        return primary_account_2a_r23c7;
    }

    public void setPrimary_account_2a_r23c7(java.lang.String v)
    {
        this.primary_account_2a_r23c7 = v;
    }

    public java.lang.String getAmount_of_deposit_6()
    {
        return amount_of_deposit_6;
    }

    public void setAmount_of_deposit_6(java.lang.String v)
    {
        this.amount_of_deposit_6 = v;
    }

    public java.lang.Double getAmount_of_deposit_total()
    {
        return amount_of_deposit_total;
    }

    public void setAmount_of_deposit_total(java.lang.Double v)
    {
        this.amount_of_deposit_total = v;
    }

    public java.lang.String getCheck_number()
    {
        return check_number;
    }

    public void setCheck_number(java.lang.String v)
    {
        this.check_number = v;
    }

    public java.lang.String getDate()
    {
        return date;
    }

    public void setDate(java.lang.String v)
    {
        this.date = v;
    }

    public java.lang.String getCheck_amount()
    {
        return check_amount;
    }

    public void setCheck_amount(java.lang.String v)
    {
        this.check_amount = v;
    }

    public java.lang.String getCheck_number_2()
    {
        return check_number_2;
    }

    public void setCheck_number_2(java.lang.String v)
    {
        this.check_number_2 = v;
    }

    public java.lang.String getDate_2()
    {
        return date_2;
    }

    public void setDate_2(java.lang.String v)
    {
        this.date_2 = v;
    }

    public java.lang.String getCheck_amount_2()
    {
        return check_amount_2;
    }

    public void setCheck_amount_2(java.lang.String v)
    {
        this.check_amount_2 = v;
    }

    public java.lang.String getCheck_number_3()
    {
        return check_number_3;
    }

    public void setCheck_number_3(java.lang.String v)
    {
        this.check_number_3 = v;
    }

    public java.lang.String getDate_3()
    {
        return date_3;
    }

    public void setDate_3(java.lang.String v)
    {
        this.date_3 = v;
    }

    public java.lang.String getCheck_amount_3()
    {
        return check_amount_3;
    }

    public void setCheck_amount_3(java.lang.String v)
    {
        this.check_amount_3 = v;
    }

    public java.lang.String getCheck_number_4()
    {
        return check_number_4;
    }

    public void setCheck_number_4(java.lang.String v)
    {
        this.check_number_4 = v;
    }

    public java.lang.String getDate_4()
    {
        return date_4;
    }

    public void setDate_4(java.lang.String v)
    {
        this.date_4 = v;
    }

    public java.lang.String getCheck_amount_4()
    {
        return check_amount_4;
    }

    public void setCheck_amount_4(java.lang.String v)
    {
        this.check_amount_4 = v;
    }

    public java.lang.String getCheck_number_5()
    {
        return check_number_5;
    }

    public void setCheck_number_5(java.lang.String v)
    {
        this.check_number_5 = v;
    }

    public java.lang.String getDate_5()
    {
        return date_5;
    }

    public void setDate_5(java.lang.String v)
    {
        this.date_5 = v;
    }

    public java.lang.String getCheck_amount_5()
    {
        return check_amount_5;
    }

    public void setCheck_amount_5(java.lang.String v)
    {
        this.check_amount_5 = v;
    }

    public java.lang.String getCheck_number_6()
    {
        return check_number_6;
    }

    public void setCheck_number_6(java.lang.String v)
    {
        this.check_number_6 = v;
    }

    public java.lang.String getDate_6()
    {
        return date_6;
    }

    public void setDate_6(java.lang.String v)
    {
        this.date_6 = v;
    }

    public java.lang.String getCheck_amount_6()
    {
        return check_amount_6;
    }

    public void setCheck_amount_6(java.lang.String v)
    {
        this.check_amount_6 = v;
    }

    public java.lang.String getCheck_number_7()
    {
        return check_number_7;
    }

    public void setCheck_number_7(java.lang.String v)
    {
        this.check_number_7 = v;
    }

    public java.lang.String getDate_7()
    {
        return date_7;
    }

    public void setDate_7(java.lang.String v)
    {
        this.date_7 = v;
    }

    public java.lang.String getCheck_amount_7()
    {
        return check_amount_7;
    }

    public void setCheck_amount_7(java.lang.String v)
    {
        this.check_amount_7 = v;
    }

    public java.lang.String getCheck_number_8()
    {
        return check_number_8;
    }

    public void setCheck_number_8(java.lang.String v)
    {
        this.check_number_8 = v;
    }

    public java.lang.String getDate_8()
    {
        return date_8;
    }

    public void setDate_8(java.lang.String v)
    {
        this.date_8 = v;
    }

    public java.lang.String getCheck_amount_8()
    {
        return check_amount_8;
    }

    public void setCheck_amount_8(java.lang.String v)
    {
        this.check_amount_8 = v;
    }

    public java.lang.String getCheck_number_9()
    {
        return check_number_9;
    }

    public void setCheck_number_9(java.lang.String v)
    {
        this.check_number_9 = v;
    }

    public java.lang.String getDate_9()
    {
        return date_9;
    }

    public void setDate_9(java.lang.String v)
    {
        this.date_9 = v;
    }

    public java.lang.String getCheck_amount_9()
    {
        return check_amount_9;
    }

    public void setCheck_amount_9(java.lang.String v)
    {
        this.check_amount_9 = v;
    }

    public java.lang.String getCheck_number_10()
    {
        return check_number_10;
    }

    public void setCheck_number_10(java.lang.String v)
    {
        this.check_number_10 = v;
    }

    public java.lang.String getDate_10()
    {
        return date_10;
    }

    public void setDate_10(java.lang.String v)
    {
        this.date_10 = v;
    }

    public java.lang.String getCheck_amount_10()
    {
        return check_amount_10;
    }

    public void setCheck_amount_10(java.lang.String v)
    {
        this.check_amount_10 = v;
    }

    public java.lang.String getCheck_number_11()
    {
        return check_number_11;
    }

    public void setCheck_number_11(java.lang.String v)
    {
        this.check_number_11 = v;
    }

    public java.lang.String getDate_11()
    {
        return date_11;
    }

    public void setDate_11(java.lang.String v)
    {
        this.date_11 = v;
    }

    public java.lang.String getCheck_amount_11()
    {
        return check_amount_11;
    }

    public void setCheck_amount_11(java.lang.String v)
    {
        this.check_amount_11 = v;
    }

    public java.lang.String getCheck_number_12()
    {
        return check_number_12;
    }

    public void setCheck_number_12(java.lang.String v)
    {
        this.check_number_12 = v;
    }

    public java.lang.String getDate_12()
    {
        return date_12;
    }

    public void setDate_12(java.lang.String v)
    {
        this.date_12 = v;
    }

    public java.lang.String getCheck_amount_12()
    {
        return check_amount_12;
    }

    public void setCheck_amount_12(java.lang.String v)
    {
        this.check_amount_12 = v;
    }

    public java.lang.String getCheck_number_13()
    {
        return check_number_13;
    }

    public void setCheck_number_13(java.lang.String v)
    {
        this.check_number_13 = v;
    }

    public java.lang.String getDate_13()
    {
        return date_13;
    }

    public void setDate_13(java.lang.String v)
    {
        this.date_13 = v;
    }

    public java.lang.String getCheck_amount_13()
    {
        return check_amount_13;
    }

    public void setCheck_amount_13(java.lang.String v)
    {
        this.check_amount_13 = v;
    }

    public java.lang.String getCheck_number_14()
    {
        return check_number_14;
    }

    public void setCheck_number_14(java.lang.String v)
    {
        this.check_number_14 = v;
    }

    public java.lang.String getDate_14()
    {
        return date_14;
    }

    public void setDate_14(java.lang.String v)
    {
        this.date_14 = v;
    }

    public java.lang.String getCheck_amount_14()
    {
        return check_amount_14;
    }

    public void setCheck_amount_14(java.lang.String v)
    {
        this.check_amount_14 = v;
    }

    public java.lang.String getCheck_number_15()
    {
        return check_number_15;
    }

    public void setCheck_number_15(java.lang.String v)
    {
        this.check_number_15 = v;
    }

    public java.lang.String getDate_15()
    {
        return date_15;
    }

    public void setDate_15(java.lang.String v)
    {
        this.date_15 = v;
    }

    public java.lang.String getCheck_amount_15()
    {
        return check_amount_15;
    }

    public void setCheck_amount_15(java.lang.String v)
    {
        this.check_amount_15 = v;
    }

    public java.lang.String getCheck_number_16()
    {
        return check_number_16;
    }

    public void setCheck_number_16(java.lang.String v)
    {
        this.check_number_16 = v;
    }

    public java.lang.String getDate_16()
    {
        return date_16;
    }

    public void setDate_16(java.lang.String v)
    {
        this.date_16 = v;
    }

    public java.lang.String getCheck_amount_16()
    {
        return check_amount_16;
    }

    public void setCheck_amount_16(java.lang.String v)
    {
        this.check_amount_16 = v;
    }

    public java.lang.Double getCheck_amount_total()
    {
        return check_amount_total;
    }

    public void setCheck_amount_total(java.lang.Double v)
    {
        this.check_amount_total = v;
    }

    public java.lang.Double getDate_4_adjusted_account_balance_line_1_line_2_line_3()
    {
        return date_4_adjusted_account_balance_line_1_line_2_line_3;
    }

    public void setDate_4_adjusted_account_balance_line_1_line_2_line_3(java.lang.Double v)
    {
        this.date_4_adjusted_account_balance_line_1_line_2_line_3 = v;
    }

    public java.lang.Double getRound_sum_e27_e34_2_round_sum_h27_h34_2_h_36_h_37()
    {
        return round_sum_e27_e34_2_round_sum_h27_h34_2_h_36_h_37;
    }

    public void setRound_sum_e27_e34_2_round_sum_h27_h34_2_h_36_h_37(java.lang.Double v)
    {
        this.round_sum_e27_e34_2_round_sum_h27_h34_2_h_36_h_37 = v;
    }

    public java.lang.String getRound_h19_h24_h35_2_5_ending_ledger_or_register_balance()
    {
        return round_h19_h24_h35_2_5_ending_ledger_or_register_balance;
    }

    public void setRound_h19_h24_h35_2_5_ending_ledger_or_register_balance(java.lang.String v)
    {
        this.round_h19_h24_h35_2_5_ending_ledger_or_register_balance = v;
    }

    public java.lang.String getTotal_6_does_this_account_earn_interest_yes_or_no()
    {
        return total_6_does_this_account_earn_interest_yes_or_no;
    }

    public void setTotal_6_does_this_account_earn_interest_yes_or_no(java.lang.String v)
    {
        this.total_6_does_this_account_earn_interest_yes_or_no = v;
    }

    public java.lang.String getRound_h19_h24_h35_2_all_persons_below_are_on_the_signature_card_as_of_date()
    {
        return round_h19_h24_h35_2_all_persons_below_are_on_the_signature_card_as_of_date;
    }

    public void setRound_h19_h24_h35_2_all_persons_below_are_on_the_signature_card_as_of_date(java.lang.String v)
    {
        this.round_h19_h24_h35_2_all_persons_below_are_on_the_signature_card_as_of_date = v;
    }

    public java.lang.Double getLegal_name_print_exchequer()
    {
        return legal_name_print_exchequer;
    }

    public void setLegal_name_print_exchequer(java.lang.Double v)
    {
        this.legal_name_print_exchequer = v;
    }

    public java.lang.Double getAddress_contact_info_1_d11()
    {
        return address_contact_info_1_d11;
    }

    public void setAddress_contact_info_1_d11(java.lang.Double v)
    {
        this.address_contact_info_1_d11 = v;
    }

    public java.lang.Double getMember_exp_mm_yyyy_contact_info_1_d12()
    {
        return member_exp_mm_yyyy_contact_info_1_d12;
    }

    public void setMember_exp_mm_yyyy_contact_info_1_d12(java.lang.Double v)
    {
        this.member_exp_mm_yyyy_contact_info_1_d12 = v;
    }

    public java.lang.Double getContact_info_1_d12()
    {
        return contact_info_1_d12;
    }

    public void setContact_info_1_d12(java.lang.Double v)
    {
        this.contact_info_1_d12 = v;
    }

    public java.lang.Double getContact_info_1_h15_if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13()
    {
        return contact_info_1_h15_if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13;
    }

    public void setContact_info_1_h15_if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13(java.lang.Double v)
    {
        this.contact_info_1_h15_if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13 = v;
    }

    public java.lang.String getExchequer()
    {
        return exchequer;
    }

    public void setExchequer(java.lang.String v)
    {
        this.exchequer = v;
    }

    public java.lang.String getContact_info_1_d11()
    {
        return contact_info_1_d11;
    }

    public void setContact_info_1_d11(java.lang.String v)
    {
        this.contact_info_1_d11 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end = v;
    }

    public java.lang.String getContact_info_1_h16()
    {
        return contact_info_1_h16;
    }

    public void setContact_info_1_h16(java.lang.String v)
    {
        this.contact_info_1_h16 = v;
    }

    public java.lang.String getExchequer_2()
    {
        return exchequer_2;
    }

    public void setExchequer_2(java.lang.String v)
    {
        this.exchequer_2 = v;
    }

    public java.lang.String getContact_info_1_d11_2()
    {
        return contact_info_1_d11_2;
    }

    public void setContact_info_1_d11_2(java.lang.String v)
    {
        this.contact_info_1_d11_2 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_2()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_2;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_2(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_2 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_2()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_2;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_2(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_2 = v;
    }

    public java.lang.String getContact_info_1_h16_2()
    {
        return contact_info_1_h16_2;
    }

    public void setContact_info_1_h16_2(java.lang.String v)
    {
        this.contact_info_1_h16_2 = v;
    }

    public java.lang.String getExchequer_3()
    {
        return exchequer_3;
    }

    public void setExchequer_3(java.lang.String v)
    {
        this.exchequer_3 = v;
    }

    public java.lang.String getContact_info_1_d11_3()
    {
        return contact_info_1_d11_3;
    }

    public void setContact_info_1_d11_3(java.lang.String v)
    {
        this.contact_info_1_d11_3 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_3()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_3;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_3(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_3 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_3()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_3;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_3(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_3 = v;
    }

    public java.lang.String getContact_info_1_h16_3()
    {
        return contact_info_1_h16_3;
    }

    public void setContact_info_1_h16_3(java.lang.String v)
    {
        this.contact_info_1_h16_3 = v;
    }

    public java.lang.String getExchequer_4()
    {
        return exchequer_4;
    }

    public void setExchequer_4(java.lang.String v)
    {
        this.exchequer_4 = v;
    }

    public java.lang.String getContact_info_1_d11_4()
    {
        return contact_info_1_d11_4;
    }

    public void setContact_info_1_d11_4(java.lang.String v)
    {
        this.contact_info_1_d11_4 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_4()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_4;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_4(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_4 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_4()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_4;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_4(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_4 = v;
    }

    public java.lang.String getContact_info_1_h16_4()
    {
        return contact_info_1_h16_4;
    }

    public void setContact_info_1_h16_4(java.lang.String v)
    {
        this.contact_info_1_h16_4 = v;
    }

    public java.lang.String getExchequer_5()
    {
        return exchequer_5;
    }

    public void setExchequer_5(java.lang.String v)
    {
        this.exchequer_5 = v;
    }

    public java.lang.String getContact_info_1_d11_5()
    {
        return contact_info_1_d11_5;
    }

    public void setContact_info_1_d11_5(java.lang.String v)
    {
        this.contact_info_1_d11_5 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_5()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_5;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_5(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_5 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_5()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_5;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_5(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_5 = v;
    }

    public java.lang.String getContact_info_1_h16_5()
    {
        return contact_info_1_h16_5;
    }

    public void setContact_info_1_h16_5(java.lang.String v)
    {
        this.contact_info_1_h16_5 = v;
    }

    public java.lang.String getExchequer_6()
    {
        return exchequer_6;
    }

    public void setExchequer_6(java.lang.String v)
    {
        this.exchequer_6 = v;
    }

    public java.lang.String getContact_info_1_d11_6()
    {
        return contact_info_1_d11_6;
    }

    public void setContact_info_1_d11_6(java.lang.String v)
    {
        this.contact_info_1_d11_6 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_6()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_6;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_6(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_6 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_6()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_6;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_6(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_6 = v;
    }

    public java.lang.String getContact_info_1_h16_6()
    {
        return contact_info_1_h16_6;
    }

    public void setContact_info_1_h16_6(java.lang.String v)
    {
        this.contact_info_1_h16_6 = v;
    }

    public java.lang.String getExchequer_7()
    {
        return exchequer_7;
    }

    public void setExchequer_7(java.lang.String v)
    {
        this.exchequer_7 = v;
    }

    public java.lang.String getContact_info_1_d11_7()
    {
        return contact_info_1_d11_7;
    }

    public void setContact_info_1_d11_7(java.lang.String v)
    {
        this.contact_info_1_d11_7 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_7()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_7;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_7(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_7 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_7()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_7;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_7(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_7 = v;
    }

    public java.lang.String getContact_info_1_h16_7()
    {
        return contact_info_1_h16_7;
    }

    public void setContact_info_1_h16_7(java.lang.String v)
    {
        this.contact_info_1_h16_7 = v;
    }

    public java.lang.String getExchequer_8()
    {
        return exchequer_8;
    }

    public void setExchequer_8(java.lang.String v)
    {
        this.exchequer_8 = v;
    }

    public java.lang.String getContact_info_1_d11_8()
    {
        return contact_info_1_d11_8;
    }

    public void setContact_info_1_d11_8(java.lang.String v)
    {
        this.contact_info_1_d11_8 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_8()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_8;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_8(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_8 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_8()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_8;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_8(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_8 = v;
    }

    public java.lang.String getContact_info_1_h16_8()
    {
        return contact_info_1_h16_8;
    }

    public void setContact_info_1_h16_8(java.lang.String v)
    {
        this.contact_info_1_h16_8 = v;
    }

    public java.lang.String getExchequer_9()
    {
        return exchequer_9;
    }

    public void setExchequer_9(java.lang.String v)
    {
        this.exchequer_9 = v;
    }

    public java.lang.String getContact_info_1_d11_9()
    {
        return contact_info_1_d11_9;
    }

    public void setContact_info_1_d11_9(java.lang.String v)
    {
        this.contact_info_1_d11_9 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_9()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_9;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_9(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_9 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_9()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_9;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_9(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_9 = v;
    }

    public java.lang.String getContact_info_1_h16_9()
    {
        return contact_info_1_h16_9;
    }

    public void setContact_info_1_h16_9(java.lang.String v)
    {
        this.contact_info_1_h16_9 = v;
    }

    public java.lang.String getExchequer_10()
    {
        return exchequer_10;
    }

    public void setExchequer_10(java.lang.String v)
    {
        this.exchequer_10 = v;
    }

    public java.lang.String getContact_info_1_d11_10()
    {
        return contact_info_1_d11_10;
    }

    public void setContact_info_1_d11_10(java.lang.String v)
    {
        this.contact_info_1_d11_10 = v;
    }

    public java.lang.String getIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_10()
    {
        return if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_10;
    }

    public void setIf_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_10(java.lang.String v)
    {
        this.if_contact_info_1_d13_concatenate_contact_info_1_d13_contact_info_1_f13_contact_info_1_h13_10 = v;
    }

    public java.lang.String getYes_add_line_5_to_pg_3_line_i_b_end_10()
    {
        return yes_add_line_5_to_pg_3_line_i_b_end_10;
    }

    public void setYes_add_line_5_to_pg_3_line_i_b_end_10(java.lang.String v)
    {
        this.yes_add_line_5_to_pg_3_line_i_b_end_10 = v;
    }

    public java.lang.String getContact_info_1_h16_10()
    {
        return contact_info_1_h16_10;
    }

    public void setContact_info_1_h16_10(java.lang.String v)
    {
        this.contact_info_1_h16_10 = v;
    }

    public java.lang.Double getOther()
    {
        return other;
    }

    public void setOther(java.lang.Double v)
    {
        this.other = v;
    }

    public PRIMARY_ACCOUNT_2aBean()
    {
    }

}
