package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet COMMENTS */
public class COMMENTSBean
{

    private java.lang.Double comments_r2c3;
    private java.lang.String contents_b59;
    private java.lang.String contents_b59_2;
    private java.lang.String contents_b59_3;
    private java.lang.String contents_b59_4;
    private java.lang.String contents_b59_5;
    private java.lang.String contents_b59_6;
    private java.lang.String contents_b59_7;
    private java.lang.String contents_b59_8;
    private java.lang.String contents_b59_9;
    private java.lang.String contents_b59_10;
    private java.lang.Double contents_b59_11;
    private java.lang.String contents_e_3;
    private java.lang.String contents_e_3_2;
    private java.lang.String contents_e_3_3;
    private java.lang.String contents_e_3_4;
    private java.lang.String contents_e_3_5;
    private java.lang.String contents_e_3_6;
    private java.lang.String contents_e_3_7;
    private java.lang.String contents_e_3_8;
    private java.lang.String contents_e_3_9;
    private java.lang.String contents_e_3_10;
    private java.lang.Double contents_e_3_11;
    private java.lang.String contents_e_4;
    private java.lang.String contents_e_4_2;
    private java.lang.String contents_e_4_3;
    private java.lang.String contents_e_4_4;
    private java.lang.String contents_e_4_5;
    private java.lang.String contents_e_4_6;
    private java.lang.String contents_e_4_7;
    private java.lang.String contents_e_4_8;
    private java.lang.String contents_e_4_9;
    private java.lang.String contents_e_4_10;
    private java.lang.String comments_r5c6;
    private java.lang.String comments_r5c7;
    private java.lang.String comments_r5c8;
    private java.lang.String comments_r5c9;
    private java.lang.String comments_r5c10;
    private java.lang.String comments_r5c11;
    private java.lang.String comments_r5c12;
    private java.lang.String comments_r5c13;
    private java.lang.String comments_r5c14;
    private java.lang.String comments_r5c15;
    private java.lang.Double contents_e_4_11;
    private java.lang.String contents_b58;
    private java.lang.String contents_b58_2;
    private java.lang.String contents_b58_3;
    private java.lang.String contents_b58_4;
    private java.lang.String contents_b58_5;
    private java.lang.String contents_b58_6;
    private java.lang.String contents_b58_7;
    private java.lang.String contents_b58_8;
    private java.lang.String contents_b58_9;
    private java.lang.String contents_b58_10;
    private java.lang.String comments;
    private java.lang.String comments_2;
    private java.lang.String comments_3;
    private java.lang.String comments_4;
    private java.lang.String comments_5;
    private java.lang.String comments_6;
    private java.lang.String comments_7;
    private java.lang.String comments_8;
    private java.lang.String comments_9;
    private java.lang.String comments_10;
    private java.lang.String comments_11;
    private java.lang.String comments_r8c6;
    private java.lang.String comments_r8c7;
    private java.lang.String comments_r8c8;
    private java.lang.String comments_r8c9;
    private java.lang.String comments_r8c10;
    private java.lang.String comments_r8c11;
    private java.lang.String comments_r8c12;
    private java.lang.String comments_r8c13;
    private java.lang.String comments_r8c14;
    private java.lang.String comments_r8c15;
    private java.lang.String comments_12;
    private java.lang.String comments_r9c6;
    private java.lang.String comments_r9c7;
    private java.lang.String comments_r9c8;
    private java.lang.String comments_r9c9;
    private java.lang.String comments_r9c10;
    private java.lang.String comments_r9c11;
    private java.lang.String comments_r9c12;
    private java.lang.String comments_r9c13;
    private java.lang.String comments_r9c14;
    private java.lang.String comments_r9c15;
    private java.lang.String comments_13;
    private java.lang.String comments_r10c6;
    private java.lang.String comments_r10c7;
    private java.lang.String comments_r10c8;
    private java.lang.String comments_r10c9;
    private java.lang.String comments_r10c10;
    private java.lang.String comments_r10c11;
    private java.lang.String comments_r10c12;
    private java.lang.String comments_r10c13;
    private java.lang.String comments_r10c14;
    private java.lang.String comments_r10c15;
    private java.lang.String comments_14;
    private java.lang.String comments_r11c6;
    private java.lang.String comments_r11c7;
    private java.lang.String comments_r11c8;
    private java.lang.String comments_r11c9;
    private java.lang.String comments_r11c10;
    private java.lang.String comments_r11c11;
    private java.lang.String comments_r11c12;
    private java.lang.String comments_r11c13;
    private java.lang.String comments_r11c14;
    private java.lang.String comments_r11c15;
    private java.lang.String comments_15;
    private java.lang.String comments_r12c6;
    private java.lang.String comments_r12c7;
    private java.lang.String comments_r12c8;
    private java.lang.String comments_r12c9;
    private java.lang.String comments_r12c10;
    private java.lang.String comments_r12c11;
    private java.lang.String comments_r12c12;
    private java.lang.String comments_r12c13;
    private java.lang.String comments_r12c14;
    private java.lang.String comments_r12c15;
    private java.lang.String comments_16;
    private java.lang.String comments_r13c6;
    private java.lang.String comments_r13c7;
    private java.lang.String comments_r13c8;
    private java.lang.String comments_r13c9;
    private java.lang.String comments_r13c10;
    private java.lang.String comments_r13c11;
    private java.lang.String comments_r13c12;
    private java.lang.String comments_r13c13;
    private java.lang.String comments_r13c14;
    private java.lang.String comments_r13c15;
    private java.lang.String comments_17;
    private java.lang.String comments_r14c6;
    private java.lang.String comments_r14c7;
    private java.lang.String comments_r14c8;
    private java.lang.String comments_r14c9;
    private java.lang.String comments_r14c10;
    private java.lang.String comments_r14c11;
    private java.lang.String comments_r14c12;
    private java.lang.String comments_r14c13;
    private java.lang.String comments_r14c14;
    private java.lang.String comments_r14c15;
    private java.lang.String comments_18;
    private java.lang.String comments_r15c6;
    private java.lang.String comments_r15c7;
    private java.lang.String comments_r15c8;
    private java.lang.String comments_r15c9;
    private java.lang.String comments_r15c10;
    private java.lang.String comments_r15c11;
    private java.lang.String comments_r15c12;
    private java.lang.String comments_r15c13;
    private java.lang.String comments_r15c14;
    private java.lang.String comments_r15c15;
    private java.lang.String comments_19;
    private java.lang.String comments_r16c6;
    private java.lang.String comments_r16c7;
    private java.lang.String comments_r16c8;
    private java.lang.String comments_r16c9;
    private java.lang.String comments_r16c10;
    private java.lang.String comments_r16c11;
    private java.lang.String comments_r16c12;
    private java.lang.String comments_r16c13;
    private java.lang.String comments_r16c14;
    private java.lang.String comments_r16c15;
    private java.lang.String comments_20;
    private java.lang.String comments_r17c6;
    private java.lang.String comments_r17c7;
    private java.lang.String comments_r17c8;
    private java.lang.String comments_r17c9;
    private java.lang.String comments_r17c10;
    private java.lang.String comments_r17c11;
    private java.lang.String comments_r17c12;
    private java.lang.String comments_r17c13;
    private java.lang.String comments_r17c14;
    private java.lang.String comments_r17c15;
    private java.lang.String comments_21;
    private java.lang.String comments_r18c6;
    private java.lang.String comments_r18c7;
    private java.lang.String comments_r18c8;
    private java.lang.String comments_r18c9;
    private java.lang.String comments_r18c10;
    private java.lang.String comments_r18c11;
    private java.lang.String comments_r18c12;
    private java.lang.String comments_r18c13;
    private java.lang.String comments_r18c14;
    private java.lang.String comments_r18c15;
    private java.lang.String comments_22;
    private java.lang.String comments_r19c6;
    private java.lang.String comments_r19c7;
    private java.lang.String comments_r19c8;
    private java.lang.String comments_r19c9;
    private java.lang.String comments_r19c10;
    private java.lang.String comments_r19c11;
    private java.lang.String comments_r19c12;
    private java.lang.String comments_r19c13;
    private java.lang.String comments_r19c14;
    private java.lang.String comments_r19c15;
    private java.lang.String comments_23;
    private java.lang.String comments_r20c6;
    private java.lang.String comments_r20c7;
    private java.lang.String comments_r20c8;
    private java.lang.String comments_r20c9;
    private java.lang.String comments_r20c10;
    private java.lang.String comments_r20c11;
    private java.lang.String comments_r20c12;
    private java.lang.String comments_r20c13;
    private java.lang.String comments_r20c14;
    private java.lang.String comments_r20c15;
    private java.lang.String comments_24;
    private java.lang.String comments_r21c6;
    private java.lang.String comments_r21c7;
    private java.lang.String comments_r21c8;
    private java.lang.String comments_r21c9;
    private java.lang.String comments_r21c10;
    private java.lang.String comments_r21c11;
    private java.lang.String comments_r21c12;
    private java.lang.String comments_r21c13;
    private java.lang.String comments_r21c14;
    private java.lang.String comments_r21c15;
    private java.lang.String comments_25;
    private java.lang.String comments_r22c6;
    private java.lang.String comments_r22c7;
    private java.lang.String comments_r22c8;
    private java.lang.String comments_r22c9;
    private java.lang.String comments_r22c10;
    private java.lang.String comments_r22c11;
    private java.lang.String comments_r22c12;
    private java.lang.String comments_r22c13;
    private java.lang.String comments_r22c14;
    private java.lang.String comments_r22c15;
    private java.lang.String comments_26;
    private java.lang.String comments_r23c6;
    private java.lang.String comments_r23c7;
    private java.lang.String comments_r23c8;
    private java.lang.String comments_r23c9;
    private java.lang.String comments_r23c10;
    private java.lang.String comments_r23c11;
    private java.lang.String comments_r23c12;
    private java.lang.String comments_r23c13;
    private java.lang.String comments_r23c14;
    private java.lang.String comments_r23c15;
    private java.lang.String comments_27;
    private java.lang.String comments_r24c6;
    private java.lang.String comments_r24c7;
    private java.lang.String comments_r24c8;
    private java.lang.String comments_r24c9;
    private java.lang.String comments_r24c10;
    private java.lang.String comments_r24c11;
    private java.lang.String comments_r24c12;
    private java.lang.String comments_r24c13;
    private java.lang.String comments_r24c14;
    private java.lang.String comments_r24c15;
    private java.lang.String comments_28;
    private java.lang.String comments_r25c6;
    private java.lang.String comments_r25c7;
    private java.lang.String comments_r25c8;
    private java.lang.String comments_r25c9;
    private java.lang.String comments_r25c10;
    private java.lang.String comments_r25c11;
    private java.lang.String comments_r25c12;
    private java.lang.String comments_r25c13;
    private java.lang.String comments_r25c14;
    private java.lang.String comments_r25c15;
    private java.lang.String comments_29;
    private java.lang.String comments_r26c6;
    private java.lang.String comments_r26c7;
    private java.lang.String comments_r26c8;
    private java.lang.String comments_r26c9;
    private java.lang.String comments_r26c10;
    private java.lang.String comments_r26c11;
    private java.lang.String comments_r26c12;
    private java.lang.String comments_r26c13;
    private java.lang.String comments_r26c14;
    private java.lang.String comments_r26c15;
    private java.lang.String comments_30;
    private java.lang.String comments_r27c6;
    private java.lang.String comments_r27c7;
    private java.lang.String comments_r27c8;
    private java.lang.String comments_r27c9;
    private java.lang.String comments_r27c10;
    private java.lang.String comments_r27c11;
    private java.lang.String comments_r27c12;
    private java.lang.String comments_r27c13;
    private java.lang.String comments_r27c14;
    private java.lang.String comments_r27c15;
    private java.lang.String comments_31;
    private java.lang.String comments_r28c6;
    private java.lang.String comments_r28c7;
    private java.lang.String comments_r28c8;
    private java.lang.String comments_r28c9;
    private java.lang.String comments_r28c10;
    private java.lang.String comments_r28c11;
    private java.lang.String comments_r28c12;
    private java.lang.String comments_r28c13;
    private java.lang.String comments_r28c14;
    private java.lang.String comments_r28c15;
    private java.lang.String comments_32;
    private java.lang.String comments_r29c6;
    private java.lang.String comments_r29c7;
    private java.lang.String comments_r29c8;
    private java.lang.String comments_r29c9;
    private java.lang.String comments_r29c10;
    private java.lang.String comments_r29c11;
    private java.lang.String comments_r29c12;
    private java.lang.String comments_r29c13;
    private java.lang.String comments_r29c14;
    private java.lang.String comments_r29c15;
    private java.lang.String comments_33;
    private java.lang.String comments_r30c6;
    private java.lang.String comments_r30c7;
    private java.lang.String comments_r30c8;
    private java.lang.String comments_r30c9;
    private java.lang.String comments_r30c10;
    private java.lang.String comments_r30c11;
    private java.lang.String comments_r30c12;
    private java.lang.String comments_r30c13;
    private java.lang.String comments_r30c14;
    private java.lang.String comments_r30c15;
    private java.lang.String comments_34;
    private java.lang.String comments_r31c6;
    private java.lang.String comments_r31c7;
    private java.lang.String comments_r31c8;
    private java.lang.String comments_r31c9;
    private java.lang.String comments_r31c10;
    private java.lang.String comments_r31c11;
    private java.lang.String comments_r31c12;
    private java.lang.String comments_r31c13;
    private java.lang.String comments_r31c14;
    private java.lang.String comments_r31c15;
    private java.lang.String comments_35;
    private java.lang.String comments_r32c6;
    private java.lang.String comments_r32c7;
    private java.lang.String comments_r32c8;
    private java.lang.String comments_r32c9;
    private java.lang.String comments_r32c10;
    private java.lang.String comments_r32c11;
    private java.lang.String comments_r32c12;
    private java.lang.String comments_r32c13;
    private java.lang.String comments_r32c14;
    private java.lang.String comments_r32c15;
    private java.lang.String comments_r33c6;
    private java.lang.String comments_r33c7;
    private java.lang.String comments_r33c8;
    private java.lang.String comments_r33c9;
    private java.lang.String comments_r33c10;
    private java.lang.String comments_r33c11;
    private java.lang.String comments_r33c12;
    private java.lang.String comments_r33c13;
    private java.lang.String comments_r33c14;
    private java.lang.String comments_r33c15;

    public java.lang.Double getComments_r2c3()
    {
        return comments_r2c3;
    }

    public void setComments_r2c3(java.lang.Double v)
    {
        this.comments_r2c3 = v;
    }

    public java.lang.String getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.String v)
    {
        this.contents_b59 = v;
    }

    public java.lang.String getContents_b59_2()
    {
        return contents_b59_2;
    }

    public void setContents_b59_2(java.lang.String v)
    {
        this.contents_b59_2 = v;
    }

    public java.lang.String getContents_b59_3()
    {
        return contents_b59_3;
    }

    public void setContents_b59_3(java.lang.String v)
    {
        this.contents_b59_3 = v;
    }

    public java.lang.String getContents_b59_4()
    {
        return contents_b59_4;
    }

    public void setContents_b59_4(java.lang.String v)
    {
        this.contents_b59_4 = v;
    }

    public java.lang.String getContents_b59_5()
    {
        return contents_b59_5;
    }

    public void setContents_b59_5(java.lang.String v)
    {
        this.contents_b59_5 = v;
    }

    public java.lang.String getContents_b59_6()
    {
        return contents_b59_6;
    }

    public void setContents_b59_6(java.lang.String v)
    {
        this.contents_b59_6 = v;
    }

    public java.lang.String getContents_b59_7()
    {
        return contents_b59_7;
    }

    public void setContents_b59_7(java.lang.String v)
    {
        this.contents_b59_7 = v;
    }

    public java.lang.String getContents_b59_8()
    {
        return contents_b59_8;
    }

    public void setContents_b59_8(java.lang.String v)
    {
        this.contents_b59_8 = v;
    }

    public java.lang.String getContents_b59_9()
    {
        return contents_b59_9;
    }

    public void setContents_b59_9(java.lang.String v)
    {
        this.contents_b59_9 = v;
    }

    public java.lang.String getContents_b59_10()
    {
        return contents_b59_10;
    }

    public void setContents_b59_10(java.lang.String v)
    {
        this.contents_b59_10 = v;
    }

    public java.lang.Double getContents_b59_11()
    {
        return contents_b59_11;
    }

    public void setContents_b59_11(java.lang.Double v)
    {
        this.contents_b59_11 = v;
    }

    public java.lang.String getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.String v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.String getContents_e_3_2()
    {
        return contents_e_3_2;
    }

    public void setContents_e_3_2(java.lang.String v)
    {
        this.contents_e_3_2 = v;
    }

    public java.lang.String getContents_e_3_3()
    {
        return contents_e_3_3;
    }

    public void setContents_e_3_3(java.lang.String v)
    {
        this.contents_e_3_3 = v;
    }

    public java.lang.String getContents_e_3_4()
    {
        return contents_e_3_4;
    }

    public void setContents_e_3_4(java.lang.String v)
    {
        this.contents_e_3_4 = v;
    }

    public java.lang.String getContents_e_3_5()
    {
        return contents_e_3_5;
    }

    public void setContents_e_3_5(java.lang.String v)
    {
        this.contents_e_3_5 = v;
    }

    public java.lang.String getContents_e_3_6()
    {
        return contents_e_3_6;
    }

    public void setContents_e_3_6(java.lang.String v)
    {
        this.contents_e_3_6 = v;
    }

    public java.lang.String getContents_e_3_7()
    {
        return contents_e_3_7;
    }

    public void setContents_e_3_7(java.lang.String v)
    {
        this.contents_e_3_7 = v;
    }

    public java.lang.String getContents_e_3_8()
    {
        return contents_e_3_8;
    }

    public void setContents_e_3_8(java.lang.String v)
    {
        this.contents_e_3_8 = v;
    }

    public java.lang.String getContents_e_3_9()
    {
        return contents_e_3_9;
    }

    public void setContents_e_3_9(java.lang.String v)
    {
        this.contents_e_3_9 = v;
    }

    public java.lang.String getContents_e_3_10()
    {
        return contents_e_3_10;
    }

    public void setContents_e_3_10(java.lang.String v)
    {
        this.contents_e_3_10 = v;
    }

    public java.lang.Double getContents_e_3_11()
    {
        return contents_e_3_11;
    }

    public void setContents_e_3_11(java.lang.Double v)
    {
        this.contents_e_3_11 = v;
    }

    public java.lang.String getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.String v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getContents_e_4_2()
    {
        return contents_e_4_2;
    }

    public void setContents_e_4_2(java.lang.String v)
    {
        this.contents_e_4_2 = v;
    }

    public java.lang.String getContents_e_4_3()
    {
        return contents_e_4_3;
    }

    public void setContents_e_4_3(java.lang.String v)
    {
        this.contents_e_4_3 = v;
    }

    public java.lang.String getContents_e_4_4()
    {
        return contents_e_4_4;
    }

    public void setContents_e_4_4(java.lang.String v)
    {
        this.contents_e_4_4 = v;
    }

    public java.lang.String getContents_e_4_5()
    {
        return contents_e_4_5;
    }

    public void setContents_e_4_5(java.lang.String v)
    {
        this.contents_e_4_5 = v;
    }

    public java.lang.String getContents_e_4_6()
    {
        return contents_e_4_6;
    }

    public void setContents_e_4_6(java.lang.String v)
    {
        this.contents_e_4_6 = v;
    }

    public java.lang.String getContents_e_4_7()
    {
        return contents_e_4_7;
    }

    public void setContents_e_4_7(java.lang.String v)
    {
        this.contents_e_4_7 = v;
    }

    public java.lang.String getContents_e_4_8()
    {
        return contents_e_4_8;
    }

    public void setContents_e_4_8(java.lang.String v)
    {
        this.contents_e_4_8 = v;
    }

    public java.lang.String getContents_e_4_9()
    {
        return contents_e_4_9;
    }

    public void setContents_e_4_9(java.lang.String v)
    {
        this.contents_e_4_9 = v;
    }

    public java.lang.String getContents_e_4_10()
    {
        return contents_e_4_10;
    }

    public void setContents_e_4_10(java.lang.String v)
    {
        this.contents_e_4_10 = v;
    }

    public java.lang.String getComments_r5c6()
    {
        return comments_r5c6;
    }

    public void setComments_r5c6(java.lang.String v)
    {
        this.comments_r5c6 = v;
    }

    public java.lang.String getComments_r5c7()
    {
        return comments_r5c7;
    }

    public void setComments_r5c7(java.lang.String v)
    {
        this.comments_r5c7 = v;
    }

    public java.lang.String getComments_r5c8()
    {
        return comments_r5c8;
    }

    public void setComments_r5c8(java.lang.String v)
    {
        this.comments_r5c8 = v;
    }

    public java.lang.String getComments_r5c9()
    {
        return comments_r5c9;
    }

    public void setComments_r5c9(java.lang.String v)
    {
        this.comments_r5c9 = v;
    }

    public java.lang.String getComments_r5c10()
    {
        return comments_r5c10;
    }

    public void setComments_r5c10(java.lang.String v)
    {
        this.comments_r5c10 = v;
    }

    public java.lang.String getComments_r5c11()
    {
        return comments_r5c11;
    }

    public void setComments_r5c11(java.lang.String v)
    {
        this.comments_r5c11 = v;
    }

    public java.lang.String getComments_r5c12()
    {
        return comments_r5c12;
    }

    public void setComments_r5c12(java.lang.String v)
    {
        this.comments_r5c12 = v;
    }

    public java.lang.String getComments_r5c13()
    {
        return comments_r5c13;
    }

    public void setComments_r5c13(java.lang.String v)
    {
        this.comments_r5c13 = v;
    }

    public java.lang.String getComments_r5c14()
    {
        return comments_r5c14;
    }

    public void setComments_r5c14(java.lang.String v)
    {
        this.comments_r5c14 = v;
    }

    public java.lang.String getComments_r5c15()
    {
        return comments_r5c15;
    }

    public void setComments_r5c15(java.lang.String v)
    {
        this.comments_r5c15 = v;
    }

    public java.lang.Double getContents_e_4_11()
    {
        return contents_e_4_11;
    }

    public void setContents_e_4_11(java.lang.Double v)
    {
        this.contents_e_4_11 = v;
    }

    public java.lang.String getContents_b58()
    {
        return contents_b58;
    }

    public void setContents_b58(java.lang.String v)
    {
        this.contents_b58 = v;
    }

    public java.lang.String getContents_b58_2()
    {
        return contents_b58_2;
    }

    public void setContents_b58_2(java.lang.String v)
    {
        this.contents_b58_2 = v;
    }

    public java.lang.String getContents_b58_3()
    {
        return contents_b58_3;
    }

    public void setContents_b58_3(java.lang.String v)
    {
        this.contents_b58_3 = v;
    }

    public java.lang.String getContents_b58_4()
    {
        return contents_b58_4;
    }

    public void setContents_b58_4(java.lang.String v)
    {
        this.contents_b58_4 = v;
    }

    public java.lang.String getContents_b58_5()
    {
        return contents_b58_5;
    }

    public void setContents_b58_5(java.lang.String v)
    {
        this.contents_b58_5 = v;
    }

    public java.lang.String getContents_b58_6()
    {
        return contents_b58_6;
    }

    public void setContents_b58_6(java.lang.String v)
    {
        this.contents_b58_6 = v;
    }

    public java.lang.String getContents_b58_7()
    {
        return contents_b58_7;
    }

    public void setContents_b58_7(java.lang.String v)
    {
        this.contents_b58_7 = v;
    }

    public java.lang.String getContents_b58_8()
    {
        return contents_b58_8;
    }

    public void setContents_b58_8(java.lang.String v)
    {
        this.contents_b58_8 = v;
    }

    public java.lang.String getContents_b58_9()
    {
        return contents_b58_9;
    }

    public void setContents_b58_9(java.lang.String v)
    {
        this.contents_b58_9 = v;
    }

    public java.lang.String getContents_b58_10()
    {
        return contents_b58_10;
    }

    public void setContents_b58_10(java.lang.String v)
    {
        this.contents_b58_10 = v;
    }

    public java.lang.String getComments()
    {
        return comments;
    }

    public void setComments(java.lang.String v)
    {
        this.comments = v;
    }

    public java.lang.String getComments_2()
    {
        return comments_2;
    }

    public void setComments_2(java.lang.String v)
    {
        this.comments_2 = v;
    }

    public java.lang.String getComments_3()
    {
        return comments_3;
    }

    public void setComments_3(java.lang.String v)
    {
        this.comments_3 = v;
    }

    public java.lang.String getComments_4()
    {
        return comments_4;
    }

    public void setComments_4(java.lang.String v)
    {
        this.comments_4 = v;
    }

    public java.lang.String getComments_5()
    {
        return comments_5;
    }

    public void setComments_5(java.lang.String v)
    {
        this.comments_5 = v;
    }

    public java.lang.String getComments_6()
    {
        return comments_6;
    }

    public void setComments_6(java.lang.String v)
    {
        this.comments_6 = v;
    }

    public java.lang.String getComments_7()
    {
        return comments_7;
    }

    public void setComments_7(java.lang.String v)
    {
        this.comments_7 = v;
    }

    public java.lang.String getComments_8()
    {
        return comments_8;
    }

    public void setComments_8(java.lang.String v)
    {
        this.comments_8 = v;
    }

    public java.lang.String getComments_9()
    {
        return comments_9;
    }

    public void setComments_9(java.lang.String v)
    {
        this.comments_9 = v;
    }

    public java.lang.String getComments_10()
    {
        return comments_10;
    }

    public void setComments_10(java.lang.String v)
    {
        this.comments_10 = v;
    }

    public java.lang.String getComments_11()
    {
        return comments_11;
    }

    public void setComments_11(java.lang.String v)
    {
        this.comments_11 = v;
    }

    public java.lang.String getComments_r8c6()
    {
        return comments_r8c6;
    }

    public void setComments_r8c6(java.lang.String v)
    {
        this.comments_r8c6 = v;
    }

    public java.lang.String getComments_r8c7()
    {
        return comments_r8c7;
    }

    public void setComments_r8c7(java.lang.String v)
    {
        this.comments_r8c7 = v;
    }

    public java.lang.String getComments_r8c8()
    {
        return comments_r8c8;
    }

    public void setComments_r8c8(java.lang.String v)
    {
        this.comments_r8c8 = v;
    }

    public java.lang.String getComments_r8c9()
    {
        return comments_r8c9;
    }

    public void setComments_r8c9(java.lang.String v)
    {
        this.comments_r8c9 = v;
    }

    public java.lang.String getComments_r8c10()
    {
        return comments_r8c10;
    }

    public void setComments_r8c10(java.lang.String v)
    {
        this.comments_r8c10 = v;
    }

    public java.lang.String getComments_r8c11()
    {
        return comments_r8c11;
    }

    public void setComments_r8c11(java.lang.String v)
    {
        this.comments_r8c11 = v;
    }

    public java.lang.String getComments_r8c12()
    {
        return comments_r8c12;
    }

    public void setComments_r8c12(java.lang.String v)
    {
        this.comments_r8c12 = v;
    }

    public java.lang.String getComments_r8c13()
    {
        return comments_r8c13;
    }

    public void setComments_r8c13(java.lang.String v)
    {
        this.comments_r8c13 = v;
    }

    public java.lang.String getComments_r8c14()
    {
        return comments_r8c14;
    }

    public void setComments_r8c14(java.lang.String v)
    {
        this.comments_r8c14 = v;
    }

    public java.lang.String getComments_r8c15()
    {
        return comments_r8c15;
    }

    public void setComments_r8c15(java.lang.String v)
    {
        this.comments_r8c15 = v;
    }

    public java.lang.String getComments_12()
    {
        return comments_12;
    }

    public void setComments_12(java.lang.String v)
    {
        this.comments_12 = v;
    }

    public java.lang.String getComments_r9c6()
    {
        return comments_r9c6;
    }

    public void setComments_r9c6(java.lang.String v)
    {
        this.comments_r9c6 = v;
    }

    public java.lang.String getComments_r9c7()
    {
        return comments_r9c7;
    }

    public void setComments_r9c7(java.lang.String v)
    {
        this.comments_r9c7 = v;
    }

    public java.lang.String getComments_r9c8()
    {
        return comments_r9c8;
    }

    public void setComments_r9c8(java.lang.String v)
    {
        this.comments_r9c8 = v;
    }

    public java.lang.String getComments_r9c9()
    {
        return comments_r9c9;
    }

    public void setComments_r9c9(java.lang.String v)
    {
        this.comments_r9c9 = v;
    }

    public java.lang.String getComments_r9c10()
    {
        return comments_r9c10;
    }

    public void setComments_r9c10(java.lang.String v)
    {
        this.comments_r9c10 = v;
    }

    public java.lang.String getComments_r9c11()
    {
        return comments_r9c11;
    }

    public void setComments_r9c11(java.lang.String v)
    {
        this.comments_r9c11 = v;
    }

    public java.lang.String getComments_r9c12()
    {
        return comments_r9c12;
    }

    public void setComments_r9c12(java.lang.String v)
    {
        this.comments_r9c12 = v;
    }

    public java.lang.String getComments_r9c13()
    {
        return comments_r9c13;
    }

    public void setComments_r9c13(java.lang.String v)
    {
        this.comments_r9c13 = v;
    }

    public java.lang.String getComments_r9c14()
    {
        return comments_r9c14;
    }

    public void setComments_r9c14(java.lang.String v)
    {
        this.comments_r9c14 = v;
    }

    public java.lang.String getComments_r9c15()
    {
        return comments_r9c15;
    }

    public void setComments_r9c15(java.lang.String v)
    {
        this.comments_r9c15 = v;
    }

    public java.lang.String getComments_13()
    {
        return comments_13;
    }

    public void setComments_13(java.lang.String v)
    {
        this.comments_13 = v;
    }

    public java.lang.String getComments_r10c6()
    {
        return comments_r10c6;
    }

    public void setComments_r10c6(java.lang.String v)
    {
        this.comments_r10c6 = v;
    }

    public java.lang.String getComments_r10c7()
    {
        return comments_r10c7;
    }

    public void setComments_r10c7(java.lang.String v)
    {
        this.comments_r10c7 = v;
    }

    public java.lang.String getComments_r10c8()
    {
        return comments_r10c8;
    }

    public void setComments_r10c8(java.lang.String v)
    {
        this.comments_r10c8 = v;
    }

    public java.lang.String getComments_r10c9()
    {
        return comments_r10c9;
    }

    public void setComments_r10c9(java.lang.String v)
    {
        this.comments_r10c9 = v;
    }

    public java.lang.String getComments_r10c10()
    {
        return comments_r10c10;
    }

    public void setComments_r10c10(java.lang.String v)
    {
        this.comments_r10c10 = v;
    }

    public java.lang.String getComments_r10c11()
    {
        return comments_r10c11;
    }

    public void setComments_r10c11(java.lang.String v)
    {
        this.comments_r10c11 = v;
    }

    public java.lang.String getComments_r10c12()
    {
        return comments_r10c12;
    }

    public void setComments_r10c12(java.lang.String v)
    {
        this.comments_r10c12 = v;
    }

    public java.lang.String getComments_r10c13()
    {
        return comments_r10c13;
    }

    public void setComments_r10c13(java.lang.String v)
    {
        this.comments_r10c13 = v;
    }

    public java.lang.String getComments_r10c14()
    {
        return comments_r10c14;
    }

    public void setComments_r10c14(java.lang.String v)
    {
        this.comments_r10c14 = v;
    }

    public java.lang.String getComments_r10c15()
    {
        return comments_r10c15;
    }

    public void setComments_r10c15(java.lang.String v)
    {
        this.comments_r10c15 = v;
    }

    public java.lang.String getComments_14()
    {
        return comments_14;
    }

    public void setComments_14(java.lang.String v)
    {
        this.comments_14 = v;
    }

    public java.lang.String getComments_r11c6()
    {
        return comments_r11c6;
    }

    public void setComments_r11c6(java.lang.String v)
    {
        this.comments_r11c6 = v;
    }

    public java.lang.String getComments_r11c7()
    {
        return comments_r11c7;
    }

    public void setComments_r11c7(java.lang.String v)
    {
        this.comments_r11c7 = v;
    }

    public java.lang.String getComments_r11c8()
    {
        return comments_r11c8;
    }

    public void setComments_r11c8(java.lang.String v)
    {
        this.comments_r11c8 = v;
    }

    public java.lang.String getComments_r11c9()
    {
        return comments_r11c9;
    }

    public void setComments_r11c9(java.lang.String v)
    {
        this.comments_r11c9 = v;
    }

    public java.lang.String getComments_r11c10()
    {
        return comments_r11c10;
    }

    public void setComments_r11c10(java.lang.String v)
    {
        this.comments_r11c10 = v;
    }

    public java.lang.String getComments_r11c11()
    {
        return comments_r11c11;
    }

    public void setComments_r11c11(java.lang.String v)
    {
        this.comments_r11c11 = v;
    }

    public java.lang.String getComments_r11c12()
    {
        return comments_r11c12;
    }

    public void setComments_r11c12(java.lang.String v)
    {
        this.comments_r11c12 = v;
    }

    public java.lang.String getComments_r11c13()
    {
        return comments_r11c13;
    }

    public void setComments_r11c13(java.lang.String v)
    {
        this.comments_r11c13 = v;
    }

    public java.lang.String getComments_r11c14()
    {
        return comments_r11c14;
    }

    public void setComments_r11c14(java.lang.String v)
    {
        this.comments_r11c14 = v;
    }

    public java.lang.String getComments_r11c15()
    {
        return comments_r11c15;
    }

    public void setComments_r11c15(java.lang.String v)
    {
        this.comments_r11c15 = v;
    }

    public java.lang.String getComments_15()
    {
        return comments_15;
    }

    public void setComments_15(java.lang.String v)
    {
        this.comments_15 = v;
    }

    public java.lang.String getComments_r12c6()
    {
        return comments_r12c6;
    }

    public void setComments_r12c6(java.lang.String v)
    {
        this.comments_r12c6 = v;
    }

    public java.lang.String getComments_r12c7()
    {
        return comments_r12c7;
    }

    public void setComments_r12c7(java.lang.String v)
    {
        this.comments_r12c7 = v;
    }

    public java.lang.String getComments_r12c8()
    {
        return comments_r12c8;
    }

    public void setComments_r12c8(java.lang.String v)
    {
        this.comments_r12c8 = v;
    }

    public java.lang.String getComments_r12c9()
    {
        return comments_r12c9;
    }

    public void setComments_r12c9(java.lang.String v)
    {
        this.comments_r12c9 = v;
    }

    public java.lang.String getComments_r12c10()
    {
        return comments_r12c10;
    }

    public void setComments_r12c10(java.lang.String v)
    {
        this.comments_r12c10 = v;
    }

    public java.lang.String getComments_r12c11()
    {
        return comments_r12c11;
    }

    public void setComments_r12c11(java.lang.String v)
    {
        this.comments_r12c11 = v;
    }

    public java.lang.String getComments_r12c12()
    {
        return comments_r12c12;
    }

    public void setComments_r12c12(java.lang.String v)
    {
        this.comments_r12c12 = v;
    }

    public java.lang.String getComments_r12c13()
    {
        return comments_r12c13;
    }

    public void setComments_r12c13(java.lang.String v)
    {
        this.comments_r12c13 = v;
    }

    public java.lang.String getComments_r12c14()
    {
        return comments_r12c14;
    }

    public void setComments_r12c14(java.lang.String v)
    {
        this.comments_r12c14 = v;
    }

    public java.lang.String getComments_r12c15()
    {
        return comments_r12c15;
    }

    public void setComments_r12c15(java.lang.String v)
    {
        this.comments_r12c15 = v;
    }

    public java.lang.String getComments_16()
    {
        return comments_16;
    }

    public void setComments_16(java.lang.String v)
    {
        this.comments_16 = v;
    }

    public java.lang.String getComments_r13c6()
    {
        return comments_r13c6;
    }

    public void setComments_r13c6(java.lang.String v)
    {
        this.comments_r13c6 = v;
    }

    public java.lang.String getComments_r13c7()
    {
        return comments_r13c7;
    }

    public void setComments_r13c7(java.lang.String v)
    {
        this.comments_r13c7 = v;
    }

    public java.lang.String getComments_r13c8()
    {
        return comments_r13c8;
    }

    public void setComments_r13c8(java.lang.String v)
    {
        this.comments_r13c8 = v;
    }

    public java.lang.String getComments_r13c9()
    {
        return comments_r13c9;
    }

    public void setComments_r13c9(java.lang.String v)
    {
        this.comments_r13c9 = v;
    }

    public java.lang.String getComments_r13c10()
    {
        return comments_r13c10;
    }

    public void setComments_r13c10(java.lang.String v)
    {
        this.comments_r13c10 = v;
    }

    public java.lang.String getComments_r13c11()
    {
        return comments_r13c11;
    }

    public void setComments_r13c11(java.lang.String v)
    {
        this.comments_r13c11 = v;
    }

    public java.lang.String getComments_r13c12()
    {
        return comments_r13c12;
    }

    public void setComments_r13c12(java.lang.String v)
    {
        this.comments_r13c12 = v;
    }

    public java.lang.String getComments_r13c13()
    {
        return comments_r13c13;
    }

    public void setComments_r13c13(java.lang.String v)
    {
        this.comments_r13c13 = v;
    }

    public java.lang.String getComments_r13c14()
    {
        return comments_r13c14;
    }

    public void setComments_r13c14(java.lang.String v)
    {
        this.comments_r13c14 = v;
    }

    public java.lang.String getComments_r13c15()
    {
        return comments_r13c15;
    }

    public void setComments_r13c15(java.lang.String v)
    {
        this.comments_r13c15 = v;
    }

    public java.lang.String getComments_17()
    {
        return comments_17;
    }

    public void setComments_17(java.lang.String v)
    {
        this.comments_17 = v;
    }

    public java.lang.String getComments_r14c6()
    {
        return comments_r14c6;
    }

    public void setComments_r14c6(java.lang.String v)
    {
        this.comments_r14c6 = v;
    }

    public java.lang.String getComments_r14c7()
    {
        return comments_r14c7;
    }

    public void setComments_r14c7(java.lang.String v)
    {
        this.comments_r14c7 = v;
    }

    public java.lang.String getComments_r14c8()
    {
        return comments_r14c8;
    }

    public void setComments_r14c8(java.lang.String v)
    {
        this.comments_r14c8 = v;
    }

    public java.lang.String getComments_r14c9()
    {
        return comments_r14c9;
    }

    public void setComments_r14c9(java.lang.String v)
    {
        this.comments_r14c9 = v;
    }

    public java.lang.String getComments_r14c10()
    {
        return comments_r14c10;
    }

    public void setComments_r14c10(java.lang.String v)
    {
        this.comments_r14c10 = v;
    }

    public java.lang.String getComments_r14c11()
    {
        return comments_r14c11;
    }

    public void setComments_r14c11(java.lang.String v)
    {
        this.comments_r14c11 = v;
    }

    public java.lang.String getComments_r14c12()
    {
        return comments_r14c12;
    }

    public void setComments_r14c12(java.lang.String v)
    {
        this.comments_r14c12 = v;
    }

    public java.lang.String getComments_r14c13()
    {
        return comments_r14c13;
    }

    public void setComments_r14c13(java.lang.String v)
    {
        this.comments_r14c13 = v;
    }

    public java.lang.String getComments_r14c14()
    {
        return comments_r14c14;
    }

    public void setComments_r14c14(java.lang.String v)
    {
        this.comments_r14c14 = v;
    }

    public java.lang.String getComments_r14c15()
    {
        return comments_r14c15;
    }

    public void setComments_r14c15(java.lang.String v)
    {
        this.comments_r14c15 = v;
    }

    public java.lang.String getComments_18()
    {
        return comments_18;
    }

    public void setComments_18(java.lang.String v)
    {
        this.comments_18 = v;
    }

    public java.lang.String getComments_r15c6()
    {
        return comments_r15c6;
    }

    public void setComments_r15c6(java.lang.String v)
    {
        this.comments_r15c6 = v;
    }

    public java.lang.String getComments_r15c7()
    {
        return comments_r15c7;
    }

    public void setComments_r15c7(java.lang.String v)
    {
        this.comments_r15c7 = v;
    }

    public java.lang.String getComments_r15c8()
    {
        return comments_r15c8;
    }

    public void setComments_r15c8(java.lang.String v)
    {
        this.comments_r15c8 = v;
    }

    public java.lang.String getComments_r15c9()
    {
        return comments_r15c9;
    }

    public void setComments_r15c9(java.lang.String v)
    {
        this.comments_r15c9 = v;
    }

    public java.lang.String getComments_r15c10()
    {
        return comments_r15c10;
    }

    public void setComments_r15c10(java.lang.String v)
    {
        this.comments_r15c10 = v;
    }

    public java.lang.String getComments_r15c11()
    {
        return comments_r15c11;
    }

    public void setComments_r15c11(java.lang.String v)
    {
        this.comments_r15c11 = v;
    }

    public java.lang.String getComments_r15c12()
    {
        return comments_r15c12;
    }

    public void setComments_r15c12(java.lang.String v)
    {
        this.comments_r15c12 = v;
    }

    public java.lang.String getComments_r15c13()
    {
        return comments_r15c13;
    }

    public void setComments_r15c13(java.lang.String v)
    {
        this.comments_r15c13 = v;
    }

    public java.lang.String getComments_r15c14()
    {
        return comments_r15c14;
    }

    public void setComments_r15c14(java.lang.String v)
    {
        this.comments_r15c14 = v;
    }

    public java.lang.String getComments_r15c15()
    {
        return comments_r15c15;
    }

    public void setComments_r15c15(java.lang.String v)
    {
        this.comments_r15c15 = v;
    }

    public java.lang.String getComments_19()
    {
        return comments_19;
    }

    public void setComments_19(java.lang.String v)
    {
        this.comments_19 = v;
    }

    public java.lang.String getComments_r16c6()
    {
        return comments_r16c6;
    }

    public void setComments_r16c6(java.lang.String v)
    {
        this.comments_r16c6 = v;
    }

    public java.lang.String getComments_r16c7()
    {
        return comments_r16c7;
    }

    public void setComments_r16c7(java.lang.String v)
    {
        this.comments_r16c7 = v;
    }

    public java.lang.String getComments_r16c8()
    {
        return comments_r16c8;
    }

    public void setComments_r16c8(java.lang.String v)
    {
        this.comments_r16c8 = v;
    }

    public java.lang.String getComments_r16c9()
    {
        return comments_r16c9;
    }

    public void setComments_r16c9(java.lang.String v)
    {
        this.comments_r16c9 = v;
    }

    public java.lang.String getComments_r16c10()
    {
        return comments_r16c10;
    }

    public void setComments_r16c10(java.lang.String v)
    {
        this.comments_r16c10 = v;
    }

    public java.lang.String getComments_r16c11()
    {
        return comments_r16c11;
    }

    public void setComments_r16c11(java.lang.String v)
    {
        this.comments_r16c11 = v;
    }

    public java.lang.String getComments_r16c12()
    {
        return comments_r16c12;
    }

    public void setComments_r16c12(java.lang.String v)
    {
        this.comments_r16c12 = v;
    }

    public java.lang.String getComments_r16c13()
    {
        return comments_r16c13;
    }

    public void setComments_r16c13(java.lang.String v)
    {
        this.comments_r16c13 = v;
    }

    public java.lang.String getComments_r16c14()
    {
        return comments_r16c14;
    }

    public void setComments_r16c14(java.lang.String v)
    {
        this.comments_r16c14 = v;
    }

    public java.lang.String getComments_r16c15()
    {
        return comments_r16c15;
    }

    public void setComments_r16c15(java.lang.String v)
    {
        this.comments_r16c15 = v;
    }

    public java.lang.String getComments_20()
    {
        return comments_20;
    }

    public void setComments_20(java.lang.String v)
    {
        this.comments_20 = v;
    }

    public java.lang.String getComments_r17c6()
    {
        return comments_r17c6;
    }

    public void setComments_r17c6(java.lang.String v)
    {
        this.comments_r17c6 = v;
    }

    public java.lang.String getComments_r17c7()
    {
        return comments_r17c7;
    }

    public void setComments_r17c7(java.lang.String v)
    {
        this.comments_r17c7 = v;
    }

    public java.lang.String getComments_r17c8()
    {
        return comments_r17c8;
    }

    public void setComments_r17c8(java.lang.String v)
    {
        this.comments_r17c8 = v;
    }

    public java.lang.String getComments_r17c9()
    {
        return comments_r17c9;
    }

    public void setComments_r17c9(java.lang.String v)
    {
        this.comments_r17c9 = v;
    }

    public java.lang.String getComments_r17c10()
    {
        return comments_r17c10;
    }

    public void setComments_r17c10(java.lang.String v)
    {
        this.comments_r17c10 = v;
    }

    public java.lang.String getComments_r17c11()
    {
        return comments_r17c11;
    }

    public void setComments_r17c11(java.lang.String v)
    {
        this.comments_r17c11 = v;
    }

    public java.lang.String getComments_r17c12()
    {
        return comments_r17c12;
    }

    public void setComments_r17c12(java.lang.String v)
    {
        this.comments_r17c12 = v;
    }

    public java.lang.String getComments_r17c13()
    {
        return comments_r17c13;
    }

    public void setComments_r17c13(java.lang.String v)
    {
        this.comments_r17c13 = v;
    }

    public java.lang.String getComments_r17c14()
    {
        return comments_r17c14;
    }

    public void setComments_r17c14(java.lang.String v)
    {
        this.comments_r17c14 = v;
    }

    public java.lang.String getComments_r17c15()
    {
        return comments_r17c15;
    }

    public void setComments_r17c15(java.lang.String v)
    {
        this.comments_r17c15 = v;
    }

    public java.lang.String getComments_21()
    {
        return comments_21;
    }

    public void setComments_21(java.lang.String v)
    {
        this.comments_21 = v;
    }

    public java.lang.String getComments_r18c6()
    {
        return comments_r18c6;
    }

    public void setComments_r18c6(java.lang.String v)
    {
        this.comments_r18c6 = v;
    }

    public java.lang.String getComments_r18c7()
    {
        return comments_r18c7;
    }

    public void setComments_r18c7(java.lang.String v)
    {
        this.comments_r18c7 = v;
    }

    public java.lang.String getComments_r18c8()
    {
        return comments_r18c8;
    }

    public void setComments_r18c8(java.lang.String v)
    {
        this.comments_r18c8 = v;
    }

    public java.lang.String getComments_r18c9()
    {
        return comments_r18c9;
    }

    public void setComments_r18c9(java.lang.String v)
    {
        this.comments_r18c9 = v;
    }

    public java.lang.String getComments_r18c10()
    {
        return comments_r18c10;
    }

    public void setComments_r18c10(java.lang.String v)
    {
        this.comments_r18c10 = v;
    }

    public java.lang.String getComments_r18c11()
    {
        return comments_r18c11;
    }

    public void setComments_r18c11(java.lang.String v)
    {
        this.comments_r18c11 = v;
    }

    public java.lang.String getComments_r18c12()
    {
        return comments_r18c12;
    }

    public void setComments_r18c12(java.lang.String v)
    {
        this.comments_r18c12 = v;
    }

    public java.lang.String getComments_r18c13()
    {
        return comments_r18c13;
    }

    public void setComments_r18c13(java.lang.String v)
    {
        this.comments_r18c13 = v;
    }

    public java.lang.String getComments_r18c14()
    {
        return comments_r18c14;
    }

    public void setComments_r18c14(java.lang.String v)
    {
        this.comments_r18c14 = v;
    }

    public java.lang.String getComments_r18c15()
    {
        return comments_r18c15;
    }

    public void setComments_r18c15(java.lang.String v)
    {
        this.comments_r18c15 = v;
    }

    public java.lang.String getComments_22()
    {
        return comments_22;
    }

    public void setComments_22(java.lang.String v)
    {
        this.comments_22 = v;
    }

    public java.lang.String getComments_r19c6()
    {
        return comments_r19c6;
    }

    public void setComments_r19c6(java.lang.String v)
    {
        this.comments_r19c6 = v;
    }

    public java.lang.String getComments_r19c7()
    {
        return comments_r19c7;
    }

    public void setComments_r19c7(java.lang.String v)
    {
        this.comments_r19c7 = v;
    }

    public java.lang.String getComments_r19c8()
    {
        return comments_r19c8;
    }

    public void setComments_r19c8(java.lang.String v)
    {
        this.comments_r19c8 = v;
    }

    public java.lang.String getComments_r19c9()
    {
        return comments_r19c9;
    }

    public void setComments_r19c9(java.lang.String v)
    {
        this.comments_r19c9 = v;
    }

    public java.lang.String getComments_r19c10()
    {
        return comments_r19c10;
    }

    public void setComments_r19c10(java.lang.String v)
    {
        this.comments_r19c10 = v;
    }

    public java.lang.String getComments_r19c11()
    {
        return comments_r19c11;
    }

    public void setComments_r19c11(java.lang.String v)
    {
        this.comments_r19c11 = v;
    }

    public java.lang.String getComments_r19c12()
    {
        return comments_r19c12;
    }

    public void setComments_r19c12(java.lang.String v)
    {
        this.comments_r19c12 = v;
    }

    public java.lang.String getComments_r19c13()
    {
        return comments_r19c13;
    }

    public void setComments_r19c13(java.lang.String v)
    {
        this.comments_r19c13 = v;
    }

    public java.lang.String getComments_r19c14()
    {
        return comments_r19c14;
    }

    public void setComments_r19c14(java.lang.String v)
    {
        this.comments_r19c14 = v;
    }

    public java.lang.String getComments_r19c15()
    {
        return comments_r19c15;
    }

    public void setComments_r19c15(java.lang.String v)
    {
        this.comments_r19c15 = v;
    }

    public java.lang.String getComments_23()
    {
        return comments_23;
    }

    public void setComments_23(java.lang.String v)
    {
        this.comments_23 = v;
    }

    public java.lang.String getComments_r20c6()
    {
        return comments_r20c6;
    }

    public void setComments_r20c6(java.lang.String v)
    {
        this.comments_r20c6 = v;
    }

    public java.lang.String getComments_r20c7()
    {
        return comments_r20c7;
    }

    public void setComments_r20c7(java.lang.String v)
    {
        this.comments_r20c7 = v;
    }

    public java.lang.String getComments_r20c8()
    {
        return comments_r20c8;
    }

    public void setComments_r20c8(java.lang.String v)
    {
        this.comments_r20c8 = v;
    }

    public java.lang.String getComments_r20c9()
    {
        return comments_r20c9;
    }

    public void setComments_r20c9(java.lang.String v)
    {
        this.comments_r20c9 = v;
    }

    public java.lang.String getComments_r20c10()
    {
        return comments_r20c10;
    }

    public void setComments_r20c10(java.lang.String v)
    {
        this.comments_r20c10 = v;
    }

    public java.lang.String getComments_r20c11()
    {
        return comments_r20c11;
    }

    public void setComments_r20c11(java.lang.String v)
    {
        this.comments_r20c11 = v;
    }

    public java.lang.String getComments_r20c12()
    {
        return comments_r20c12;
    }

    public void setComments_r20c12(java.lang.String v)
    {
        this.comments_r20c12 = v;
    }

    public java.lang.String getComments_r20c13()
    {
        return comments_r20c13;
    }

    public void setComments_r20c13(java.lang.String v)
    {
        this.comments_r20c13 = v;
    }

    public java.lang.String getComments_r20c14()
    {
        return comments_r20c14;
    }

    public void setComments_r20c14(java.lang.String v)
    {
        this.comments_r20c14 = v;
    }

    public java.lang.String getComments_r20c15()
    {
        return comments_r20c15;
    }

    public void setComments_r20c15(java.lang.String v)
    {
        this.comments_r20c15 = v;
    }

    public java.lang.String getComments_24()
    {
        return comments_24;
    }

    public void setComments_24(java.lang.String v)
    {
        this.comments_24 = v;
    }

    public java.lang.String getComments_r21c6()
    {
        return comments_r21c6;
    }

    public void setComments_r21c6(java.lang.String v)
    {
        this.comments_r21c6 = v;
    }

    public java.lang.String getComments_r21c7()
    {
        return comments_r21c7;
    }

    public void setComments_r21c7(java.lang.String v)
    {
        this.comments_r21c7 = v;
    }

    public java.lang.String getComments_r21c8()
    {
        return comments_r21c8;
    }

    public void setComments_r21c8(java.lang.String v)
    {
        this.comments_r21c8 = v;
    }

    public java.lang.String getComments_r21c9()
    {
        return comments_r21c9;
    }

    public void setComments_r21c9(java.lang.String v)
    {
        this.comments_r21c9 = v;
    }

    public java.lang.String getComments_r21c10()
    {
        return comments_r21c10;
    }

    public void setComments_r21c10(java.lang.String v)
    {
        this.comments_r21c10 = v;
    }

    public java.lang.String getComments_r21c11()
    {
        return comments_r21c11;
    }

    public void setComments_r21c11(java.lang.String v)
    {
        this.comments_r21c11 = v;
    }

    public java.lang.String getComments_r21c12()
    {
        return comments_r21c12;
    }

    public void setComments_r21c12(java.lang.String v)
    {
        this.comments_r21c12 = v;
    }

    public java.lang.String getComments_r21c13()
    {
        return comments_r21c13;
    }

    public void setComments_r21c13(java.lang.String v)
    {
        this.comments_r21c13 = v;
    }

    public java.lang.String getComments_r21c14()
    {
        return comments_r21c14;
    }

    public void setComments_r21c14(java.lang.String v)
    {
        this.comments_r21c14 = v;
    }

    public java.lang.String getComments_r21c15()
    {
        return comments_r21c15;
    }

    public void setComments_r21c15(java.lang.String v)
    {
        this.comments_r21c15 = v;
    }

    public java.lang.String getComments_25()
    {
        return comments_25;
    }

    public void setComments_25(java.lang.String v)
    {
        this.comments_25 = v;
    }

    public java.lang.String getComments_r22c6()
    {
        return comments_r22c6;
    }

    public void setComments_r22c6(java.lang.String v)
    {
        this.comments_r22c6 = v;
    }

    public java.lang.String getComments_r22c7()
    {
        return comments_r22c7;
    }

    public void setComments_r22c7(java.lang.String v)
    {
        this.comments_r22c7 = v;
    }

    public java.lang.String getComments_r22c8()
    {
        return comments_r22c8;
    }

    public void setComments_r22c8(java.lang.String v)
    {
        this.comments_r22c8 = v;
    }

    public java.lang.String getComments_r22c9()
    {
        return comments_r22c9;
    }

    public void setComments_r22c9(java.lang.String v)
    {
        this.comments_r22c9 = v;
    }

    public java.lang.String getComments_r22c10()
    {
        return comments_r22c10;
    }

    public void setComments_r22c10(java.lang.String v)
    {
        this.comments_r22c10 = v;
    }

    public java.lang.String getComments_r22c11()
    {
        return comments_r22c11;
    }

    public void setComments_r22c11(java.lang.String v)
    {
        this.comments_r22c11 = v;
    }

    public java.lang.String getComments_r22c12()
    {
        return comments_r22c12;
    }

    public void setComments_r22c12(java.lang.String v)
    {
        this.comments_r22c12 = v;
    }

    public java.lang.String getComments_r22c13()
    {
        return comments_r22c13;
    }

    public void setComments_r22c13(java.lang.String v)
    {
        this.comments_r22c13 = v;
    }

    public java.lang.String getComments_r22c14()
    {
        return comments_r22c14;
    }

    public void setComments_r22c14(java.lang.String v)
    {
        this.comments_r22c14 = v;
    }

    public java.lang.String getComments_r22c15()
    {
        return comments_r22c15;
    }

    public void setComments_r22c15(java.lang.String v)
    {
        this.comments_r22c15 = v;
    }

    public java.lang.String getComments_26()
    {
        return comments_26;
    }

    public void setComments_26(java.lang.String v)
    {
        this.comments_26 = v;
    }

    public java.lang.String getComments_r23c6()
    {
        return comments_r23c6;
    }

    public void setComments_r23c6(java.lang.String v)
    {
        this.comments_r23c6 = v;
    }

    public java.lang.String getComments_r23c7()
    {
        return comments_r23c7;
    }

    public void setComments_r23c7(java.lang.String v)
    {
        this.comments_r23c7 = v;
    }

    public java.lang.String getComments_r23c8()
    {
        return comments_r23c8;
    }

    public void setComments_r23c8(java.lang.String v)
    {
        this.comments_r23c8 = v;
    }

    public java.lang.String getComments_r23c9()
    {
        return comments_r23c9;
    }

    public void setComments_r23c9(java.lang.String v)
    {
        this.comments_r23c9 = v;
    }

    public java.lang.String getComments_r23c10()
    {
        return comments_r23c10;
    }

    public void setComments_r23c10(java.lang.String v)
    {
        this.comments_r23c10 = v;
    }

    public java.lang.String getComments_r23c11()
    {
        return comments_r23c11;
    }

    public void setComments_r23c11(java.lang.String v)
    {
        this.comments_r23c11 = v;
    }

    public java.lang.String getComments_r23c12()
    {
        return comments_r23c12;
    }

    public void setComments_r23c12(java.lang.String v)
    {
        this.comments_r23c12 = v;
    }

    public java.lang.String getComments_r23c13()
    {
        return comments_r23c13;
    }

    public void setComments_r23c13(java.lang.String v)
    {
        this.comments_r23c13 = v;
    }

    public java.lang.String getComments_r23c14()
    {
        return comments_r23c14;
    }

    public void setComments_r23c14(java.lang.String v)
    {
        this.comments_r23c14 = v;
    }

    public java.lang.String getComments_r23c15()
    {
        return comments_r23c15;
    }

    public void setComments_r23c15(java.lang.String v)
    {
        this.comments_r23c15 = v;
    }

    public java.lang.String getComments_27()
    {
        return comments_27;
    }

    public void setComments_27(java.lang.String v)
    {
        this.comments_27 = v;
    }

    public java.lang.String getComments_r24c6()
    {
        return comments_r24c6;
    }

    public void setComments_r24c6(java.lang.String v)
    {
        this.comments_r24c6 = v;
    }

    public java.lang.String getComments_r24c7()
    {
        return comments_r24c7;
    }

    public void setComments_r24c7(java.lang.String v)
    {
        this.comments_r24c7 = v;
    }

    public java.lang.String getComments_r24c8()
    {
        return comments_r24c8;
    }

    public void setComments_r24c8(java.lang.String v)
    {
        this.comments_r24c8 = v;
    }

    public java.lang.String getComments_r24c9()
    {
        return comments_r24c9;
    }

    public void setComments_r24c9(java.lang.String v)
    {
        this.comments_r24c9 = v;
    }

    public java.lang.String getComments_r24c10()
    {
        return comments_r24c10;
    }

    public void setComments_r24c10(java.lang.String v)
    {
        this.comments_r24c10 = v;
    }

    public java.lang.String getComments_r24c11()
    {
        return comments_r24c11;
    }

    public void setComments_r24c11(java.lang.String v)
    {
        this.comments_r24c11 = v;
    }

    public java.lang.String getComments_r24c12()
    {
        return comments_r24c12;
    }

    public void setComments_r24c12(java.lang.String v)
    {
        this.comments_r24c12 = v;
    }

    public java.lang.String getComments_r24c13()
    {
        return comments_r24c13;
    }

    public void setComments_r24c13(java.lang.String v)
    {
        this.comments_r24c13 = v;
    }

    public java.lang.String getComments_r24c14()
    {
        return comments_r24c14;
    }

    public void setComments_r24c14(java.lang.String v)
    {
        this.comments_r24c14 = v;
    }

    public java.lang.String getComments_r24c15()
    {
        return comments_r24c15;
    }

    public void setComments_r24c15(java.lang.String v)
    {
        this.comments_r24c15 = v;
    }

    public java.lang.String getComments_28()
    {
        return comments_28;
    }

    public void setComments_28(java.lang.String v)
    {
        this.comments_28 = v;
    }

    public java.lang.String getComments_r25c6()
    {
        return comments_r25c6;
    }

    public void setComments_r25c6(java.lang.String v)
    {
        this.comments_r25c6 = v;
    }

    public java.lang.String getComments_r25c7()
    {
        return comments_r25c7;
    }

    public void setComments_r25c7(java.lang.String v)
    {
        this.comments_r25c7 = v;
    }

    public java.lang.String getComments_r25c8()
    {
        return comments_r25c8;
    }

    public void setComments_r25c8(java.lang.String v)
    {
        this.comments_r25c8 = v;
    }

    public java.lang.String getComments_r25c9()
    {
        return comments_r25c9;
    }

    public void setComments_r25c9(java.lang.String v)
    {
        this.comments_r25c9 = v;
    }

    public java.lang.String getComments_r25c10()
    {
        return comments_r25c10;
    }

    public void setComments_r25c10(java.lang.String v)
    {
        this.comments_r25c10 = v;
    }

    public java.lang.String getComments_r25c11()
    {
        return comments_r25c11;
    }

    public void setComments_r25c11(java.lang.String v)
    {
        this.comments_r25c11 = v;
    }

    public java.lang.String getComments_r25c12()
    {
        return comments_r25c12;
    }

    public void setComments_r25c12(java.lang.String v)
    {
        this.comments_r25c12 = v;
    }

    public java.lang.String getComments_r25c13()
    {
        return comments_r25c13;
    }

    public void setComments_r25c13(java.lang.String v)
    {
        this.comments_r25c13 = v;
    }

    public java.lang.String getComments_r25c14()
    {
        return comments_r25c14;
    }

    public void setComments_r25c14(java.lang.String v)
    {
        this.comments_r25c14 = v;
    }

    public java.lang.String getComments_r25c15()
    {
        return comments_r25c15;
    }

    public void setComments_r25c15(java.lang.String v)
    {
        this.comments_r25c15 = v;
    }

    public java.lang.String getComments_29()
    {
        return comments_29;
    }

    public void setComments_29(java.lang.String v)
    {
        this.comments_29 = v;
    }

    public java.lang.String getComments_r26c6()
    {
        return comments_r26c6;
    }

    public void setComments_r26c6(java.lang.String v)
    {
        this.comments_r26c6 = v;
    }

    public java.lang.String getComments_r26c7()
    {
        return comments_r26c7;
    }

    public void setComments_r26c7(java.lang.String v)
    {
        this.comments_r26c7 = v;
    }

    public java.lang.String getComments_r26c8()
    {
        return comments_r26c8;
    }

    public void setComments_r26c8(java.lang.String v)
    {
        this.comments_r26c8 = v;
    }

    public java.lang.String getComments_r26c9()
    {
        return comments_r26c9;
    }

    public void setComments_r26c9(java.lang.String v)
    {
        this.comments_r26c9 = v;
    }

    public java.lang.String getComments_r26c10()
    {
        return comments_r26c10;
    }

    public void setComments_r26c10(java.lang.String v)
    {
        this.comments_r26c10 = v;
    }

    public java.lang.String getComments_r26c11()
    {
        return comments_r26c11;
    }

    public void setComments_r26c11(java.lang.String v)
    {
        this.comments_r26c11 = v;
    }

    public java.lang.String getComments_r26c12()
    {
        return comments_r26c12;
    }

    public void setComments_r26c12(java.lang.String v)
    {
        this.comments_r26c12 = v;
    }

    public java.lang.String getComments_r26c13()
    {
        return comments_r26c13;
    }

    public void setComments_r26c13(java.lang.String v)
    {
        this.comments_r26c13 = v;
    }

    public java.lang.String getComments_r26c14()
    {
        return comments_r26c14;
    }

    public void setComments_r26c14(java.lang.String v)
    {
        this.comments_r26c14 = v;
    }

    public java.lang.String getComments_r26c15()
    {
        return comments_r26c15;
    }

    public void setComments_r26c15(java.lang.String v)
    {
        this.comments_r26c15 = v;
    }

    public java.lang.String getComments_30()
    {
        return comments_30;
    }

    public void setComments_30(java.lang.String v)
    {
        this.comments_30 = v;
    }

    public java.lang.String getComments_r27c6()
    {
        return comments_r27c6;
    }

    public void setComments_r27c6(java.lang.String v)
    {
        this.comments_r27c6 = v;
    }

    public java.lang.String getComments_r27c7()
    {
        return comments_r27c7;
    }

    public void setComments_r27c7(java.lang.String v)
    {
        this.comments_r27c7 = v;
    }

    public java.lang.String getComments_r27c8()
    {
        return comments_r27c8;
    }

    public void setComments_r27c8(java.lang.String v)
    {
        this.comments_r27c8 = v;
    }

    public java.lang.String getComments_r27c9()
    {
        return comments_r27c9;
    }

    public void setComments_r27c9(java.lang.String v)
    {
        this.comments_r27c9 = v;
    }

    public java.lang.String getComments_r27c10()
    {
        return comments_r27c10;
    }

    public void setComments_r27c10(java.lang.String v)
    {
        this.comments_r27c10 = v;
    }

    public java.lang.String getComments_r27c11()
    {
        return comments_r27c11;
    }

    public void setComments_r27c11(java.lang.String v)
    {
        this.comments_r27c11 = v;
    }

    public java.lang.String getComments_r27c12()
    {
        return comments_r27c12;
    }

    public void setComments_r27c12(java.lang.String v)
    {
        this.comments_r27c12 = v;
    }

    public java.lang.String getComments_r27c13()
    {
        return comments_r27c13;
    }

    public void setComments_r27c13(java.lang.String v)
    {
        this.comments_r27c13 = v;
    }

    public java.lang.String getComments_r27c14()
    {
        return comments_r27c14;
    }

    public void setComments_r27c14(java.lang.String v)
    {
        this.comments_r27c14 = v;
    }

    public java.lang.String getComments_r27c15()
    {
        return comments_r27c15;
    }

    public void setComments_r27c15(java.lang.String v)
    {
        this.comments_r27c15 = v;
    }

    public java.lang.String getComments_31()
    {
        return comments_31;
    }

    public void setComments_31(java.lang.String v)
    {
        this.comments_31 = v;
    }

    public java.lang.String getComments_r28c6()
    {
        return comments_r28c6;
    }

    public void setComments_r28c6(java.lang.String v)
    {
        this.comments_r28c6 = v;
    }

    public java.lang.String getComments_r28c7()
    {
        return comments_r28c7;
    }

    public void setComments_r28c7(java.lang.String v)
    {
        this.comments_r28c7 = v;
    }

    public java.lang.String getComments_r28c8()
    {
        return comments_r28c8;
    }

    public void setComments_r28c8(java.lang.String v)
    {
        this.comments_r28c8 = v;
    }

    public java.lang.String getComments_r28c9()
    {
        return comments_r28c9;
    }

    public void setComments_r28c9(java.lang.String v)
    {
        this.comments_r28c9 = v;
    }

    public java.lang.String getComments_r28c10()
    {
        return comments_r28c10;
    }

    public void setComments_r28c10(java.lang.String v)
    {
        this.comments_r28c10 = v;
    }

    public java.lang.String getComments_r28c11()
    {
        return comments_r28c11;
    }

    public void setComments_r28c11(java.lang.String v)
    {
        this.comments_r28c11 = v;
    }

    public java.lang.String getComments_r28c12()
    {
        return comments_r28c12;
    }

    public void setComments_r28c12(java.lang.String v)
    {
        this.comments_r28c12 = v;
    }

    public java.lang.String getComments_r28c13()
    {
        return comments_r28c13;
    }

    public void setComments_r28c13(java.lang.String v)
    {
        this.comments_r28c13 = v;
    }

    public java.lang.String getComments_r28c14()
    {
        return comments_r28c14;
    }

    public void setComments_r28c14(java.lang.String v)
    {
        this.comments_r28c14 = v;
    }

    public java.lang.String getComments_r28c15()
    {
        return comments_r28c15;
    }

    public void setComments_r28c15(java.lang.String v)
    {
        this.comments_r28c15 = v;
    }

    public java.lang.String getComments_32()
    {
        return comments_32;
    }

    public void setComments_32(java.lang.String v)
    {
        this.comments_32 = v;
    }

    public java.lang.String getComments_r29c6()
    {
        return comments_r29c6;
    }

    public void setComments_r29c6(java.lang.String v)
    {
        this.comments_r29c6 = v;
    }

    public java.lang.String getComments_r29c7()
    {
        return comments_r29c7;
    }

    public void setComments_r29c7(java.lang.String v)
    {
        this.comments_r29c7 = v;
    }

    public java.lang.String getComments_r29c8()
    {
        return comments_r29c8;
    }

    public void setComments_r29c8(java.lang.String v)
    {
        this.comments_r29c8 = v;
    }

    public java.lang.String getComments_r29c9()
    {
        return comments_r29c9;
    }

    public void setComments_r29c9(java.lang.String v)
    {
        this.comments_r29c9 = v;
    }

    public java.lang.String getComments_r29c10()
    {
        return comments_r29c10;
    }

    public void setComments_r29c10(java.lang.String v)
    {
        this.comments_r29c10 = v;
    }

    public java.lang.String getComments_r29c11()
    {
        return comments_r29c11;
    }

    public void setComments_r29c11(java.lang.String v)
    {
        this.comments_r29c11 = v;
    }

    public java.lang.String getComments_r29c12()
    {
        return comments_r29c12;
    }

    public void setComments_r29c12(java.lang.String v)
    {
        this.comments_r29c12 = v;
    }

    public java.lang.String getComments_r29c13()
    {
        return comments_r29c13;
    }

    public void setComments_r29c13(java.lang.String v)
    {
        this.comments_r29c13 = v;
    }

    public java.lang.String getComments_r29c14()
    {
        return comments_r29c14;
    }

    public void setComments_r29c14(java.lang.String v)
    {
        this.comments_r29c14 = v;
    }

    public java.lang.String getComments_r29c15()
    {
        return comments_r29c15;
    }

    public void setComments_r29c15(java.lang.String v)
    {
        this.comments_r29c15 = v;
    }

    public java.lang.String getComments_33()
    {
        return comments_33;
    }

    public void setComments_33(java.lang.String v)
    {
        this.comments_33 = v;
    }

    public java.lang.String getComments_r30c6()
    {
        return comments_r30c6;
    }

    public void setComments_r30c6(java.lang.String v)
    {
        this.comments_r30c6 = v;
    }

    public java.lang.String getComments_r30c7()
    {
        return comments_r30c7;
    }

    public void setComments_r30c7(java.lang.String v)
    {
        this.comments_r30c7 = v;
    }

    public java.lang.String getComments_r30c8()
    {
        return comments_r30c8;
    }

    public void setComments_r30c8(java.lang.String v)
    {
        this.comments_r30c8 = v;
    }

    public java.lang.String getComments_r30c9()
    {
        return comments_r30c9;
    }

    public void setComments_r30c9(java.lang.String v)
    {
        this.comments_r30c9 = v;
    }

    public java.lang.String getComments_r30c10()
    {
        return comments_r30c10;
    }

    public void setComments_r30c10(java.lang.String v)
    {
        this.comments_r30c10 = v;
    }

    public java.lang.String getComments_r30c11()
    {
        return comments_r30c11;
    }

    public void setComments_r30c11(java.lang.String v)
    {
        this.comments_r30c11 = v;
    }

    public java.lang.String getComments_r30c12()
    {
        return comments_r30c12;
    }

    public void setComments_r30c12(java.lang.String v)
    {
        this.comments_r30c12 = v;
    }

    public java.lang.String getComments_r30c13()
    {
        return comments_r30c13;
    }

    public void setComments_r30c13(java.lang.String v)
    {
        this.comments_r30c13 = v;
    }

    public java.lang.String getComments_r30c14()
    {
        return comments_r30c14;
    }

    public void setComments_r30c14(java.lang.String v)
    {
        this.comments_r30c14 = v;
    }

    public java.lang.String getComments_r30c15()
    {
        return comments_r30c15;
    }

    public void setComments_r30c15(java.lang.String v)
    {
        this.comments_r30c15 = v;
    }

    public java.lang.String getComments_34()
    {
        return comments_34;
    }

    public void setComments_34(java.lang.String v)
    {
        this.comments_34 = v;
    }

    public java.lang.String getComments_r31c6()
    {
        return comments_r31c6;
    }

    public void setComments_r31c6(java.lang.String v)
    {
        this.comments_r31c6 = v;
    }

    public java.lang.String getComments_r31c7()
    {
        return comments_r31c7;
    }

    public void setComments_r31c7(java.lang.String v)
    {
        this.comments_r31c7 = v;
    }

    public java.lang.String getComments_r31c8()
    {
        return comments_r31c8;
    }

    public void setComments_r31c8(java.lang.String v)
    {
        this.comments_r31c8 = v;
    }

    public java.lang.String getComments_r31c9()
    {
        return comments_r31c9;
    }

    public void setComments_r31c9(java.lang.String v)
    {
        this.comments_r31c9 = v;
    }

    public java.lang.String getComments_r31c10()
    {
        return comments_r31c10;
    }

    public void setComments_r31c10(java.lang.String v)
    {
        this.comments_r31c10 = v;
    }

    public java.lang.String getComments_r31c11()
    {
        return comments_r31c11;
    }

    public void setComments_r31c11(java.lang.String v)
    {
        this.comments_r31c11 = v;
    }

    public java.lang.String getComments_r31c12()
    {
        return comments_r31c12;
    }

    public void setComments_r31c12(java.lang.String v)
    {
        this.comments_r31c12 = v;
    }

    public java.lang.String getComments_r31c13()
    {
        return comments_r31c13;
    }

    public void setComments_r31c13(java.lang.String v)
    {
        this.comments_r31c13 = v;
    }

    public java.lang.String getComments_r31c14()
    {
        return comments_r31c14;
    }

    public void setComments_r31c14(java.lang.String v)
    {
        this.comments_r31c14 = v;
    }

    public java.lang.String getComments_r31c15()
    {
        return comments_r31c15;
    }

    public void setComments_r31c15(java.lang.String v)
    {
        this.comments_r31c15 = v;
    }

    public java.lang.String getComments_35()
    {
        return comments_35;
    }

    public void setComments_35(java.lang.String v)
    {
        this.comments_35 = v;
    }

    public java.lang.String getComments_r32c6()
    {
        return comments_r32c6;
    }

    public void setComments_r32c6(java.lang.String v)
    {
        this.comments_r32c6 = v;
    }

    public java.lang.String getComments_r32c7()
    {
        return comments_r32c7;
    }

    public void setComments_r32c7(java.lang.String v)
    {
        this.comments_r32c7 = v;
    }

    public java.lang.String getComments_r32c8()
    {
        return comments_r32c8;
    }

    public void setComments_r32c8(java.lang.String v)
    {
        this.comments_r32c8 = v;
    }

    public java.lang.String getComments_r32c9()
    {
        return comments_r32c9;
    }

    public void setComments_r32c9(java.lang.String v)
    {
        this.comments_r32c9 = v;
    }

    public java.lang.String getComments_r32c10()
    {
        return comments_r32c10;
    }

    public void setComments_r32c10(java.lang.String v)
    {
        this.comments_r32c10 = v;
    }

    public java.lang.String getComments_r32c11()
    {
        return comments_r32c11;
    }

    public void setComments_r32c11(java.lang.String v)
    {
        this.comments_r32c11 = v;
    }

    public java.lang.String getComments_r32c12()
    {
        return comments_r32c12;
    }

    public void setComments_r32c12(java.lang.String v)
    {
        this.comments_r32c12 = v;
    }

    public java.lang.String getComments_r32c13()
    {
        return comments_r32c13;
    }

    public void setComments_r32c13(java.lang.String v)
    {
        this.comments_r32c13 = v;
    }

    public java.lang.String getComments_r32c14()
    {
        return comments_r32c14;
    }

    public void setComments_r32c14(java.lang.String v)
    {
        this.comments_r32c14 = v;
    }

    public java.lang.String getComments_r32c15()
    {
        return comments_r32c15;
    }

    public void setComments_r32c15(java.lang.String v)
    {
        this.comments_r32c15 = v;
    }

    public java.lang.String getComments_r33c6()
    {
        return comments_r33c6;
    }

    public void setComments_r33c6(java.lang.String v)
    {
        this.comments_r33c6 = v;
    }

    public java.lang.String getComments_r33c7()
    {
        return comments_r33c7;
    }

    public void setComments_r33c7(java.lang.String v)
    {
        this.comments_r33c7 = v;
    }

    public java.lang.String getComments_r33c8()
    {
        return comments_r33c8;
    }

    public void setComments_r33c8(java.lang.String v)
    {
        this.comments_r33c8 = v;
    }

    public java.lang.String getComments_r33c9()
    {
        return comments_r33c9;
    }

    public void setComments_r33c9(java.lang.String v)
    {
        this.comments_r33c9 = v;
    }

    public java.lang.String getComments_r33c10()
    {
        return comments_r33c10;
    }

    public void setComments_r33c10(java.lang.String v)
    {
        this.comments_r33c10 = v;
    }

    public java.lang.String getComments_r33c11()
    {
        return comments_r33c11;
    }

    public void setComments_r33c11(java.lang.String v)
    {
        this.comments_r33c11 = v;
    }

    public java.lang.String getComments_r33c12()
    {
        return comments_r33c12;
    }

    public void setComments_r33c12(java.lang.String v)
    {
        this.comments_r33c12 = v;
    }

    public java.lang.String getComments_r33c13()
    {
        return comments_r33c13;
    }

    public void setComments_r33c13(java.lang.String v)
    {
        this.comments_r33c13 = v;
    }

    public java.lang.String getComments_r33c14()
    {
        return comments_r33c14;
    }

    public void setComments_r33c14(java.lang.String v)
    {
        this.comments_r33c14 = v;
    }

    public java.lang.String getComments_r33c15()
    {
        return comments_r33c15;
    }

    public void setComments_r33c15(java.lang.String v)
    {
        this.comments_r33c15 = v;
    }

    public COMMENTSBean()
    {
    }

}
