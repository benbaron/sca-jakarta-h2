package nonprofitbookkeeping.reports.jasper.beans;

public class AssetDtl5aPrepaidExpenseLineItem
{
    private java.lang.String prepaid_expenses_description;
    private java.lang.String prior_amount;
    private java.lang.String current_amount;

    public java.lang.String getPrepaid_expenses_description()
    {
        return prepaid_expenses_description;
    }

    public void setPrepaid_expenses_description(java.lang.String v)
    {
        this.prepaid_expenses_description = v;
    }

    public java.lang.String getPrior_amount()
    {
        return prior_amount;
    }

    public void setPrior_amount(java.lang.String v)
    {
        this.prior_amount = v;
    }

    public java.lang.String getCurrent_amount()
    {
        return current_amount;
    }

    public void setCurrent_amount(java.lang.String v)
    {
        this.current_amount = v;
    }
}
