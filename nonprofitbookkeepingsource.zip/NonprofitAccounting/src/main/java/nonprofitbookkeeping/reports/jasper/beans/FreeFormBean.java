package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet FreeForm */
public class FreeFormBean
{


    public FreeFormBean()
    {
    }

}
