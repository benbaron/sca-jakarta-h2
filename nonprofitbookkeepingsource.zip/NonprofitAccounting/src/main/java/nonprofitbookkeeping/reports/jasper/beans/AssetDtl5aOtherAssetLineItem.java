package nonprofitbookkeeping.reports.jasper.beans;

public class AssetDtl5aOtherAssetLineItem
{
    private java.lang.String other_assets_description;
    private java.lang.String reason;
    private java.lang.String show_on;
    private java.lang.String prior_amount;
    private java.lang.String current_amount;

    public java.lang.String getOther_assets_description()
    {
        return other_assets_description;
    }

    public void setOther_assets_description(java.lang.String v)
    {
        this.other_assets_description = v;
    }

    public java.lang.String getReason()
    {
        return reason;
    }

    public void setReason(java.lang.String v)
    {
        this.reason = v;
    }

    public java.lang.String getShow_on()
    {
        return show_on;
    }

    public void setShow_on(java.lang.String v)
    {
        this.show_on = v;
    }

    public java.lang.String getPrior_amount()
    {
        return prior_amount;
    }

    public void setPrior_amount(java.lang.String v)
    {
        this.prior_amount = v;
    }

    public java.lang.String getCurrent_amount()
    {
        return current_amount;
    }

    public void setCurrent_amount(java.lang.String v)
    {
        this.current_amount = v;
    }
}
