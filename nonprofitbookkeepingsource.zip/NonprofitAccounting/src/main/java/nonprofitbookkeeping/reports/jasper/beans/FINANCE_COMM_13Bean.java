package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet FINANCE_COMM_13 */
public class FINANCE_COMM_13Bean
{

    private java.lang.Double finance_comm_13_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String mark_only_one;
    private java.lang.String mark_only_one_2;
    private java.lang.String mark_only_one_3;
    private java.lang.Double sca_name_seneschal;
    private java.lang.String number_if_contents_c_9_contents_c_9;
    private java.lang.String mm_yyyy_if_contents_c_9_contents_c_9;
    private java.lang.String if_contents_c_9_contents_c_9;
    private java.lang.String number;
    private java.lang.String mm_yyyy;
    private java.lang.Double if_contents_c_9_contents_c_9_exchequer;
    private java.lang.Double number_if_contents_c_10_contents_c_10;
    private java.lang.Double mm_yyyy_if_isblank_contact_info_1_h15_contact_info_1_h15;
    private java.lang.Double if_contents_c_10_contents_c_10;
    private java.lang.String exchequer;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16;
    private java.lang.String exchequer_2;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_2;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_2;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_2;
    private java.lang.String exchequer_3;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_3;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_3;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_3;
    private java.lang.String exchequer_4;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_4;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_4;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_4;
    private java.lang.String exchequer_5;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_5;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_5;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_5;
    private java.lang.String exchequer_6;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_6;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_6;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_6;
    private java.lang.String exchequer_7;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_7;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_7;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_7;
    private java.lang.String exchequer_8;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_8;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_8;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_8;
    private java.lang.String exchequer_9;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_9;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_9;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_9;
    private java.lang.String exchequer_10;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_10;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_10;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_10;
    private java.lang.String exchequer_11;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_11;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_11;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_11;
    private java.lang.String exchequer_12;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_12;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_12;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_12;
    private java.lang.String exchequer_13;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_13;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_13;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_13;
    private java.lang.String exchequer_14;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_14;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_14;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_14;
    private java.lang.String exchequer_15;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_15;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_15;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_15;
    private java.lang.String exchequer_16;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_16;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_16;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_16;
    private java.lang.String exchequer_17;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_17;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_17;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_17;
    private java.lang.String exchequer_18;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_18;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_18;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_18;
    private java.lang.String exchequer_19;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_19;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_19;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_19;
    private java.lang.String exchequer_20;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_20;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_20;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_20;
    private java.lang.String exchequer_21;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_21;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_21;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_21;
    private java.lang.String exchequer_22;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_22;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_22;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_22;
    private java.lang.String exchequer_23;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_23;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_23;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_23;
    private java.lang.String exchequer_24;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_24;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_24;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_24;
    private java.lang.String exchequer_25;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_25;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_25;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_25;
    private java.lang.String exchequer_26;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_26;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_26;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_26;
    private java.lang.String exchequer_27;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_27;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_27;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_27;
    private java.lang.String exchequer_28;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_28;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_28;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_28;
    private java.lang.String exchequer_29;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_29;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_29;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_29;
    private java.lang.String exchequer_30;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_30;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_30;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_30;
    private java.lang.String exchequer_31;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_31;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_31;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_31;
    private java.lang.String exchequer_32;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_32;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_32;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_32;
    private java.lang.String exchequer_33;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_33;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_33;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_33;
    private java.lang.String exchequer_34;
    private java.lang.String if_isblank_contact_info_1_d16_contact_info_1_d16_34;
    private java.lang.String if_isblank_contact_info_1_h15_contact_info_1_h15_34;
    private java.lang.String if_isblank_contact_info_1_h16_contact_info_1_h16_34;
    private java.lang.Double x;

    public java.lang.Double getFinance_comm_13_r2c3()
    {
        return finance_comm_13_r2c3;
    }

    public void setFinance_comm_13_r2c3(java.lang.Double v)
    {
        this.finance_comm_13_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getMark_only_one()
    {
        return mark_only_one;
    }

    public void setMark_only_one(java.lang.String v)
    {
        this.mark_only_one = v;
    }

    public java.lang.String getMark_only_one_2()
    {
        return mark_only_one_2;
    }

    public void setMark_only_one_2(java.lang.String v)
    {
        this.mark_only_one_2 = v;
    }

    public java.lang.String getMark_only_one_3()
    {
        return mark_only_one_3;
    }

    public void setMark_only_one_3(java.lang.String v)
    {
        this.mark_only_one_3 = v;
    }

    public java.lang.Double getSca_name_seneschal()
    {
        return sca_name_seneschal;
    }

    public void setSca_name_seneschal(java.lang.Double v)
    {
        this.sca_name_seneschal = v;
    }

    public java.lang.String getNumber_if_contents_c_9_contents_c_9()
    {
        return number_if_contents_c_9_contents_c_9;
    }

    public void setNumber_if_contents_c_9_contents_c_9(java.lang.String v)
    {
        this.number_if_contents_c_9_contents_c_9 = v;
    }

    public java.lang.String getMm_yyyy_if_contents_c_9_contents_c_9()
    {
        return mm_yyyy_if_contents_c_9_contents_c_9;
    }

    public void setMm_yyyy_if_contents_c_9_contents_c_9(java.lang.String v)
    {
        this.mm_yyyy_if_contents_c_9_contents_c_9 = v;
    }

    public java.lang.String getIf_contents_c_9_contents_c_9()
    {
        return if_contents_c_9_contents_c_9;
    }

    public void setIf_contents_c_9_contents_c_9(java.lang.String v)
    {
        this.if_contents_c_9_contents_c_9 = v;
    }

    public java.lang.String getNumber()
    {
        return number;
    }

    public void setNumber(java.lang.String v)
    {
        this.number = v;
    }

    public java.lang.String getMm_yyyy()
    {
        return mm_yyyy;
    }

    public void setMm_yyyy(java.lang.String v)
    {
        this.mm_yyyy = v;
    }

    public java.lang.Double getIf_contents_c_9_contents_c_9_exchequer()
    {
        return if_contents_c_9_contents_c_9_exchequer;
    }

    public void setIf_contents_c_9_contents_c_9_exchequer(java.lang.Double v)
    {
        this.if_contents_c_9_contents_c_9_exchequer = v;
    }

    public java.lang.Double getNumber_if_contents_c_10_contents_c_10()
    {
        return number_if_contents_c_10_contents_c_10;
    }

    public void setNumber_if_contents_c_10_contents_c_10(java.lang.Double v)
    {
        this.number_if_contents_c_10_contents_c_10 = v;
    }

    public java.lang.Double getMm_yyyy_if_isblank_contact_info_1_h15_contact_info_1_h15()
    {
        return mm_yyyy_if_isblank_contact_info_1_h15_contact_info_1_h15;
    }

    public void setMm_yyyy_if_isblank_contact_info_1_h15_contact_info_1_h15(java.lang.Double v)
    {
        this.mm_yyyy_if_isblank_contact_info_1_h15_contact_info_1_h15 = v;
    }

    public java.lang.Double getIf_contents_c_10_contents_c_10()
    {
        return if_contents_c_10_contents_c_10;
    }

    public void setIf_contents_c_10_contents_c_10(java.lang.Double v)
    {
        this.if_contents_c_10_contents_c_10 = v;
    }

    public java.lang.String getExchequer()
    {
        return exchequer;
    }

    public void setExchequer(java.lang.String v)
    {
        this.exchequer = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16 = v;
    }

    public java.lang.String getExchequer_2()
    {
        return exchequer_2;
    }

    public void setExchequer_2(java.lang.String v)
    {
        this.exchequer_2 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_2()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_2;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_2(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_2 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_2()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_2;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_2(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_2 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_2()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_2;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_2(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_2 = v;
    }

    public java.lang.String getExchequer_3()
    {
        return exchequer_3;
    }

    public void setExchequer_3(java.lang.String v)
    {
        this.exchequer_3 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_3()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_3;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_3(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_3 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_3()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_3;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_3(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_3 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_3()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_3;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_3(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_3 = v;
    }

    public java.lang.String getExchequer_4()
    {
        return exchequer_4;
    }

    public void setExchequer_4(java.lang.String v)
    {
        this.exchequer_4 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_4()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_4;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_4(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_4 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_4()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_4;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_4(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_4 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_4()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_4;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_4(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_4 = v;
    }

    public java.lang.String getExchequer_5()
    {
        return exchequer_5;
    }

    public void setExchequer_5(java.lang.String v)
    {
        this.exchequer_5 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_5()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_5;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_5(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_5 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_5()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_5;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_5(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_5 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_5()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_5;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_5(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_5 = v;
    }

    public java.lang.String getExchequer_6()
    {
        return exchequer_6;
    }

    public void setExchequer_6(java.lang.String v)
    {
        this.exchequer_6 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_6()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_6;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_6(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_6 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_6()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_6;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_6(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_6 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_6()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_6;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_6(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_6 = v;
    }

    public java.lang.String getExchequer_7()
    {
        return exchequer_7;
    }

    public void setExchequer_7(java.lang.String v)
    {
        this.exchequer_7 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_7()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_7;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_7(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_7 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_7()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_7;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_7(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_7 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_7()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_7;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_7(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_7 = v;
    }

    public java.lang.String getExchequer_8()
    {
        return exchequer_8;
    }

    public void setExchequer_8(java.lang.String v)
    {
        this.exchequer_8 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_8()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_8;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_8(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_8 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_8()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_8;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_8(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_8 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_8()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_8;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_8(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_8 = v;
    }

    public java.lang.String getExchequer_9()
    {
        return exchequer_9;
    }

    public void setExchequer_9(java.lang.String v)
    {
        this.exchequer_9 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_9()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_9;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_9(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_9 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_9()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_9;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_9(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_9 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_9()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_9;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_9(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_9 = v;
    }

    public java.lang.String getExchequer_10()
    {
        return exchequer_10;
    }

    public void setExchequer_10(java.lang.String v)
    {
        this.exchequer_10 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_10()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_10;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_10(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_10 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_10()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_10;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_10(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_10 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_10()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_10;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_10(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_10 = v;
    }

    public java.lang.String getExchequer_11()
    {
        return exchequer_11;
    }

    public void setExchequer_11(java.lang.String v)
    {
        this.exchequer_11 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_11()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_11;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_11(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_11 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_11()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_11;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_11(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_11 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_11()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_11;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_11(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_11 = v;
    }

    public java.lang.String getExchequer_12()
    {
        return exchequer_12;
    }

    public void setExchequer_12(java.lang.String v)
    {
        this.exchequer_12 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_12()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_12;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_12(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_12 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_12()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_12;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_12(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_12 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_12()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_12;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_12(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_12 = v;
    }

    public java.lang.String getExchequer_13()
    {
        return exchequer_13;
    }

    public void setExchequer_13(java.lang.String v)
    {
        this.exchequer_13 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_13()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_13;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_13(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_13 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_13()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_13;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_13(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_13 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_13()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_13;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_13(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_13 = v;
    }

    public java.lang.String getExchequer_14()
    {
        return exchequer_14;
    }

    public void setExchequer_14(java.lang.String v)
    {
        this.exchequer_14 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_14()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_14;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_14(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_14 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_14()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_14;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_14(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_14 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_14()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_14;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_14(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_14 = v;
    }

    public java.lang.String getExchequer_15()
    {
        return exchequer_15;
    }

    public void setExchequer_15(java.lang.String v)
    {
        this.exchequer_15 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_15()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_15;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_15(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_15 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_15()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_15;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_15(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_15 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_15()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_15;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_15(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_15 = v;
    }

    public java.lang.String getExchequer_16()
    {
        return exchequer_16;
    }

    public void setExchequer_16(java.lang.String v)
    {
        this.exchequer_16 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_16()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_16;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_16(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_16 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_16()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_16;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_16(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_16 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_16()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_16;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_16(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_16 = v;
    }

    public java.lang.String getExchequer_17()
    {
        return exchequer_17;
    }

    public void setExchequer_17(java.lang.String v)
    {
        this.exchequer_17 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_17()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_17;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_17(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_17 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_17()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_17;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_17(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_17 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_17()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_17;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_17(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_17 = v;
    }

    public java.lang.String getExchequer_18()
    {
        return exchequer_18;
    }

    public void setExchequer_18(java.lang.String v)
    {
        this.exchequer_18 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_18()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_18;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_18(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_18 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_18()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_18;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_18(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_18 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_18()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_18;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_18(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_18 = v;
    }

    public java.lang.String getExchequer_19()
    {
        return exchequer_19;
    }

    public void setExchequer_19(java.lang.String v)
    {
        this.exchequer_19 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_19()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_19;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_19(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_19 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_19()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_19;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_19(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_19 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_19()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_19;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_19(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_19 = v;
    }

    public java.lang.String getExchequer_20()
    {
        return exchequer_20;
    }

    public void setExchequer_20(java.lang.String v)
    {
        this.exchequer_20 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_20()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_20;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_20(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_20 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_20()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_20;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_20(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_20 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_20()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_20;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_20(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_20 = v;
    }

    public java.lang.String getExchequer_21()
    {
        return exchequer_21;
    }

    public void setExchequer_21(java.lang.String v)
    {
        this.exchequer_21 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_21()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_21;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_21(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_21 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_21()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_21;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_21(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_21 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_21()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_21;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_21(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_21 = v;
    }

    public java.lang.String getExchequer_22()
    {
        return exchequer_22;
    }

    public void setExchequer_22(java.lang.String v)
    {
        this.exchequer_22 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_22()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_22;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_22(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_22 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_22()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_22;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_22(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_22 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_22()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_22;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_22(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_22 = v;
    }

    public java.lang.String getExchequer_23()
    {
        return exchequer_23;
    }

    public void setExchequer_23(java.lang.String v)
    {
        this.exchequer_23 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_23()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_23;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_23(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_23 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_23()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_23;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_23(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_23 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_23()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_23;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_23(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_23 = v;
    }

    public java.lang.String getExchequer_24()
    {
        return exchequer_24;
    }

    public void setExchequer_24(java.lang.String v)
    {
        this.exchequer_24 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_24()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_24;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_24(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_24 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_24()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_24;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_24(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_24 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_24()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_24;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_24(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_24 = v;
    }

    public java.lang.String getExchequer_25()
    {
        return exchequer_25;
    }

    public void setExchequer_25(java.lang.String v)
    {
        this.exchequer_25 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_25()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_25;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_25(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_25 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_25()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_25;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_25(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_25 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_25()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_25;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_25(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_25 = v;
    }

    public java.lang.String getExchequer_26()
    {
        return exchequer_26;
    }

    public void setExchequer_26(java.lang.String v)
    {
        this.exchequer_26 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_26()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_26;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_26(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_26 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_26()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_26;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_26(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_26 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_26()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_26;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_26(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_26 = v;
    }

    public java.lang.String getExchequer_27()
    {
        return exchequer_27;
    }

    public void setExchequer_27(java.lang.String v)
    {
        this.exchequer_27 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_27()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_27;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_27(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_27 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_27()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_27;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_27(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_27 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_27()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_27;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_27(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_27 = v;
    }

    public java.lang.String getExchequer_28()
    {
        return exchequer_28;
    }

    public void setExchequer_28(java.lang.String v)
    {
        this.exchequer_28 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_28()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_28;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_28(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_28 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_28()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_28;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_28(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_28 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_28()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_28;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_28(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_28 = v;
    }

    public java.lang.String getExchequer_29()
    {
        return exchequer_29;
    }

    public void setExchequer_29(java.lang.String v)
    {
        this.exchequer_29 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_29()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_29;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_29(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_29 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_29()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_29;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_29(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_29 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_29()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_29;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_29(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_29 = v;
    }

    public java.lang.String getExchequer_30()
    {
        return exchequer_30;
    }

    public void setExchequer_30(java.lang.String v)
    {
        this.exchequer_30 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_30()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_30;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_30(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_30 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_30()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_30;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_30(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_30 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_30()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_30;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_30(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_30 = v;
    }

    public java.lang.String getExchequer_31()
    {
        return exchequer_31;
    }

    public void setExchequer_31(java.lang.String v)
    {
        this.exchequer_31 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_31()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_31;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_31(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_31 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_31()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_31;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_31(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_31 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_31()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_31;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_31(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_31 = v;
    }

    public java.lang.String getExchequer_32()
    {
        return exchequer_32;
    }

    public void setExchequer_32(java.lang.String v)
    {
        this.exchequer_32 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_32()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_32;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_32(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_32 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_32()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_32;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_32(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_32 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_32()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_32;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_32(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_32 = v;
    }

    public java.lang.String getExchequer_33()
    {
        return exchequer_33;
    }

    public void setExchequer_33(java.lang.String v)
    {
        this.exchequer_33 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_33()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_33;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_33(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_33 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_33()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_33;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_33(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_33 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_33()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_33;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_33(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_33 = v;
    }

    public java.lang.String getExchequer_34()
    {
        return exchequer_34;
    }

    public void setExchequer_34(java.lang.String v)
    {
        this.exchequer_34 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_d16_contact_info_1_d16_34()
    {
        return if_isblank_contact_info_1_d16_contact_info_1_d16_34;
    }

    public void setIf_isblank_contact_info_1_d16_contact_info_1_d16_34(java.lang.String v)
    {
        this.if_isblank_contact_info_1_d16_contact_info_1_d16_34 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h15_contact_info_1_h15_34()
    {
        return if_isblank_contact_info_1_h15_contact_info_1_h15_34;
    }

    public void setIf_isblank_contact_info_1_h15_contact_info_1_h15_34(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h15_contact_info_1_h15_34 = v;
    }

    public java.lang.String getIf_isblank_contact_info_1_h16_contact_info_1_h16_34()
    {
        return if_isblank_contact_info_1_h16_contact_info_1_h16_34;
    }

    public void setIf_isblank_contact_info_1_h16_contact_info_1_h16_34(java.lang.String v)
    {
        this.if_isblank_contact_info_1_h16_contact_info_1_h16_34 = v;
    }

    public java.lang.Double getX()
    {
        return x;
    }

    public void setX(java.lang.Double v)
    {
        this.x = v;
    }

    public FINANCE_COMM_13Bean()
    {
    }

}
