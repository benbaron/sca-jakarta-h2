package nonprofitbookkeeping.reports.jasper.beans;

public class AssetDtl5aUndepositedFundsLineItem
{
    private java.lang.String sending_branch_or_reason_left;
    private java.lang.String amount_left;
    private java.lang.String sending_branch_or_reason_right;
    private java.lang.String sending_branch_or_reason_detail;
    private java.lang.String amount_right;

    public java.lang.String getSending_branch_or_reason_left()
    {
        return sending_branch_or_reason_left;
    }

    public void setSending_branch_or_reason_left(java.lang.String v)
    {
        this.sending_branch_or_reason_left = v;
    }

    public java.lang.String getAmount_left()
    {
        return amount_left;
    }

    public void setAmount_left(java.lang.String v)
    {
        this.amount_left = v;
    }

    public java.lang.String getSending_branch_or_reason_right()
    {
        return sending_branch_or_reason_right;
    }

    public void setSending_branch_or_reason_right(java.lang.String v)
    {
        this.sending_branch_or_reason_right = v;
    }

    public java.lang.String getSending_branch_or_reason_detail()
    {
        return sending_branch_or_reason_detail;
    }

    public void setSending_branch_or_reason_detail(java.lang.String v)
    {
        this.sending_branch_or_reason_detail = v;
    }

    public java.lang.String getAmount_right()
    {
        return amount_right;
    }

    public void setAmount_right(java.lang.String v)
    {
        this.amount_right = v;
    }
}
