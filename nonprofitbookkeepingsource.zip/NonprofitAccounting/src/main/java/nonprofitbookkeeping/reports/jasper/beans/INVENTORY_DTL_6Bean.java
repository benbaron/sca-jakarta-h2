package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet INVENTORY_DTL_6 */
public class INVENTORY_DTL_6Bean
{

    private java.lang.Double inventory_dtl_6_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String lot_item_description_and_year_purchased;
    private java.lang.String lot_item_description_and_year_purchased_2;
    private java.lang.String lot_item_description_and_year_purchased_3;
    private java.lang.String lot_item_description_and_year_purchased_4;
    private java.lang.String lot_item_description_and_year_purchased_5;
    private java.lang.String lot_item_description_and_year_purchased_6;
    private java.lang.String lot_item_description_and_year_purchased_7;
    private java.lang.String lot_item_description_and_year_purchased_8;
    private java.lang.String suggested_selling_price;
    private java.lang.String suggested_selling_price_2;
    private java.lang.String suggested_selling_price_3;
    private java.lang.String suggested_selling_price_4;
    private java.lang.String suggested_selling_price_5;
    private java.lang.String suggested_selling_price_6;
    private java.lang.String suggested_selling_price_7;
    private java.lang.String suggested_selling_price_8;
    private java.lang.String existing_lot_quantity;
    private java.lang.String existing_lot_quantity_2;
    private java.lang.String existing_lot_quantity_3;
    private java.lang.String existing_lot_quantity_4;
    private java.lang.String existing_lot_quantity_5;
    private java.lang.String existing_lot_quantity_6;
    private java.lang.String existing_lot_quantity_7;
    private java.lang.String existing_lot_quantity_8;
    private java.lang.String existing_lot_extended_cost;
    private java.lang.String existing_lot_extended_cost_2;
    private java.lang.String existing_lot_extended_cost_3;
    private java.lang.String existing_lot_extended_cost_4;
    private java.lang.String existing_lot_extended_cost_5;
    private java.lang.String existing_lot_extended_cost_6;
    private java.lang.String existing_lot_extended_cost_7;
    private java.lang.String existing_lot_extended_cost_8;
    private java.lang.Double pg_3_i_d_start_existing_lot_extended_cost;
    private java.lang.String new_lot_purchase_quantity;
    private java.lang.String new_lot_purchase_quantity_2;
    private java.lang.String new_lot_purchase_quantity_3;
    private java.lang.String new_lot_purchase_quantity_4;
    private java.lang.String new_lot_purchase_quantity_5;
    private java.lang.String new_lot_purchase_quantity_6;
    private java.lang.String new_lot_purchase_quantity_7;
    private java.lang.String new_lot_purchase_quantity_8;
    private java.lang.String new_lot_purchase_cost;
    private java.lang.String new_lot_purchase_cost_2;
    private java.lang.String new_lot_purchase_cost_3;
    private java.lang.String new_lot_purchase_cost_4;
    private java.lang.String new_lot_purchase_cost_5;
    private java.lang.String new_lot_purchase_cost_6;
    private java.lang.String new_lot_purchase_cost_7;
    private java.lang.String new_lot_purchase_cost_8;
    private java.lang.Double per_unit_cost_b1_a1_or_b2_a2;
    private java.lang.Double if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0;
    private java.lang.Double if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0;
    private java.lang.Double if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0;
    private java.lang.Double if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0;
    private java.lang.Double if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0;
    private java.lang.Double if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0;
    private java.lang.Double if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0;
    private java.lang.String if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_sold_at_any_price;
    private java.lang.String if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_sold_at_any_price;
    private java.lang.String if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_sold_at_any_price;
    private java.lang.String if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_sold_at_any_price;
    private java.lang.String if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_sold_at_any_price;
    private java.lang.String if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_sold_at_any_price;
    private java.lang.String if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_sold_at_any_price;
    private java.lang.String if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_sold_at_any_price;
    private java.lang.String if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_removed_or_discarded;
    private java.lang.String if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_removed_or_discarded;
    private java.lang.String if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_removed_or_discarded;
    private java.lang.String if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_removed_or_discarded;
    private java.lang.String if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_removed_or_discarded;
    private java.lang.String if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_removed_or_discarded;
    private java.lang.String if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_removed_or_discarded;
    private java.lang.String if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_removed_or_discarded;
    private java.lang.Double if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_ending_quantity_b1or_b2_d_e;
    private java.lang.Double if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_if_e16_0_e16_e19_e24_e25;
    private java.lang.Double if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_if_f16_0_f16_f19_f24_f25;
    private java.lang.Double if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_if_g16_0_g16_g19_g24_g25;
    private java.lang.Double if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_if_h16_0_h16_h19_h24_h25;
    private java.lang.Double if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_if_i16_0_i16_i19_i24_i25;
    private java.lang.Double if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_if_j16_0_j16_j19_j24_j25;
    private java.lang.Double if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_if_k16_0_k16_k19_k24_k25;
    private java.lang.Double if_e16_0_e16_e19_e24_e25_ending_extended_cost_f_x_c;
    private java.lang.Double if_f16_0_f16_f19_f24_f25_e26_e22;
    private java.lang.Double if_g16_0_g16_g19_g24_g25_f26_f22;
    private java.lang.Double if_h16_0_h16_h19_h24_h25_g26_g22;
    private java.lang.Double if_i16_0_i16_i19_i24_i25_h26_h22;
    private java.lang.Double if_j16_0_j16_j19_j24_j25_i26_i22;
    private java.lang.Double if_k16_0_k16_k19_k24_k25_j26_j22;
    private java.lang.Double if_l16_0_l16_l19_l24_l25_k26_k22;
    private java.lang.Double pg_3_i_d_end_l26_l22;
    private java.lang.Double e26_e22_cost_of_goods_b1_b2_g;
    private java.lang.Double f26_f22_e17_e20_e27;
    private java.lang.Double g26_g22_f17_f20_f27;
    private java.lang.Double h26_h22_g17_g20_g27;
    private java.lang.Double i26_i22_h17_h20_h27;
    private java.lang.Double j26_j22_i17_i20_i27;
    private java.lang.Double k26_k22_j17_j20_j27;
    private java.lang.Double l26_l22_k17_k20_k27;
    private java.lang.Double sum_e27_l27_l17_l20_l27;
    private java.lang.String e17_e20_e27_actual_gross_income_from_inventory_sales;
    private java.lang.String f17_f20_f27_actual_gross_income_from_inventory_sales;
    private java.lang.String g17_g20_g27_actual_gross_income_from_inventory_sales;
    private java.lang.String h17_h20_h27_actual_gross_income_from_inventory_sales;
    private java.lang.String i17_i20_i27_actual_gross_income_from_inventory_sales;
    private java.lang.String j17_j20_j27_actual_gross_income_from_inventory_sales;
    private java.lang.String k17_k20_k27_actual_gross_income_from_inventory_sales;
    private java.lang.String l17_l20_l27_actual_gross_income_from_inventory_sales;
    private java.lang.Double sum_e29_l29_actual_gross_income_from_inventory_sales;
    private java.lang.Double e17_e20_e27_net_inventory_sales_income_i_h;
    private java.lang.Double f17_f20_f27_e30_e29;
    private java.lang.Double g17_g20_g27_f30_f29;
    private java.lang.Double h17_h20_h27_g30_g29;
    private java.lang.Double i17_i20_i27_h30_h29;
    private java.lang.Double j17_j20_j27_i30_i29;
    private java.lang.Double k17_k20_k27_j30_j29;
    private java.lang.Double l17_l20_l27_k30_k29;

    public java.lang.Double getInventory_dtl_6_r2c3()
    {
        return inventory_dtl_6_r2c3;
    }

    public void setInventory_dtl_6_r2c3(java.lang.Double v)
    {
        this.inventory_dtl_6_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getLot_item_description_and_year_purchased()
    {
        return lot_item_description_and_year_purchased;
    }

    public void setLot_item_description_and_year_purchased(java.lang.String v)
    {
        this.lot_item_description_and_year_purchased = v;
    }

    public java.lang.String getLot_item_description_and_year_purchased_2()
    {
        return lot_item_description_and_year_purchased_2;
    }

    public void setLot_item_description_and_year_purchased_2(java.lang.String v)
    {
        this.lot_item_description_and_year_purchased_2 = v;
    }

    public java.lang.String getLot_item_description_and_year_purchased_3()
    {
        return lot_item_description_and_year_purchased_3;
    }

    public void setLot_item_description_and_year_purchased_3(java.lang.String v)
    {
        this.lot_item_description_and_year_purchased_3 = v;
    }

    public java.lang.String getLot_item_description_and_year_purchased_4()
    {
        return lot_item_description_and_year_purchased_4;
    }

    public void setLot_item_description_and_year_purchased_4(java.lang.String v)
    {
        this.lot_item_description_and_year_purchased_4 = v;
    }

    public java.lang.String getLot_item_description_and_year_purchased_5()
    {
        return lot_item_description_and_year_purchased_5;
    }

    public void setLot_item_description_and_year_purchased_5(java.lang.String v)
    {
        this.lot_item_description_and_year_purchased_5 = v;
    }

    public java.lang.String getLot_item_description_and_year_purchased_6()
    {
        return lot_item_description_and_year_purchased_6;
    }

    public void setLot_item_description_and_year_purchased_6(java.lang.String v)
    {
        this.lot_item_description_and_year_purchased_6 = v;
    }

    public java.lang.String getLot_item_description_and_year_purchased_7()
    {
        return lot_item_description_and_year_purchased_7;
    }

    public void setLot_item_description_and_year_purchased_7(java.lang.String v)
    {
        this.lot_item_description_and_year_purchased_7 = v;
    }

    public java.lang.String getLot_item_description_and_year_purchased_8()
    {
        return lot_item_description_and_year_purchased_8;
    }

    public void setLot_item_description_and_year_purchased_8(java.lang.String v)
    {
        this.lot_item_description_and_year_purchased_8 = v;
    }

    public java.lang.String getSuggested_selling_price()
    {
        return suggested_selling_price;
    }

    public void setSuggested_selling_price(java.lang.String v)
    {
        this.suggested_selling_price = v;
    }

    public java.lang.String getSuggested_selling_price_2()
    {
        return suggested_selling_price_2;
    }

    public void setSuggested_selling_price_2(java.lang.String v)
    {
        this.suggested_selling_price_2 = v;
    }

    public java.lang.String getSuggested_selling_price_3()
    {
        return suggested_selling_price_3;
    }

    public void setSuggested_selling_price_3(java.lang.String v)
    {
        this.suggested_selling_price_3 = v;
    }

    public java.lang.String getSuggested_selling_price_4()
    {
        return suggested_selling_price_4;
    }

    public void setSuggested_selling_price_4(java.lang.String v)
    {
        this.suggested_selling_price_4 = v;
    }

    public java.lang.String getSuggested_selling_price_5()
    {
        return suggested_selling_price_5;
    }

    public void setSuggested_selling_price_5(java.lang.String v)
    {
        this.suggested_selling_price_5 = v;
    }

    public java.lang.String getSuggested_selling_price_6()
    {
        return suggested_selling_price_6;
    }

    public void setSuggested_selling_price_6(java.lang.String v)
    {
        this.suggested_selling_price_6 = v;
    }

    public java.lang.String getSuggested_selling_price_7()
    {
        return suggested_selling_price_7;
    }

    public void setSuggested_selling_price_7(java.lang.String v)
    {
        this.suggested_selling_price_7 = v;
    }

    public java.lang.String getSuggested_selling_price_8()
    {
        return suggested_selling_price_8;
    }

    public void setSuggested_selling_price_8(java.lang.String v)
    {
        this.suggested_selling_price_8 = v;
    }

    public java.lang.String getExisting_lot_quantity()
    {
        return existing_lot_quantity;
    }

    public void setExisting_lot_quantity(java.lang.String v)
    {
        this.existing_lot_quantity = v;
    }

    public java.lang.String getExisting_lot_quantity_2()
    {
        return existing_lot_quantity_2;
    }

    public void setExisting_lot_quantity_2(java.lang.String v)
    {
        this.existing_lot_quantity_2 = v;
    }

    public java.lang.String getExisting_lot_quantity_3()
    {
        return existing_lot_quantity_3;
    }

    public void setExisting_lot_quantity_3(java.lang.String v)
    {
        this.existing_lot_quantity_3 = v;
    }

    public java.lang.String getExisting_lot_quantity_4()
    {
        return existing_lot_quantity_4;
    }

    public void setExisting_lot_quantity_4(java.lang.String v)
    {
        this.existing_lot_quantity_4 = v;
    }

    public java.lang.String getExisting_lot_quantity_5()
    {
        return existing_lot_quantity_5;
    }

    public void setExisting_lot_quantity_5(java.lang.String v)
    {
        this.existing_lot_quantity_5 = v;
    }

    public java.lang.String getExisting_lot_quantity_6()
    {
        return existing_lot_quantity_6;
    }

    public void setExisting_lot_quantity_6(java.lang.String v)
    {
        this.existing_lot_quantity_6 = v;
    }

    public java.lang.String getExisting_lot_quantity_7()
    {
        return existing_lot_quantity_7;
    }

    public void setExisting_lot_quantity_7(java.lang.String v)
    {
        this.existing_lot_quantity_7 = v;
    }

    public java.lang.String getExisting_lot_quantity_8()
    {
        return existing_lot_quantity_8;
    }

    public void setExisting_lot_quantity_8(java.lang.String v)
    {
        this.existing_lot_quantity_8 = v;
    }

    public java.lang.String getExisting_lot_extended_cost()
    {
        return existing_lot_extended_cost;
    }

    public void setExisting_lot_extended_cost(java.lang.String v)
    {
        this.existing_lot_extended_cost = v;
    }

    public java.lang.String getExisting_lot_extended_cost_2()
    {
        return existing_lot_extended_cost_2;
    }

    public void setExisting_lot_extended_cost_2(java.lang.String v)
    {
        this.existing_lot_extended_cost_2 = v;
    }

    public java.lang.String getExisting_lot_extended_cost_3()
    {
        return existing_lot_extended_cost_3;
    }

    public void setExisting_lot_extended_cost_3(java.lang.String v)
    {
        this.existing_lot_extended_cost_3 = v;
    }

    public java.lang.String getExisting_lot_extended_cost_4()
    {
        return existing_lot_extended_cost_4;
    }

    public void setExisting_lot_extended_cost_4(java.lang.String v)
    {
        this.existing_lot_extended_cost_4 = v;
    }

    public java.lang.String getExisting_lot_extended_cost_5()
    {
        return existing_lot_extended_cost_5;
    }

    public void setExisting_lot_extended_cost_5(java.lang.String v)
    {
        this.existing_lot_extended_cost_5 = v;
    }

    public java.lang.String getExisting_lot_extended_cost_6()
    {
        return existing_lot_extended_cost_6;
    }

    public void setExisting_lot_extended_cost_6(java.lang.String v)
    {
        this.existing_lot_extended_cost_6 = v;
    }

    public java.lang.String getExisting_lot_extended_cost_7()
    {
        return existing_lot_extended_cost_7;
    }

    public void setExisting_lot_extended_cost_7(java.lang.String v)
    {
        this.existing_lot_extended_cost_7 = v;
    }

    public java.lang.String getExisting_lot_extended_cost_8()
    {
        return existing_lot_extended_cost_8;
    }

    public void setExisting_lot_extended_cost_8(java.lang.String v)
    {
        this.existing_lot_extended_cost_8 = v;
    }

    public java.lang.Double getPg_3_i_d_start_existing_lot_extended_cost()
    {
        return pg_3_i_d_start_existing_lot_extended_cost;
    }

    public void setPg_3_i_d_start_existing_lot_extended_cost(java.lang.Double v)
    {
        this.pg_3_i_d_start_existing_lot_extended_cost = v;
    }

    public java.lang.String getNew_lot_purchase_quantity()
    {
        return new_lot_purchase_quantity;
    }

    public void setNew_lot_purchase_quantity(java.lang.String v)
    {
        this.new_lot_purchase_quantity = v;
    }

    public java.lang.String getNew_lot_purchase_quantity_2()
    {
        return new_lot_purchase_quantity_2;
    }

    public void setNew_lot_purchase_quantity_2(java.lang.String v)
    {
        this.new_lot_purchase_quantity_2 = v;
    }

    public java.lang.String getNew_lot_purchase_quantity_3()
    {
        return new_lot_purchase_quantity_3;
    }

    public void setNew_lot_purchase_quantity_3(java.lang.String v)
    {
        this.new_lot_purchase_quantity_3 = v;
    }

    public java.lang.String getNew_lot_purchase_quantity_4()
    {
        return new_lot_purchase_quantity_4;
    }

    public void setNew_lot_purchase_quantity_4(java.lang.String v)
    {
        this.new_lot_purchase_quantity_4 = v;
    }

    public java.lang.String getNew_lot_purchase_quantity_5()
    {
        return new_lot_purchase_quantity_5;
    }

    public void setNew_lot_purchase_quantity_5(java.lang.String v)
    {
        this.new_lot_purchase_quantity_5 = v;
    }

    public java.lang.String getNew_lot_purchase_quantity_6()
    {
        return new_lot_purchase_quantity_6;
    }

    public void setNew_lot_purchase_quantity_6(java.lang.String v)
    {
        this.new_lot_purchase_quantity_6 = v;
    }

    public java.lang.String getNew_lot_purchase_quantity_7()
    {
        return new_lot_purchase_quantity_7;
    }

    public void setNew_lot_purchase_quantity_7(java.lang.String v)
    {
        this.new_lot_purchase_quantity_7 = v;
    }

    public java.lang.String getNew_lot_purchase_quantity_8()
    {
        return new_lot_purchase_quantity_8;
    }

    public void setNew_lot_purchase_quantity_8(java.lang.String v)
    {
        this.new_lot_purchase_quantity_8 = v;
    }

    public java.lang.String getNew_lot_purchase_cost()
    {
        return new_lot_purchase_cost;
    }

    public void setNew_lot_purchase_cost(java.lang.String v)
    {
        this.new_lot_purchase_cost = v;
    }

    public java.lang.String getNew_lot_purchase_cost_2()
    {
        return new_lot_purchase_cost_2;
    }

    public void setNew_lot_purchase_cost_2(java.lang.String v)
    {
        this.new_lot_purchase_cost_2 = v;
    }

    public java.lang.String getNew_lot_purchase_cost_3()
    {
        return new_lot_purchase_cost_3;
    }

    public void setNew_lot_purchase_cost_3(java.lang.String v)
    {
        this.new_lot_purchase_cost_3 = v;
    }

    public java.lang.String getNew_lot_purchase_cost_4()
    {
        return new_lot_purchase_cost_4;
    }

    public void setNew_lot_purchase_cost_4(java.lang.String v)
    {
        this.new_lot_purchase_cost_4 = v;
    }

    public java.lang.String getNew_lot_purchase_cost_5()
    {
        return new_lot_purchase_cost_5;
    }

    public void setNew_lot_purchase_cost_5(java.lang.String v)
    {
        this.new_lot_purchase_cost_5 = v;
    }

    public java.lang.String getNew_lot_purchase_cost_6()
    {
        return new_lot_purchase_cost_6;
    }

    public void setNew_lot_purchase_cost_6(java.lang.String v)
    {
        this.new_lot_purchase_cost_6 = v;
    }

    public java.lang.String getNew_lot_purchase_cost_7()
    {
        return new_lot_purchase_cost_7;
    }

    public void setNew_lot_purchase_cost_7(java.lang.String v)
    {
        this.new_lot_purchase_cost_7 = v;
    }

    public java.lang.String getNew_lot_purchase_cost_8()
    {
        return new_lot_purchase_cost_8;
    }

    public void setNew_lot_purchase_cost_8(java.lang.String v)
    {
        this.new_lot_purchase_cost_8 = v;
    }

    public java.lang.Double getPer_unit_cost_b1_a1_or_b2_a2()
    {
        return per_unit_cost_b1_a1_or_b2_a2;
    }

    public void setPer_unit_cost_b1_a1_or_b2_a2(java.lang.Double v)
    {
        this.per_unit_cost_b1_a1_or_b2_a2 = v;
    }

    public java.lang.Double getIf_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0()
    {
        return if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0;
    }

    public void setIf_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0(java.lang.Double v)
    {
        this.if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0 = v;
    }

    public java.lang.Double getIf_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0()
    {
        return if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0;
    }

    public void setIf_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0(java.lang.Double v)
    {
        this.if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0 = v;
    }

    public java.lang.Double getIf_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0()
    {
        return if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0;
    }

    public void setIf_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0(java.lang.Double v)
    {
        this.if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0 = v;
    }

    public java.lang.Double getIf_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0()
    {
        return if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0;
    }

    public void setIf_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0(java.lang.Double v)
    {
        this.if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0 = v;
    }

    public java.lang.Double getIf_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0()
    {
        return if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0;
    }

    public void setIf_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0(java.lang.Double v)
    {
        this.if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0 = v;
    }

    public java.lang.Double getIf_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0()
    {
        return if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0;
    }

    public void setIf_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0(java.lang.Double v)
    {
        this.if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0 = v;
    }

    public java.lang.Double getIf_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0()
    {
        return if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0;
    }

    public void setIf_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0(java.lang.Double v)
    {
        this.if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0 = v;
    }

    public java.lang.String getIf_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_sold_at_any_price()
    {
        return if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_sold_at_any_price;
    }

    public void setIf_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_sold_at_any_price(java.lang.String v)
    {
        this.if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_sold_at_any_price = v;
    }

    public java.lang.String getIf_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_sold_at_any_price()
    {
        return if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_sold_at_any_price;
    }

    public void setIf_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_sold_at_any_price(java.lang.String v)
    {
        this.if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_sold_at_any_price = v;
    }

    public java.lang.String getIf_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_sold_at_any_price()
    {
        return if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_sold_at_any_price;
    }

    public void setIf_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_sold_at_any_price(java.lang.String v)
    {
        this.if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_sold_at_any_price = v;
    }

    public java.lang.String getIf_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_sold_at_any_price()
    {
        return if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_sold_at_any_price;
    }

    public void setIf_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_sold_at_any_price(java.lang.String v)
    {
        this.if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_sold_at_any_price = v;
    }

    public java.lang.String getIf_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_sold_at_any_price()
    {
        return if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_sold_at_any_price;
    }

    public void setIf_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_sold_at_any_price(java.lang.String v)
    {
        this.if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_sold_at_any_price = v;
    }

    public java.lang.String getIf_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_sold_at_any_price()
    {
        return if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_sold_at_any_price;
    }

    public void setIf_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_sold_at_any_price(java.lang.String v)
    {
        this.if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_sold_at_any_price = v;
    }

    public java.lang.String getIf_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_sold_at_any_price()
    {
        return if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_sold_at_any_price;
    }

    public void setIf_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_sold_at_any_price(java.lang.String v)
    {
        this.if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_sold_at_any_price = v;
    }

    public java.lang.String getIf_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_sold_at_any_price()
    {
        return if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_sold_at_any_price;
    }

    public void setIf_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_sold_at_any_price(java.lang.String v)
    {
        this.if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_sold_at_any_price = v;
    }

    public java.lang.String getIf_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_removed_or_discarded()
    {
        return if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_removed_or_discarded;
    }

    public void setIf_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_removed_or_discarded(java.lang.String v)
    {
        this.if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_quantity_removed_or_discarded = v;
    }

    public java.lang.String getIf_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_removed_or_discarded()
    {
        return if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_removed_or_discarded;
    }

    public void setIf_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_removed_or_discarded(java.lang.String v)
    {
        this.if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_quantity_removed_or_discarded = v;
    }

    public java.lang.String getIf_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_removed_or_discarded()
    {
        return if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_removed_or_discarded;
    }

    public void setIf_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_removed_or_discarded(java.lang.String v)
    {
        this.if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_quantity_removed_or_discarded = v;
    }

    public java.lang.String getIf_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_removed_or_discarded()
    {
        return if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_removed_or_discarded;
    }

    public void setIf_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_removed_or_discarded(java.lang.String v)
    {
        this.if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_quantity_removed_or_discarded = v;
    }

    public java.lang.String getIf_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_removed_or_discarded()
    {
        return if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_removed_or_discarded;
    }

    public void setIf_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_removed_or_discarded(java.lang.String v)
    {
        this.if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_quantity_removed_or_discarded = v;
    }

    public java.lang.String getIf_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_removed_or_discarded()
    {
        return if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_removed_or_discarded;
    }

    public void setIf_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_removed_or_discarded(java.lang.String v)
    {
        this.if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_quantity_removed_or_discarded = v;
    }

    public java.lang.String getIf_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_removed_or_discarded()
    {
        return if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_removed_or_discarded;
    }

    public void setIf_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_removed_or_discarded(java.lang.String v)
    {
        this.if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_quantity_removed_or_discarded = v;
    }

    public java.lang.String getIf_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_removed_or_discarded()
    {
        return if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_removed_or_discarded;
    }

    public void setIf_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_removed_or_discarded(java.lang.String v)
    {
        this.if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_quantity_removed_or_discarded = v;
    }

    public java.lang.Double getIf_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_ending_quantity_b1or_b2_d_e()
    {
        return if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_ending_quantity_b1or_b2_d_e;
    }

    public void setIf_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_ending_quantity_b1or_b2_d_e(java.lang.Double v)
    {
        this.if_and_e16_0_e17_0_e17_e16_if_and_e19_0_e20_0_e20_e19_0_ending_quantity_b1or_b2_d_e = v;
    }

    public java.lang.Double getIf_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_if_e16_0_e16_e19_e24_e25()
    {
        return if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_if_e16_0_e16_e19_e24_e25;
    }

    public void setIf_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_if_e16_0_e16_e19_e24_e25(java.lang.Double v)
    {
        this.if_and_f16_0_f17_0_f17_f16_if_and_f19_0_f20_0_f20_f19_0_if_e16_0_e16_e19_e24_e25 = v;
    }

    public java.lang.Double getIf_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_if_f16_0_f16_f19_f24_f25()
    {
        return if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_if_f16_0_f16_f19_f24_f25;
    }

    public void setIf_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_if_f16_0_f16_f19_f24_f25(java.lang.Double v)
    {
        this.if_and_g16_0_g17_0_g17_g16_if_and_g19_0_g20_0_g20_g19_0_if_f16_0_f16_f19_f24_f25 = v;
    }

    public java.lang.Double getIf_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_if_g16_0_g16_g19_g24_g25()
    {
        return if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_if_g16_0_g16_g19_g24_g25;
    }

    public void setIf_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_if_g16_0_g16_g19_g24_g25(java.lang.Double v)
    {
        this.if_and_h16_0_h17_0_h17_h16_if_and_h19_0_h20_0_h20_h19_0_if_g16_0_g16_g19_g24_g25 = v;
    }

    public java.lang.Double getIf_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_if_h16_0_h16_h19_h24_h25()
    {
        return if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_if_h16_0_h16_h19_h24_h25;
    }

    public void setIf_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_if_h16_0_h16_h19_h24_h25(java.lang.Double v)
    {
        this.if_and_i16_0_i17_0_i17_i16_if_and_i19_0_i20_0_i20_i19_0_if_h16_0_h16_h19_h24_h25 = v;
    }

    public java.lang.Double getIf_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_if_i16_0_i16_i19_i24_i25()
    {
        return if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_if_i16_0_i16_i19_i24_i25;
    }

    public void setIf_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_if_i16_0_i16_i19_i24_i25(java.lang.Double v)
    {
        this.if_and_j16_0_j17_0_j17_j16_if_and_j19_0_j20_0_j20_j19_0_if_i16_0_i16_i19_i24_i25 = v;
    }

    public java.lang.Double getIf_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_if_j16_0_j16_j19_j24_j25()
    {
        return if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_if_j16_0_j16_j19_j24_j25;
    }

    public void setIf_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_if_j16_0_j16_j19_j24_j25(java.lang.Double v)
    {
        this.if_and_k16_0_k17_0_k17_k16_if_and_k19_0_k20_0_k20_k19_0_if_j16_0_j16_j19_j24_j25 = v;
    }

    public java.lang.Double getIf_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_if_k16_0_k16_k19_k24_k25()
    {
        return if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_if_k16_0_k16_k19_k24_k25;
    }

    public void setIf_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_if_k16_0_k16_k19_k24_k25(java.lang.Double v)
    {
        this.if_and_l16_0_l17_0_l17_l16_if_and_l19_0_l20_0_l20_l19_0_if_k16_0_k16_k19_k24_k25 = v;
    }

    public java.lang.Double getIf_e16_0_e16_e19_e24_e25_ending_extended_cost_f_x_c()
    {
        return if_e16_0_e16_e19_e24_e25_ending_extended_cost_f_x_c;
    }

    public void setIf_e16_0_e16_e19_e24_e25_ending_extended_cost_f_x_c(java.lang.Double v)
    {
        this.if_e16_0_e16_e19_e24_e25_ending_extended_cost_f_x_c = v;
    }

    public java.lang.Double getIf_f16_0_f16_f19_f24_f25_e26_e22()
    {
        return if_f16_0_f16_f19_f24_f25_e26_e22;
    }

    public void setIf_f16_0_f16_f19_f24_f25_e26_e22(java.lang.Double v)
    {
        this.if_f16_0_f16_f19_f24_f25_e26_e22 = v;
    }

    public java.lang.Double getIf_g16_0_g16_g19_g24_g25_f26_f22()
    {
        return if_g16_0_g16_g19_g24_g25_f26_f22;
    }

    public void setIf_g16_0_g16_g19_g24_g25_f26_f22(java.lang.Double v)
    {
        this.if_g16_0_g16_g19_g24_g25_f26_f22 = v;
    }

    public java.lang.Double getIf_h16_0_h16_h19_h24_h25_g26_g22()
    {
        return if_h16_0_h16_h19_h24_h25_g26_g22;
    }

    public void setIf_h16_0_h16_h19_h24_h25_g26_g22(java.lang.Double v)
    {
        this.if_h16_0_h16_h19_h24_h25_g26_g22 = v;
    }

    public java.lang.Double getIf_i16_0_i16_i19_i24_i25_h26_h22()
    {
        return if_i16_0_i16_i19_i24_i25_h26_h22;
    }

    public void setIf_i16_0_i16_i19_i24_i25_h26_h22(java.lang.Double v)
    {
        this.if_i16_0_i16_i19_i24_i25_h26_h22 = v;
    }

    public java.lang.Double getIf_j16_0_j16_j19_j24_j25_i26_i22()
    {
        return if_j16_0_j16_j19_j24_j25_i26_i22;
    }

    public void setIf_j16_0_j16_j19_j24_j25_i26_i22(java.lang.Double v)
    {
        this.if_j16_0_j16_j19_j24_j25_i26_i22 = v;
    }

    public java.lang.Double getIf_k16_0_k16_k19_k24_k25_j26_j22()
    {
        return if_k16_0_k16_k19_k24_k25_j26_j22;
    }

    public void setIf_k16_0_k16_k19_k24_k25_j26_j22(java.lang.Double v)
    {
        this.if_k16_0_k16_k19_k24_k25_j26_j22 = v;
    }

    public java.lang.Double getIf_l16_0_l16_l19_l24_l25_k26_k22()
    {
        return if_l16_0_l16_l19_l24_l25_k26_k22;
    }

    public void setIf_l16_0_l16_l19_l24_l25_k26_k22(java.lang.Double v)
    {
        this.if_l16_0_l16_l19_l24_l25_k26_k22 = v;
    }

    public java.lang.Double getPg_3_i_d_end_l26_l22()
    {
        return pg_3_i_d_end_l26_l22;
    }

    public void setPg_3_i_d_end_l26_l22(java.lang.Double v)
    {
        this.pg_3_i_d_end_l26_l22 = v;
    }

    public java.lang.Double getE26_e22_cost_of_goods_b1_b2_g()
    {
        return e26_e22_cost_of_goods_b1_b2_g;
    }

    public void setE26_e22_cost_of_goods_b1_b2_g(java.lang.Double v)
    {
        this.e26_e22_cost_of_goods_b1_b2_g = v;
    }

    public java.lang.Double getF26_f22_e17_e20_e27()
    {
        return f26_f22_e17_e20_e27;
    }

    public void setF26_f22_e17_e20_e27(java.lang.Double v)
    {
        this.f26_f22_e17_e20_e27 = v;
    }

    public java.lang.Double getG26_g22_f17_f20_f27()
    {
        return g26_g22_f17_f20_f27;
    }

    public void setG26_g22_f17_f20_f27(java.lang.Double v)
    {
        this.g26_g22_f17_f20_f27 = v;
    }

    public java.lang.Double getH26_h22_g17_g20_g27()
    {
        return h26_h22_g17_g20_g27;
    }

    public void setH26_h22_g17_g20_g27(java.lang.Double v)
    {
        this.h26_h22_g17_g20_g27 = v;
    }

    public java.lang.Double getI26_i22_h17_h20_h27()
    {
        return i26_i22_h17_h20_h27;
    }

    public void setI26_i22_h17_h20_h27(java.lang.Double v)
    {
        this.i26_i22_h17_h20_h27 = v;
    }

    public java.lang.Double getJ26_j22_i17_i20_i27()
    {
        return j26_j22_i17_i20_i27;
    }

    public void setJ26_j22_i17_i20_i27(java.lang.Double v)
    {
        this.j26_j22_i17_i20_i27 = v;
    }

    public java.lang.Double getK26_k22_j17_j20_j27()
    {
        return k26_k22_j17_j20_j27;
    }

    public void setK26_k22_j17_j20_j27(java.lang.Double v)
    {
        this.k26_k22_j17_j20_j27 = v;
    }

    public java.lang.Double getL26_l22_k17_k20_k27()
    {
        return l26_l22_k17_k20_k27;
    }

    public void setL26_l22_k17_k20_k27(java.lang.Double v)
    {
        this.l26_l22_k17_k20_k27 = v;
    }

    public java.lang.Double getSum_e27_l27_l17_l20_l27()
    {
        return sum_e27_l27_l17_l20_l27;
    }

    public void setSum_e27_l27_l17_l20_l27(java.lang.Double v)
    {
        this.sum_e27_l27_l17_l20_l27 = v;
    }

    public java.lang.String getE17_e20_e27_actual_gross_income_from_inventory_sales()
    {
        return e17_e20_e27_actual_gross_income_from_inventory_sales;
    }

    public void setE17_e20_e27_actual_gross_income_from_inventory_sales(java.lang.String v)
    {
        this.e17_e20_e27_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.String getF17_f20_f27_actual_gross_income_from_inventory_sales()
    {
        return f17_f20_f27_actual_gross_income_from_inventory_sales;
    }

    public void setF17_f20_f27_actual_gross_income_from_inventory_sales(java.lang.String v)
    {
        this.f17_f20_f27_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.String getG17_g20_g27_actual_gross_income_from_inventory_sales()
    {
        return g17_g20_g27_actual_gross_income_from_inventory_sales;
    }

    public void setG17_g20_g27_actual_gross_income_from_inventory_sales(java.lang.String v)
    {
        this.g17_g20_g27_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.String getH17_h20_h27_actual_gross_income_from_inventory_sales()
    {
        return h17_h20_h27_actual_gross_income_from_inventory_sales;
    }

    public void setH17_h20_h27_actual_gross_income_from_inventory_sales(java.lang.String v)
    {
        this.h17_h20_h27_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.String getI17_i20_i27_actual_gross_income_from_inventory_sales()
    {
        return i17_i20_i27_actual_gross_income_from_inventory_sales;
    }

    public void setI17_i20_i27_actual_gross_income_from_inventory_sales(java.lang.String v)
    {
        this.i17_i20_i27_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.String getJ17_j20_j27_actual_gross_income_from_inventory_sales()
    {
        return j17_j20_j27_actual_gross_income_from_inventory_sales;
    }

    public void setJ17_j20_j27_actual_gross_income_from_inventory_sales(java.lang.String v)
    {
        this.j17_j20_j27_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.String getK17_k20_k27_actual_gross_income_from_inventory_sales()
    {
        return k17_k20_k27_actual_gross_income_from_inventory_sales;
    }

    public void setK17_k20_k27_actual_gross_income_from_inventory_sales(java.lang.String v)
    {
        this.k17_k20_k27_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.String getL17_l20_l27_actual_gross_income_from_inventory_sales()
    {
        return l17_l20_l27_actual_gross_income_from_inventory_sales;
    }

    public void setL17_l20_l27_actual_gross_income_from_inventory_sales(java.lang.String v)
    {
        this.l17_l20_l27_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.Double getSum_e29_l29_actual_gross_income_from_inventory_sales()
    {
        return sum_e29_l29_actual_gross_income_from_inventory_sales;
    }

    public void setSum_e29_l29_actual_gross_income_from_inventory_sales(java.lang.Double v)
    {
        this.sum_e29_l29_actual_gross_income_from_inventory_sales = v;
    }

    public java.lang.Double getE17_e20_e27_net_inventory_sales_income_i_h()
    {
        return e17_e20_e27_net_inventory_sales_income_i_h;
    }

    public void setE17_e20_e27_net_inventory_sales_income_i_h(java.lang.Double v)
    {
        this.e17_e20_e27_net_inventory_sales_income_i_h = v;
    }

    public java.lang.Double getF17_f20_f27_e30_e29()
    {
        return f17_f20_f27_e30_e29;
    }

    public void setF17_f20_f27_e30_e29(java.lang.Double v)
    {
        this.f17_f20_f27_e30_e29 = v;
    }

    public java.lang.Double getG17_g20_g27_f30_f29()
    {
        return g17_g20_g27_f30_f29;
    }

    public void setG17_g20_g27_f30_f29(java.lang.Double v)
    {
        this.g17_g20_g27_f30_f29 = v;
    }

    public java.lang.Double getH17_h20_h27_g30_g29()
    {
        return h17_h20_h27_g30_g29;
    }

    public void setH17_h20_h27_g30_g29(java.lang.Double v)
    {
        this.h17_h20_h27_g30_g29 = v;
    }

    public java.lang.Double getI17_i20_i27_h30_h29()
    {
        return i17_i20_i27_h30_h29;
    }

    public void setI17_i20_i27_h30_h29(java.lang.Double v)
    {
        this.i17_i20_i27_h30_h29 = v;
    }

    public java.lang.Double getJ17_j20_j27_i30_i29()
    {
        return j17_j20_j27_i30_i29;
    }

    public void setJ17_j20_j27_i30_i29(java.lang.Double v)
    {
        this.j17_j20_j27_i30_i29 = v;
    }

    public java.lang.Double getK17_k20_k27_j30_j29()
    {
        return k17_k20_k27_j30_j29;
    }

    public void setK17_k20_k27_j30_j29(java.lang.Double v)
    {
        this.k17_k20_k27_j30_j29 = v;
    }

    public java.lang.Double getL17_l20_l27_k30_k29()
    {
        return l17_l20_l27_k30_k29;
    }

    public void setL17_l20_l27_k30_k29(java.lang.Double v)
    {
        this.l17_l20_l27_k30_k29 = v;
    }

    public INVENTORY_DTL_6Bean()
    {
    }

}
