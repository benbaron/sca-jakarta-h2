package nonprofitbookkeeping.reports.jasper.beans;

public class AssetDtl5aReceivableLineItem
{
    private java.lang.String receivables_owed_from;
    private java.lang.String reason;
    private java.lang.String sending_branch_or_reason;
    private java.lang.String prior_amount;
    private java.lang.String current_amount;

    public java.lang.String getReceivables_owed_from()
    {
        return receivables_owed_from;
    }

    public void setReceivables_owed_from(java.lang.String v)
    {
        this.receivables_owed_from = v;
    }

    public java.lang.String getReason()
    {
        return reason;
    }

    public void setReason(java.lang.String v)
    {
        this.reason = v;
    }

    public java.lang.String getSending_branch_or_reason()
    {
        return sending_branch_or_reason;
    }

    public void setSending_branch_or_reason(java.lang.String v)
    {
        this.sending_branch_or_reason = v;
    }

    public java.lang.String getPrior_amount()
    {
        return prior_amount;
    }

    public void setPrior_amount(java.lang.String v)
    {
        this.prior_amount = v;
    }

    public java.lang.String getCurrent_amount()
    {
        return current_amount;
    }

    public void setCurrent_amount(java.lang.String v)
    {
        this.current_amount = v;
    }
}
