package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet TRANSFER_OUT_10 */
public class TRANSFER_OUT_10Bean
{

    private java.lang.Double transfer_out_10_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String within_the_kingdom;
    private java.lang.String check;
    private java.lang.String check_date;
    private java.lang.String amount;
    private java.lang.String within_the_kingdom_2;
    private java.lang.String check_2;
    private java.lang.String check_date_2;
    private java.lang.String amount_2;
    private java.lang.String within_the_kingdom_3;
    private java.lang.String check_3;
    private java.lang.String check_date_3;
    private java.lang.String amount_3;
    private java.lang.String within_the_kingdom_4;
    private java.lang.String check_4;
    private java.lang.String check_date_4;
    private java.lang.String amount_4;
    private java.lang.String within_the_kingdom_5;
    private java.lang.String check_5;
    private java.lang.String check_date_5;
    private java.lang.String amount_5;
    private java.lang.String within_the_kingdom_6;
    private java.lang.String check_6;
    private java.lang.String check_date_6;
    private java.lang.String amount_6;
    private java.lang.String within_the_kingdom_7;
    private java.lang.String check_7;
    private java.lang.String check_date_7;
    private java.lang.String amount_7;
    private java.lang.String within_the_kingdom_8;
    private java.lang.String check_8;
    private java.lang.String check_date_8;
    private java.lang.String amount_8;
    private java.lang.String within_the_kingdom_9;
    private java.lang.String check_9;
    private java.lang.String check_date_9;
    private java.lang.String amount_9;
    private java.lang.String within_the_kingdom_10;
    private java.lang.String check_10;
    private java.lang.String check_date_10;
    private java.lang.String amount_10;
    private java.lang.String within_the_kingdom_11;
    private java.lang.String check_11;
    private java.lang.String check_date_11;
    private java.lang.String amount_11;
    private java.lang.String within_the_kingdom_12;
    private java.lang.String check_12;
    private java.lang.String check_date_12;
    private java.lang.String amount_12;
    private java.lang.String within_the_kingdom_13;
    private java.lang.String check_13;
    private java.lang.String check_date_13;
    private java.lang.String amount_13;
    private java.lang.String within_the_kingdom_14;
    private java.lang.String check_14;
    private java.lang.String check_date_14;
    private java.lang.String amount_14;
    private java.lang.Double amount_show_total_on_pg_4_line_30a;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason;
    private java.lang.String check_15;
    private java.lang.String check_date_15;
    private java.lang.String amount_15;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_2;
    private java.lang.String check_16;
    private java.lang.String check_date_16;
    private java.lang.String amount_16;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_3;
    private java.lang.String check_17;
    private java.lang.String check_date_17;
    private java.lang.String amount_17;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_4;
    private java.lang.String check_18;
    private java.lang.String check_date_18;
    private java.lang.String amount_18;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_5;
    private java.lang.String check_19;
    private java.lang.String check_date_19;
    private java.lang.String amount_19;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_6;
    private java.lang.String check_20;
    private java.lang.String check_date_20;
    private java.lang.String amount_20;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_7;
    private java.lang.String check_21;
    private java.lang.String check_date_21;
    private java.lang.String amount_21;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_8;
    private java.lang.String check_22;
    private java.lang.String check_date_22;
    private java.lang.String amount_22;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_9;
    private java.lang.String check_23;
    private java.lang.String check_date_23;
    private java.lang.String amount_23;
    private java.lang.String a_the_corporate_office_or_officer_office_and_reason_10;
    private java.lang.String check_24;
    private java.lang.String check_date_24;
    private java.lang.String amount_24;
    private java.lang.Double amount_total_a;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account;
    private java.lang.String check_25;
    private java.lang.String check_date_25;
    private java.lang.String amount_25;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_2;
    private java.lang.String check_26;
    private java.lang.String check_date_26;
    private java.lang.String amount_26;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_3;
    private java.lang.String check_27;
    private java.lang.String check_date_27;
    private java.lang.String amount_27;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_4;
    private java.lang.String check_28;
    private java.lang.String check_date_28;
    private java.lang.String amount_28;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_5;
    private java.lang.String check_29;
    private java.lang.String check_date_29;
    private java.lang.String amount_29;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_6;
    private java.lang.String check_30;
    private java.lang.String check_date_30;
    private java.lang.String amount_30;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_7;
    private java.lang.String check_31;
    private java.lang.String check_date_31;
    private java.lang.String amount_31;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_8;
    private java.lang.String check_32;
    private java.lang.String check_date_32;
    private java.lang.String amount_32;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_9;
    private java.lang.String check_33;
    private java.lang.String check_date_33;
    private java.lang.String amount_33;
    private java.lang.String b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_10;
    private java.lang.String check_34;
    private java.lang.String check_date_34;
    private java.lang.String amount_34;
    private java.lang.Double amount_total_b;
    private java.lang.Double sum_f41_f50_total_transfers_to_outside_the_kingdom_a_b;

    public java.lang.Double getTransfer_out_10_r2c3()
    {
        return transfer_out_10_r2c3;
    }

    public void setTransfer_out_10_r2c3(java.lang.Double v)
    {
        this.transfer_out_10_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getWithin_the_kingdom()
    {
        return within_the_kingdom;
    }

    public void setWithin_the_kingdom(java.lang.String v)
    {
        this.within_the_kingdom = v;
    }

    public java.lang.String getCheck()
    {
        return check;
    }

    public void setCheck(java.lang.String v)
    {
        this.check = v;
    }

    public java.lang.String getCheck_date()
    {
        return check_date;
    }

    public void setCheck_date(java.lang.String v)
    {
        this.check_date = v;
    }

    public java.lang.String getAmount()
    {
        return amount;
    }

    public void setAmount(java.lang.String v)
    {
        this.amount = v;
    }

    public java.lang.String getWithin_the_kingdom_2()
    {
        return within_the_kingdom_2;
    }

    public void setWithin_the_kingdom_2(java.lang.String v)
    {
        this.within_the_kingdom_2 = v;
    }

    public java.lang.String getCheck_2()
    {
        return check_2;
    }

    public void setCheck_2(java.lang.String v)
    {
        this.check_2 = v;
    }

    public java.lang.String getCheck_date_2()
    {
        return check_date_2;
    }

    public void setCheck_date_2(java.lang.String v)
    {
        this.check_date_2 = v;
    }

    public java.lang.String getAmount_2()
    {
        return amount_2;
    }

    public void setAmount_2(java.lang.String v)
    {
        this.amount_2 = v;
    }

    public java.lang.String getWithin_the_kingdom_3()
    {
        return within_the_kingdom_3;
    }

    public void setWithin_the_kingdom_3(java.lang.String v)
    {
        this.within_the_kingdom_3 = v;
    }

    public java.lang.String getCheck_3()
    {
        return check_3;
    }

    public void setCheck_3(java.lang.String v)
    {
        this.check_3 = v;
    }

    public java.lang.String getCheck_date_3()
    {
        return check_date_3;
    }

    public void setCheck_date_3(java.lang.String v)
    {
        this.check_date_3 = v;
    }

    public java.lang.String getAmount_3()
    {
        return amount_3;
    }

    public void setAmount_3(java.lang.String v)
    {
        this.amount_3 = v;
    }

    public java.lang.String getWithin_the_kingdom_4()
    {
        return within_the_kingdom_4;
    }

    public void setWithin_the_kingdom_4(java.lang.String v)
    {
        this.within_the_kingdom_4 = v;
    }

    public java.lang.String getCheck_4()
    {
        return check_4;
    }

    public void setCheck_4(java.lang.String v)
    {
        this.check_4 = v;
    }

    public java.lang.String getCheck_date_4()
    {
        return check_date_4;
    }

    public void setCheck_date_4(java.lang.String v)
    {
        this.check_date_4 = v;
    }

    public java.lang.String getAmount_4()
    {
        return amount_4;
    }

    public void setAmount_4(java.lang.String v)
    {
        this.amount_4 = v;
    }

    public java.lang.String getWithin_the_kingdom_5()
    {
        return within_the_kingdom_5;
    }

    public void setWithin_the_kingdom_5(java.lang.String v)
    {
        this.within_the_kingdom_5 = v;
    }

    public java.lang.String getCheck_5()
    {
        return check_5;
    }

    public void setCheck_5(java.lang.String v)
    {
        this.check_5 = v;
    }

    public java.lang.String getCheck_date_5()
    {
        return check_date_5;
    }

    public void setCheck_date_5(java.lang.String v)
    {
        this.check_date_5 = v;
    }

    public java.lang.String getAmount_5()
    {
        return amount_5;
    }

    public void setAmount_5(java.lang.String v)
    {
        this.amount_5 = v;
    }

    public java.lang.String getWithin_the_kingdom_6()
    {
        return within_the_kingdom_6;
    }

    public void setWithin_the_kingdom_6(java.lang.String v)
    {
        this.within_the_kingdom_6 = v;
    }

    public java.lang.String getCheck_6()
    {
        return check_6;
    }

    public void setCheck_6(java.lang.String v)
    {
        this.check_6 = v;
    }

    public java.lang.String getCheck_date_6()
    {
        return check_date_6;
    }

    public void setCheck_date_6(java.lang.String v)
    {
        this.check_date_6 = v;
    }

    public java.lang.String getAmount_6()
    {
        return amount_6;
    }

    public void setAmount_6(java.lang.String v)
    {
        this.amount_6 = v;
    }

    public java.lang.String getWithin_the_kingdom_7()
    {
        return within_the_kingdom_7;
    }

    public void setWithin_the_kingdom_7(java.lang.String v)
    {
        this.within_the_kingdom_7 = v;
    }

    public java.lang.String getCheck_7()
    {
        return check_7;
    }

    public void setCheck_7(java.lang.String v)
    {
        this.check_7 = v;
    }

    public java.lang.String getCheck_date_7()
    {
        return check_date_7;
    }

    public void setCheck_date_7(java.lang.String v)
    {
        this.check_date_7 = v;
    }

    public java.lang.String getAmount_7()
    {
        return amount_7;
    }

    public void setAmount_7(java.lang.String v)
    {
        this.amount_7 = v;
    }

    public java.lang.String getWithin_the_kingdom_8()
    {
        return within_the_kingdom_8;
    }

    public void setWithin_the_kingdom_8(java.lang.String v)
    {
        this.within_the_kingdom_8 = v;
    }

    public java.lang.String getCheck_8()
    {
        return check_8;
    }

    public void setCheck_8(java.lang.String v)
    {
        this.check_8 = v;
    }

    public java.lang.String getCheck_date_8()
    {
        return check_date_8;
    }

    public void setCheck_date_8(java.lang.String v)
    {
        this.check_date_8 = v;
    }

    public java.lang.String getAmount_8()
    {
        return amount_8;
    }

    public void setAmount_8(java.lang.String v)
    {
        this.amount_8 = v;
    }

    public java.lang.String getWithin_the_kingdom_9()
    {
        return within_the_kingdom_9;
    }

    public void setWithin_the_kingdom_9(java.lang.String v)
    {
        this.within_the_kingdom_9 = v;
    }

    public java.lang.String getCheck_9()
    {
        return check_9;
    }

    public void setCheck_9(java.lang.String v)
    {
        this.check_9 = v;
    }

    public java.lang.String getCheck_date_9()
    {
        return check_date_9;
    }

    public void setCheck_date_9(java.lang.String v)
    {
        this.check_date_9 = v;
    }

    public java.lang.String getAmount_9()
    {
        return amount_9;
    }

    public void setAmount_9(java.lang.String v)
    {
        this.amount_9 = v;
    }

    public java.lang.String getWithin_the_kingdom_10()
    {
        return within_the_kingdom_10;
    }

    public void setWithin_the_kingdom_10(java.lang.String v)
    {
        this.within_the_kingdom_10 = v;
    }

    public java.lang.String getCheck_10()
    {
        return check_10;
    }

    public void setCheck_10(java.lang.String v)
    {
        this.check_10 = v;
    }

    public java.lang.String getCheck_date_10()
    {
        return check_date_10;
    }

    public void setCheck_date_10(java.lang.String v)
    {
        this.check_date_10 = v;
    }

    public java.lang.String getAmount_10()
    {
        return amount_10;
    }

    public void setAmount_10(java.lang.String v)
    {
        this.amount_10 = v;
    }

    public java.lang.String getWithin_the_kingdom_11()
    {
        return within_the_kingdom_11;
    }

    public void setWithin_the_kingdom_11(java.lang.String v)
    {
        this.within_the_kingdom_11 = v;
    }

    public java.lang.String getCheck_11()
    {
        return check_11;
    }

    public void setCheck_11(java.lang.String v)
    {
        this.check_11 = v;
    }

    public java.lang.String getCheck_date_11()
    {
        return check_date_11;
    }

    public void setCheck_date_11(java.lang.String v)
    {
        this.check_date_11 = v;
    }

    public java.lang.String getAmount_11()
    {
        return amount_11;
    }

    public void setAmount_11(java.lang.String v)
    {
        this.amount_11 = v;
    }

    public java.lang.String getWithin_the_kingdom_12()
    {
        return within_the_kingdom_12;
    }

    public void setWithin_the_kingdom_12(java.lang.String v)
    {
        this.within_the_kingdom_12 = v;
    }

    public java.lang.String getCheck_12()
    {
        return check_12;
    }

    public void setCheck_12(java.lang.String v)
    {
        this.check_12 = v;
    }

    public java.lang.String getCheck_date_12()
    {
        return check_date_12;
    }

    public void setCheck_date_12(java.lang.String v)
    {
        this.check_date_12 = v;
    }

    public java.lang.String getAmount_12()
    {
        return amount_12;
    }

    public void setAmount_12(java.lang.String v)
    {
        this.amount_12 = v;
    }

    public java.lang.String getWithin_the_kingdom_13()
    {
        return within_the_kingdom_13;
    }

    public void setWithin_the_kingdom_13(java.lang.String v)
    {
        this.within_the_kingdom_13 = v;
    }

    public java.lang.String getCheck_13()
    {
        return check_13;
    }

    public void setCheck_13(java.lang.String v)
    {
        this.check_13 = v;
    }

    public java.lang.String getCheck_date_13()
    {
        return check_date_13;
    }

    public void setCheck_date_13(java.lang.String v)
    {
        this.check_date_13 = v;
    }

    public java.lang.String getAmount_13()
    {
        return amount_13;
    }

    public void setAmount_13(java.lang.String v)
    {
        this.amount_13 = v;
    }

    public java.lang.String getWithin_the_kingdom_14()
    {
        return within_the_kingdom_14;
    }

    public void setWithin_the_kingdom_14(java.lang.String v)
    {
        this.within_the_kingdom_14 = v;
    }

    public java.lang.String getCheck_14()
    {
        return check_14;
    }

    public void setCheck_14(java.lang.String v)
    {
        this.check_14 = v;
    }

    public java.lang.String getCheck_date_14()
    {
        return check_date_14;
    }

    public void setCheck_date_14(java.lang.String v)
    {
        this.check_date_14 = v;
    }

    public java.lang.String getAmount_14()
    {
        return amount_14;
    }

    public void setAmount_14(java.lang.String v)
    {
        this.amount_14 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_30a()
    {
        return amount_show_total_on_pg_4_line_30a;
    }

    public void setAmount_show_total_on_pg_4_line_30a(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_30a = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason()
    {
        return a_the_corporate_office_or_officer_office_and_reason;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason = v;
    }

    public java.lang.String getCheck_15()
    {
        return check_15;
    }

    public void setCheck_15(java.lang.String v)
    {
        this.check_15 = v;
    }

    public java.lang.String getCheck_date_15()
    {
        return check_date_15;
    }

    public void setCheck_date_15(java.lang.String v)
    {
        this.check_date_15 = v;
    }

    public java.lang.String getAmount_15()
    {
        return amount_15;
    }

    public void setAmount_15(java.lang.String v)
    {
        this.amount_15 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_2()
    {
        return a_the_corporate_office_or_officer_office_and_reason_2;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_2(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_2 = v;
    }

    public java.lang.String getCheck_16()
    {
        return check_16;
    }

    public void setCheck_16(java.lang.String v)
    {
        this.check_16 = v;
    }

    public java.lang.String getCheck_date_16()
    {
        return check_date_16;
    }

    public void setCheck_date_16(java.lang.String v)
    {
        this.check_date_16 = v;
    }

    public java.lang.String getAmount_16()
    {
        return amount_16;
    }

    public void setAmount_16(java.lang.String v)
    {
        this.amount_16 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_3()
    {
        return a_the_corporate_office_or_officer_office_and_reason_3;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_3(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_3 = v;
    }

    public java.lang.String getCheck_17()
    {
        return check_17;
    }

    public void setCheck_17(java.lang.String v)
    {
        this.check_17 = v;
    }

    public java.lang.String getCheck_date_17()
    {
        return check_date_17;
    }

    public void setCheck_date_17(java.lang.String v)
    {
        this.check_date_17 = v;
    }

    public java.lang.String getAmount_17()
    {
        return amount_17;
    }

    public void setAmount_17(java.lang.String v)
    {
        this.amount_17 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_4()
    {
        return a_the_corporate_office_or_officer_office_and_reason_4;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_4(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_4 = v;
    }

    public java.lang.String getCheck_18()
    {
        return check_18;
    }

    public void setCheck_18(java.lang.String v)
    {
        this.check_18 = v;
    }

    public java.lang.String getCheck_date_18()
    {
        return check_date_18;
    }

    public void setCheck_date_18(java.lang.String v)
    {
        this.check_date_18 = v;
    }

    public java.lang.String getAmount_18()
    {
        return amount_18;
    }

    public void setAmount_18(java.lang.String v)
    {
        this.amount_18 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_5()
    {
        return a_the_corporate_office_or_officer_office_and_reason_5;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_5(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_5 = v;
    }

    public java.lang.String getCheck_19()
    {
        return check_19;
    }

    public void setCheck_19(java.lang.String v)
    {
        this.check_19 = v;
    }

    public java.lang.String getCheck_date_19()
    {
        return check_date_19;
    }

    public void setCheck_date_19(java.lang.String v)
    {
        this.check_date_19 = v;
    }

    public java.lang.String getAmount_19()
    {
        return amount_19;
    }

    public void setAmount_19(java.lang.String v)
    {
        this.amount_19 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_6()
    {
        return a_the_corporate_office_or_officer_office_and_reason_6;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_6(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_6 = v;
    }

    public java.lang.String getCheck_20()
    {
        return check_20;
    }

    public void setCheck_20(java.lang.String v)
    {
        this.check_20 = v;
    }

    public java.lang.String getCheck_date_20()
    {
        return check_date_20;
    }

    public void setCheck_date_20(java.lang.String v)
    {
        this.check_date_20 = v;
    }

    public java.lang.String getAmount_20()
    {
        return amount_20;
    }

    public void setAmount_20(java.lang.String v)
    {
        this.amount_20 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_7()
    {
        return a_the_corporate_office_or_officer_office_and_reason_7;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_7(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_7 = v;
    }

    public java.lang.String getCheck_21()
    {
        return check_21;
    }

    public void setCheck_21(java.lang.String v)
    {
        this.check_21 = v;
    }

    public java.lang.String getCheck_date_21()
    {
        return check_date_21;
    }

    public void setCheck_date_21(java.lang.String v)
    {
        this.check_date_21 = v;
    }

    public java.lang.String getAmount_21()
    {
        return amount_21;
    }

    public void setAmount_21(java.lang.String v)
    {
        this.amount_21 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_8()
    {
        return a_the_corporate_office_or_officer_office_and_reason_8;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_8(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_8 = v;
    }

    public java.lang.String getCheck_22()
    {
        return check_22;
    }

    public void setCheck_22(java.lang.String v)
    {
        this.check_22 = v;
    }

    public java.lang.String getCheck_date_22()
    {
        return check_date_22;
    }

    public void setCheck_date_22(java.lang.String v)
    {
        this.check_date_22 = v;
    }

    public java.lang.String getAmount_22()
    {
        return amount_22;
    }

    public void setAmount_22(java.lang.String v)
    {
        this.amount_22 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_9()
    {
        return a_the_corporate_office_or_officer_office_and_reason_9;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_9(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_9 = v;
    }

    public java.lang.String getCheck_23()
    {
        return check_23;
    }

    public void setCheck_23(java.lang.String v)
    {
        this.check_23 = v;
    }

    public java.lang.String getCheck_date_23()
    {
        return check_date_23;
    }

    public void setCheck_date_23(java.lang.String v)
    {
        this.check_date_23 = v;
    }

    public java.lang.String getAmount_23()
    {
        return amount_23;
    }

    public void setAmount_23(java.lang.String v)
    {
        this.amount_23 = v;
    }

    public java.lang.String getA_the_corporate_office_or_officer_office_and_reason_10()
    {
        return a_the_corporate_office_or_officer_office_and_reason_10;
    }

    public void setA_the_corporate_office_or_officer_office_and_reason_10(java.lang.String v)
    {
        this.a_the_corporate_office_or_officer_office_and_reason_10 = v;
    }

    public java.lang.String getCheck_24()
    {
        return check_24;
    }

    public void setCheck_24(java.lang.String v)
    {
        this.check_24 = v;
    }

    public java.lang.String getCheck_date_24()
    {
        return check_date_24;
    }

    public void setCheck_date_24(java.lang.String v)
    {
        this.check_date_24 = v;
    }

    public java.lang.String getAmount_24()
    {
        return amount_24;
    }

    public void setAmount_24(java.lang.String v)
    {
        this.amount_24 = v;
    }

    public java.lang.Double getAmount_total_a()
    {
        return amount_total_a;
    }

    public void setAmount_total_a(java.lang.Double v)
    {
        this.amount_total_a = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account = v;
    }

    public java.lang.String getCheck_25()
    {
        return check_25;
    }

    public void setCheck_25(java.lang.String v)
    {
        this.check_25 = v;
    }

    public java.lang.String getCheck_date_25()
    {
        return check_date_25;
    }

    public void setCheck_date_25(java.lang.String v)
    {
        this.check_date_25 = v;
    }

    public java.lang.String getAmount_25()
    {
        return amount_25;
    }

    public void setAmount_25(java.lang.String v)
    {
        this.amount_25 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_2()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_2;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_2(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_2 = v;
    }

    public java.lang.String getCheck_26()
    {
        return check_26;
    }

    public void setCheck_26(java.lang.String v)
    {
        this.check_26 = v;
    }

    public java.lang.String getCheck_date_26()
    {
        return check_date_26;
    }

    public void setCheck_date_26(java.lang.String v)
    {
        this.check_date_26 = v;
    }

    public java.lang.String getAmount_26()
    {
        return amount_26;
    }

    public void setAmount_26(java.lang.String v)
    {
        this.amount_26 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_3()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_3;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_3(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_3 = v;
    }

    public java.lang.String getCheck_27()
    {
        return check_27;
    }

    public void setCheck_27(java.lang.String v)
    {
        this.check_27 = v;
    }

    public java.lang.String getCheck_date_27()
    {
        return check_date_27;
    }

    public void setCheck_date_27(java.lang.String v)
    {
        this.check_date_27 = v;
    }

    public java.lang.String getAmount_27()
    {
        return amount_27;
    }

    public void setAmount_27(java.lang.String v)
    {
        this.amount_27 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_4()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_4;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_4(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_4 = v;
    }

    public java.lang.String getCheck_28()
    {
        return check_28;
    }

    public void setCheck_28(java.lang.String v)
    {
        this.check_28 = v;
    }

    public java.lang.String getCheck_date_28()
    {
        return check_date_28;
    }

    public void setCheck_date_28(java.lang.String v)
    {
        this.check_date_28 = v;
    }

    public java.lang.String getAmount_28()
    {
        return amount_28;
    }

    public void setAmount_28(java.lang.String v)
    {
        this.amount_28 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_5()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_5;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_5(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_5 = v;
    }

    public java.lang.String getCheck_29()
    {
        return check_29;
    }

    public void setCheck_29(java.lang.String v)
    {
        this.check_29 = v;
    }

    public java.lang.String getCheck_date_29()
    {
        return check_date_29;
    }

    public void setCheck_date_29(java.lang.String v)
    {
        this.check_date_29 = v;
    }

    public java.lang.String getAmount_29()
    {
        return amount_29;
    }

    public void setAmount_29(java.lang.String v)
    {
        this.amount_29 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_6()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_6;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_6(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_6 = v;
    }

    public java.lang.String getCheck_30()
    {
        return check_30;
    }

    public void setCheck_30(java.lang.String v)
    {
        this.check_30 = v;
    }

    public java.lang.String getCheck_date_30()
    {
        return check_date_30;
    }

    public void setCheck_date_30(java.lang.String v)
    {
        this.check_date_30 = v;
    }

    public java.lang.String getAmount_30()
    {
        return amount_30;
    }

    public void setAmount_30(java.lang.String v)
    {
        this.amount_30 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_7()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_7;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_7(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_7 = v;
    }

    public java.lang.String getCheck_31()
    {
        return check_31;
    }

    public void setCheck_31(java.lang.String v)
    {
        this.check_31 = v;
    }

    public java.lang.String getCheck_date_31()
    {
        return check_date_31;
    }

    public void setCheck_date_31(java.lang.String v)
    {
        this.check_date_31 = v;
    }

    public java.lang.String getAmount_31()
    {
        return amount_31;
    }

    public void setAmount_31(java.lang.String v)
    {
        this.amount_31 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_8()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_8;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_8(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_8 = v;
    }

    public java.lang.String getCheck_32()
    {
        return check_32;
    }

    public void setCheck_32(java.lang.String v)
    {
        this.check_32 = v;
    }

    public java.lang.String getCheck_date_32()
    {
        return check_date_32;
    }

    public void setCheck_date_32(java.lang.String v)
    {
        this.check_date_32 = v;
    }

    public java.lang.String getAmount_32()
    {
        return amount_32;
    }

    public void setAmount_32(java.lang.String v)
    {
        this.amount_32 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_9()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_9;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_9(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_9 = v;
    }

    public java.lang.String getCheck_33()
    {
        return check_33;
    }

    public void setCheck_33(java.lang.String v)
    {
        this.check_33 = v;
    }

    public java.lang.String getCheck_date_33()
    {
        return check_date_33;
    }

    public void setCheck_date_33(java.lang.String v)
    {
        this.check_date_33 = v;
    }

    public java.lang.String getAmount_33()
    {
        return amount_33;
    }

    public void setAmount_33(java.lang.String v)
    {
        this.amount_33 = v;
    }

    public java.lang.String getB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_10()
    {
        return b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_10;
    }

    public void setB_outside_the_kingdom_same_country_kingdom_and_branch_or_account_10(java.lang.String v)
    {
        this.b_outside_the_kingdom_same_country_kingdom_and_branch_or_account_10 = v;
    }

    public java.lang.String getCheck_34()
    {
        return check_34;
    }

    public void setCheck_34(java.lang.String v)
    {
        this.check_34 = v;
    }

    public java.lang.String getCheck_date_34()
    {
        return check_date_34;
    }

    public void setCheck_date_34(java.lang.String v)
    {
        this.check_date_34 = v;
    }

    public java.lang.String getAmount_34()
    {
        return amount_34;
    }

    public void setAmount_34(java.lang.String v)
    {
        this.amount_34 = v;
    }

    public java.lang.Double getAmount_total_b()
    {
        return amount_total_b;
    }

    public void setAmount_total_b(java.lang.Double v)
    {
        this.amount_total_b = v;
    }

    public java.lang.Double getSum_f41_f50_total_transfers_to_outside_the_kingdom_a_b()
    {
        return sum_f41_f50_total_transfers_to_outside_the_kingdom_a_b;
    }

    public void setSum_f41_f50_total_transfers_to_outside_the_kingdom_a_b(java.lang.Double v)
    {
        this.sum_f41_f50_total_transfers_to_outside_the_kingdom_a_b = v;
    }

    public TRANSFER_OUT_10Bean()
    {
    }

}
