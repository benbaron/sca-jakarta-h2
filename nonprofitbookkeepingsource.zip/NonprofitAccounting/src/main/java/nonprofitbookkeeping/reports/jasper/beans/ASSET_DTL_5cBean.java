package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet ASSET_DTL_5c */
public class ASSET_DTL_5cBean
{

    private java.lang.Double asset_dtl_5c_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String receivables_owed_from;
    private java.lang.String reason;
    private java.lang.String prior_amount;
    private java.lang.String current_amount;
    private java.lang.String receivables_owed_from_2;
    private java.lang.String reason_2;
    private java.lang.String prior_amount_2;
    private java.lang.String current_amount_2;
    private java.lang.String receivables_owed_from_3;
    private java.lang.String reason_3;
    private java.lang.String prior_amount_3;
    private java.lang.String current_amount_3;
    private java.lang.String receivables_owed_from_4;
    private java.lang.String reason_4;
    private java.lang.String prior_amount_4;
    private java.lang.String current_amount_4;
    private java.lang.String receivables_owed_from_5;
    private java.lang.String reason_5;
    private java.lang.String prior_amount_5;
    private java.lang.String current_amount_5;
    private java.lang.String receivables_owed_from_6;
    private java.lang.String reason_6;
    private java.lang.String prior_amount_6;
    private java.lang.String current_amount_6;
    private java.lang.String receivables_owed_from_7;
    private java.lang.String reason_7;
    private java.lang.String prior_amount_7;
    private java.lang.String current_amount_7;
    private java.lang.String receivables_owed_from_8;
    private java.lang.String reason_8;
    private java.lang.String prior_amount_8;
    private java.lang.String current_amount_8;
    private java.lang.String receivables_owed_from_9;
    private java.lang.String reason_9;
    private java.lang.String prior_amount_9;
    private java.lang.String current_amount_9;
    private java.lang.String receivables_owed_from_10;
    private java.lang.String reason_10;
    private java.lang.String prior_amount_10;
    private java.lang.String current_amount_10;
    private java.lang.String receivables_owed_from_11;
    private java.lang.String reason_11;
    private java.lang.String prior_amount_11;
    private java.lang.String current_amount_11;
    private java.lang.String receivables_owed_from_12;
    private java.lang.String reason_12;
    private java.lang.String prior_amount_12;
    private java.lang.String current_amount_12;
    private java.lang.String receivables_owed_from_13;
    private java.lang.String reason_13;
    private java.lang.String prior_amount_13;
    private java.lang.String current_amount_13;
    private java.lang.String receivables_owed_from_14;
    private java.lang.String reason_14;
    private java.lang.String prior_amount_14;
    private java.lang.String current_amount_14;
    private java.lang.String receivables_owed_from_15;
    private java.lang.String reason_15;
    private java.lang.String prior_amount_15;
    private java.lang.String current_amount_15;
    private java.lang.String receivables_owed_from_16;
    private java.lang.String reason_16;
    private java.lang.String prior_amount_16;
    private java.lang.String current_amount_16;
    private java.lang.String receivables_owed_from_17;
    private java.lang.String reason_17;
    private java.lang.String prior_amount_17;
    private java.lang.String current_amount_17;
    private java.lang.String receivables_owed_from_18;
    private java.lang.String reason_18;
    private java.lang.String prior_amount_18;
    private java.lang.String current_amount_18;
    private java.lang.String receivables_owed_from_19;
    private java.lang.String reason_19;
    private java.lang.String prior_amount_19;
    private java.lang.String current_amount_19;
    private java.lang.String receivables_owed_from_20;
    private java.lang.String reason_20;
    private java.lang.String prior_amount_20;
    private java.lang.String current_amount_20;
    private java.lang.Double prior_amount_total;
    private java.lang.Double current_amount_sum_e13_e32;
    private java.lang.String prepaid_expenses_description;
    private java.lang.String prior_amount_21;
    private java.lang.String current_amount_21;
    private java.lang.String prepaid_expenses_description_2;
    private java.lang.String prior_amount_22;
    private java.lang.String current_amount_22;
    private java.lang.String prepaid_expenses_description_3;
    private java.lang.String prior_amount_23;
    private java.lang.String current_amount_23;
    private java.lang.String prepaid_expenses_description_4;
    private java.lang.String prior_amount_24;
    private java.lang.String current_amount_24;
    private java.lang.String prepaid_expenses_description_5;
    private java.lang.String prior_amount_25;
    private java.lang.String current_amount_25;
    private java.lang.Double prior_amount_total_2;
    private java.lang.Double current_amount_sum_e39_e43;
    private java.lang.String other_assets_description;
    private java.lang.String show_on;
    private java.lang.String prior_amount_26;
    private java.lang.String current_amount_26;
    private java.lang.String other_assets_description_2;
    private java.lang.String show_on_2;
    private java.lang.String prior_amount_27;
    private java.lang.String current_amount_27;
    private java.lang.String other_assets_description_3;
    private java.lang.String show_on_3;
    private java.lang.String prior_amount_28;
    private java.lang.String current_amount_28;
    private java.lang.String other_assets_description_4;
    private java.lang.String show_on_4;
    private java.lang.String prior_amount_29;
    private java.lang.String current_amount_29;
    private java.lang.String other_assets_description_5;
    private java.lang.String show_on_5;
    private java.lang.String prior_amount_30;
    private java.lang.String current_amount_30;
    private java.lang.String other_assets_description_6;
    private java.lang.String show_on_6;
    private java.lang.String prior_amount_31;
    private java.lang.String current_amount_31;
    private java.lang.String other_assets_description_7;
    private java.lang.String show_on_7;
    private java.lang.String prior_amount_32;
    private java.lang.String current_amount_32;
    private java.lang.String other_assets_description_8;
    private java.lang.String show_on_8;
    private java.lang.String prior_amount_33;
    private java.lang.String current_amount_33;
    private java.lang.Double prior_amount_total_3;
    private java.lang.Double current_amount_sum_e50_e57;

    public java.lang.Double getAsset_dtl_5c_r2c3()
    {
        return asset_dtl_5c_r2c3;
    }

    public void setAsset_dtl_5c_r2c3(java.lang.Double v)
    {
        this.asset_dtl_5c_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getReceivables_owed_from()
    {
        return receivables_owed_from;
    }

    public void setReceivables_owed_from(java.lang.String v)
    {
        this.receivables_owed_from = v;
    }

    public java.lang.String getReason()
    {
        return reason;
    }

    public void setReason(java.lang.String v)
    {
        this.reason = v;
    }

    public java.lang.String getPrior_amount()
    {
        return prior_amount;
    }

    public void setPrior_amount(java.lang.String v)
    {
        this.prior_amount = v;
    }

    public java.lang.String getCurrent_amount()
    {
        return current_amount;
    }

    public void setCurrent_amount(java.lang.String v)
    {
        this.current_amount = v;
    }

    public java.lang.String getReceivables_owed_from_2()
    {
        return receivables_owed_from_2;
    }

    public void setReceivables_owed_from_2(java.lang.String v)
    {
        this.receivables_owed_from_2 = v;
    }

    public java.lang.String getReason_2()
    {
        return reason_2;
    }

    public void setReason_2(java.lang.String v)
    {
        this.reason_2 = v;
    }

    public java.lang.String getPrior_amount_2()
    {
        return prior_amount_2;
    }

    public void setPrior_amount_2(java.lang.String v)
    {
        this.prior_amount_2 = v;
    }

    public java.lang.String getCurrent_amount_2()
    {
        return current_amount_2;
    }

    public void setCurrent_amount_2(java.lang.String v)
    {
        this.current_amount_2 = v;
    }

    public java.lang.String getReceivables_owed_from_3()
    {
        return receivables_owed_from_3;
    }

    public void setReceivables_owed_from_3(java.lang.String v)
    {
        this.receivables_owed_from_3 = v;
    }

    public java.lang.String getReason_3()
    {
        return reason_3;
    }

    public void setReason_3(java.lang.String v)
    {
        this.reason_3 = v;
    }

    public java.lang.String getPrior_amount_3()
    {
        return prior_amount_3;
    }

    public void setPrior_amount_3(java.lang.String v)
    {
        this.prior_amount_3 = v;
    }

    public java.lang.String getCurrent_amount_3()
    {
        return current_amount_3;
    }

    public void setCurrent_amount_3(java.lang.String v)
    {
        this.current_amount_3 = v;
    }

    public java.lang.String getReceivables_owed_from_4()
    {
        return receivables_owed_from_4;
    }

    public void setReceivables_owed_from_4(java.lang.String v)
    {
        this.receivables_owed_from_4 = v;
    }

    public java.lang.String getReason_4()
    {
        return reason_4;
    }

    public void setReason_4(java.lang.String v)
    {
        this.reason_4 = v;
    }

    public java.lang.String getPrior_amount_4()
    {
        return prior_amount_4;
    }

    public void setPrior_amount_4(java.lang.String v)
    {
        this.prior_amount_4 = v;
    }

    public java.lang.String getCurrent_amount_4()
    {
        return current_amount_4;
    }

    public void setCurrent_amount_4(java.lang.String v)
    {
        this.current_amount_4 = v;
    }

    public java.lang.String getReceivables_owed_from_5()
    {
        return receivables_owed_from_5;
    }

    public void setReceivables_owed_from_5(java.lang.String v)
    {
        this.receivables_owed_from_5 = v;
    }

    public java.lang.String getReason_5()
    {
        return reason_5;
    }

    public void setReason_5(java.lang.String v)
    {
        this.reason_5 = v;
    }

    public java.lang.String getPrior_amount_5()
    {
        return prior_amount_5;
    }

    public void setPrior_amount_5(java.lang.String v)
    {
        this.prior_amount_5 = v;
    }

    public java.lang.String getCurrent_amount_5()
    {
        return current_amount_5;
    }

    public void setCurrent_amount_5(java.lang.String v)
    {
        this.current_amount_5 = v;
    }

    public java.lang.String getReceivables_owed_from_6()
    {
        return receivables_owed_from_6;
    }

    public void setReceivables_owed_from_6(java.lang.String v)
    {
        this.receivables_owed_from_6 = v;
    }

    public java.lang.String getReason_6()
    {
        return reason_6;
    }

    public void setReason_6(java.lang.String v)
    {
        this.reason_6 = v;
    }

    public java.lang.String getPrior_amount_6()
    {
        return prior_amount_6;
    }

    public void setPrior_amount_6(java.lang.String v)
    {
        this.prior_amount_6 = v;
    }

    public java.lang.String getCurrent_amount_6()
    {
        return current_amount_6;
    }

    public void setCurrent_amount_6(java.lang.String v)
    {
        this.current_amount_6 = v;
    }

    public java.lang.String getReceivables_owed_from_7()
    {
        return receivables_owed_from_7;
    }

    public void setReceivables_owed_from_7(java.lang.String v)
    {
        this.receivables_owed_from_7 = v;
    }

    public java.lang.String getReason_7()
    {
        return reason_7;
    }

    public void setReason_7(java.lang.String v)
    {
        this.reason_7 = v;
    }

    public java.lang.String getPrior_amount_7()
    {
        return prior_amount_7;
    }

    public void setPrior_amount_7(java.lang.String v)
    {
        this.prior_amount_7 = v;
    }

    public java.lang.String getCurrent_amount_7()
    {
        return current_amount_7;
    }

    public void setCurrent_amount_7(java.lang.String v)
    {
        this.current_amount_7 = v;
    }

    public java.lang.String getReceivables_owed_from_8()
    {
        return receivables_owed_from_8;
    }

    public void setReceivables_owed_from_8(java.lang.String v)
    {
        this.receivables_owed_from_8 = v;
    }

    public java.lang.String getReason_8()
    {
        return reason_8;
    }

    public void setReason_8(java.lang.String v)
    {
        this.reason_8 = v;
    }

    public java.lang.String getPrior_amount_8()
    {
        return prior_amount_8;
    }

    public void setPrior_amount_8(java.lang.String v)
    {
        this.prior_amount_8 = v;
    }

    public java.lang.String getCurrent_amount_8()
    {
        return current_amount_8;
    }

    public void setCurrent_amount_8(java.lang.String v)
    {
        this.current_amount_8 = v;
    }

    public java.lang.String getReceivables_owed_from_9()
    {
        return receivables_owed_from_9;
    }

    public void setReceivables_owed_from_9(java.lang.String v)
    {
        this.receivables_owed_from_9 = v;
    }

    public java.lang.String getReason_9()
    {
        return reason_9;
    }

    public void setReason_9(java.lang.String v)
    {
        this.reason_9 = v;
    }

    public java.lang.String getPrior_amount_9()
    {
        return prior_amount_9;
    }

    public void setPrior_amount_9(java.lang.String v)
    {
        this.prior_amount_9 = v;
    }

    public java.lang.String getCurrent_amount_9()
    {
        return current_amount_9;
    }

    public void setCurrent_amount_9(java.lang.String v)
    {
        this.current_amount_9 = v;
    }

    public java.lang.String getReceivables_owed_from_10()
    {
        return receivables_owed_from_10;
    }

    public void setReceivables_owed_from_10(java.lang.String v)
    {
        this.receivables_owed_from_10 = v;
    }

    public java.lang.String getReason_10()
    {
        return reason_10;
    }

    public void setReason_10(java.lang.String v)
    {
        this.reason_10 = v;
    }

    public java.lang.String getPrior_amount_10()
    {
        return prior_amount_10;
    }

    public void setPrior_amount_10(java.lang.String v)
    {
        this.prior_amount_10 = v;
    }

    public java.lang.String getCurrent_amount_10()
    {
        return current_amount_10;
    }

    public void setCurrent_amount_10(java.lang.String v)
    {
        this.current_amount_10 = v;
    }

    public java.lang.String getReceivables_owed_from_11()
    {
        return receivables_owed_from_11;
    }

    public void setReceivables_owed_from_11(java.lang.String v)
    {
        this.receivables_owed_from_11 = v;
    }

    public java.lang.String getReason_11()
    {
        return reason_11;
    }

    public void setReason_11(java.lang.String v)
    {
        this.reason_11 = v;
    }

    public java.lang.String getPrior_amount_11()
    {
        return prior_amount_11;
    }

    public void setPrior_amount_11(java.lang.String v)
    {
        this.prior_amount_11 = v;
    }

    public java.lang.String getCurrent_amount_11()
    {
        return current_amount_11;
    }

    public void setCurrent_amount_11(java.lang.String v)
    {
        this.current_amount_11 = v;
    }

    public java.lang.String getReceivables_owed_from_12()
    {
        return receivables_owed_from_12;
    }

    public void setReceivables_owed_from_12(java.lang.String v)
    {
        this.receivables_owed_from_12 = v;
    }

    public java.lang.String getReason_12()
    {
        return reason_12;
    }

    public void setReason_12(java.lang.String v)
    {
        this.reason_12 = v;
    }

    public java.lang.String getPrior_amount_12()
    {
        return prior_amount_12;
    }

    public void setPrior_amount_12(java.lang.String v)
    {
        this.prior_amount_12 = v;
    }

    public java.lang.String getCurrent_amount_12()
    {
        return current_amount_12;
    }

    public void setCurrent_amount_12(java.lang.String v)
    {
        this.current_amount_12 = v;
    }

    public java.lang.String getReceivables_owed_from_13()
    {
        return receivables_owed_from_13;
    }

    public void setReceivables_owed_from_13(java.lang.String v)
    {
        this.receivables_owed_from_13 = v;
    }

    public java.lang.String getReason_13()
    {
        return reason_13;
    }

    public void setReason_13(java.lang.String v)
    {
        this.reason_13 = v;
    }

    public java.lang.String getPrior_amount_13()
    {
        return prior_amount_13;
    }

    public void setPrior_amount_13(java.lang.String v)
    {
        this.prior_amount_13 = v;
    }

    public java.lang.String getCurrent_amount_13()
    {
        return current_amount_13;
    }

    public void setCurrent_amount_13(java.lang.String v)
    {
        this.current_amount_13 = v;
    }

    public java.lang.String getReceivables_owed_from_14()
    {
        return receivables_owed_from_14;
    }

    public void setReceivables_owed_from_14(java.lang.String v)
    {
        this.receivables_owed_from_14 = v;
    }

    public java.lang.String getReason_14()
    {
        return reason_14;
    }

    public void setReason_14(java.lang.String v)
    {
        this.reason_14 = v;
    }

    public java.lang.String getPrior_amount_14()
    {
        return prior_amount_14;
    }

    public void setPrior_amount_14(java.lang.String v)
    {
        this.prior_amount_14 = v;
    }

    public java.lang.String getCurrent_amount_14()
    {
        return current_amount_14;
    }

    public void setCurrent_amount_14(java.lang.String v)
    {
        this.current_amount_14 = v;
    }

    public java.lang.String getReceivables_owed_from_15()
    {
        return receivables_owed_from_15;
    }

    public void setReceivables_owed_from_15(java.lang.String v)
    {
        this.receivables_owed_from_15 = v;
    }

    public java.lang.String getReason_15()
    {
        return reason_15;
    }

    public void setReason_15(java.lang.String v)
    {
        this.reason_15 = v;
    }

    public java.lang.String getPrior_amount_15()
    {
        return prior_amount_15;
    }

    public void setPrior_amount_15(java.lang.String v)
    {
        this.prior_amount_15 = v;
    }

    public java.lang.String getCurrent_amount_15()
    {
        return current_amount_15;
    }

    public void setCurrent_amount_15(java.lang.String v)
    {
        this.current_amount_15 = v;
    }

    public java.lang.String getReceivables_owed_from_16()
    {
        return receivables_owed_from_16;
    }

    public void setReceivables_owed_from_16(java.lang.String v)
    {
        this.receivables_owed_from_16 = v;
    }

    public java.lang.String getReason_16()
    {
        return reason_16;
    }

    public void setReason_16(java.lang.String v)
    {
        this.reason_16 = v;
    }

    public java.lang.String getPrior_amount_16()
    {
        return prior_amount_16;
    }

    public void setPrior_amount_16(java.lang.String v)
    {
        this.prior_amount_16 = v;
    }

    public java.lang.String getCurrent_amount_16()
    {
        return current_amount_16;
    }

    public void setCurrent_amount_16(java.lang.String v)
    {
        this.current_amount_16 = v;
    }

    public java.lang.String getReceivables_owed_from_17()
    {
        return receivables_owed_from_17;
    }

    public void setReceivables_owed_from_17(java.lang.String v)
    {
        this.receivables_owed_from_17 = v;
    }

    public java.lang.String getReason_17()
    {
        return reason_17;
    }

    public void setReason_17(java.lang.String v)
    {
        this.reason_17 = v;
    }

    public java.lang.String getPrior_amount_17()
    {
        return prior_amount_17;
    }

    public void setPrior_amount_17(java.lang.String v)
    {
        this.prior_amount_17 = v;
    }

    public java.lang.String getCurrent_amount_17()
    {
        return current_amount_17;
    }

    public void setCurrent_amount_17(java.lang.String v)
    {
        this.current_amount_17 = v;
    }

    public java.lang.String getReceivables_owed_from_18()
    {
        return receivables_owed_from_18;
    }

    public void setReceivables_owed_from_18(java.lang.String v)
    {
        this.receivables_owed_from_18 = v;
    }

    public java.lang.String getReason_18()
    {
        return reason_18;
    }

    public void setReason_18(java.lang.String v)
    {
        this.reason_18 = v;
    }

    public java.lang.String getPrior_amount_18()
    {
        return prior_amount_18;
    }

    public void setPrior_amount_18(java.lang.String v)
    {
        this.prior_amount_18 = v;
    }

    public java.lang.String getCurrent_amount_18()
    {
        return current_amount_18;
    }

    public void setCurrent_amount_18(java.lang.String v)
    {
        this.current_amount_18 = v;
    }

    public java.lang.String getReceivables_owed_from_19()
    {
        return receivables_owed_from_19;
    }

    public void setReceivables_owed_from_19(java.lang.String v)
    {
        this.receivables_owed_from_19 = v;
    }

    public java.lang.String getReason_19()
    {
        return reason_19;
    }

    public void setReason_19(java.lang.String v)
    {
        this.reason_19 = v;
    }

    public java.lang.String getPrior_amount_19()
    {
        return prior_amount_19;
    }

    public void setPrior_amount_19(java.lang.String v)
    {
        this.prior_amount_19 = v;
    }

    public java.lang.String getCurrent_amount_19()
    {
        return current_amount_19;
    }

    public void setCurrent_amount_19(java.lang.String v)
    {
        this.current_amount_19 = v;
    }

    public java.lang.String getReceivables_owed_from_20()
    {
        return receivables_owed_from_20;
    }

    public void setReceivables_owed_from_20(java.lang.String v)
    {
        this.receivables_owed_from_20 = v;
    }

    public java.lang.String getReason_20()
    {
        return reason_20;
    }

    public void setReason_20(java.lang.String v)
    {
        this.reason_20 = v;
    }

    public java.lang.String getPrior_amount_20()
    {
        return prior_amount_20;
    }

    public void setPrior_amount_20(java.lang.String v)
    {
        this.prior_amount_20 = v;
    }

    public java.lang.String getCurrent_amount_20()
    {
        return current_amount_20;
    }

    public void setCurrent_amount_20(java.lang.String v)
    {
        this.current_amount_20 = v;
    }

    public java.lang.Double getPrior_amount_total()
    {
        return prior_amount_total;
    }

    public void setPrior_amount_total(java.lang.Double v)
    {
        this.prior_amount_total = v;
    }

    public java.lang.Double getCurrent_amount_sum_e13_e32()
    {
        return current_amount_sum_e13_e32;
    }

    public void setCurrent_amount_sum_e13_e32(java.lang.Double v)
    {
        this.current_amount_sum_e13_e32 = v;
    }

    public java.lang.String getPrepaid_expenses_description()
    {
        return prepaid_expenses_description;
    }

    public void setPrepaid_expenses_description(java.lang.String v)
    {
        this.prepaid_expenses_description = v;
    }

    public java.lang.String getPrior_amount_21()
    {
        return prior_amount_21;
    }

    public void setPrior_amount_21(java.lang.String v)
    {
        this.prior_amount_21 = v;
    }

    public java.lang.String getCurrent_amount_21()
    {
        return current_amount_21;
    }

    public void setCurrent_amount_21(java.lang.String v)
    {
        this.current_amount_21 = v;
    }

    public java.lang.String getPrepaid_expenses_description_2()
    {
        return prepaid_expenses_description_2;
    }

    public void setPrepaid_expenses_description_2(java.lang.String v)
    {
        this.prepaid_expenses_description_2 = v;
    }

    public java.lang.String getPrior_amount_22()
    {
        return prior_amount_22;
    }

    public void setPrior_amount_22(java.lang.String v)
    {
        this.prior_amount_22 = v;
    }

    public java.lang.String getCurrent_amount_22()
    {
        return current_amount_22;
    }

    public void setCurrent_amount_22(java.lang.String v)
    {
        this.current_amount_22 = v;
    }

    public java.lang.String getPrepaid_expenses_description_3()
    {
        return prepaid_expenses_description_3;
    }

    public void setPrepaid_expenses_description_3(java.lang.String v)
    {
        this.prepaid_expenses_description_3 = v;
    }

    public java.lang.String getPrior_amount_23()
    {
        return prior_amount_23;
    }

    public void setPrior_amount_23(java.lang.String v)
    {
        this.prior_amount_23 = v;
    }

    public java.lang.String getCurrent_amount_23()
    {
        return current_amount_23;
    }

    public void setCurrent_amount_23(java.lang.String v)
    {
        this.current_amount_23 = v;
    }

    public java.lang.String getPrepaid_expenses_description_4()
    {
        return prepaid_expenses_description_4;
    }

    public void setPrepaid_expenses_description_4(java.lang.String v)
    {
        this.prepaid_expenses_description_4 = v;
    }

    public java.lang.String getPrior_amount_24()
    {
        return prior_amount_24;
    }

    public void setPrior_amount_24(java.lang.String v)
    {
        this.prior_amount_24 = v;
    }

    public java.lang.String getCurrent_amount_24()
    {
        return current_amount_24;
    }

    public void setCurrent_amount_24(java.lang.String v)
    {
        this.current_amount_24 = v;
    }

    public java.lang.String getPrepaid_expenses_description_5()
    {
        return prepaid_expenses_description_5;
    }

    public void setPrepaid_expenses_description_5(java.lang.String v)
    {
        this.prepaid_expenses_description_5 = v;
    }

    public java.lang.String getPrior_amount_25()
    {
        return prior_amount_25;
    }

    public void setPrior_amount_25(java.lang.String v)
    {
        this.prior_amount_25 = v;
    }

    public java.lang.String getCurrent_amount_25()
    {
        return current_amount_25;
    }

    public void setCurrent_amount_25(java.lang.String v)
    {
        this.current_amount_25 = v;
    }

    public java.lang.Double getPrior_amount_total_2()
    {
        return prior_amount_total_2;
    }

    public void setPrior_amount_total_2(java.lang.Double v)
    {
        this.prior_amount_total_2 = v;
    }

    public java.lang.Double getCurrent_amount_sum_e39_e43()
    {
        return current_amount_sum_e39_e43;
    }

    public void setCurrent_amount_sum_e39_e43(java.lang.Double v)
    {
        this.current_amount_sum_e39_e43 = v;
    }

    public java.lang.String getOther_assets_description()
    {
        return other_assets_description;
    }

    public void setOther_assets_description(java.lang.String v)
    {
        this.other_assets_description = v;
    }

    public java.lang.String getShow_on()
    {
        return show_on;
    }

    public void setShow_on(java.lang.String v)
    {
        this.show_on = v;
    }

    public java.lang.String getPrior_amount_26()
    {
        return prior_amount_26;
    }

    public void setPrior_amount_26(java.lang.String v)
    {
        this.prior_amount_26 = v;
    }

    public java.lang.String getCurrent_amount_26()
    {
        return current_amount_26;
    }

    public void setCurrent_amount_26(java.lang.String v)
    {
        this.current_amount_26 = v;
    }

    public java.lang.String getOther_assets_description_2()
    {
        return other_assets_description_2;
    }

    public void setOther_assets_description_2(java.lang.String v)
    {
        this.other_assets_description_2 = v;
    }

    public java.lang.String getShow_on_2()
    {
        return show_on_2;
    }

    public void setShow_on_2(java.lang.String v)
    {
        this.show_on_2 = v;
    }

    public java.lang.String getPrior_amount_27()
    {
        return prior_amount_27;
    }

    public void setPrior_amount_27(java.lang.String v)
    {
        this.prior_amount_27 = v;
    }

    public java.lang.String getCurrent_amount_27()
    {
        return current_amount_27;
    }

    public void setCurrent_amount_27(java.lang.String v)
    {
        this.current_amount_27 = v;
    }

    public java.lang.String getOther_assets_description_3()
    {
        return other_assets_description_3;
    }

    public void setOther_assets_description_3(java.lang.String v)
    {
        this.other_assets_description_3 = v;
    }

    public java.lang.String getShow_on_3()
    {
        return show_on_3;
    }

    public void setShow_on_3(java.lang.String v)
    {
        this.show_on_3 = v;
    }

    public java.lang.String getPrior_amount_28()
    {
        return prior_amount_28;
    }

    public void setPrior_amount_28(java.lang.String v)
    {
        this.prior_amount_28 = v;
    }

    public java.lang.String getCurrent_amount_28()
    {
        return current_amount_28;
    }

    public void setCurrent_amount_28(java.lang.String v)
    {
        this.current_amount_28 = v;
    }

    public java.lang.String getOther_assets_description_4()
    {
        return other_assets_description_4;
    }

    public void setOther_assets_description_4(java.lang.String v)
    {
        this.other_assets_description_4 = v;
    }

    public java.lang.String getShow_on_4()
    {
        return show_on_4;
    }

    public void setShow_on_4(java.lang.String v)
    {
        this.show_on_4 = v;
    }

    public java.lang.String getPrior_amount_29()
    {
        return prior_amount_29;
    }

    public void setPrior_amount_29(java.lang.String v)
    {
        this.prior_amount_29 = v;
    }

    public java.lang.String getCurrent_amount_29()
    {
        return current_amount_29;
    }

    public void setCurrent_amount_29(java.lang.String v)
    {
        this.current_amount_29 = v;
    }

    public java.lang.String getOther_assets_description_5()
    {
        return other_assets_description_5;
    }

    public void setOther_assets_description_5(java.lang.String v)
    {
        this.other_assets_description_5 = v;
    }

    public java.lang.String getShow_on_5()
    {
        return show_on_5;
    }

    public void setShow_on_5(java.lang.String v)
    {
        this.show_on_5 = v;
    }

    public java.lang.String getPrior_amount_30()
    {
        return prior_amount_30;
    }

    public void setPrior_amount_30(java.lang.String v)
    {
        this.prior_amount_30 = v;
    }

    public java.lang.String getCurrent_amount_30()
    {
        return current_amount_30;
    }

    public void setCurrent_amount_30(java.lang.String v)
    {
        this.current_amount_30 = v;
    }

    public java.lang.String getOther_assets_description_6()
    {
        return other_assets_description_6;
    }

    public void setOther_assets_description_6(java.lang.String v)
    {
        this.other_assets_description_6 = v;
    }

    public java.lang.String getShow_on_6()
    {
        return show_on_6;
    }

    public void setShow_on_6(java.lang.String v)
    {
        this.show_on_6 = v;
    }

    public java.lang.String getPrior_amount_31()
    {
        return prior_amount_31;
    }

    public void setPrior_amount_31(java.lang.String v)
    {
        this.prior_amount_31 = v;
    }

    public java.lang.String getCurrent_amount_31()
    {
        return current_amount_31;
    }

    public void setCurrent_amount_31(java.lang.String v)
    {
        this.current_amount_31 = v;
    }

    public java.lang.String getOther_assets_description_7()
    {
        return other_assets_description_7;
    }

    public void setOther_assets_description_7(java.lang.String v)
    {
        this.other_assets_description_7 = v;
    }

    public java.lang.String getShow_on_7()
    {
        return show_on_7;
    }

    public void setShow_on_7(java.lang.String v)
    {
        this.show_on_7 = v;
    }

    public java.lang.String getPrior_amount_32()
    {
        return prior_amount_32;
    }

    public void setPrior_amount_32(java.lang.String v)
    {
        this.prior_amount_32 = v;
    }

    public java.lang.String getCurrent_amount_32()
    {
        return current_amount_32;
    }

    public void setCurrent_amount_32(java.lang.String v)
    {
        this.current_amount_32 = v;
    }

    public java.lang.String getOther_assets_description_8()
    {
        return other_assets_description_8;
    }

    public void setOther_assets_description_8(java.lang.String v)
    {
        this.other_assets_description_8 = v;
    }

    public java.lang.String getShow_on_8()
    {
        return show_on_8;
    }

    public void setShow_on_8(java.lang.String v)
    {
        this.show_on_8 = v;
    }

    public java.lang.String getPrior_amount_33()
    {
        return prior_amount_33;
    }

    public void setPrior_amount_33(java.lang.String v)
    {
        this.prior_amount_33 = v;
    }

    public java.lang.String getCurrent_amount_33()
    {
        return current_amount_33;
    }

    public void setCurrent_amount_33(java.lang.String v)
    {
        this.current_amount_33 = v;
    }

    public java.lang.Double getPrior_amount_total_3()
    {
        return prior_amount_total_3;
    }

    public void setPrior_amount_total_3(java.lang.Double v)
    {
        this.prior_amount_total_3 = v;
    }

    public java.lang.Double getCurrent_amount_sum_e50_e57()
    {
        return current_amount_sum_e50_e57;
    }

    public void setCurrent_amount_sum_e50_e57(java.lang.Double v)
    {
        this.current_amount_sum_e50_e57 = v;
    }

    public ASSET_DTL_5cBean()
    {
    }

}
