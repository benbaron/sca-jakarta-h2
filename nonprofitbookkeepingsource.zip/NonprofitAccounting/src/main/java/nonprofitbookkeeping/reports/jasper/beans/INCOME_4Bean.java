package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet INCOME_4 */
public class INCOME_4Bean
{

    private java.lang.Double income_4_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.Double income_4_r9c10;
    private java.lang.Double amount_internal;
    private java.lang.Double income_dtl_11a_e20_external;
    private java.lang.Double income_dtl_11a_e30_11a;
    private java.lang.Double income_dtl_11a_e36_income_from_demos_and_activity_fees;
    private java.lang.Double income_dtl_11a_e52_adjusted_gross_event_income;
    private java.lang.Double income_dtl_11b_g37_within_kingdom;
    private java.lang.Double transfer_in_9_f38_transfer_in_9b_f32_transfer_in_9c_f32_transfer_in_9d_f55_outside_kingdom;
    private java.lang.String transfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_interest_earned;
    private java.lang.Double gross_gross_cost_net;
    private java.lang.Double cost_inventory_dtl_6_m30_inventory_dtl_6b_m30;
    private java.lang.Double transfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_inventory_dtl_6_m29_inventory_dtl_6b_m29;
    private java.lang.Double h19_i19_7;
    private java.lang.Double regalia_sales_dtl_7_i53_regalia_sales_dtl_7b_i53_15;
    private java.lang.Double inventory_dtl_6_m30_inventory_dtl_6b_m30_gross_cost_net;
    private java.lang.Double inventory_dtl_6_m29_inventory_dtl_6b_m29_income_dtl_11b_e43;
    private java.lang.Double newsletter_15_e17_income_dtl_11b_f43;
    private java.lang.Double h22_i22_11b;
    private java.lang.Double income_dtl_11b_g56_sum_of_lines_1_through_9;
    private java.lang.Double activity_related_12a;
    private java.lang.Double total_sumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22;
    private java.lang.Double office_admin_12a;
    private java.lang.Double sumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22_sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38;
    private java.lang.Double fund_raising_sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38;
    private java.lang.Double sum_g27_i27_sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38;
    private java.lang.String sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_bank_service_charges;
    private java.lang.String sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_bank_service_charges;
    private java.lang.String sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_bank_service_charges;
    private java.lang.Double sum_g28_i28_bank_service_charges;
    private java.lang.Double sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_8;
    private java.lang.Double sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53;
    private java.lang.Double sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53;
    private java.lang.Double sum_g29_i29_sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53;
    private java.lang.String sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_equipment_rental_maintenance;
    private java.lang.String sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_equipment_rental_maintenance;
    private java.lang.String sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_equipment_rental_maintenance;
    private java.lang.Double sum_g30_i30_equipment_rental_maintenance;
    private java.lang.Double sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_12a;
    private java.lang.Double sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54;
    private java.lang.Double sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54;
    private java.lang.Double sum_g31_i31_sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54;
    private java.lang.String sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_food;
    private java.lang.String sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_food;
    private java.lang.String sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_food;
    private java.lang.Double sum_g32_i32_food;
    private java.lang.String sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_general_supplies;
    private java.lang.String sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_general_supplies;
    private java.lang.String sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_general_supplies;
    private java.lang.Double sum_g33_i33_general_supplies;
    private java.lang.Double sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_0_0;
    private java.lang.Double sum_g34_i34_0_0;
    private java.lang.String _0_0_occupancy_site_charges;
    private java.lang.String expense_dtl_12b_i16_occupancy_site_charges;
    private java.lang.String _0_0_occupancy_site_charges_2;
    private java.lang.Double sum_g35_i35_occupancy_site_charges;
    private java.lang.String _0_0_postage_shipping_po_box_rental;
    private java.lang.String expense_dtl_12b_i16_postage_shipping_po_box_rental;
    private java.lang.String _0_0_postage_shipping_po_box_rental_2;
    private java.lang.Double sum_g36_i36_postage_shipping_po_box_rental;
    private java.lang.String _0_0_printing_publications;
    private java.lang.String expense_dtl_12b_i16_printing_publications;
    private java.lang.String _0_0_printing_publications_2;
    private java.lang.Double sum_g37_i37_printing_publications;
    private java.lang.Double expense_dtl_12b_i16_0_0;
    private java.lang.Double sum_g38_i38_0_0;
    private java.lang.String _0_0_telephone;
    private java.lang.String regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_telephone;
    private java.lang.String _0_0_telephone_2;
    private java.lang.Double sum_g39_i39_telephone;
    private java.lang.String _0_0_travel_gas_tolls_airfare;
    private java.lang.String regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_travel_gas_tolls_airfare;
    private java.lang.String _0_0_travel_gas_tolls_airfare_2;
    private java.lang.Double sum_g40_i40_travel_gas_tolls_airfare;
    private java.lang.Double _0_0_sub_total_lines_12_26;
    private java.lang.Double regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_sum_g27_g41;
    private java.lang.Double _0_0_sum_h27_h41;
    private java.lang.Double sum_g41_i41_sum_i27_i41;
    private java.lang.Double sum_j27_j41_12b;
    private java.lang.Double expense_dtl_12b_i27_12b;
    private java.lang.Double expense_dtl_12b_i56_10;
    private java.lang.Double transfer_out_10_f25_transfer_out_10b_f28_transfer_out_10c_f28_transfer_out_10d_f28_10;
    private java.lang.Double transfer_out_10_f52_transfer_out_10b_f42_transfer_out_10b_f54_transfer_out_10c_f42_transfer_out_10c_f54_transfer_out_10d_f42_transfer_out_10d_f54_line_27_total_lines_28_to_30b;
    private java.lang.Double sum_j42_j46_line_11_minus_line_31;
    private java.lang.Double print_exchequer;
    private java.lang.Double if_contents_c_10_contents_c_10_seneschal;

    public java.lang.Double getIncome_4_r2c3()
    {
        return income_4_r2c3;
    }

    public void setIncome_4_r2c3(java.lang.Double v)
    {
        this.income_4_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.Double getIncome_4_r9c10()
    {
        return income_4_r9c10;
    }

    public void setIncome_4_r9c10(java.lang.Double v)
    {
        this.income_4_r9c10 = v;
    }

    public java.lang.Double getAmount_internal()
    {
        return amount_internal;
    }

    public void setAmount_internal(java.lang.Double v)
    {
        this.amount_internal = v;
    }

    public java.lang.Double getIncome_dtl_11a_e20_external()
    {
        return income_dtl_11a_e20_external;
    }

    public void setIncome_dtl_11a_e20_external(java.lang.Double v)
    {
        this.income_dtl_11a_e20_external = v;
    }

    public java.lang.Double getIncome_dtl_11a_e30_11a()
    {
        return income_dtl_11a_e30_11a;
    }

    public void setIncome_dtl_11a_e30_11a(java.lang.Double v)
    {
        this.income_dtl_11a_e30_11a = v;
    }

    public java.lang.Double getIncome_dtl_11a_e36_income_from_demos_and_activity_fees()
    {
        return income_dtl_11a_e36_income_from_demos_and_activity_fees;
    }

    public void setIncome_dtl_11a_e36_income_from_demos_and_activity_fees(java.lang.Double v)
    {
        this.income_dtl_11a_e36_income_from_demos_and_activity_fees = v;
    }

    public java.lang.Double getIncome_dtl_11a_e52_adjusted_gross_event_income()
    {
        return income_dtl_11a_e52_adjusted_gross_event_income;
    }

    public void setIncome_dtl_11a_e52_adjusted_gross_event_income(java.lang.Double v)
    {
        this.income_dtl_11a_e52_adjusted_gross_event_income = v;
    }

    public java.lang.Double getIncome_dtl_11b_g37_within_kingdom()
    {
        return income_dtl_11b_g37_within_kingdom;
    }

    public void setIncome_dtl_11b_g37_within_kingdom(java.lang.Double v)
    {
        this.income_dtl_11b_g37_within_kingdom = v;
    }

    public java.lang.Double getTransfer_in_9_f38_transfer_in_9b_f32_transfer_in_9c_f32_transfer_in_9d_f55_outside_kingdom()
    {
        return transfer_in_9_f38_transfer_in_9b_f32_transfer_in_9c_f32_transfer_in_9d_f55_outside_kingdom;
    }

    public void setTransfer_in_9_f38_transfer_in_9b_f32_transfer_in_9c_f32_transfer_in_9d_f55_outside_kingdom(java.lang.Double v)
    {
        this.transfer_in_9_f38_transfer_in_9b_f32_transfer_in_9c_f32_transfer_in_9d_f55_outside_kingdom = v;
    }

    public java.lang.String getTransfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_interest_earned()
    {
        return transfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_interest_earned;
    }

    public void setTransfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_interest_earned(java.lang.String v)
    {
        this.transfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_interest_earned = v;
    }

    public java.lang.Double getGross_gross_cost_net()
    {
        return gross_gross_cost_net;
    }

    public void setGross_gross_cost_net(java.lang.Double v)
    {
        this.gross_gross_cost_net = v;
    }

    public java.lang.Double getCost_inventory_dtl_6_m30_inventory_dtl_6b_m30()
    {
        return cost_inventory_dtl_6_m30_inventory_dtl_6b_m30;
    }

    public void setCost_inventory_dtl_6_m30_inventory_dtl_6b_m30(java.lang.Double v)
    {
        this.cost_inventory_dtl_6_m30_inventory_dtl_6b_m30 = v;
    }

    public java.lang.Double getTransfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_inventory_dtl_6_m29_inventory_dtl_6b_m29()
    {
        return transfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_inventory_dtl_6_m29_inventory_dtl_6b_m29;
    }

    public void setTransfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_inventory_dtl_6_m29_inventory_dtl_6b_m29(java.lang.Double v)
    {
        this.transfer_in_9_f58_transfer_in_9b_f54_transfer_in_9c_f54_inventory_dtl_6_m29_inventory_dtl_6b_m29 = v;
    }

    public java.lang.Double getH19_i19_7()
    {
        return h19_i19_7;
    }

    public void setH19_i19_7(java.lang.Double v)
    {
        this.h19_i19_7 = v;
    }

    public java.lang.Double getRegalia_sales_dtl_7_i53_regalia_sales_dtl_7b_i53_15()
    {
        return regalia_sales_dtl_7_i53_regalia_sales_dtl_7b_i53_15;
    }

    public void setRegalia_sales_dtl_7_i53_regalia_sales_dtl_7b_i53_15(java.lang.Double v)
    {
        this.regalia_sales_dtl_7_i53_regalia_sales_dtl_7b_i53_15 = v;
    }

    public java.lang.Double getInventory_dtl_6_m30_inventory_dtl_6b_m30_gross_cost_net()
    {
        return inventory_dtl_6_m30_inventory_dtl_6b_m30_gross_cost_net;
    }

    public void setInventory_dtl_6_m30_inventory_dtl_6b_m30_gross_cost_net(java.lang.Double v)
    {
        this.inventory_dtl_6_m30_inventory_dtl_6b_m30_gross_cost_net = v;
    }

    public java.lang.Double getInventory_dtl_6_m29_inventory_dtl_6b_m29_income_dtl_11b_e43()
    {
        return inventory_dtl_6_m29_inventory_dtl_6b_m29_income_dtl_11b_e43;
    }

    public void setInventory_dtl_6_m29_inventory_dtl_6b_m29_income_dtl_11b_e43(java.lang.Double v)
    {
        this.inventory_dtl_6_m29_inventory_dtl_6b_m29_income_dtl_11b_e43 = v;
    }

    public java.lang.Double getNewsletter_15_e17_income_dtl_11b_f43()
    {
        return newsletter_15_e17_income_dtl_11b_f43;
    }

    public void setNewsletter_15_e17_income_dtl_11b_f43(java.lang.Double v)
    {
        this.newsletter_15_e17_income_dtl_11b_f43 = v;
    }

    public java.lang.Double getH22_i22_11b()
    {
        return h22_i22_11b;
    }

    public void setH22_i22_11b(java.lang.Double v)
    {
        this.h22_i22_11b = v;
    }

    public java.lang.Double getIncome_dtl_11b_g56_sum_of_lines_1_through_9()
    {
        return income_dtl_11b_g56_sum_of_lines_1_through_9;
    }

    public void setIncome_dtl_11b_g56_sum_of_lines_1_through_9(java.lang.Double v)
    {
        this.income_dtl_11b_g56_sum_of_lines_1_through_9 = v;
    }

    public java.lang.Double getActivity_related_12a()
    {
        return activity_related_12a;
    }

    public void setActivity_related_12a(java.lang.Double v)
    {
        this.activity_related_12a = v;
    }

    public java.lang.Double getTotal_sumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22()
    {
        return total_sumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22;
    }

    public void setTotal_sumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22(java.lang.Double v)
    {
        this.total_sumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22 = v;
    }

    public java.lang.Double getOffice_admin_12a()
    {
        return office_admin_12a;
    }

    public void setOffice_admin_12a(java.lang.Double v)
    {
        this.office_admin_12a = v;
    }

    public java.lang.Double getSumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22_sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38()
    {
        return sumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22_sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38;
    }

    public void setSumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22_sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38(java.lang.Double v)
    {
        this.sumif_expense_dtl_12a_c12_c22_ar_expense_dtl_12a_f12_f22_sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38 = v;
    }

    public java.lang.Double getFund_raising_sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38()
    {
        return fund_raising_sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38;
    }

    public void setFund_raising_sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38(java.lang.Double v)
    {
        this.fund_raising_sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38 = v;
    }

    public java.lang.Double getSum_g27_i27_sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38()
    {
        return sum_g27_i27_sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38;
    }

    public void setSum_g27_i27_sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38(java.lang.Double v)
    {
        this.sum_g27_i27_sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38 = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_bank_service_charges()
    {
        return sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_bank_service_charges;
    }

    public void setSumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_bank_service_charges(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_bank_service_charges = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_bank_service_charges()
    {
        return sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_bank_service_charges;
    }

    public void setSumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_bank_service_charges(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_bank_service_charges = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_bank_service_charges()
    {
        return sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_bank_service_charges;
    }

    public void setSumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_bank_service_charges(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_bank_service_charges = v;
    }

    public java.lang.Double getSum_g28_i28_bank_service_charges()
    {
        return sum_g28_i28_bank_service_charges;
    }

    public void setSum_g28_i28_bank_service_charges(java.lang.Double v)
    {
        this.sum_g28_i28_bank_service_charges = v;
    }

    public java.lang.Double getSumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_8()
    {
        return sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_8;
    }

    public void setSumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_8(java.lang.Double v)
    {
        this.sumif_expense_dtl_12a_c27_c38_oa_expense_dtl_12a_f27_f38_8 = v;
    }

    public java.lang.Double getSumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53()
    {
        return sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53;
    }

    public void setSumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53(java.lang.Double v)
    {
        this.sumif_expense_dtl_12a_c27_c38_ar_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53 = v;
    }

    public java.lang.Double getSumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53()
    {
        return sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53;
    }

    public void setSumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53(java.lang.Double v)
    {
        this.sumif_expense_dtl_12a_c27_c38_fr_expense_dtl_12a_f27_f38_sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53 = v;
    }

    public java.lang.Double getSum_g29_i29_sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53()
    {
        return sum_g29_i29_sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53;
    }

    public void setSum_g29_i29_sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53(java.lang.Double v)
    {
        this.sum_g29_i29_sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53 = v;
    }

    public java.lang.String getSumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_equipment_rental_maintenance()
    {
        return sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_equipment_rental_maintenance;
    }

    public void setSumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_equipment_rental_maintenance(java.lang.String v)
    {
        this.sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_equipment_rental_maintenance = v;
    }

    public java.lang.String getSumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_equipment_rental_maintenance()
    {
        return sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_equipment_rental_maintenance;
    }

    public void setSumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_equipment_rental_maintenance(java.lang.String v)
    {
        this.sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_equipment_rental_maintenance = v;
    }

    public java.lang.String getSumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_equipment_rental_maintenance()
    {
        return sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_equipment_rental_maintenance;
    }

    public void setSumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_equipment_rental_maintenance(java.lang.String v)
    {
        this.sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_equipment_rental_maintenance = v;
    }

    public java.lang.Double getSum_g30_i30_equipment_rental_maintenance()
    {
        return sum_g30_i30_equipment_rental_maintenance;
    }

    public void setSum_g30_i30_equipment_rental_maintenance(java.lang.Double v)
    {
        this.sum_g30_i30_equipment_rental_maintenance = v;
    }

    public java.lang.Double getSumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_12a()
    {
        return sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_12a;
    }

    public void setSumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_12a(java.lang.Double v)
    {
        this.sumif_depr_dtl_8_d14_d23_oa_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_oa_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_oa_depr_dtl_8b_l14_l53_12a = v;
    }

    public java.lang.Double getSumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54()
    {
        return sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54;
    }

    public void setSumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54(java.lang.Double v)
    {
        this.sumif_depr_dtl_8_d14_d23_ar_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_ar_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_ar_depr_dtl_8b_l14_l53_sumif_depr_dtl_8c_d14_d53_ar_depr_dtl_8c_l14_l53_sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54 = v;
    }

    public java.lang.Double getSumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54()
    {
        return sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54;
    }

    public void setSumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54(java.lang.Double v)
    {
        this.sumif_depr_dtl_8_d14_d23_fr_depr_dtl_8_l14_l23_sumif_depr_dtl_8_d32_d41_fr_depr_dtl_8_l32_l41_sumif_depr_dtl_8b_d14_d53_fr_depr_dtl_8b_l14_l53_sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54 = v;
    }

    public java.lang.Double getSum_g31_i31_sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54()
    {
        return sum_g31_i31_sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54;
    }

    public void setSum_g31_i31_sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54(java.lang.Double v)
    {
        this.sum_g31_i31_sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54 = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_food()
    {
        return sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_food;
    }

    public void setSumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_food(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_food = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_food()
    {
        return sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_food;
    }

    public void setSumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_food(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_food = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_food()
    {
        return sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_food;
    }

    public void setSumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_food(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_food = v;
    }

    public java.lang.Double getSum_g32_i32_food()
    {
        return sum_g32_i32_food;
    }

    public void setSum_g32_i32_food(java.lang.Double v)
    {
        this.sum_g32_i32_food = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_general_supplies()
    {
        return sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_general_supplies;
    }

    public void setSumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_general_supplies(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c43_c54_oa_expense_dtl_12a_f43_f54_general_supplies = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_general_supplies()
    {
        return sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_general_supplies;
    }

    public void setSumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_general_supplies(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_general_supplies = v;
    }

    public java.lang.String getSumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_general_supplies()
    {
        return sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_general_supplies;
    }

    public void setSumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_general_supplies(java.lang.String v)
    {
        this.sumif_expense_dtl_12a_c43_c54_fr_expense_dtl_12a_f43_f54_general_supplies = v;
    }

    public java.lang.Double getSum_g33_i33_general_supplies()
    {
        return sum_g33_i33_general_supplies;
    }

    public void setSum_g33_i33_general_supplies(java.lang.Double v)
    {
        this.sum_g33_i33_general_supplies = v;
    }

    public java.lang.Double getSumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_0_0()
    {
        return sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_0_0;
    }

    public void setSumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_0_0(java.lang.Double v)
    {
        this.sumif_expense_dtl_12a_c43_c54_ar_expense_dtl_12a_f43_f54_0_0 = v;
    }

    public java.lang.Double getSum_g34_i34_0_0()
    {
        return sum_g34_i34_0_0;
    }

    public void setSum_g34_i34_0_0(java.lang.Double v)
    {
        this.sum_g34_i34_0_0 = v;
    }

    public java.lang.String get_0_0_occupancy_site_charges()
    {
        return _0_0_occupancy_site_charges;
    }

    public void set_0_0_occupancy_site_charges(java.lang.String v)
    {
        this._0_0_occupancy_site_charges = v;
    }

    public java.lang.String getExpense_dtl_12b_i16_occupancy_site_charges()
    {
        return expense_dtl_12b_i16_occupancy_site_charges;
    }

    public void setExpense_dtl_12b_i16_occupancy_site_charges(java.lang.String v)
    {
        this.expense_dtl_12b_i16_occupancy_site_charges = v;
    }

    public java.lang.String get_0_0_occupancy_site_charges_2()
    {
        return _0_0_occupancy_site_charges_2;
    }

    public void set_0_0_occupancy_site_charges_2(java.lang.String v)
    {
        this._0_0_occupancy_site_charges_2 = v;
    }

    public java.lang.Double getSum_g35_i35_occupancy_site_charges()
    {
        return sum_g35_i35_occupancy_site_charges;
    }

    public void setSum_g35_i35_occupancy_site_charges(java.lang.Double v)
    {
        this.sum_g35_i35_occupancy_site_charges = v;
    }

    public java.lang.String get_0_0_postage_shipping_po_box_rental()
    {
        return _0_0_postage_shipping_po_box_rental;
    }

    public void set_0_0_postage_shipping_po_box_rental(java.lang.String v)
    {
        this._0_0_postage_shipping_po_box_rental = v;
    }

    public java.lang.String getExpense_dtl_12b_i16_postage_shipping_po_box_rental()
    {
        return expense_dtl_12b_i16_postage_shipping_po_box_rental;
    }

    public void setExpense_dtl_12b_i16_postage_shipping_po_box_rental(java.lang.String v)
    {
        this.expense_dtl_12b_i16_postage_shipping_po_box_rental = v;
    }

    public java.lang.String get_0_0_postage_shipping_po_box_rental_2()
    {
        return _0_0_postage_shipping_po_box_rental_2;
    }

    public void set_0_0_postage_shipping_po_box_rental_2(java.lang.String v)
    {
        this._0_0_postage_shipping_po_box_rental_2 = v;
    }

    public java.lang.Double getSum_g36_i36_postage_shipping_po_box_rental()
    {
        return sum_g36_i36_postage_shipping_po_box_rental;
    }

    public void setSum_g36_i36_postage_shipping_po_box_rental(java.lang.Double v)
    {
        this.sum_g36_i36_postage_shipping_po_box_rental = v;
    }

    public java.lang.String get_0_0_printing_publications()
    {
        return _0_0_printing_publications;
    }

    public void set_0_0_printing_publications(java.lang.String v)
    {
        this._0_0_printing_publications = v;
    }

    public java.lang.String getExpense_dtl_12b_i16_printing_publications()
    {
        return expense_dtl_12b_i16_printing_publications;
    }

    public void setExpense_dtl_12b_i16_printing_publications(java.lang.String v)
    {
        this.expense_dtl_12b_i16_printing_publications = v;
    }

    public java.lang.String get_0_0_printing_publications_2()
    {
        return _0_0_printing_publications_2;
    }

    public void set_0_0_printing_publications_2(java.lang.String v)
    {
        this._0_0_printing_publications_2 = v;
    }

    public java.lang.Double getSum_g37_i37_printing_publications()
    {
        return sum_g37_i37_printing_publications;
    }

    public void setSum_g37_i37_printing_publications(java.lang.Double v)
    {
        this.sum_g37_i37_printing_publications = v;
    }

    public java.lang.Double getExpense_dtl_12b_i16_0_0()
    {
        return expense_dtl_12b_i16_0_0;
    }

    public void setExpense_dtl_12b_i16_0_0(java.lang.Double v)
    {
        this.expense_dtl_12b_i16_0_0 = v;
    }

    public java.lang.Double getSum_g38_i38_0_0()
    {
        return sum_g38_i38_0_0;
    }

    public void setSum_g38_i38_0_0(java.lang.Double v)
    {
        this.sum_g38_i38_0_0 = v;
    }

    public java.lang.String get_0_0_telephone()
    {
        return _0_0_telephone;
    }

    public void set_0_0_telephone(java.lang.String v)
    {
        this._0_0_telephone = v;
    }

    public java.lang.String getRegalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_telephone()
    {
        return regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_telephone;
    }

    public void setRegalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_telephone(java.lang.String v)
    {
        this.regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_telephone = v;
    }

    public java.lang.String get_0_0_telephone_2()
    {
        return _0_0_telephone_2;
    }

    public void set_0_0_telephone_2(java.lang.String v)
    {
        this._0_0_telephone_2 = v;
    }

    public java.lang.Double getSum_g39_i39_telephone()
    {
        return sum_g39_i39_telephone;
    }

    public void setSum_g39_i39_telephone(java.lang.Double v)
    {
        this.sum_g39_i39_telephone = v;
    }

    public java.lang.String get_0_0_travel_gas_tolls_airfare()
    {
        return _0_0_travel_gas_tolls_airfare;
    }

    public void set_0_0_travel_gas_tolls_airfare(java.lang.String v)
    {
        this._0_0_travel_gas_tolls_airfare = v;
    }

    public java.lang.String getRegalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_travel_gas_tolls_airfare()
    {
        return regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_travel_gas_tolls_airfare;
    }

    public void setRegalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_travel_gas_tolls_airfare(java.lang.String v)
    {
        this.regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_travel_gas_tolls_airfare = v;
    }

    public java.lang.String get_0_0_travel_gas_tolls_airfare_2()
    {
        return _0_0_travel_gas_tolls_airfare_2;
    }

    public void set_0_0_travel_gas_tolls_airfare_2(java.lang.String v)
    {
        this._0_0_travel_gas_tolls_airfare_2 = v;
    }

    public java.lang.Double getSum_g40_i40_travel_gas_tolls_airfare()
    {
        return sum_g40_i40_travel_gas_tolls_airfare;
    }

    public void setSum_g40_i40_travel_gas_tolls_airfare(java.lang.Double v)
    {
        this.sum_g40_i40_travel_gas_tolls_airfare = v;
    }

    public java.lang.Double get_0_0_sub_total_lines_12_26()
    {
        return _0_0_sub_total_lines_12_26;
    }

    public void set_0_0_sub_total_lines_12_26(java.lang.Double v)
    {
        this._0_0_sub_total_lines_12_26 = v;
    }

    public java.lang.Double getRegalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_sum_g27_g41()
    {
        return regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_sum_g27_g41;
    }

    public void setRegalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_sum_g27_g41(java.lang.Double v)
    {
        this.regalia_sales_dtl_7_h52_regalia_sales_dtl_7b_h52_sum_g27_g41 = v;
    }

    public java.lang.Double get_0_0_sum_h27_h41()
    {
        return _0_0_sum_h27_h41;
    }

    public void set_0_0_sum_h27_h41(java.lang.Double v)
    {
        this._0_0_sum_h27_h41 = v;
    }

    public java.lang.Double getSum_g41_i41_sum_i27_i41()
    {
        return sum_g41_i41_sum_i27_i41;
    }

    public void setSum_g41_i41_sum_i27_i41(java.lang.Double v)
    {
        this.sum_g41_i41_sum_i27_i41 = v;
    }

    public java.lang.Double getSum_j27_j41_12b()
    {
        return sum_j27_j41_12b;
    }

    public void setSum_j27_j41_12b(java.lang.Double v)
    {
        this.sum_j27_j41_12b = v;
    }

    public java.lang.Double getExpense_dtl_12b_i27_12b()
    {
        return expense_dtl_12b_i27_12b;
    }

    public void setExpense_dtl_12b_i27_12b(java.lang.Double v)
    {
        this.expense_dtl_12b_i27_12b = v;
    }

    public java.lang.Double getExpense_dtl_12b_i56_10()
    {
        return expense_dtl_12b_i56_10;
    }

    public void setExpense_dtl_12b_i56_10(java.lang.Double v)
    {
        this.expense_dtl_12b_i56_10 = v;
    }

    public java.lang.Double getTransfer_out_10_f25_transfer_out_10b_f28_transfer_out_10c_f28_transfer_out_10d_f28_10()
    {
        return transfer_out_10_f25_transfer_out_10b_f28_transfer_out_10c_f28_transfer_out_10d_f28_10;
    }

    public void setTransfer_out_10_f25_transfer_out_10b_f28_transfer_out_10c_f28_transfer_out_10d_f28_10(java.lang.Double v)
    {
        this.transfer_out_10_f25_transfer_out_10b_f28_transfer_out_10c_f28_transfer_out_10d_f28_10 = v;
    }

    public java.lang.Double getTransfer_out_10_f52_transfer_out_10b_f42_transfer_out_10b_f54_transfer_out_10c_f42_transfer_out_10c_f54_transfer_out_10d_f42_transfer_out_10d_f54_line_27_total_lines_28_to_30b()
    {
        return transfer_out_10_f52_transfer_out_10b_f42_transfer_out_10b_f54_transfer_out_10c_f42_transfer_out_10c_f54_transfer_out_10d_f42_transfer_out_10d_f54_line_27_total_lines_28_to_30b;
    }

    public void setTransfer_out_10_f52_transfer_out_10b_f42_transfer_out_10b_f54_transfer_out_10c_f42_transfer_out_10c_f54_transfer_out_10d_f42_transfer_out_10d_f54_line_27_total_lines_28_to_30b(java.lang.Double v)
    {
        this.transfer_out_10_f52_transfer_out_10b_f42_transfer_out_10b_f54_transfer_out_10c_f42_transfer_out_10c_f54_transfer_out_10d_f42_transfer_out_10d_f54_line_27_total_lines_28_to_30b = v;
    }

    public java.lang.Double getSum_j42_j46_line_11_minus_line_31()
    {
        return sum_j42_j46_line_11_minus_line_31;
    }

    public void setSum_j42_j46_line_11_minus_line_31(java.lang.Double v)
    {
        this.sum_j42_j46_line_11_minus_line_31 = v;
    }

    public java.lang.Double getPrint_exchequer()
    {
        return print_exchequer;
    }

    public void setPrint_exchequer(java.lang.Double v)
    {
        this.print_exchequer = v;
    }

    public java.lang.Double getIf_contents_c_10_contents_c_10_seneschal()
    {
        return if_contents_c_10_contents_c_10_seneschal;
    }

    public void setIf_contents_c_10_contents_c_10_seneschal(java.lang.Double v)
    {
        this.if_contents_c_10_contents_c_10_seneschal = v;
    }

    public INCOME_4Bean()
    {
    }

}
