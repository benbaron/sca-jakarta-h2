package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet EXPENSE_DTL_12a */
public class EXPENSE_DTL_12aBean
{

    private java.lang.Double expense_dtl_12a_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published;
    private java.lang.String expense_dtl_12a_r12c5;
    private java.lang.String amount;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_2;
    private java.lang.String expense_dtl_12a_r13c5;
    private java.lang.String amount_2;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_3;
    private java.lang.String expense_dtl_12a_r14c5;
    private java.lang.String amount_3;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_4;
    private java.lang.String expense_dtl_12a_r15c5;
    private java.lang.String amount_4;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_5;
    private java.lang.String expense_dtl_12a_r16c5;
    private java.lang.String amount_5;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_6;
    private java.lang.String expense_dtl_12a_r17c5;
    private java.lang.String amount_6;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_7;
    private java.lang.String expense_dtl_12a_r18c5;
    private java.lang.String amount_7;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_8;
    private java.lang.String expense_dtl_12a_r19c5;
    private java.lang.String amount_8;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_9;
    private java.lang.String expense_dtl_12a_r20c5;
    private java.lang.String amount_9;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_10;
    private java.lang.String expense_dtl_12a_r21c5;
    private java.lang.String amount_10;
    private java.lang.String organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_11;
    private java.lang.String expense_dtl_12a_r22c5;
    private java.lang.String amount_11;
    private java.lang.Double amount_show_total_on_pg_4_line_12;
    private java.lang.String oa_ar_or_fr;
    private java.lang.String organization_or_person;
    private java.lang.String reason;
    private java.lang.String amount_12;
    private java.lang.String oa_ar_or_fr_2;
    private java.lang.String organization_or_person_2;
    private java.lang.String reason_2;
    private java.lang.String amount_13;
    private java.lang.String oa_ar_or_fr_3;
    private java.lang.String organization_or_person_3;
    private java.lang.String reason_3;
    private java.lang.String amount_14;
    private java.lang.String oa_ar_or_fr_4;
    private java.lang.String organization_or_person_4;
    private java.lang.String reason_4;
    private java.lang.String amount_15;
    private java.lang.String oa_ar_or_fr_5;
    private java.lang.String organization_or_person_5;
    private java.lang.String reason_5;
    private java.lang.String amount_16;
    private java.lang.String oa_ar_or_fr_6;
    private java.lang.String organization_or_person_6;
    private java.lang.String reason_6;
    private java.lang.String amount_17;
    private java.lang.String oa_ar_or_fr_7;
    private java.lang.String organization_or_person_7;
    private java.lang.String reason_7;
    private java.lang.String amount_18;
    private java.lang.String oa_ar_or_fr_8;
    private java.lang.String organization_or_person_8;
    private java.lang.String reason_8;
    private java.lang.String amount_19;
    private java.lang.String oa_ar_or_fr_9;
    private java.lang.String organization_or_person_9;
    private java.lang.String reason_9;
    private java.lang.String amount_20;
    private java.lang.String oa_ar_or_fr_10;
    private java.lang.String organization_or_person_10;
    private java.lang.String reason_10;
    private java.lang.String amount_21;
    private java.lang.String oa_ar_or_fr_11;
    private java.lang.String organization_or_person_11;
    private java.lang.String reason_11;
    private java.lang.String amount_22;
    private java.lang.String oa_ar_or_fr_12;
    private java.lang.String organization_or_person_12;
    private java.lang.String reason_12;
    private java.lang.String amount_23;
    private java.lang.Double amount_show_total_on_pg_4_line_13;
    private java.lang.String oa_ar_or_fr_13;
    private java.lang.String organization_or_person_13;
    private java.lang.String service_provided;
    private java.lang.String amount_24;
    private java.lang.String oa_ar_or_fr_14;
    private java.lang.String organization_or_person_14;
    private java.lang.String service_provided_2;
    private java.lang.String amount_25;
    private java.lang.String oa_ar_or_fr_15;
    private java.lang.String organization_or_person_15;
    private java.lang.String service_provided_3;
    private java.lang.String amount_26;
    private java.lang.String oa_ar_or_fr_16;
    private java.lang.String organization_or_person_16;
    private java.lang.String service_provided_4;
    private java.lang.String amount_27;
    private java.lang.String oa_ar_or_fr_17;
    private java.lang.String organization_or_person_17;
    private java.lang.String service_provided_5;
    private java.lang.String amount_28;
    private java.lang.String oa_ar_or_fr_18;
    private java.lang.String organization_or_person_18;
    private java.lang.String service_provided_6;
    private java.lang.String amount_29;
    private java.lang.String oa_ar_or_fr_19;
    private java.lang.String organization_or_person_19;
    private java.lang.String service_provided_7;
    private java.lang.String amount_30;
    private java.lang.String oa_ar_or_fr_20;
    private java.lang.String organization_or_person_20;
    private java.lang.String service_provided_8;
    private java.lang.String amount_31;
    private java.lang.String oa_ar_or_fr_21;
    private java.lang.String organization_or_person_21;
    private java.lang.String service_provided_9;
    private java.lang.String amount_32;
    private java.lang.String oa_ar_or_fr_22;
    private java.lang.String organization_or_person_22;
    private java.lang.String service_provided_10;
    private java.lang.String amount_33;
    private java.lang.String oa_ar_or_fr_23;
    private java.lang.String organization_or_person_23;
    private java.lang.String service_provided_11;
    private java.lang.String amount_34;
    private java.lang.String oa_ar_or_fr_24;
    private java.lang.String organization_or_person_24;
    private java.lang.String service_provided_12;
    private java.lang.String amount_35;
    private java.lang.Double amount_show_total_on_pg_4_line_17;

    public java.lang.Double getExpense_dtl_12a_r2c3()
    {
        return expense_dtl_12a_r2c3;
    }

    public void setExpense_dtl_12a_r2c3(java.lang.Double v)
    {
        this.expense_dtl_12a_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published = v;
    }

    public java.lang.String getExpense_dtl_12a_r12c5()
    {
        return expense_dtl_12a_r12c5;
    }

    public void setExpense_dtl_12a_r12c5(java.lang.String v)
    {
        this.expense_dtl_12a_r12c5 = v;
    }

    public java.lang.String getAmount()
    {
        return amount;
    }

    public void setAmount(java.lang.String v)
    {
        this.amount = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_2()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_2;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_2(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_2 = v;
    }

    public java.lang.String getExpense_dtl_12a_r13c5()
    {
        return expense_dtl_12a_r13c5;
    }

    public void setExpense_dtl_12a_r13c5(java.lang.String v)
    {
        this.expense_dtl_12a_r13c5 = v;
    }

    public java.lang.String getAmount_2()
    {
        return amount_2;
    }

    public void setAmount_2(java.lang.String v)
    {
        this.amount_2 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_3()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_3;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_3(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_3 = v;
    }

    public java.lang.String getExpense_dtl_12a_r14c5()
    {
        return expense_dtl_12a_r14c5;
    }

    public void setExpense_dtl_12a_r14c5(java.lang.String v)
    {
        this.expense_dtl_12a_r14c5 = v;
    }

    public java.lang.String getAmount_3()
    {
        return amount_3;
    }

    public void setAmount_3(java.lang.String v)
    {
        this.amount_3 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_4()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_4;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_4(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_4 = v;
    }

    public java.lang.String getExpense_dtl_12a_r15c5()
    {
        return expense_dtl_12a_r15c5;
    }

    public void setExpense_dtl_12a_r15c5(java.lang.String v)
    {
        this.expense_dtl_12a_r15c5 = v;
    }

    public java.lang.String getAmount_4()
    {
        return amount_4;
    }

    public void setAmount_4(java.lang.String v)
    {
        this.amount_4 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_5()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_5;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_5(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_5 = v;
    }

    public java.lang.String getExpense_dtl_12a_r16c5()
    {
        return expense_dtl_12a_r16c5;
    }

    public void setExpense_dtl_12a_r16c5(java.lang.String v)
    {
        this.expense_dtl_12a_r16c5 = v;
    }

    public java.lang.String getAmount_5()
    {
        return amount_5;
    }

    public void setAmount_5(java.lang.String v)
    {
        this.amount_5 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_6()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_6;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_6(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_6 = v;
    }

    public java.lang.String getExpense_dtl_12a_r17c5()
    {
        return expense_dtl_12a_r17c5;
    }

    public void setExpense_dtl_12a_r17c5(java.lang.String v)
    {
        this.expense_dtl_12a_r17c5 = v;
    }

    public java.lang.String getAmount_6()
    {
        return amount_6;
    }

    public void setAmount_6(java.lang.String v)
    {
        this.amount_6 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_7()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_7;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_7(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_7 = v;
    }

    public java.lang.String getExpense_dtl_12a_r18c5()
    {
        return expense_dtl_12a_r18c5;
    }

    public void setExpense_dtl_12a_r18c5(java.lang.String v)
    {
        this.expense_dtl_12a_r18c5 = v;
    }

    public java.lang.String getAmount_7()
    {
        return amount_7;
    }

    public void setAmount_7(java.lang.String v)
    {
        this.amount_7 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_8()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_8;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_8(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_8 = v;
    }

    public java.lang.String getExpense_dtl_12a_r19c5()
    {
        return expense_dtl_12a_r19c5;
    }

    public void setExpense_dtl_12a_r19c5(java.lang.String v)
    {
        this.expense_dtl_12a_r19c5 = v;
    }

    public java.lang.String getAmount_8()
    {
        return amount_8;
    }

    public void setAmount_8(java.lang.String v)
    {
        this.amount_8 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_9()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_9;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_9(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_9 = v;
    }

    public java.lang.String getExpense_dtl_12a_r20c5()
    {
        return expense_dtl_12a_r20c5;
    }

    public void setExpense_dtl_12a_r20c5(java.lang.String v)
    {
        this.expense_dtl_12a_r20c5 = v;
    }

    public java.lang.String getAmount_9()
    {
        return amount_9;
    }

    public void setAmount_9(java.lang.String v)
    {
        this.amount_9 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_10()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_10;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_10(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_10 = v;
    }

    public java.lang.String getExpense_dtl_12a_r21c5()
    {
        return expense_dtl_12a_r21c5;
    }

    public void setExpense_dtl_12a_r21c5(java.lang.String v)
    {
        this.expense_dtl_12a_r21c5 = v;
    }

    public java.lang.String getAmount_10()
    {
        return amount_10;
    }

    public void setAmount_10(java.lang.String v)
    {
        this.amount_10 = v;
    }

    public java.lang.String getOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_11()
    {
        return organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_11;
    }

    public void setOrganization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_11(java.lang.String v)
    {
        this.organization_or_periodical_not_a_kingdom_newsletter_and_date_ad_was_published_11 = v;
    }

    public java.lang.String getExpense_dtl_12a_r22c5()
    {
        return expense_dtl_12a_r22c5;
    }

    public void setExpense_dtl_12a_r22c5(java.lang.String v)
    {
        this.expense_dtl_12a_r22c5 = v;
    }

    public java.lang.String getAmount_11()
    {
        return amount_11;
    }

    public void setAmount_11(java.lang.String v)
    {
        this.amount_11 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_12()
    {
        return amount_show_total_on_pg_4_line_12;
    }

    public void setAmount_show_total_on_pg_4_line_12(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_12 = v;
    }

    public java.lang.String getOa_ar_or_fr()
    {
        return oa_ar_or_fr;
    }

    public void setOa_ar_or_fr(java.lang.String v)
    {
        this.oa_ar_or_fr = v;
    }

    public java.lang.String getOrganization_or_person()
    {
        return organization_or_person;
    }

    public void setOrganization_or_person(java.lang.String v)
    {
        this.organization_or_person = v;
    }

    public java.lang.String getReason()
    {
        return reason;
    }

    public void setReason(java.lang.String v)
    {
        this.reason = v;
    }

    public java.lang.String getAmount_12()
    {
        return amount_12;
    }

    public void setAmount_12(java.lang.String v)
    {
        this.amount_12 = v;
    }

    public java.lang.String getOa_ar_or_fr_2()
    {
        return oa_ar_or_fr_2;
    }

    public void setOa_ar_or_fr_2(java.lang.String v)
    {
        this.oa_ar_or_fr_2 = v;
    }

    public java.lang.String getOrganization_or_person_2()
    {
        return organization_or_person_2;
    }

    public void setOrganization_or_person_2(java.lang.String v)
    {
        this.organization_or_person_2 = v;
    }

    public java.lang.String getReason_2()
    {
        return reason_2;
    }

    public void setReason_2(java.lang.String v)
    {
        this.reason_2 = v;
    }

    public java.lang.String getAmount_13()
    {
        return amount_13;
    }

    public void setAmount_13(java.lang.String v)
    {
        this.amount_13 = v;
    }

    public java.lang.String getOa_ar_or_fr_3()
    {
        return oa_ar_or_fr_3;
    }

    public void setOa_ar_or_fr_3(java.lang.String v)
    {
        this.oa_ar_or_fr_3 = v;
    }

    public java.lang.String getOrganization_or_person_3()
    {
        return organization_or_person_3;
    }

    public void setOrganization_or_person_3(java.lang.String v)
    {
        this.organization_or_person_3 = v;
    }

    public java.lang.String getReason_3()
    {
        return reason_3;
    }

    public void setReason_3(java.lang.String v)
    {
        this.reason_3 = v;
    }

    public java.lang.String getAmount_14()
    {
        return amount_14;
    }

    public void setAmount_14(java.lang.String v)
    {
        this.amount_14 = v;
    }

    public java.lang.String getOa_ar_or_fr_4()
    {
        return oa_ar_or_fr_4;
    }

    public void setOa_ar_or_fr_4(java.lang.String v)
    {
        this.oa_ar_or_fr_4 = v;
    }

    public java.lang.String getOrganization_or_person_4()
    {
        return organization_or_person_4;
    }

    public void setOrganization_or_person_4(java.lang.String v)
    {
        this.organization_or_person_4 = v;
    }

    public java.lang.String getReason_4()
    {
        return reason_4;
    }

    public void setReason_4(java.lang.String v)
    {
        this.reason_4 = v;
    }

    public java.lang.String getAmount_15()
    {
        return amount_15;
    }

    public void setAmount_15(java.lang.String v)
    {
        this.amount_15 = v;
    }

    public java.lang.String getOa_ar_or_fr_5()
    {
        return oa_ar_or_fr_5;
    }

    public void setOa_ar_or_fr_5(java.lang.String v)
    {
        this.oa_ar_or_fr_5 = v;
    }

    public java.lang.String getOrganization_or_person_5()
    {
        return organization_or_person_5;
    }

    public void setOrganization_or_person_5(java.lang.String v)
    {
        this.organization_or_person_5 = v;
    }

    public java.lang.String getReason_5()
    {
        return reason_5;
    }

    public void setReason_5(java.lang.String v)
    {
        this.reason_5 = v;
    }

    public java.lang.String getAmount_16()
    {
        return amount_16;
    }

    public void setAmount_16(java.lang.String v)
    {
        this.amount_16 = v;
    }

    public java.lang.String getOa_ar_or_fr_6()
    {
        return oa_ar_or_fr_6;
    }

    public void setOa_ar_or_fr_6(java.lang.String v)
    {
        this.oa_ar_or_fr_6 = v;
    }

    public java.lang.String getOrganization_or_person_6()
    {
        return organization_or_person_6;
    }

    public void setOrganization_or_person_6(java.lang.String v)
    {
        this.organization_or_person_6 = v;
    }

    public java.lang.String getReason_6()
    {
        return reason_6;
    }

    public void setReason_6(java.lang.String v)
    {
        this.reason_6 = v;
    }

    public java.lang.String getAmount_17()
    {
        return amount_17;
    }

    public void setAmount_17(java.lang.String v)
    {
        this.amount_17 = v;
    }

    public java.lang.String getOa_ar_or_fr_7()
    {
        return oa_ar_or_fr_7;
    }

    public void setOa_ar_or_fr_7(java.lang.String v)
    {
        this.oa_ar_or_fr_7 = v;
    }

    public java.lang.String getOrganization_or_person_7()
    {
        return organization_or_person_7;
    }

    public void setOrganization_or_person_7(java.lang.String v)
    {
        this.organization_or_person_7 = v;
    }

    public java.lang.String getReason_7()
    {
        return reason_7;
    }

    public void setReason_7(java.lang.String v)
    {
        this.reason_7 = v;
    }

    public java.lang.String getAmount_18()
    {
        return amount_18;
    }

    public void setAmount_18(java.lang.String v)
    {
        this.amount_18 = v;
    }

    public java.lang.String getOa_ar_or_fr_8()
    {
        return oa_ar_or_fr_8;
    }

    public void setOa_ar_or_fr_8(java.lang.String v)
    {
        this.oa_ar_or_fr_8 = v;
    }

    public java.lang.String getOrganization_or_person_8()
    {
        return organization_or_person_8;
    }

    public void setOrganization_or_person_8(java.lang.String v)
    {
        this.organization_or_person_8 = v;
    }

    public java.lang.String getReason_8()
    {
        return reason_8;
    }

    public void setReason_8(java.lang.String v)
    {
        this.reason_8 = v;
    }

    public java.lang.String getAmount_19()
    {
        return amount_19;
    }

    public void setAmount_19(java.lang.String v)
    {
        this.amount_19 = v;
    }

    public java.lang.String getOa_ar_or_fr_9()
    {
        return oa_ar_or_fr_9;
    }

    public void setOa_ar_or_fr_9(java.lang.String v)
    {
        this.oa_ar_or_fr_9 = v;
    }

    public java.lang.String getOrganization_or_person_9()
    {
        return organization_or_person_9;
    }

    public void setOrganization_or_person_9(java.lang.String v)
    {
        this.organization_or_person_9 = v;
    }

    public java.lang.String getReason_9()
    {
        return reason_9;
    }

    public void setReason_9(java.lang.String v)
    {
        this.reason_9 = v;
    }

    public java.lang.String getAmount_20()
    {
        return amount_20;
    }

    public void setAmount_20(java.lang.String v)
    {
        this.amount_20 = v;
    }

    public java.lang.String getOa_ar_or_fr_10()
    {
        return oa_ar_or_fr_10;
    }

    public void setOa_ar_or_fr_10(java.lang.String v)
    {
        this.oa_ar_or_fr_10 = v;
    }

    public java.lang.String getOrganization_or_person_10()
    {
        return organization_or_person_10;
    }

    public void setOrganization_or_person_10(java.lang.String v)
    {
        this.organization_or_person_10 = v;
    }

    public java.lang.String getReason_10()
    {
        return reason_10;
    }

    public void setReason_10(java.lang.String v)
    {
        this.reason_10 = v;
    }

    public java.lang.String getAmount_21()
    {
        return amount_21;
    }

    public void setAmount_21(java.lang.String v)
    {
        this.amount_21 = v;
    }

    public java.lang.String getOa_ar_or_fr_11()
    {
        return oa_ar_or_fr_11;
    }

    public void setOa_ar_or_fr_11(java.lang.String v)
    {
        this.oa_ar_or_fr_11 = v;
    }

    public java.lang.String getOrganization_or_person_11()
    {
        return organization_or_person_11;
    }

    public void setOrganization_or_person_11(java.lang.String v)
    {
        this.organization_or_person_11 = v;
    }

    public java.lang.String getReason_11()
    {
        return reason_11;
    }

    public void setReason_11(java.lang.String v)
    {
        this.reason_11 = v;
    }

    public java.lang.String getAmount_22()
    {
        return amount_22;
    }

    public void setAmount_22(java.lang.String v)
    {
        this.amount_22 = v;
    }

    public java.lang.String getOa_ar_or_fr_12()
    {
        return oa_ar_or_fr_12;
    }

    public void setOa_ar_or_fr_12(java.lang.String v)
    {
        this.oa_ar_or_fr_12 = v;
    }

    public java.lang.String getOrganization_or_person_12()
    {
        return organization_or_person_12;
    }

    public void setOrganization_or_person_12(java.lang.String v)
    {
        this.organization_or_person_12 = v;
    }

    public java.lang.String getReason_12()
    {
        return reason_12;
    }

    public void setReason_12(java.lang.String v)
    {
        this.reason_12 = v;
    }

    public java.lang.String getAmount_23()
    {
        return amount_23;
    }

    public void setAmount_23(java.lang.String v)
    {
        this.amount_23 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_13()
    {
        return amount_show_total_on_pg_4_line_13;
    }

    public void setAmount_show_total_on_pg_4_line_13(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_13 = v;
    }

    public java.lang.String getOa_ar_or_fr_13()
    {
        return oa_ar_or_fr_13;
    }

    public void setOa_ar_or_fr_13(java.lang.String v)
    {
        this.oa_ar_or_fr_13 = v;
    }

    public java.lang.String getOrganization_or_person_13()
    {
        return organization_or_person_13;
    }

    public void setOrganization_or_person_13(java.lang.String v)
    {
        this.organization_or_person_13 = v;
    }

    public java.lang.String getService_provided()
    {
        return service_provided;
    }

    public void setService_provided(java.lang.String v)
    {
        this.service_provided = v;
    }

    public java.lang.String getAmount_24()
    {
        return amount_24;
    }

    public void setAmount_24(java.lang.String v)
    {
        this.amount_24 = v;
    }

    public java.lang.String getOa_ar_or_fr_14()
    {
        return oa_ar_or_fr_14;
    }

    public void setOa_ar_or_fr_14(java.lang.String v)
    {
        this.oa_ar_or_fr_14 = v;
    }

    public java.lang.String getOrganization_or_person_14()
    {
        return organization_or_person_14;
    }

    public void setOrganization_or_person_14(java.lang.String v)
    {
        this.organization_or_person_14 = v;
    }

    public java.lang.String getService_provided_2()
    {
        return service_provided_2;
    }

    public void setService_provided_2(java.lang.String v)
    {
        this.service_provided_2 = v;
    }

    public java.lang.String getAmount_25()
    {
        return amount_25;
    }

    public void setAmount_25(java.lang.String v)
    {
        this.amount_25 = v;
    }

    public java.lang.String getOa_ar_or_fr_15()
    {
        return oa_ar_or_fr_15;
    }

    public void setOa_ar_or_fr_15(java.lang.String v)
    {
        this.oa_ar_or_fr_15 = v;
    }

    public java.lang.String getOrganization_or_person_15()
    {
        return organization_or_person_15;
    }

    public void setOrganization_or_person_15(java.lang.String v)
    {
        this.organization_or_person_15 = v;
    }

    public java.lang.String getService_provided_3()
    {
        return service_provided_3;
    }

    public void setService_provided_3(java.lang.String v)
    {
        this.service_provided_3 = v;
    }

    public java.lang.String getAmount_26()
    {
        return amount_26;
    }

    public void setAmount_26(java.lang.String v)
    {
        this.amount_26 = v;
    }

    public java.lang.String getOa_ar_or_fr_16()
    {
        return oa_ar_or_fr_16;
    }

    public void setOa_ar_or_fr_16(java.lang.String v)
    {
        this.oa_ar_or_fr_16 = v;
    }

    public java.lang.String getOrganization_or_person_16()
    {
        return organization_or_person_16;
    }

    public void setOrganization_or_person_16(java.lang.String v)
    {
        this.organization_or_person_16 = v;
    }

    public java.lang.String getService_provided_4()
    {
        return service_provided_4;
    }

    public void setService_provided_4(java.lang.String v)
    {
        this.service_provided_4 = v;
    }

    public java.lang.String getAmount_27()
    {
        return amount_27;
    }

    public void setAmount_27(java.lang.String v)
    {
        this.amount_27 = v;
    }

    public java.lang.String getOa_ar_or_fr_17()
    {
        return oa_ar_or_fr_17;
    }

    public void setOa_ar_or_fr_17(java.lang.String v)
    {
        this.oa_ar_or_fr_17 = v;
    }

    public java.lang.String getOrganization_or_person_17()
    {
        return organization_or_person_17;
    }

    public void setOrganization_or_person_17(java.lang.String v)
    {
        this.organization_or_person_17 = v;
    }

    public java.lang.String getService_provided_5()
    {
        return service_provided_5;
    }

    public void setService_provided_5(java.lang.String v)
    {
        this.service_provided_5 = v;
    }

    public java.lang.String getAmount_28()
    {
        return amount_28;
    }

    public void setAmount_28(java.lang.String v)
    {
        this.amount_28 = v;
    }

    public java.lang.String getOa_ar_or_fr_18()
    {
        return oa_ar_or_fr_18;
    }

    public void setOa_ar_or_fr_18(java.lang.String v)
    {
        this.oa_ar_or_fr_18 = v;
    }

    public java.lang.String getOrganization_or_person_18()
    {
        return organization_or_person_18;
    }

    public void setOrganization_or_person_18(java.lang.String v)
    {
        this.organization_or_person_18 = v;
    }

    public java.lang.String getService_provided_6()
    {
        return service_provided_6;
    }

    public void setService_provided_6(java.lang.String v)
    {
        this.service_provided_6 = v;
    }

    public java.lang.String getAmount_29()
    {
        return amount_29;
    }

    public void setAmount_29(java.lang.String v)
    {
        this.amount_29 = v;
    }

    public java.lang.String getOa_ar_or_fr_19()
    {
        return oa_ar_or_fr_19;
    }

    public void setOa_ar_or_fr_19(java.lang.String v)
    {
        this.oa_ar_or_fr_19 = v;
    }

    public java.lang.String getOrganization_or_person_19()
    {
        return organization_or_person_19;
    }

    public void setOrganization_or_person_19(java.lang.String v)
    {
        this.organization_or_person_19 = v;
    }

    public java.lang.String getService_provided_7()
    {
        return service_provided_7;
    }

    public void setService_provided_7(java.lang.String v)
    {
        this.service_provided_7 = v;
    }

    public java.lang.String getAmount_30()
    {
        return amount_30;
    }

    public void setAmount_30(java.lang.String v)
    {
        this.amount_30 = v;
    }

    public java.lang.String getOa_ar_or_fr_20()
    {
        return oa_ar_or_fr_20;
    }

    public void setOa_ar_or_fr_20(java.lang.String v)
    {
        this.oa_ar_or_fr_20 = v;
    }

    public java.lang.String getOrganization_or_person_20()
    {
        return organization_or_person_20;
    }

    public void setOrganization_or_person_20(java.lang.String v)
    {
        this.organization_or_person_20 = v;
    }

    public java.lang.String getService_provided_8()
    {
        return service_provided_8;
    }

    public void setService_provided_8(java.lang.String v)
    {
        this.service_provided_8 = v;
    }

    public java.lang.String getAmount_31()
    {
        return amount_31;
    }

    public void setAmount_31(java.lang.String v)
    {
        this.amount_31 = v;
    }

    public java.lang.String getOa_ar_or_fr_21()
    {
        return oa_ar_or_fr_21;
    }

    public void setOa_ar_or_fr_21(java.lang.String v)
    {
        this.oa_ar_or_fr_21 = v;
    }

    public java.lang.String getOrganization_or_person_21()
    {
        return organization_or_person_21;
    }

    public void setOrganization_or_person_21(java.lang.String v)
    {
        this.organization_or_person_21 = v;
    }

    public java.lang.String getService_provided_9()
    {
        return service_provided_9;
    }

    public void setService_provided_9(java.lang.String v)
    {
        this.service_provided_9 = v;
    }

    public java.lang.String getAmount_32()
    {
        return amount_32;
    }

    public void setAmount_32(java.lang.String v)
    {
        this.amount_32 = v;
    }

    public java.lang.String getOa_ar_or_fr_22()
    {
        return oa_ar_or_fr_22;
    }

    public void setOa_ar_or_fr_22(java.lang.String v)
    {
        this.oa_ar_or_fr_22 = v;
    }

    public java.lang.String getOrganization_or_person_22()
    {
        return organization_or_person_22;
    }

    public void setOrganization_or_person_22(java.lang.String v)
    {
        this.organization_or_person_22 = v;
    }

    public java.lang.String getService_provided_10()
    {
        return service_provided_10;
    }

    public void setService_provided_10(java.lang.String v)
    {
        this.service_provided_10 = v;
    }

    public java.lang.String getAmount_33()
    {
        return amount_33;
    }

    public void setAmount_33(java.lang.String v)
    {
        this.amount_33 = v;
    }

    public java.lang.String getOa_ar_or_fr_23()
    {
        return oa_ar_or_fr_23;
    }

    public void setOa_ar_or_fr_23(java.lang.String v)
    {
        this.oa_ar_or_fr_23 = v;
    }

    public java.lang.String getOrganization_or_person_23()
    {
        return organization_or_person_23;
    }

    public void setOrganization_or_person_23(java.lang.String v)
    {
        this.organization_or_person_23 = v;
    }

    public java.lang.String getService_provided_11()
    {
        return service_provided_11;
    }

    public void setService_provided_11(java.lang.String v)
    {
        this.service_provided_11 = v;
    }

    public java.lang.String getAmount_34()
    {
        return amount_34;
    }

    public void setAmount_34(java.lang.String v)
    {
        this.amount_34 = v;
    }

    public java.lang.String getOa_ar_or_fr_24()
    {
        return oa_ar_or_fr_24;
    }

    public void setOa_ar_or_fr_24(java.lang.String v)
    {
        this.oa_ar_or_fr_24 = v;
    }

    public java.lang.String getOrganization_or_person_24()
    {
        return organization_or_person_24;
    }

    public void setOrganization_or_person_24(java.lang.String v)
    {
        this.organization_or_person_24 = v;
    }

    public java.lang.String getService_provided_12()
    {
        return service_provided_12;
    }

    public void setService_provided_12(java.lang.String v)
    {
        this.service_provided_12 = v;
    }

    public java.lang.String getAmount_35()
    {
        return amount_35;
    }

    public void setAmount_35(java.lang.String v)
    {
        this.amount_35 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_17()
    {
        return amount_show_total_on_pg_4_line_17;
    }

    public void setAmount_show_total_on_pg_4_line_17(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_17 = v;
    }

    public EXPENSE_DTL_12aBean()
    {
    }

}
