package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet REGALIA_SALES_DTL_7 */
public class REGALIA_SALES_DTL_7Bean
{

    private java.lang.Double regalia_sales_dtl_7_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String regalia_other_sales_detail;
    private java.lang.String regalia_non_depreciated_equipment_this_section_will_be_going_away;
    private java.lang.String regalia_non_depreciated_equipment_this_section_will_be_going_away_2;
    private java.lang.String regalia_non_depreciated_equipment_this_section_will_be_going_away_3;
    private java.lang.String regalia_non_depreciated_equipment_this_section_will_be_going_away_4;
    private java.lang.String regalia_non_depreciated_equipment_this_section_will_be_going_away_5;
    private java.lang.String regalia_non_depreciated_equipment_this_section_will_be_going_away_6;
    private java.lang.String regalia_non_depreciated_equipment_this_section_will_be_going_away_7;
    private java.lang.String do_not_enter_any_more_items_under_regalia;
    private java.lang.String do_not_enter_any_more_items_under_regalia_2;
    private java.lang.String do_not_enter_any_more_items_under_regalia_3;
    private java.lang.String do_not_enter_any_more_items_under_regalia_4;
    private java.lang.String do_not_enter_any_more_items_under_regalia_5;
    private java.lang.String do_not_enter_any_more_items_under_regalia_6;
    private java.lang.String do_not_enter_any_more_items_under_regalia_7;
    private java.lang.String any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section;
    private java.lang.String any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_2;
    private java.lang.String any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_3;
    private java.lang.String any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_4;
    private java.lang.String any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_5;
    private java.lang.String any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_6;
    private java.lang.String any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_7;
    private java.lang.String if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be;
    private java.lang.String if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_2;
    private java.lang.String if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_3;
    private java.lang.String if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_4;
    private java.lang.String if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_5;
    private java.lang.String if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_6;
    private java.lang.String if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_7;
    private java.lang.String depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s;
    private java.lang.String depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_2;
    private java.lang.String depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_3;
    private java.lang.String depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_4;
    private java.lang.String depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_5;
    private java.lang.String depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_6;
    private java.lang.String depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_7;
    private java.lang.String property_list;
    private java.lang.String property_list_2;
    private java.lang.String property_list_3;
    private java.lang.String property_list_4;
    private java.lang.String property_list_5;
    private java.lang.String property_list_6;
    private java.lang.String item_description;
    private java.lang.String qty;
    private java.lang.String year_acquired;
    private java.lang.String a_start_prior_value;
    private java.lang.String b_value_of_new_item;
    private java.lang.String c_value_adjustment;
    private java.lang.Double a_or_b_c_end_value;
    private java.lang.String item_description_2;
    private java.lang.String qty_2;
    private java.lang.String year_acquired_2;
    private java.lang.String a_start_prior_value_2;
    private java.lang.String b_value_of_new_item_2;
    private java.lang.String c_value_adjustment_2;
    private java.lang.Double if_f20_0_f20_g20_h20;
    private java.lang.String item_description_3;
    private java.lang.String qty_3;
    private java.lang.String year_acquired_3;
    private java.lang.String a_start_prior_value_3;
    private java.lang.String b_value_of_new_item_3;
    private java.lang.String c_value_adjustment_3;
    private java.lang.Double if_f21_0_f21_g21_h21;
    private java.lang.String item_description_4;
    private java.lang.String qty_4;
    private java.lang.String year_acquired_4;
    private java.lang.String a_start_prior_value_4;
    private java.lang.String b_value_of_new_item_4;
    private java.lang.String c_value_adjustment_4;
    private java.lang.Double if_f22_0_f22_g22_h22;
    private java.lang.String item_description_5;
    private java.lang.String qty_5;
    private java.lang.String year_acquired_5;
    private java.lang.String a_start_prior_value_5;
    private java.lang.String b_value_of_new_item_5;
    private java.lang.String c_value_adjustment_5;
    private java.lang.Double if_f23_0_f23_g23_h23;
    private java.lang.String item_description_6;
    private java.lang.String qty_6;
    private java.lang.String year_acquired_6;
    private java.lang.String a_start_prior_value_6;
    private java.lang.String b_value_of_new_item_6;
    private java.lang.String c_value_adjustment_6;
    private java.lang.Double if_f24_0_f24_g24_h24;
    private java.lang.String item_description_7;
    private java.lang.String qty_7;
    private java.lang.String year_acquired_7;
    private java.lang.String a_start_prior_value_7;
    private java.lang.String b_value_of_new_item_7;
    private java.lang.String c_value_adjustment_7;
    private java.lang.Double if_f25_0_f25_g25_h25;
    private java.lang.String item_description_8;
    private java.lang.String qty_8;
    private java.lang.String year_acquired_8;
    private java.lang.String a_start_prior_value_8;
    private java.lang.String b_value_of_new_item_8;
    private java.lang.String c_value_adjustment_8;
    private java.lang.Double if_f26_0_f26_g26_h26;
    private java.lang.String item_description_9;
    private java.lang.String qty_9;
    private java.lang.String year_acquired_9;
    private java.lang.String a_start_prior_value_9;
    private java.lang.String b_value_of_new_item_9;
    private java.lang.String c_value_adjustment_9;
    private java.lang.Double if_f27_0_f27_g27_h27;
    private java.lang.String item_description_10;
    private java.lang.String qty_10;
    private java.lang.String year_acquired_10;
    private java.lang.String a_start_prior_value_10;
    private java.lang.String b_value_of_new_item_10;
    private java.lang.String c_value_adjustment_10;
    private java.lang.Double if_f28_0_f28_g28_h28;
    private java.lang.String item_description_11;
    private java.lang.String qty_11;
    private java.lang.String year_acquired_11;
    private java.lang.String a_start_prior_value_11;
    private java.lang.String b_value_of_new_item_11;
    private java.lang.String c_value_adjustment_11;
    private java.lang.Double if_f29_0_f29_g29_h29;
    private java.lang.String item_description_12;
    private java.lang.String qty_12;
    private java.lang.String year_acquired_12;
    private java.lang.String a_start_prior_value_12;
    private java.lang.String b_value_of_new_item_12;
    private java.lang.String c_value_adjustment_12;
    private java.lang.Double if_f30_0_f30_g30_h30;
    private java.lang.Double a_start_prior_value_total;
    private java.lang.Double c_value_adjustment_sum_f20_f31;
    private java.lang.Double if_f31_0_f31_g31_h31_sumif_h20_h31_0_h20_h31;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased;
    private java.lang.String qty_13;
    private java.lang.String show_on;
    private java.lang.String pg_3_i_e_start;
    private java.lang.String b_value_of_new_item_13;
    private java.lang.String number_sold;
    private java.lang.String income_from_sale;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_2;
    private java.lang.String qty_14;
    private java.lang.String show_on_2;
    private java.lang.String pg_3_i_e_start_2;
    private java.lang.String b_value_of_new_item_14;
    private java.lang.String number_sold_2;
    private java.lang.String income_from_sale_2;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_3;
    private java.lang.String qty_15;
    private java.lang.String show_on_3;
    private java.lang.String pg_3_i_e_start_3;
    private java.lang.String b_value_of_new_item_15;
    private java.lang.String number_sold_3;
    private java.lang.String income_from_sale_3;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_4;
    private java.lang.String qty_16;
    private java.lang.String show_on_4;
    private java.lang.String pg_3_i_e_start_4;
    private java.lang.String b_value_of_new_item_16;
    private java.lang.String number_sold_4;
    private java.lang.String income_from_sale_4;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_5;
    private java.lang.String qty_17;
    private java.lang.String show_on_5;
    private java.lang.String pg_3_i_e_start_5;
    private java.lang.String b_value_of_new_item_17;
    private java.lang.String number_sold_5;
    private java.lang.String income_from_sale_5;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_6;
    private java.lang.String qty_18;
    private java.lang.String show_on_6;
    private java.lang.String pg_3_i_e_start_6;
    private java.lang.String b_value_of_new_item_18;
    private java.lang.String number_sold_6;
    private java.lang.String income_from_sale_6;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_7;
    private java.lang.String qty_19;
    private java.lang.String show_on_7;
    private java.lang.String pg_3_i_e_start_7;
    private java.lang.String b_value_of_new_item_19;
    private java.lang.String number_sold_7;
    private java.lang.String income_from_sale_7;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_8;
    private java.lang.String qty_20;
    private java.lang.String show_on_8;
    private java.lang.String pg_3_i_e_start_8;
    private java.lang.String b_value_of_new_item_20;
    private java.lang.String number_sold_8;
    private java.lang.String income_from_sale_8;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_9;
    private java.lang.String qty_21;
    private java.lang.String show_on_9;
    private java.lang.String pg_3_i_e_start_9;
    private java.lang.String b_value_of_new_item_21;
    private java.lang.String number_sold_9;
    private java.lang.String income_from_sale_9;
    private java.lang.String _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_10;
    private java.lang.String qty_22;
    private java.lang.String show_on_10;
    private java.lang.String pg_3_i_e_start_10;
    private java.lang.String b_value_of_new_item_22;
    private java.lang.String number_sold_10;
    private java.lang.String income_from_sale_10;
    private java.lang.Double income_from_sale_total_1;
    private java.lang.String _2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report;
    private java.lang.String qty_23;
    private java.lang.String year_acquired_13;
    private java.lang.String a_start_prior_value_from_pg_7_or_8;
    private java.lang.String b_start_accum_depr_if_from_pg_8;
    private java.lang.Double a_b_value_lost;
    private java.lang.String income_from_sale_if_any_f49_g49;
    private java.lang.String _2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_2;
    private java.lang.String qty_24;
    private java.lang.String year_acquired_14;
    private java.lang.String a_start_prior_value_from_pg_7_or_8_2;
    private java.lang.String b_start_accum_depr_if_from_pg_8_2;
    private java.lang.Double f49_g49;
    private java.lang.String income_from_sale_if_any_f50_g50;
    private java.lang.String _2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_3;
    private java.lang.String qty_25;
    private java.lang.String year_acquired_15;
    private java.lang.String a_start_prior_value_from_pg_7_or_8_3;
    private java.lang.String b_start_accum_depr_if_from_pg_8_3;
    private java.lang.Double f50_g50;
    private java.lang.String income_from_sale_if_any_f51_g51;
    private java.lang.Double f51_g51_total_2;
    private java.lang.Double income_from_sale_if_any_sum_h49_h51;
    private java.lang.Double sum_i49_i51_total_1_2;

    public java.lang.Double getRegalia_sales_dtl_7_r2c3()
    {
        return regalia_sales_dtl_7_r2c3;
    }

    public void setRegalia_sales_dtl_7_r2c3(java.lang.Double v)
    {
        this.regalia_sales_dtl_7_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getRegalia_other_sales_detail()
    {
        return regalia_other_sales_detail;
    }

    public void setRegalia_other_sales_detail(java.lang.String v)
    {
        this.regalia_other_sales_detail = v;
    }

    public java.lang.String getRegalia_non_depreciated_equipment_this_section_will_be_going_away()
    {
        return regalia_non_depreciated_equipment_this_section_will_be_going_away;
    }

    public void setRegalia_non_depreciated_equipment_this_section_will_be_going_away(java.lang.String v)
    {
        this.regalia_non_depreciated_equipment_this_section_will_be_going_away = v;
    }

    public java.lang.String getRegalia_non_depreciated_equipment_this_section_will_be_going_away_2()
    {
        return regalia_non_depreciated_equipment_this_section_will_be_going_away_2;
    }

    public void setRegalia_non_depreciated_equipment_this_section_will_be_going_away_2(java.lang.String v)
    {
        this.regalia_non_depreciated_equipment_this_section_will_be_going_away_2 = v;
    }

    public java.lang.String getRegalia_non_depreciated_equipment_this_section_will_be_going_away_3()
    {
        return regalia_non_depreciated_equipment_this_section_will_be_going_away_3;
    }

    public void setRegalia_non_depreciated_equipment_this_section_will_be_going_away_3(java.lang.String v)
    {
        this.regalia_non_depreciated_equipment_this_section_will_be_going_away_3 = v;
    }

    public java.lang.String getRegalia_non_depreciated_equipment_this_section_will_be_going_away_4()
    {
        return regalia_non_depreciated_equipment_this_section_will_be_going_away_4;
    }

    public void setRegalia_non_depreciated_equipment_this_section_will_be_going_away_4(java.lang.String v)
    {
        this.regalia_non_depreciated_equipment_this_section_will_be_going_away_4 = v;
    }

    public java.lang.String getRegalia_non_depreciated_equipment_this_section_will_be_going_away_5()
    {
        return regalia_non_depreciated_equipment_this_section_will_be_going_away_5;
    }

    public void setRegalia_non_depreciated_equipment_this_section_will_be_going_away_5(java.lang.String v)
    {
        this.regalia_non_depreciated_equipment_this_section_will_be_going_away_5 = v;
    }

    public java.lang.String getRegalia_non_depreciated_equipment_this_section_will_be_going_away_6()
    {
        return regalia_non_depreciated_equipment_this_section_will_be_going_away_6;
    }

    public void setRegalia_non_depreciated_equipment_this_section_will_be_going_away_6(java.lang.String v)
    {
        this.regalia_non_depreciated_equipment_this_section_will_be_going_away_6 = v;
    }

    public java.lang.String getRegalia_non_depreciated_equipment_this_section_will_be_going_away_7()
    {
        return regalia_non_depreciated_equipment_this_section_will_be_going_away_7;
    }

    public void setRegalia_non_depreciated_equipment_this_section_will_be_going_away_7(java.lang.String v)
    {
        this.regalia_non_depreciated_equipment_this_section_will_be_going_away_7 = v;
    }

    public java.lang.String getDo_not_enter_any_more_items_under_regalia()
    {
        return do_not_enter_any_more_items_under_regalia;
    }

    public void setDo_not_enter_any_more_items_under_regalia(java.lang.String v)
    {
        this.do_not_enter_any_more_items_under_regalia = v;
    }

    public java.lang.String getDo_not_enter_any_more_items_under_regalia_2()
    {
        return do_not_enter_any_more_items_under_regalia_2;
    }

    public void setDo_not_enter_any_more_items_under_regalia_2(java.lang.String v)
    {
        this.do_not_enter_any_more_items_under_regalia_2 = v;
    }

    public java.lang.String getDo_not_enter_any_more_items_under_regalia_3()
    {
        return do_not_enter_any_more_items_under_regalia_3;
    }

    public void setDo_not_enter_any_more_items_under_regalia_3(java.lang.String v)
    {
        this.do_not_enter_any_more_items_under_regalia_3 = v;
    }

    public java.lang.String getDo_not_enter_any_more_items_under_regalia_4()
    {
        return do_not_enter_any_more_items_under_regalia_4;
    }

    public void setDo_not_enter_any_more_items_under_regalia_4(java.lang.String v)
    {
        this.do_not_enter_any_more_items_under_regalia_4 = v;
    }

    public java.lang.String getDo_not_enter_any_more_items_under_regalia_5()
    {
        return do_not_enter_any_more_items_under_regalia_5;
    }

    public void setDo_not_enter_any_more_items_under_regalia_5(java.lang.String v)
    {
        this.do_not_enter_any_more_items_under_regalia_5 = v;
    }

    public java.lang.String getDo_not_enter_any_more_items_under_regalia_6()
    {
        return do_not_enter_any_more_items_under_regalia_6;
    }

    public void setDo_not_enter_any_more_items_under_regalia_6(java.lang.String v)
    {
        this.do_not_enter_any_more_items_under_regalia_6 = v;
    }

    public java.lang.String getDo_not_enter_any_more_items_under_regalia_7()
    {
        return do_not_enter_any_more_items_under_regalia_7;
    }

    public void setDo_not_enter_any_more_items_under_regalia_7(java.lang.String v)
    {
        this.do_not_enter_any_more_items_under_regalia_7 = v;
    }

    public java.lang.String getAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section()
    {
        return any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section;
    }

    public void setAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section(java.lang.String v)
    {
        this.any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section = v;
    }

    public java.lang.String getAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_2()
    {
        return any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_2;
    }

    public void setAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_2(java.lang.String v)
    {
        this.any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_2 = v;
    }

    public java.lang.String getAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_3()
    {
        return any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_3;
    }

    public void setAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_3(java.lang.String v)
    {
        this.any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_3 = v;
    }

    public java.lang.String getAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_4()
    {
        return any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_4;
    }

    public void setAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_4(java.lang.String v)
    {
        this.any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_4 = v;
    }

    public java.lang.String getAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_5()
    {
        return any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_5;
    }

    public void setAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_5(java.lang.String v)
    {
        this.any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_5 = v;
    }

    public java.lang.String getAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_6()
    {
        return any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_6;
    }

    public void setAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_6(java.lang.String v)
    {
        this.any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_6 = v;
    }

    public java.lang.String getAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_7()
    {
        return any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_7;
    }

    public void setAny_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_7(java.lang.String v)
    {
        this.any_regalia_type_item_such_as_a_crown_that_cost_2000_or_more_needs_to_be_depreciated_under_the_7_year_section_7 = v;
    }

    public java.lang.String getIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be()
    {
        return if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be;
    }

    public void setIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be(java.lang.String v)
    {
        this.if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be = v;
    }

    public java.lang.String getIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_2()
    {
        return if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_2;
    }

    public void setIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_2(java.lang.String v)
    {
        this.if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_2 = v;
    }

    public java.lang.String getIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_3()
    {
        return if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_3;
    }

    public void setIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_3(java.lang.String v)
    {
        this.if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_3 = v;
    }

    public java.lang.String getIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_4()
    {
        return if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_4;
    }

    public void setIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_4(java.lang.String v)
    {
        this.if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_4 = v;
    }

    public java.lang.String getIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_5()
    {
        return if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_5;
    }

    public void setIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_5(java.lang.String v)
    {
        this.if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_5 = v;
    }

    public java.lang.String getIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_6()
    {
        return if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_6;
    }

    public void setIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_6(java.lang.String v)
    {
        this.if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_6 = v;
    }

    public java.lang.String getIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_7()
    {
        return if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_7;
    }

    public void setIf_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_7(java.lang.String v)
    {
        this.if_you_purchased_two_crowns_coronets_for_3000_then_each_one_would_be_1500_a_piece_and_these_would_not_be_7 = v;
    }

    public java.lang.String getDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s()
    {
        return depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s;
    }

    public void setDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s(java.lang.String v)
    {
        this.depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s = v;
    }

    public java.lang.String getDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_2()
    {
        return depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_2;
    }

    public void setDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_2(java.lang.String v)
    {
        this.depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_2 = v;
    }

    public java.lang.String getDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_3()
    {
        return depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_3;
    }

    public void setDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_3(java.lang.String v)
    {
        this.depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_3 = v;
    }

    public java.lang.String getDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_4()
    {
        return depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_4;
    }

    public void setDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_4(java.lang.String v)
    {
        this.depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_4 = v;
    }

    public java.lang.String getDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_5()
    {
        return depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_5;
    }

    public void setDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_5(java.lang.String v)
    {
        this.depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_5 = v;
    }

    public java.lang.String getDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_6()
    {
        return depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_6;
    }

    public void setDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_6(java.lang.String v)
    {
        this.depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_6 = v;
    }

    public java.lang.String getDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_7()
    {
        return depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_7;
    }

    public void setDepreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_7(java.lang.String v)
    {
        this.depreciatied_but_rather_expensed_under_ar_general_supplies_you_would_still_need_to_list_the_items_on_the_group_s_7 = v;
    }

    public java.lang.String getProperty_list()
    {
        return property_list;
    }

    public void setProperty_list(java.lang.String v)
    {
        this.property_list = v;
    }

    public java.lang.String getProperty_list_2()
    {
        return property_list_2;
    }

    public void setProperty_list_2(java.lang.String v)
    {
        this.property_list_2 = v;
    }

    public java.lang.String getProperty_list_3()
    {
        return property_list_3;
    }

    public void setProperty_list_3(java.lang.String v)
    {
        this.property_list_3 = v;
    }

    public java.lang.String getProperty_list_4()
    {
        return property_list_4;
    }

    public void setProperty_list_4(java.lang.String v)
    {
        this.property_list_4 = v;
    }

    public java.lang.String getProperty_list_5()
    {
        return property_list_5;
    }

    public void setProperty_list_5(java.lang.String v)
    {
        this.property_list_5 = v;
    }

    public java.lang.String getProperty_list_6()
    {
        return property_list_6;
    }

    public void setProperty_list_6(java.lang.String v)
    {
        this.property_list_6 = v;
    }

    public java.lang.String getItem_description()
    {
        return item_description;
    }

    public void setItem_description(java.lang.String v)
    {
        this.item_description = v;
    }

    public java.lang.String getQty()
    {
        return qty;
    }

    public void setQty(java.lang.String v)
    {
        this.qty = v;
    }

    public java.lang.String getYear_acquired()
    {
        return year_acquired;
    }

    public void setYear_acquired(java.lang.String v)
    {
        this.year_acquired = v;
    }

    public java.lang.String getA_start_prior_value()
    {
        return a_start_prior_value;
    }

    public void setA_start_prior_value(java.lang.String v)
    {
        this.a_start_prior_value = v;
    }

    public java.lang.String getB_value_of_new_item()
    {
        return b_value_of_new_item;
    }

    public void setB_value_of_new_item(java.lang.String v)
    {
        this.b_value_of_new_item = v;
    }

    public java.lang.String getC_value_adjustment()
    {
        return c_value_adjustment;
    }

    public void setC_value_adjustment(java.lang.String v)
    {
        this.c_value_adjustment = v;
    }

    public java.lang.Double getA_or_b_c_end_value()
    {
        return a_or_b_c_end_value;
    }

    public void setA_or_b_c_end_value(java.lang.Double v)
    {
        this.a_or_b_c_end_value = v;
    }

    public java.lang.String getItem_description_2()
    {
        return item_description_2;
    }

    public void setItem_description_2(java.lang.String v)
    {
        this.item_description_2 = v;
    }

    public java.lang.String getQty_2()
    {
        return qty_2;
    }

    public void setQty_2(java.lang.String v)
    {
        this.qty_2 = v;
    }

    public java.lang.String getYear_acquired_2()
    {
        return year_acquired_2;
    }

    public void setYear_acquired_2(java.lang.String v)
    {
        this.year_acquired_2 = v;
    }

    public java.lang.String getA_start_prior_value_2()
    {
        return a_start_prior_value_2;
    }

    public void setA_start_prior_value_2(java.lang.String v)
    {
        this.a_start_prior_value_2 = v;
    }

    public java.lang.String getB_value_of_new_item_2()
    {
        return b_value_of_new_item_2;
    }

    public void setB_value_of_new_item_2(java.lang.String v)
    {
        this.b_value_of_new_item_2 = v;
    }

    public java.lang.String getC_value_adjustment_2()
    {
        return c_value_adjustment_2;
    }

    public void setC_value_adjustment_2(java.lang.String v)
    {
        this.c_value_adjustment_2 = v;
    }

    public java.lang.Double getIf_f20_0_f20_g20_h20()
    {
        return if_f20_0_f20_g20_h20;
    }

    public void setIf_f20_0_f20_g20_h20(java.lang.Double v)
    {
        this.if_f20_0_f20_g20_h20 = v;
    }

    public java.lang.String getItem_description_3()
    {
        return item_description_3;
    }

    public void setItem_description_3(java.lang.String v)
    {
        this.item_description_3 = v;
    }

    public java.lang.String getQty_3()
    {
        return qty_3;
    }

    public void setQty_3(java.lang.String v)
    {
        this.qty_3 = v;
    }

    public java.lang.String getYear_acquired_3()
    {
        return year_acquired_3;
    }

    public void setYear_acquired_3(java.lang.String v)
    {
        this.year_acquired_3 = v;
    }

    public java.lang.String getA_start_prior_value_3()
    {
        return a_start_prior_value_3;
    }

    public void setA_start_prior_value_3(java.lang.String v)
    {
        this.a_start_prior_value_3 = v;
    }

    public java.lang.String getB_value_of_new_item_3()
    {
        return b_value_of_new_item_3;
    }

    public void setB_value_of_new_item_3(java.lang.String v)
    {
        this.b_value_of_new_item_3 = v;
    }

    public java.lang.String getC_value_adjustment_3()
    {
        return c_value_adjustment_3;
    }

    public void setC_value_adjustment_3(java.lang.String v)
    {
        this.c_value_adjustment_3 = v;
    }

    public java.lang.Double getIf_f21_0_f21_g21_h21()
    {
        return if_f21_0_f21_g21_h21;
    }

    public void setIf_f21_0_f21_g21_h21(java.lang.Double v)
    {
        this.if_f21_0_f21_g21_h21 = v;
    }

    public java.lang.String getItem_description_4()
    {
        return item_description_4;
    }

    public void setItem_description_4(java.lang.String v)
    {
        this.item_description_4 = v;
    }

    public java.lang.String getQty_4()
    {
        return qty_4;
    }

    public void setQty_4(java.lang.String v)
    {
        this.qty_4 = v;
    }

    public java.lang.String getYear_acquired_4()
    {
        return year_acquired_4;
    }

    public void setYear_acquired_4(java.lang.String v)
    {
        this.year_acquired_4 = v;
    }

    public java.lang.String getA_start_prior_value_4()
    {
        return a_start_prior_value_4;
    }

    public void setA_start_prior_value_4(java.lang.String v)
    {
        this.a_start_prior_value_4 = v;
    }

    public java.lang.String getB_value_of_new_item_4()
    {
        return b_value_of_new_item_4;
    }

    public void setB_value_of_new_item_4(java.lang.String v)
    {
        this.b_value_of_new_item_4 = v;
    }

    public java.lang.String getC_value_adjustment_4()
    {
        return c_value_adjustment_4;
    }

    public void setC_value_adjustment_4(java.lang.String v)
    {
        this.c_value_adjustment_4 = v;
    }

    public java.lang.Double getIf_f22_0_f22_g22_h22()
    {
        return if_f22_0_f22_g22_h22;
    }

    public void setIf_f22_0_f22_g22_h22(java.lang.Double v)
    {
        this.if_f22_0_f22_g22_h22 = v;
    }

    public java.lang.String getItem_description_5()
    {
        return item_description_5;
    }

    public void setItem_description_5(java.lang.String v)
    {
        this.item_description_5 = v;
    }

    public java.lang.String getQty_5()
    {
        return qty_5;
    }

    public void setQty_5(java.lang.String v)
    {
        this.qty_5 = v;
    }

    public java.lang.String getYear_acquired_5()
    {
        return year_acquired_5;
    }

    public void setYear_acquired_5(java.lang.String v)
    {
        this.year_acquired_5 = v;
    }

    public java.lang.String getA_start_prior_value_5()
    {
        return a_start_prior_value_5;
    }

    public void setA_start_prior_value_5(java.lang.String v)
    {
        this.a_start_prior_value_5 = v;
    }

    public java.lang.String getB_value_of_new_item_5()
    {
        return b_value_of_new_item_5;
    }

    public void setB_value_of_new_item_5(java.lang.String v)
    {
        this.b_value_of_new_item_5 = v;
    }

    public java.lang.String getC_value_adjustment_5()
    {
        return c_value_adjustment_5;
    }

    public void setC_value_adjustment_5(java.lang.String v)
    {
        this.c_value_adjustment_5 = v;
    }

    public java.lang.Double getIf_f23_0_f23_g23_h23()
    {
        return if_f23_0_f23_g23_h23;
    }

    public void setIf_f23_0_f23_g23_h23(java.lang.Double v)
    {
        this.if_f23_0_f23_g23_h23 = v;
    }

    public java.lang.String getItem_description_6()
    {
        return item_description_6;
    }

    public void setItem_description_6(java.lang.String v)
    {
        this.item_description_6 = v;
    }

    public java.lang.String getQty_6()
    {
        return qty_6;
    }

    public void setQty_6(java.lang.String v)
    {
        this.qty_6 = v;
    }

    public java.lang.String getYear_acquired_6()
    {
        return year_acquired_6;
    }

    public void setYear_acquired_6(java.lang.String v)
    {
        this.year_acquired_6 = v;
    }

    public java.lang.String getA_start_prior_value_6()
    {
        return a_start_prior_value_6;
    }

    public void setA_start_prior_value_6(java.lang.String v)
    {
        this.a_start_prior_value_6 = v;
    }

    public java.lang.String getB_value_of_new_item_6()
    {
        return b_value_of_new_item_6;
    }

    public void setB_value_of_new_item_6(java.lang.String v)
    {
        this.b_value_of_new_item_6 = v;
    }

    public java.lang.String getC_value_adjustment_6()
    {
        return c_value_adjustment_6;
    }

    public void setC_value_adjustment_6(java.lang.String v)
    {
        this.c_value_adjustment_6 = v;
    }

    public java.lang.Double getIf_f24_0_f24_g24_h24()
    {
        return if_f24_0_f24_g24_h24;
    }

    public void setIf_f24_0_f24_g24_h24(java.lang.Double v)
    {
        this.if_f24_0_f24_g24_h24 = v;
    }

    public java.lang.String getItem_description_7()
    {
        return item_description_7;
    }

    public void setItem_description_7(java.lang.String v)
    {
        this.item_description_7 = v;
    }

    public java.lang.String getQty_7()
    {
        return qty_7;
    }

    public void setQty_7(java.lang.String v)
    {
        this.qty_7 = v;
    }

    public java.lang.String getYear_acquired_7()
    {
        return year_acquired_7;
    }

    public void setYear_acquired_7(java.lang.String v)
    {
        this.year_acquired_7 = v;
    }

    public java.lang.String getA_start_prior_value_7()
    {
        return a_start_prior_value_7;
    }

    public void setA_start_prior_value_7(java.lang.String v)
    {
        this.a_start_prior_value_7 = v;
    }

    public java.lang.String getB_value_of_new_item_7()
    {
        return b_value_of_new_item_7;
    }

    public void setB_value_of_new_item_7(java.lang.String v)
    {
        this.b_value_of_new_item_7 = v;
    }

    public java.lang.String getC_value_adjustment_7()
    {
        return c_value_adjustment_7;
    }

    public void setC_value_adjustment_7(java.lang.String v)
    {
        this.c_value_adjustment_7 = v;
    }

    public java.lang.Double getIf_f25_0_f25_g25_h25()
    {
        return if_f25_0_f25_g25_h25;
    }

    public void setIf_f25_0_f25_g25_h25(java.lang.Double v)
    {
        this.if_f25_0_f25_g25_h25 = v;
    }

    public java.lang.String getItem_description_8()
    {
        return item_description_8;
    }

    public void setItem_description_8(java.lang.String v)
    {
        this.item_description_8 = v;
    }

    public java.lang.String getQty_8()
    {
        return qty_8;
    }

    public void setQty_8(java.lang.String v)
    {
        this.qty_8 = v;
    }

    public java.lang.String getYear_acquired_8()
    {
        return year_acquired_8;
    }

    public void setYear_acquired_8(java.lang.String v)
    {
        this.year_acquired_8 = v;
    }

    public java.lang.String getA_start_prior_value_8()
    {
        return a_start_prior_value_8;
    }

    public void setA_start_prior_value_8(java.lang.String v)
    {
        this.a_start_prior_value_8 = v;
    }

    public java.lang.String getB_value_of_new_item_8()
    {
        return b_value_of_new_item_8;
    }

    public void setB_value_of_new_item_8(java.lang.String v)
    {
        this.b_value_of_new_item_8 = v;
    }

    public java.lang.String getC_value_adjustment_8()
    {
        return c_value_adjustment_8;
    }

    public void setC_value_adjustment_8(java.lang.String v)
    {
        this.c_value_adjustment_8 = v;
    }

    public java.lang.Double getIf_f26_0_f26_g26_h26()
    {
        return if_f26_0_f26_g26_h26;
    }

    public void setIf_f26_0_f26_g26_h26(java.lang.Double v)
    {
        this.if_f26_0_f26_g26_h26 = v;
    }

    public java.lang.String getItem_description_9()
    {
        return item_description_9;
    }

    public void setItem_description_9(java.lang.String v)
    {
        this.item_description_9 = v;
    }

    public java.lang.String getQty_9()
    {
        return qty_9;
    }

    public void setQty_9(java.lang.String v)
    {
        this.qty_9 = v;
    }

    public java.lang.String getYear_acquired_9()
    {
        return year_acquired_9;
    }

    public void setYear_acquired_9(java.lang.String v)
    {
        this.year_acquired_9 = v;
    }

    public java.lang.String getA_start_prior_value_9()
    {
        return a_start_prior_value_9;
    }

    public void setA_start_prior_value_9(java.lang.String v)
    {
        this.a_start_prior_value_9 = v;
    }

    public java.lang.String getB_value_of_new_item_9()
    {
        return b_value_of_new_item_9;
    }

    public void setB_value_of_new_item_9(java.lang.String v)
    {
        this.b_value_of_new_item_9 = v;
    }

    public java.lang.String getC_value_adjustment_9()
    {
        return c_value_adjustment_9;
    }

    public void setC_value_adjustment_9(java.lang.String v)
    {
        this.c_value_adjustment_9 = v;
    }

    public java.lang.Double getIf_f27_0_f27_g27_h27()
    {
        return if_f27_0_f27_g27_h27;
    }

    public void setIf_f27_0_f27_g27_h27(java.lang.Double v)
    {
        this.if_f27_0_f27_g27_h27 = v;
    }

    public java.lang.String getItem_description_10()
    {
        return item_description_10;
    }

    public void setItem_description_10(java.lang.String v)
    {
        this.item_description_10 = v;
    }

    public java.lang.String getQty_10()
    {
        return qty_10;
    }

    public void setQty_10(java.lang.String v)
    {
        this.qty_10 = v;
    }

    public java.lang.String getYear_acquired_10()
    {
        return year_acquired_10;
    }

    public void setYear_acquired_10(java.lang.String v)
    {
        this.year_acquired_10 = v;
    }

    public java.lang.String getA_start_prior_value_10()
    {
        return a_start_prior_value_10;
    }

    public void setA_start_prior_value_10(java.lang.String v)
    {
        this.a_start_prior_value_10 = v;
    }

    public java.lang.String getB_value_of_new_item_10()
    {
        return b_value_of_new_item_10;
    }

    public void setB_value_of_new_item_10(java.lang.String v)
    {
        this.b_value_of_new_item_10 = v;
    }

    public java.lang.String getC_value_adjustment_10()
    {
        return c_value_adjustment_10;
    }

    public void setC_value_adjustment_10(java.lang.String v)
    {
        this.c_value_adjustment_10 = v;
    }

    public java.lang.Double getIf_f28_0_f28_g28_h28()
    {
        return if_f28_0_f28_g28_h28;
    }

    public void setIf_f28_0_f28_g28_h28(java.lang.Double v)
    {
        this.if_f28_0_f28_g28_h28 = v;
    }

    public java.lang.String getItem_description_11()
    {
        return item_description_11;
    }

    public void setItem_description_11(java.lang.String v)
    {
        this.item_description_11 = v;
    }

    public java.lang.String getQty_11()
    {
        return qty_11;
    }

    public void setQty_11(java.lang.String v)
    {
        this.qty_11 = v;
    }

    public java.lang.String getYear_acquired_11()
    {
        return year_acquired_11;
    }

    public void setYear_acquired_11(java.lang.String v)
    {
        this.year_acquired_11 = v;
    }

    public java.lang.String getA_start_prior_value_11()
    {
        return a_start_prior_value_11;
    }

    public void setA_start_prior_value_11(java.lang.String v)
    {
        this.a_start_prior_value_11 = v;
    }

    public java.lang.String getB_value_of_new_item_11()
    {
        return b_value_of_new_item_11;
    }

    public void setB_value_of_new_item_11(java.lang.String v)
    {
        this.b_value_of_new_item_11 = v;
    }

    public java.lang.String getC_value_adjustment_11()
    {
        return c_value_adjustment_11;
    }

    public void setC_value_adjustment_11(java.lang.String v)
    {
        this.c_value_adjustment_11 = v;
    }

    public java.lang.Double getIf_f29_0_f29_g29_h29()
    {
        return if_f29_0_f29_g29_h29;
    }

    public void setIf_f29_0_f29_g29_h29(java.lang.Double v)
    {
        this.if_f29_0_f29_g29_h29 = v;
    }

    public java.lang.String getItem_description_12()
    {
        return item_description_12;
    }

    public void setItem_description_12(java.lang.String v)
    {
        this.item_description_12 = v;
    }

    public java.lang.String getQty_12()
    {
        return qty_12;
    }

    public void setQty_12(java.lang.String v)
    {
        this.qty_12 = v;
    }

    public java.lang.String getYear_acquired_12()
    {
        return year_acquired_12;
    }

    public void setYear_acquired_12(java.lang.String v)
    {
        this.year_acquired_12 = v;
    }

    public java.lang.String getA_start_prior_value_12()
    {
        return a_start_prior_value_12;
    }

    public void setA_start_prior_value_12(java.lang.String v)
    {
        this.a_start_prior_value_12 = v;
    }

    public java.lang.String getB_value_of_new_item_12()
    {
        return b_value_of_new_item_12;
    }

    public void setB_value_of_new_item_12(java.lang.String v)
    {
        this.b_value_of_new_item_12 = v;
    }

    public java.lang.String getC_value_adjustment_12()
    {
        return c_value_adjustment_12;
    }

    public void setC_value_adjustment_12(java.lang.String v)
    {
        this.c_value_adjustment_12 = v;
    }

    public java.lang.Double getIf_f30_0_f30_g30_h30()
    {
        return if_f30_0_f30_g30_h30;
    }

    public void setIf_f30_0_f30_g30_h30(java.lang.Double v)
    {
        this.if_f30_0_f30_g30_h30 = v;
    }

    public java.lang.Double getA_start_prior_value_total()
    {
        return a_start_prior_value_total;
    }

    public void setA_start_prior_value_total(java.lang.Double v)
    {
        this.a_start_prior_value_total = v;
    }

    public java.lang.Double getC_value_adjustment_sum_f20_f31()
    {
        return c_value_adjustment_sum_f20_f31;
    }

    public void setC_value_adjustment_sum_f20_f31(java.lang.Double v)
    {
        this.c_value_adjustment_sum_f20_f31 = v;
    }

    public java.lang.Double getIf_f31_0_f31_g31_h31_sumif_h20_h31_0_h20_h31()
    {
        return if_f31_0_f31_g31_h31_sumif_h20_h31_0_h20_h31;
    }

    public void setIf_f31_0_f31_g31_h31_sumif_h20_h31_0_h20_h31(java.lang.Double v)
    {
        this.if_f31_0_f31_g31_h31_sumif_h20_h31_0_h20_h31 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased = v;
    }

    public java.lang.String getQty_13()
    {
        return qty_13;
    }

    public void setQty_13(java.lang.String v)
    {
        this.qty_13 = v;
    }

    public java.lang.String getShow_on()
    {
        return show_on;
    }

    public void setShow_on(java.lang.String v)
    {
        this.show_on = v;
    }

    public java.lang.String getPg_3_i_e_start()
    {
        return pg_3_i_e_start;
    }

    public void setPg_3_i_e_start(java.lang.String v)
    {
        this.pg_3_i_e_start = v;
    }

    public java.lang.String getB_value_of_new_item_13()
    {
        return b_value_of_new_item_13;
    }

    public void setB_value_of_new_item_13(java.lang.String v)
    {
        this.b_value_of_new_item_13 = v;
    }

    public java.lang.String getNumber_sold()
    {
        return number_sold;
    }

    public void setNumber_sold(java.lang.String v)
    {
        this.number_sold = v;
    }

    public java.lang.String getIncome_from_sale()
    {
        return income_from_sale;
    }

    public void setIncome_from_sale(java.lang.String v)
    {
        this.income_from_sale = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_2()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_2;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_2(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_2 = v;
    }

    public java.lang.String getQty_14()
    {
        return qty_14;
    }

    public void setQty_14(java.lang.String v)
    {
        this.qty_14 = v;
    }

    public java.lang.String getShow_on_2()
    {
        return show_on_2;
    }

    public void setShow_on_2(java.lang.String v)
    {
        this.show_on_2 = v;
    }

    public java.lang.String getPg_3_i_e_start_2()
    {
        return pg_3_i_e_start_2;
    }

    public void setPg_3_i_e_start_2(java.lang.String v)
    {
        this.pg_3_i_e_start_2 = v;
    }

    public java.lang.String getB_value_of_new_item_14()
    {
        return b_value_of_new_item_14;
    }

    public void setB_value_of_new_item_14(java.lang.String v)
    {
        this.b_value_of_new_item_14 = v;
    }

    public java.lang.String getNumber_sold_2()
    {
        return number_sold_2;
    }

    public void setNumber_sold_2(java.lang.String v)
    {
        this.number_sold_2 = v;
    }

    public java.lang.String getIncome_from_sale_2()
    {
        return income_from_sale_2;
    }

    public void setIncome_from_sale_2(java.lang.String v)
    {
        this.income_from_sale_2 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_3()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_3;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_3(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_3 = v;
    }

    public java.lang.String getQty_15()
    {
        return qty_15;
    }

    public void setQty_15(java.lang.String v)
    {
        this.qty_15 = v;
    }

    public java.lang.String getShow_on_3()
    {
        return show_on_3;
    }

    public void setShow_on_3(java.lang.String v)
    {
        this.show_on_3 = v;
    }

    public java.lang.String getPg_3_i_e_start_3()
    {
        return pg_3_i_e_start_3;
    }

    public void setPg_3_i_e_start_3(java.lang.String v)
    {
        this.pg_3_i_e_start_3 = v;
    }

    public java.lang.String getB_value_of_new_item_15()
    {
        return b_value_of_new_item_15;
    }

    public void setB_value_of_new_item_15(java.lang.String v)
    {
        this.b_value_of_new_item_15 = v;
    }

    public java.lang.String getNumber_sold_3()
    {
        return number_sold_3;
    }

    public void setNumber_sold_3(java.lang.String v)
    {
        this.number_sold_3 = v;
    }

    public java.lang.String getIncome_from_sale_3()
    {
        return income_from_sale_3;
    }

    public void setIncome_from_sale_3(java.lang.String v)
    {
        this.income_from_sale_3 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_4()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_4;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_4(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_4 = v;
    }

    public java.lang.String getQty_16()
    {
        return qty_16;
    }

    public void setQty_16(java.lang.String v)
    {
        this.qty_16 = v;
    }

    public java.lang.String getShow_on_4()
    {
        return show_on_4;
    }

    public void setShow_on_4(java.lang.String v)
    {
        this.show_on_4 = v;
    }

    public java.lang.String getPg_3_i_e_start_4()
    {
        return pg_3_i_e_start_4;
    }

    public void setPg_3_i_e_start_4(java.lang.String v)
    {
        this.pg_3_i_e_start_4 = v;
    }

    public java.lang.String getB_value_of_new_item_16()
    {
        return b_value_of_new_item_16;
    }

    public void setB_value_of_new_item_16(java.lang.String v)
    {
        this.b_value_of_new_item_16 = v;
    }

    public java.lang.String getNumber_sold_4()
    {
        return number_sold_4;
    }

    public void setNumber_sold_4(java.lang.String v)
    {
        this.number_sold_4 = v;
    }

    public java.lang.String getIncome_from_sale_4()
    {
        return income_from_sale_4;
    }

    public void setIncome_from_sale_4(java.lang.String v)
    {
        this.income_from_sale_4 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_5()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_5;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_5(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_5 = v;
    }

    public java.lang.String getQty_17()
    {
        return qty_17;
    }

    public void setQty_17(java.lang.String v)
    {
        this.qty_17 = v;
    }

    public java.lang.String getShow_on_5()
    {
        return show_on_5;
    }

    public void setShow_on_5(java.lang.String v)
    {
        this.show_on_5 = v;
    }

    public java.lang.String getPg_3_i_e_start_5()
    {
        return pg_3_i_e_start_5;
    }

    public void setPg_3_i_e_start_5(java.lang.String v)
    {
        this.pg_3_i_e_start_5 = v;
    }

    public java.lang.String getB_value_of_new_item_17()
    {
        return b_value_of_new_item_17;
    }

    public void setB_value_of_new_item_17(java.lang.String v)
    {
        this.b_value_of_new_item_17 = v;
    }

    public java.lang.String getNumber_sold_5()
    {
        return number_sold_5;
    }

    public void setNumber_sold_5(java.lang.String v)
    {
        this.number_sold_5 = v;
    }

    public java.lang.String getIncome_from_sale_5()
    {
        return income_from_sale_5;
    }

    public void setIncome_from_sale_5(java.lang.String v)
    {
        this.income_from_sale_5 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_6()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_6;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_6(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_6 = v;
    }

    public java.lang.String getQty_18()
    {
        return qty_18;
    }

    public void setQty_18(java.lang.String v)
    {
        this.qty_18 = v;
    }

    public java.lang.String getShow_on_6()
    {
        return show_on_6;
    }

    public void setShow_on_6(java.lang.String v)
    {
        this.show_on_6 = v;
    }

    public java.lang.String getPg_3_i_e_start_6()
    {
        return pg_3_i_e_start_6;
    }

    public void setPg_3_i_e_start_6(java.lang.String v)
    {
        this.pg_3_i_e_start_6 = v;
    }

    public java.lang.String getB_value_of_new_item_18()
    {
        return b_value_of_new_item_18;
    }

    public void setB_value_of_new_item_18(java.lang.String v)
    {
        this.b_value_of_new_item_18 = v;
    }

    public java.lang.String getNumber_sold_6()
    {
        return number_sold_6;
    }

    public void setNumber_sold_6(java.lang.String v)
    {
        this.number_sold_6 = v;
    }

    public java.lang.String getIncome_from_sale_6()
    {
        return income_from_sale_6;
    }

    public void setIncome_from_sale_6(java.lang.String v)
    {
        this.income_from_sale_6 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_7()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_7;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_7(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_7 = v;
    }

    public java.lang.String getQty_19()
    {
        return qty_19;
    }

    public void setQty_19(java.lang.String v)
    {
        this.qty_19 = v;
    }

    public java.lang.String getShow_on_7()
    {
        return show_on_7;
    }

    public void setShow_on_7(java.lang.String v)
    {
        this.show_on_7 = v;
    }

    public java.lang.String getPg_3_i_e_start_7()
    {
        return pg_3_i_e_start_7;
    }

    public void setPg_3_i_e_start_7(java.lang.String v)
    {
        this.pg_3_i_e_start_7 = v;
    }

    public java.lang.String getB_value_of_new_item_19()
    {
        return b_value_of_new_item_19;
    }

    public void setB_value_of_new_item_19(java.lang.String v)
    {
        this.b_value_of_new_item_19 = v;
    }

    public java.lang.String getNumber_sold_7()
    {
        return number_sold_7;
    }

    public void setNumber_sold_7(java.lang.String v)
    {
        this.number_sold_7 = v;
    }

    public java.lang.String getIncome_from_sale_7()
    {
        return income_from_sale_7;
    }

    public void setIncome_from_sale_7(java.lang.String v)
    {
        this.income_from_sale_7 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_8()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_8;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_8(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_8 = v;
    }

    public java.lang.String getQty_20()
    {
        return qty_20;
    }

    public void setQty_20(java.lang.String v)
    {
        this.qty_20 = v;
    }

    public java.lang.String getShow_on_8()
    {
        return show_on_8;
    }

    public void setShow_on_8(java.lang.String v)
    {
        this.show_on_8 = v;
    }

    public java.lang.String getPg_3_i_e_start_8()
    {
        return pg_3_i_e_start_8;
    }

    public void setPg_3_i_e_start_8(java.lang.String v)
    {
        this.pg_3_i_e_start_8 = v;
    }

    public java.lang.String getB_value_of_new_item_20()
    {
        return b_value_of_new_item_20;
    }

    public void setB_value_of_new_item_20(java.lang.String v)
    {
        this.b_value_of_new_item_20 = v;
    }

    public java.lang.String getNumber_sold_8()
    {
        return number_sold_8;
    }

    public void setNumber_sold_8(java.lang.String v)
    {
        this.number_sold_8 = v;
    }

    public java.lang.String getIncome_from_sale_8()
    {
        return income_from_sale_8;
    }

    public void setIncome_from_sale_8(java.lang.String v)
    {
        this.income_from_sale_8 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_9()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_9;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_9(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_9 = v;
    }

    public java.lang.String getQty_21()
    {
        return qty_21;
    }

    public void setQty_21(java.lang.String v)
    {
        this.qty_21 = v;
    }

    public java.lang.String getShow_on_9()
    {
        return show_on_9;
    }

    public void setShow_on_9(java.lang.String v)
    {
        this.show_on_9 = v;
    }

    public java.lang.String getPg_3_i_e_start_9()
    {
        return pg_3_i_e_start_9;
    }

    public void setPg_3_i_e_start_9(java.lang.String v)
    {
        this.pg_3_i_e_start_9 = v;
    }

    public java.lang.String getB_value_of_new_item_21()
    {
        return b_value_of_new_item_21;
    }

    public void setB_value_of_new_item_21(java.lang.String v)
    {
        this.b_value_of_new_item_21 = v;
    }

    public java.lang.String getNumber_sold_9()
    {
        return number_sold_9;
    }

    public void setNumber_sold_9(java.lang.String v)
    {
        this.number_sold_9 = v;
    }

    public java.lang.String getIncome_from_sale_9()
    {
        return income_from_sale_9;
    }

    public void setIncome_from_sale_9(java.lang.String v)
    {
        this.income_from_sale_9 = v;
    }

    public java.lang.String get_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_10()
    {
        return _1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_10;
    }

    public void set_1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_10(java.lang.String v)
    {
        this._1_minor_inventory_not_reported_as_major_inventory_and_expensed_as_supplies_when_purchased_10 = v;
    }

    public java.lang.String getQty_22()
    {
        return qty_22;
    }

    public void setQty_22(java.lang.String v)
    {
        this.qty_22 = v;
    }

    public java.lang.String getShow_on_10()
    {
        return show_on_10;
    }

    public void setShow_on_10(java.lang.String v)
    {
        this.show_on_10 = v;
    }

    public java.lang.String getPg_3_i_e_start_10()
    {
        return pg_3_i_e_start_10;
    }

    public void setPg_3_i_e_start_10(java.lang.String v)
    {
        this.pg_3_i_e_start_10 = v;
    }

    public java.lang.String getB_value_of_new_item_22()
    {
        return b_value_of_new_item_22;
    }

    public void setB_value_of_new_item_22(java.lang.String v)
    {
        this.b_value_of_new_item_22 = v;
    }

    public java.lang.String getNumber_sold_10()
    {
        return number_sold_10;
    }

    public void setNumber_sold_10(java.lang.String v)
    {
        this.number_sold_10 = v;
    }

    public java.lang.String getIncome_from_sale_10()
    {
        return income_from_sale_10;
    }

    public void setIncome_from_sale_10(java.lang.String v)
    {
        this.income_from_sale_10 = v;
    }

    public java.lang.Double getIncome_from_sale_total_1()
    {
        return income_from_sale_total_1;
    }

    public void setIncome_from_sale_total_1(java.lang.Double v)
    {
        this.income_from_sale_total_1 = v;
    }

    public java.lang.String get_2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report()
    {
        return _2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report;
    }

    public void set_2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report(java.lang.String v)
    {
        this._2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report = v;
    }

    public java.lang.String getQty_23()
    {
        return qty_23;
    }

    public void setQty_23(java.lang.String v)
    {
        this.qty_23 = v;
    }

    public java.lang.String getYear_acquired_13()
    {
        return year_acquired_13;
    }

    public void setYear_acquired_13(java.lang.String v)
    {
        this.year_acquired_13 = v;
    }

    public java.lang.String getA_start_prior_value_from_pg_7_or_8()
    {
        return a_start_prior_value_from_pg_7_or_8;
    }

    public void setA_start_prior_value_from_pg_7_or_8(java.lang.String v)
    {
        this.a_start_prior_value_from_pg_7_or_8 = v;
    }

    public java.lang.String getB_start_accum_depr_if_from_pg_8()
    {
        return b_start_accum_depr_if_from_pg_8;
    }

    public void setB_start_accum_depr_if_from_pg_8(java.lang.String v)
    {
        this.b_start_accum_depr_if_from_pg_8 = v;
    }

    public java.lang.Double getA_b_value_lost()
    {
        return a_b_value_lost;
    }

    public void setA_b_value_lost(java.lang.Double v)
    {
        this.a_b_value_lost = v;
    }

    public java.lang.String getIncome_from_sale_if_any_f49_g49()
    {
        return income_from_sale_if_any_f49_g49;
    }

    public void setIncome_from_sale_if_any_f49_g49(java.lang.String v)
    {
        this.income_from_sale_if_any_f49_g49 = v;
    }

    public java.lang.String get_2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_2()
    {
        return _2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_2;
    }

    public void set_2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_2(java.lang.String v)
    {
        this._2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_2 = v;
    }

    public java.lang.String getQty_24()
    {
        return qty_24;
    }

    public void setQty_24(java.lang.String v)
    {
        this.qty_24 = v;
    }

    public java.lang.String getYear_acquired_14()
    {
        return year_acquired_14;
    }

    public void setYear_acquired_14(java.lang.String v)
    {
        this.year_acquired_14 = v;
    }

    public java.lang.String getA_start_prior_value_from_pg_7_or_8_2()
    {
        return a_start_prior_value_from_pg_7_or_8_2;
    }

    public void setA_start_prior_value_from_pg_7_or_8_2(java.lang.String v)
    {
        this.a_start_prior_value_from_pg_7_or_8_2 = v;
    }

    public java.lang.String getB_start_accum_depr_if_from_pg_8_2()
    {
        return b_start_accum_depr_if_from_pg_8_2;
    }

    public void setB_start_accum_depr_if_from_pg_8_2(java.lang.String v)
    {
        this.b_start_accum_depr_if_from_pg_8_2 = v;
    }

    public java.lang.Double getF49_g49()
    {
        return f49_g49;
    }

    public void setF49_g49(java.lang.Double v)
    {
        this.f49_g49 = v;
    }

    public java.lang.String getIncome_from_sale_if_any_f50_g50()
    {
        return income_from_sale_if_any_f50_g50;
    }

    public void setIncome_from_sale_if_any_f50_g50(java.lang.String v)
    {
        this.income_from_sale_if_any_f50_g50 = v;
    }

    public java.lang.String get_2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_3()
    {
        return _2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_3;
    }

    public void set_2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_3(java.lang.String v)
    {
        this._2_released_or_sold_asset_listed_on_pg_8_8b_8c_in_a_prior_report_3 = v;
    }

    public java.lang.String getQty_25()
    {
        return qty_25;
    }

    public void setQty_25(java.lang.String v)
    {
        this.qty_25 = v;
    }

    public java.lang.String getYear_acquired_15()
    {
        return year_acquired_15;
    }

    public void setYear_acquired_15(java.lang.String v)
    {
        this.year_acquired_15 = v;
    }

    public java.lang.String getA_start_prior_value_from_pg_7_or_8_3()
    {
        return a_start_prior_value_from_pg_7_or_8_3;
    }

    public void setA_start_prior_value_from_pg_7_or_8_3(java.lang.String v)
    {
        this.a_start_prior_value_from_pg_7_or_8_3 = v;
    }

    public java.lang.String getB_start_accum_depr_if_from_pg_8_3()
    {
        return b_start_accum_depr_if_from_pg_8_3;
    }

    public void setB_start_accum_depr_if_from_pg_8_3(java.lang.String v)
    {
        this.b_start_accum_depr_if_from_pg_8_3 = v;
    }

    public java.lang.Double getF50_g50()
    {
        return f50_g50;
    }

    public void setF50_g50(java.lang.Double v)
    {
        this.f50_g50 = v;
    }

    public java.lang.String getIncome_from_sale_if_any_f51_g51()
    {
        return income_from_sale_if_any_f51_g51;
    }

    public void setIncome_from_sale_if_any_f51_g51(java.lang.String v)
    {
        this.income_from_sale_if_any_f51_g51 = v;
    }

    public java.lang.Double getF51_g51_total_2()
    {
        return f51_g51_total_2;
    }

    public void setF51_g51_total_2(java.lang.Double v)
    {
        this.f51_g51_total_2 = v;
    }

    public java.lang.Double getIncome_from_sale_if_any_sum_h49_h51()
    {
        return income_from_sale_if_any_sum_h49_h51;
    }

    public void setIncome_from_sale_if_any_sum_h49_h51(java.lang.Double v)
    {
        this.income_from_sale_if_any_sum_h49_h51 = v;
    }

    public java.lang.Double getSum_i49_i51_total_1_2()
    {
        return sum_i49_i51_total_1_2;
    }

    public void setSum_i49_i51_total_1_2(java.lang.Double v)
    {
        this.sum_i49_i51_total_1_2 = v;
    }

    public REGALIA_SALES_DTL_7Bean()
    {
    }

}
