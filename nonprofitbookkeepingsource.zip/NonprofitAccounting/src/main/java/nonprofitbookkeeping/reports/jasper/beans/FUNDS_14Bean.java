package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet FUNDS_14 */
public class FUNDS_14Bean
{

    private java.lang.Double funds_14_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double funds_14_r6c4;
    private java.lang.Double total_of_lines_i_a_end_and_i_b_end_on_the_comparative_balance_sheet_cash;
    private java.lang.String end_of_period_all_non_dedicated_funds;
    private java.lang.String general_fund_2_0;
    private java.lang.String all_non_dedicated_funds_2_0;
    private java.lang.String end_of_period_2_0;
    private java.lang.String general_fund_3_0;
    private java.lang.String all_non_dedicated_funds_3_0;
    private java.lang.String end_of_period_3_0;
    private java.lang.String general_fund_4_0;
    private java.lang.String all_non_dedicated_funds_4_0;
    private java.lang.String end_of_period_4_0;
    private java.lang.String general_fund_5_0;
    private java.lang.String all_non_dedicated_funds_5_0;
    private java.lang.String end_of_period_5_0;
    private java.lang.String general_fund_6_0;
    private java.lang.String all_non_dedicated_funds_6_0;
    private java.lang.String end_of_period_6_0;
    private java.lang.String general_fund_7_0;
    private java.lang.String all_non_dedicated_funds_7_0;
    private java.lang.String end_of_period_7_0;
    private java.lang.String general_fund_8_0;
    private java.lang.String all_non_dedicated_funds_8_0;
    private java.lang.String end_of_period_8_0;
    private java.lang.String general_fund_9_0;
    private java.lang.String all_non_dedicated_funds_9_0;
    private java.lang.String end_of_period_9_0;
    private java.lang.String general_fund_10_0;
    private java.lang.String all_non_dedicated_funds_10_0;
    private java.lang.String end_of_period_10_0;
    private java.lang.String general_fund_11_0;
    private java.lang.String all_non_dedicated_funds_11_0;
    private java.lang.String end_of_period_11_0;
    private java.lang.String general_fund_12_0;
    private java.lang.String all_non_dedicated_funds_12_0;
    private java.lang.String end_of_period_12_0;
    private java.lang.String general_fund_13_0;
    private java.lang.String all_non_dedicated_funds_13_0;
    private java.lang.String end_of_period_13_0;
    private java.lang.String general_fund_14_0;
    private java.lang.String all_non_dedicated_funds_14_0;
    private java.lang.String end_of_period_14_0;
    private java.lang.String general_fund_15_0;
    private java.lang.String all_non_dedicated_funds_15_0;
    private java.lang.String end_of_period_15_0;
    private java.lang.String general_fund_16_0;
    private java.lang.String all_non_dedicated_funds_16_0;
    private java.lang.String end_of_period_16_0;
    private java.lang.String general_fund_17_0;
    private java.lang.String all_non_dedicated_funds_17_0;
    private java.lang.String end_of_period_17_0;
    private java.lang.String general_fund_18_0;
    private java.lang.String all_non_dedicated_funds_18_0;
    private java.lang.String end_of_period_18_0;
    private java.lang.String general_fund_19_0;
    private java.lang.String all_non_dedicated_funds_19_0;
    private java.lang.String end_of_period_19_0;
    private java.lang.String general_fund_20_0;
    private java.lang.String all_non_dedicated_funds_20_0;
    private java.lang.String end_of_period_20_0;
    private java.lang.String general_fund_21_0;
    private java.lang.String all_non_dedicated_funds_21_0;
    private java.lang.String end_of_period_21_0;
    private java.lang.String general_fund_22_0;
    private java.lang.String all_non_dedicated_funds_22_0;
    private java.lang.String end_of_period_22_0;
    private java.lang.String general_fund_23_0;
    private java.lang.String all_non_dedicated_funds_23_0;
    private java.lang.String end_of_period_23_0;
    private java.lang.String general_fund_24_0;
    private java.lang.String all_non_dedicated_funds_24_0;
    private java.lang.String end_of_period_24_0;
    private java.lang.String general_fund_25_0;
    private java.lang.String all_non_dedicated_funds_25_0;
    private java.lang.String end_of_period_25_0;
    private java.lang.String general_fund_26_0;
    private java.lang.String all_non_dedicated_funds_26_0;
    private java.lang.String end_of_period_26_0;
    private java.lang.String general_fund_27_0;
    private java.lang.String all_non_dedicated_funds_27_0;
    private java.lang.String end_of_period_27_0;
    private java.lang.String general_fund_28_0;
    private java.lang.String all_non_dedicated_funds_28_0;
    private java.lang.String end_of_period_28_0;
    private java.lang.String general_fund_29_0;
    private java.lang.String all_non_dedicated_funds_29_0;
    private java.lang.String end_of_period_29_0;
    private java.lang.String general_fund_30_0;
    private java.lang.String all_non_dedicated_funds_30_0;
    private java.lang.String end_of_period_30_0;
    private java.lang.String general_fund_31_0;
    private java.lang.String all_non_dedicated_funds_31_0;
    private java.lang.String end_of_period_31_0;
    private java.lang.String general_fund_32_0;
    private java.lang.String all_non_dedicated_funds_32_0;
    private java.lang.String end_of_period_32_0;
    private java.lang.String general_fund_33_0;
    private java.lang.String all_non_dedicated_funds_33_0;
    private java.lang.String end_of_period_33_0;
    private java.lang.String general_fund_34_0;
    private java.lang.String all_non_dedicated_funds_34_0;
    private java.lang.String end_of_period_34_0;
    private java.lang.String general_fund_35_0;
    private java.lang.String all_non_dedicated_funds_35_0;
    private java.lang.String end_of_period_35_0;
    private java.lang.String general_fund_36_0;
    private java.lang.String all_non_dedicated_funds_36_0;
    private java.lang.String end_of_period_36_0;
    private java.lang.String general_fund_37_0;
    private java.lang.String all_non_dedicated_funds_37_0;
    private java.lang.String end_of_period_37_0;
    private java.lang.String general_fund_38_0;
    private java.lang.String all_non_dedicated_funds_38_0;
    private java.lang.String end_of_period_38_0;
    private java.lang.String general_fund_39_0;
    private java.lang.String all_non_dedicated_funds_39_0;
    private java.lang.String end_of_period_39_0;
    private java.lang.String general_fund_40_0;
    private java.lang.String all_non_dedicated_funds_40_0;
    private java.lang.String end_of_period_40_0;
    private java.lang.String general_fund_41_0;
    private java.lang.String all_non_dedicated_funds_41_0;
    private java.lang.String end_of_period_41_0;
    private java.lang.String general_fund_42_0;
    private java.lang.String all_non_dedicated_funds_42_0;
    private java.lang.String end_of_period_42_0;
    private java.lang.Double end_of_period_total;

    public java.lang.Double getFunds_14_r2c3()
    {
        return funds_14_r2c3;
    }

    public void setFunds_14_r2c3(java.lang.Double v)
    {
        this.funds_14_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getFunds_14_r6c4()
    {
        return funds_14_r6c4;
    }

    public void setFunds_14_r6c4(java.lang.Double v)
    {
        this.funds_14_r6c4 = v;
    }

    public java.lang.Double getTotal_of_lines_i_a_end_and_i_b_end_on_the_comparative_balance_sheet_cash()
    {
        return total_of_lines_i_a_end_and_i_b_end_on_the_comparative_balance_sheet_cash;
    }

    public void setTotal_of_lines_i_a_end_and_i_b_end_on_the_comparative_balance_sheet_cash(java.lang.Double v)
    {
        this.total_of_lines_i_a_end_and_i_b_end_on_the_comparative_balance_sheet_cash = v;
    }

    public java.lang.String getEnd_of_period_all_non_dedicated_funds()
    {
        return end_of_period_all_non_dedicated_funds;
    }

    public void setEnd_of_period_all_non_dedicated_funds(java.lang.String v)
    {
        this.end_of_period_all_non_dedicated_funds = v;
    }

    public java.lang.String getGeneral_fund_2_0()
    {
        return general_fund_2_0;
    }

    public void setGeneral_fund_2_0(java.lang.String v)
    {
        this.general_fund_2_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_2_0()
    {
        return all_non_dedicated_funds_2_0;
    }

    public void setAll_non_dedicated_funds_2_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_2_0 = v;
    }

    public java.lang.String getEnd_of_period_2_0()
    {
        return end_of_period_2_0;
    }

    public void setEnd_of_period_2_0(java.lang.String v)
    {
        this.end_of_period_2_0 = v;
    }

    public java.lang.String getGeneral_fund_3_0()
    {
        return general_fund_3_0;
    }

    public void setGeneral_fund_3_0(java.lang.String v)
    {
        this.general_fund_3_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_3_0()
    {
        return all_non_dedicated_funds_3_0;
    }

    public void setAll_non_dedicated_funds_3_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_3_0 = v;
    }

    public java.lang.String getEnd_of_period_3_0()
    {
        return end_of_period_3_0;
    }

    public void setEnd_of_period_3_0(java.lang.String v)
    {
        this.end_of_period_3_0 = v;
    }

    public java.lang.String getGeneral_fund_4_0()
    {
        return general_fund_4_0;
    }

    public void setGeneral_fund_4_0(java.lang.String v)
    {
        this.general_fund_4_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_4_0()
    {
        return all_non_dedicated_funds_4_0;
    }

    public void setAll_non_dedicated_funds_4_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_4_0 = v;
    }

    public java.lang.String getEnd_of_period_4_0()
    {
        return end_of_period_4_0;
    }

    public void setEnd_of_period_4_0(java.lang.String v)
    {
        this.end_of_period_4_0 = v;
    }

    public java.lang.String getGeneral_fund_5_0()
    {
        return general_fund_5_0;
    }

    public void setGeneral_fund_5_0(java.lang.String v)
    {
        this.general_fund_5_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_5_0()
    {
        return all_non_dedicated_funds_5_0;
    }

    public void setAll_non_dedicated_funds_5_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_5_0 = v;
    }

    public java.lang.String getEnd_of_period_5_0()
    {
        return end_of_period_5_0;
    }

    public void setEnd_of_period_5_0(java.lang.String v)
    {
        this.end_of_period_5_0 = v;
    }

    public java.lang.String getGeneral_fund_6_0()
    {
        return general_fund_6_0;
    }

    public void setGeneral_fund_6_0(java.lang.String v)
    {
        this.general_fund_6_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_6_0()
    {
        return all_non_dedicated_funds_6_0;
    }

    public void setAll_non_dedicated_funds_6_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_6_0 = v;
    }

    public java.lang.String getEnd_of_period_6_0()
    {
        return end_of_period_6_0;
    }

    public void setEnd_of_period_6_0(java.lang.String v)
    {
        this.end_of_period_6_0 = v;
    }

    public java.lang.String getGeneral_fund_7_0()
    {
        return general_fund_7_0;
    }

    public void setGeneral_fund_7_0(java.lang.String v)
    {
        this.general_fund_7_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_7_0()
    {
        return all_non_dedicated_funds_7_0;
    }

    public void setAll_non_dedicated_funds_7_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_7_0 = v;
    }

    public java.lang.String getEnd_of_period_7_0()
    {
        return end_of_period_7_0;
    }

    public void setEnd_of_period_7_0(java.lang.String v)
    {
        this.end_of_period_7_0 = v;
    }

    public java.lang.String getGeneral_fund_8_0()
    {
        return general_fund_8_0;
    }

    public void setGeneral_fund_8_0(java.lang.String v)
    {
        this.general_fund_8_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_8_0()
    {
        return all_non_dedicated_funds_8_0;
    }

    public void setAll_non_dedicated_funds_8_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_8_0 = v;
    }

    public java.lang.String getEnd_of_period_8_0()
    {
        return end_of_period_8_0;
    }

    public void setEnd_of_period_8_0(java.lang.String v)
    {
        this.end_of_period_8_0 = v;
    }

    public java.lang.String getGeneral_fund_9_0()
    {
        return general_fund_9_0;
    }

    public void setGeneral_fund_9_0(java.lang.String v)
    {
        this.general_fund_9_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_9_0()
    {
        return all_non_dedicated_funds_9_0;
    }

    public void setAll_non_dedicated_funds_9_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_9_0 = v;
    }

    public java.lang.String getEnd_of_period_9_0()
    {
        return end_of_period_9_0;
    }

    public void setEnd_of_period_9_0(java.lang.String v)
    {
        this.end_of_period_9_0 = v;
    }

    public java.lang.String getGeneral_fund_10_0()
    {
        return general_fund_10_0;
    }

    public void setGeneral_fund_10_0(java.lang.String v)
    {
        this.general_fund_10_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_10_0()
    {
        return all_non_dedicated_funds_10_0;
    }

    public void setAll_non_dedicated_funds_10_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_10_0 = v;
    }

    public java.lang.String getEnd_of_period_10_0()
    {
        return end_of_period_10_0;
    }

    public void setEnd_of_period_10_0(java.lang.String v)
    {
        this.end_of_period_10_0 = v;
    }

    public java.lang.String getGeneral_fund_11_0()
    {
        return general_fund_11_0;
    }

    public void setGeneral_fund_11_0(java.lang.String v)
    {
        this.general_fund_11_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_11_0()
    {
        return all_non_dedicated_funds_11_0;
    }

    public void setAll_non_dedicated_funds_11_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_11_0 = v;
    }

    public java.lang.String getEnd_of_period_11_0()
    {
        return end_of_period_11_0;
    }

    public void setEnd_of_period_11_0(java.lang.String v)
    {
        this.end_of_period_11_0 = v;
    }

    public java.lang.String getGeneral_fund_12_0()
    {
        return general_fund_12_0;
    }

    public void setGeneral_fund_12_0(java.lang.String v)
    {
        this.general_fund_12_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_12_0()
    {
        return all_non_dedicated_funds_12_0;
    }

    public void setAll_non_dedicated_funds_12_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_12_0 = v;
    }

    public java.lang.String getEnd_of_period_12_0()
    {
        return end_of_period_12_0;
    }

    public void setEnd_of_period_12_0(java.lang.String v)
    {
        this.end_of_period_12_0 = v;
    }

    public java.lang.String getGeneral_fund_13_0()
    {
        return general_fund_13_0;
    }

    public void setGeneral_fund_13_0(java.lang.String v)
    {
        this.general_fund_13_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_13_0()
    {
        return all_non_dedicated_funds_13_0;
    }

    public void setAll_non_dedicated_funds_13_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_13_0 = v;
    }

    public java.lang.String getEnd_of_period_13_0()
    {
        return end_of_period_13_0;
    }

    public void setEnd_of_period_13_0(java.lang.String v)
    {
        this.end_of_period_13_0 = v;
    }

    public java.lang.String getGeneral_fund_14_0()
    {
        return general_fund_14_0;
    }

    public void setGeneral_fund_14_0(java.lang.String v)
    {
        this.general_fund_14_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_14_0()
    {
        return all_non_dedicated_funds_14_0;
    }

    public void setAll_non_dedicated_funds_14_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_14_0 = v;
    }

    public java.lang.String getEnd_of_period_14_0()
    {
        return end_of_period_14_0;
    }

    public void setEnd_of_period_14_0(java.lang.String v)
    {
        this.end_of_period_14_0 = v;
    }

    public java.lang.String getGeneral_fund_15_0()
    {
        return general_fund_15_0;
    }

    public void setGeneral_fund_15_0(java.lang.String v)
    {
        this.general_fund_15_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_15_0()
    {
        return all_non_dedicated_funds_15_0;
    }

    public void setAll_non_dedicated_funds_15_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_15_0 = v;
    }

    public java.lang.String getEnd_of_period_15_0()
    {
        return end_of_period_15_0;
    }

    public void setEnd_of_period_15_0(java.lang.String v)
    {
        this.end_of_period_15_0 = v;
    }

    public java.lang.String getGeneral_fund_16_0()
    {
        return general_fund_16_0;
    }

    public void setGeneral_fund_16_0(java.lang.String v)
    {
        this.general_fund_16_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_16_0()
    {
        return all_non_dedicated_funds_16_0;
    }

    public void setAll_non_dedicated_funds_16_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_16_0 = v;
    }

    public java.lang.String getEnd_of_period_16_0()
    {
        return end_of_period_16_0;
    }

    public void setEnd_of_period_16_0(java.lang.String v)
    {
        this.end_of_period_16_0 = v;
    }

    public java.lang.String getGeneral_fund_17_0()
    {
        return general_fund_17_0;
    }

    public void setGeneral_fund_17_0(java.lang.String v)
    {
        this.general_fund_17_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_17_0()
    {
        return all_non_dedicated_funds_17_0;
    }

    public void setAll_non_dedicated_funds_17_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_17_0 = v;
    }

    public java.lang.String getEnd_of_period_17_0()
    {
        return end_of_period_17_0;
    }

    public void setEnd_of_period_17_0(java.lang.String v)
    {
        this.end_of_period_17_0 = v;
    }

    public java.lang.String getGeneral_fund_18_0()
    {
        return general_fund_18_0;
    }

    public void setGeneral_fund_18_0(java.lang.String v)
    {
        this.general_fund_18_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_18_0()
    {
        return all_non_dedicated_funds_18_0;
    }

    public void setAll_non_dedicated_funds_18_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_18_0 = v;
    }

    public java.lang.String getEnd_of_period_18_0()
    {
        return end_of_period_18_0;
    }

    public void setEnd_of_period_18_0(java.lang.String v)
    {
        this.end_of_period_18_0 = v;
    }

    public java.lang.String getGeneral_fund_19_0()
    {
        return general_fund_19_0;
    }

    public void setGeneral_fund_19_0(java.lang.String v)
    {
        this.general_fund_19_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_19_0()
    {
        return all_non_dedicated_funds_19_0;
    }

    public void setAll_non_dedicated_funds_19_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_19_0 = v;
    }

    public java.lang.String getEnd_of_period_19_0()
    {
        return end_of_period_19_0;
    }

    public void setEnd_of_period_19_0(java.lang.String v)
    {
        this.end_of_period_19_0 = v;
    }

    public java.lang.String getGeneral_fund_20_0()
    {
        return general_fund_20_0;
    }

    public void setGeneral_fund_20_0(java.lang.String v)
    {
        this.general_fund_20_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_20_0()
    {
        return all_non_dedicated_funds_20_0;
    }

    public void setAll_non_dedicated_funds_20_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_20_0 = v;
    }

    public java.lang.String getEnd_of_period_20_0()
    {
        return end_of_period_20_0;
    }

    public void setEnd_of_period_20_0(java.lang.String v)
    {
        this.end_of_period_20_0 = v;
    }

    public java.lang.String getGeneral_fund_21_0()
    {
        return general_fund_21_0;
    }

    public void setGeneral_fund_21_0(java.lang.String v)
    {
        this.general_fund_21_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_21_0()
    {
        return all_non_dedicated_funds_21_0;
    }

    public void setAll_non_dedicated_funds_21_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_21_0 = v;
    }

    public java.lang.String getEnd_of_period_21_0()
    {
        return end_of_period_21_0;
    }

    public void setEnd_of_period_21_0(java.lang.String v)
    {
        this.end_of_period_21_0 = v;
    }

    public java.lang.String getGeneral_fund_22_0()
    {
        return general_fund_22_0;
    }

    public void setGeneral_fund_22_0(java.lang.String v)
    {
        this.general_fund_22_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_22_0()
    {
        return all_non_dedicated_funds_22_0;
    }

    public void setAll_non_dedicated_funds_22_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_22_0 = v;
    }

    public java.lang.String getEnd_of_period_22_0()
    {
        return end_of_period_22_0;
    }

    public void setEnd_of_period_22_0(java.lang.String v)
    {
        this.end_of_period_22_0 = v;
    }

    public java.lang.String getGeneral_fund_23_0()
    {
        return general_fund_23_0;
    }

    public void setGeneral_fund_23_0(java.lang.String v)
    {
        this.general_fund_23_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_23_0()
    {
        return all_non_dedicated_funds_23_0;
    }

    public void setAll_non_dedicated_funds_23_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_23_0 = v;
    }

    public java.lang.String getEnd_of_period_23_0()
    {
        return end_of_period_23_0;
    }

    public void setEnd_of_period_23_0(java.lang.String v)
    {
        this.end_of_period_23_0 = v;
    }

    public java.lang.String getGeneral_fund_24_0()
    {
        return general_fund_24_0;
    }

    public void setGeneral_fund_24_0(java.lang.String v)
    {
        this.general_fund_24_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_24_0()
    {
        return all_non_dedicated_funds_24_0;
    }

    public void setAll_non_dedicated_funds_24_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_24_0 = v;
    }

    public java.lang.String getEnd_of_period_24_0()
    {
        return end_of_period_24_0;
    }

    public void setEnd_of_period_24_0(java.lang.String v)
    {
        this.end_of_period_24_0 = v;
    }

    public java.lang.String getGeneral_fund_25_0()
    {
        return general_fund_25_0;
    }

    public void setGeneral_fund_25_0(java.lang.String v)
    {
        this.general_fund_25_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_25_0()
    {
        return all_non_dedicated_funds_25_0;
    }

    public void setAll_non_dedicated_funds_25_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_25_0 = v;
    }

    public java.lang.String getEnd_of_period_25_0()
    {
        return end_of_period_25_0;
    }

    public void setEnd_of_period_25_0(java.lang.String v)
    {
        this.end_of_period_25_0 = v;
    }

    public java.lang.String getGeneral_fund_26_0()
    {
        return general_fund_26_0;
    }

    public void setGeneral_fund_26_0(java.lang.String v)
    {
        this.general_fund_26_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_26_0()
    {
        return all_non_dedicated_funds_26_0;
    }

    public void setAll_non_dedicated_funds_26_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_26_0 = v;
    }

    public java.lang.String getEnd_of_period_26_0()
    {
        return end_of_period_26_0;
    }

    public void setEnd_of_period_26_0(java.lang.String v)
    {
        this.end_of_period_26_0 = v;
    }

    public java.lang.String getGeneral_fund_27_0()
    {
        return general_fund_27_0;
    }

    public void setGeneral_fund_27_0(java.lang.String v)
    {
        this.general_fund_27_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_27_0()
    {
        return all_non_dedicated_funds_27_0;
    }

    public void setAll_non_dedicated_funds_27_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_27_0 = v;
    }

    public java.lang.String getEnd_of_period_27_0()
    {
        return end_of_period_27_0;
    }

    public void setEnd_of_period_27_0(java.lang.String v)
    {
        this.end_of_period_27_0 = v;
    }

    public java.lang.String getGeneral_fund_28_0()
    {
        return general_fund_28_0;
    }

    public void setGeneral_fund_28_0(java.lang.String v)
    {
        this.general_fund_28_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_28_0()
    {
        return all_non_dedicated_funds_28_0;
    }

    public void setAll_non_dedicated_funds_28_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_28_0 = v;
    }

    public java.lang.String getEnd_of_period_28_0()
    {
        return end_of_period_28_0;
    }

    public void setEnd_of_period_28_0(java.lang.String v)
    {
        this.end_of_period_28_0 = v;
    }

    public java.lang.String getGeneral_fund_29_0()
    {
        return general_fund_29_0;
    }

    public void setGeneral_fund_29_0(java.lang.String v)
    {
        this.general_fund_29_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_29_0()
    {
        return all_non_dedicated_funds_29_0;
    }

    public void setAll_non_dedicated_funds_29_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_29_0 = v;
    }

    public java.lang.String getEnd_of_period_29_0()
    {
        return end_of_period_29_0;
    }

    public void setEnd_of_period_29_0(java.lang.String v)
    {
        this.end_of_period_29_0 = v;
    }

    public java.lang.String getGeneral_fund_30_0()
    {
        return general_fund_30_0;
    }

    public void setGeneral_fund_30_0(java.lang.String v)
    {
        this.general_fund_30_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_30_0()
    {
        return all_non_dedicated_funds_30_0;
    }

    public void setAll_non_dedicated_funds_30_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_30_0 = v;
    }

    public java.lang.String getEnd_of_period_30_0()
    {
        return end_of_period_30_0;
    }

    public void setEnd_of_period_30_0(java.lang.String v)
    {
        this.end_of_period_30_0 = v;
    }

    public java.lang.String getGeneral_fund_31_0()
    {
        return general_fund_31_0;
    }

    public void setGeneral_fund_31_0(java.lang.String v)
    {
        this.general_fund_31_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_31_0()
    {
        return all_non_dedicated_funds_31_0;
    }

    public void setAll_non_dedicated_funds_31_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_31_0 = v;
    }

    public java.lang.String getEnd_of_period_31_0()
    {
        return end_of_period_31_0;
    }

    public void setEnd_of_period_31_0(java.lang.String v)
    {
        this.end_of_period_31_0 = v;
    }

    public java.lang.String getGeneral_fund_32_0()
    {
        return general_fund_32_0;
    }

    public void setGeneral_fund_32_0(java.lang.String v)
    {
        this.general_fund_32_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_32_0()
    {
        return all_non_dedicated_funds_32_0;
    }

    public void setAll_non_dedicated_funds_32_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_32_0 = v;
    }

    public java.lang.String getEnd_of_period_32_0()
    {
        return end_of_period_32_0;
    }

    public void setEnd_of_period_32_0(java.lang.String v)
    {
        this.end_of_period_32_0 = v;
    }

    public java.lang.String getGeneral_fund_33_0()
    {
        return general_fund_33_0;
    }

    public void setGeneral_fund_33_0(java.lang.String v)
    {
        this.general_fund_33_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_33_0()
    {
        return all_non_dedicated_funds_33_0;
    }

    public void setAll_non_dedicated_funds_33_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_33_0 = v;
    }

    public java.lang.String getEnd_of_period_33_0()
    {
        return end_of_period_33_0;
    }

    public void setEnd_of_period_33_0(java.lang.String v)
    {
        this.end_of_period_33_0 = v;
    }

    public java.lang.String getGeneral_fund_34_0()
    {
        return general_fund_34_0;
    }

    public void setGeneral_fund_34_0(java.lang.String v)
    {
        this.general_fund_34_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_34_0()
    {
        return all_non_dedicated_funds_34_0;
    }

    public void setAll_non_dedicated_funds_34_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_34_0 = v;
    }

    public java.lang.String getEnd_of_period_34_0()
    {
        return end_of_period_34_0;
    }

    public void setEnd_of_period_34_0(java.lang.String v)
    {
        this.end_of_period_34_0 = v;
    }

    public java.lang.String getGeneral_fund_35_0()
    {
        return general_fund_35_0;
    }

    public void setGeneral_fund_35_0(java.lang.String v)
    {
        this.general_fund_35_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_35_0()
    {
        return all_non_dedicated_funds_35_0;
    }

    public void setAll_non_dedicated_funds_35_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_35_0 = v;
    }

    public java.lang.String getEnd_of_period_35_0()
    {
        return end_of_period_35_0;
    }

    public void setEnd_of_period_35_0(java.lang.String v)
    {
        this.end_of_period_35_0 = v;
    }

    public java.lang.String getGeneral_fund_36_0()
    {
        return general_fund_36_0;
    }

    public void setGeneral_fund_36_0(java.lang.String v)
    {
        this.general_fund_36_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_36_0()
    {
        return all_non_dedicated_funds_36_0;
    }

    public void setAll_non_dedicated_funds_36_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_36_0 = v;
    }

    public java.lang.String getEnd_of_period_36_0()
    {
        return end_of_period_36_0;
    }

    public void setEnd_of_period_36_0(java.lang.String v)
    {
        this.end_of_period_36_0 = v;
    }

    public java.lang.String getGeneral_fund_37_0()
    {
        return general_fund_37_0;
    }

    public void setGeneral_fund_37_0(java.lang.String v)
    {
        this.general_fund_37_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_37_0()
    {
        return all_non_dedicated_funds_37_0;
    }

    public void setAll_non_dedicated_funds_37_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_37_0 = v;
    }

    public java.lang.String getEnd_of_period_37_0()
    {
        return end_of_period_37_0;
    }

    public void setEnd_of_period_37_0(java.lang.String v)
    {
        this.end_of_period_37_0 = v;
    }

    public java.lang.String getGeneral_fund_38_0()
    {
        return general_fund_38_0;
    }

    public void setGeneral_fund_38_0(java.lang.String v)
    {
        this.general_fund_38_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_38_0()
    {
        return all_non_dedicated_funds_38_0;
    }

    public void setAll_non_dedicated_funds_38_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_38_0 = v;
    }

    public java.lang.String getEnd_of_period_38_0()
    {
        return end_of_period_38_0;
    }

    public void setEnd_of_period_38_0(java.lang.String v)
    {
        this.end_of_period_38_0 = v;
    }

    public java.lang.String getGeneral_fund_39_0()
    {
        return general_fund_39_0;
    }

    public void setGeneral_fund_39_0(java.lang.String v)
    {
        this.general_fund_39_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_39_0()
    {
        return all_non_dedicated_funds_39_0;
    }

    public void setAll_non_dedicated_funds_39_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_39_0 = v;
    }

    public java.lang.String getEnd_of_period_39_0()
    {
        return end_of_period_39_0;
    }

    public void setEnd_of_period_39_0(java.lang.String v)
    {
        this.end_of_period_39_0 = v;
    }

    public java.lang.String getGeneral_fund_40_0()
    {
        return general_fund_40_0;
    }

    public void setGeneral_fund_40_0(java.lang.String v)
    {
        this.general_fund_40_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_40_0()
    {
        return all_non_dedicated_funds_40_0;
    }

    public void setAll_non_dedicated_funds_40_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_40_0 = v;
    }

    public java.lang.String getEnd_of_period_40_0()
    {
        return end_of_period_40_0;
    }

    public void setEnd_of_period_40_0(java.lang.String v)
    {
        this.end_of_period_40_0 = v;
    }

    public java.lang.String getGeneral_fund_41_0()
    {
        return general_fund_41_0;
    }

    public void setGeneral_fund_41_0(java.lang.String v)
    {
        this.general_fund_41_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_41_0()
    {
        return all_non_dedicated_funds_41_0;
    }

    public void setAll_non_dedicated_funds_41_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_41_0 = v;
    }

    public java.lang.String getEnd_of_period_41_0()
    {
        return end_of_period_41_0;
    }

    public void setEnd_of_period_41_0(java.lang.String v)
    {
        this.end_of_period_41_0 = v;
    }

    public java.lang.String getGeneral_fund_42_0()
    {
        return general_fund_42_0;
    }

    public void setGeneral_fund_42_0(java.lang.String v)
    {
        this.general_fund_42_0 = v;
    }

    public java.lang.String getAll_non_dedicated_funds_42_0()
    {
        return all_non_dedicated_funds_42_0;
    }

    public void setAll_non_dedicated_funds_42_0(java.lang.String v)
    {
        this.all_non_dedicated_funds_42_0 = v;
    }

    public java.lang.String getEnd_of_period_42_0()
    {
        return end_of_period_42_0;
    }

    public void setEnd_of_period_42_0(java.lang.String v)
    {
        this.end_of_period_42_0 = v;
    }

    public java.lang.Double getEnd_of_period_total()
    {
        return end_of_period_total;
    }

    public void setEnd_of_period_total(java.lang.Double v)
    {
        this.end_of_period_total = v;
    }

    public FUNDS_14Bean()
    {
    }

}
