package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet CONTACT_INFO_1 */
public class CONTACT_INFO_1Bean
{

    private java.lang.Double contact_info_1_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String warrant_end_date;
    private java.lang.String warrant_end_date_2;
    private java.lang.String warrant_end_date_3;
    private java.lang.String warrant_end_date_4;
    private java.lang.String warrant_end_date_5;
    private java.lang.Double legal_name;
    private java.lang.String if_contents_c_10_contents_c_10_street_address;
    private java.lang.String street_address;
    private java.lang.String street_address_2;
    private java.lang.String street_address_3;
    private java.lang.String street_address_4;
    private java.lang.String if_contents_c_10_contents_c_10_city;
    private java.lang.String state_or_province;
    private java.lang.String zip_or_postal_code;
    private java.lang.String if_contents_c_10_contents_c_10_home_telephone;
    private java.lang.String alternate_phone;
    private java.lang.String zip_or_postal_code_alternate_phone;
    private java.lang.String alternate_phone_2;
    private java.lang.String if_contents_c_10_contents_c_10_internet_or_e_mail_address_required_if_available;
    private java.lang.String alternate_phone_internet_or_e_mail_address_required_if_available;
    private java.lang.String internet_or_e_mail_address_required_if_available;
    private java.lang.String membership;
    private java.lang.String if_contents_c_10_contents_c_10_sca_name;
    private java.lang.String alternate_phone_sca_name;
    private java.lang.String sca_name;
    private java.lang.String exp_date;
    private java.lang.String if_contents_c_10_contents_c_10_po_box_address;
    private java.lang.String alternate_phone_po_box_address;
    private java.lang.String po_box_address;
    private java.lang.String exp_date_po_box_address;
    private java.lang.String po_box_address_2;
    private java.lang.String if_contents_c_10_contents_c_10_city_2;
    private java.lang.String state_or_province_2;
    private java.lang.String zip_or_postal_code_2;
    private java.lang.String state_or_province_deputy_for;
    private java.lang.String deputy_for;
    private java.lang.String zip_or_postal_code_deputy_for;
    private java.lang.String deputy_for_2;
    private java.lang.String deputy_for_legal_name;
    private java.lang.String state_or_province_legal_name;
    private java.lang.String legal_name_2;
    private java.lang.String zip_or_postal_code_legal_name;
    private java.lang.String legal_name_3;
    private java.lang.String deputy_for_street_address;
    private java.lang.String state_or_province_street_address;
    private java.lang.String street_address_5;
    private java.lang.String zip_or_postal_code_street_address;
    private java.lang.String street_address_6;
    private java.lang.String deputy_for_city;
    private java.lang.String state_or_province_3;
    private java.lang.String zip_or_postal_code_3;
    private java.lang.String deputy_for_home_telephone;
    private java.lang.String alternate_phone_3;
    private java.lang.String zip_or_postal_code_alternate_phone_2;
    private java.lang.String alternate_phone_4;
    private java.lang.String deputy_for_internet_or_e_mail_address_required_if_available;
    private java.lang.String alternate_phone_internet_or_e_mail_address_required_if_available_2;
    private java.lang.String internet_or_e_mail_address_required_if_available_2;
    private java.lang.String membership_2;
    private java.lang.String deputy_for_sca_name;
    private java.lang.String alternate_phone_sca_name_2;
    private java.lang.String sca_name_2;
    private java.lang.String exp_date_2;
    private java.lang.String alternate_phone_deputy_for;
    private java.lang.String deputy_for_3;
    private java.lang.String exp_date_deputy_for;
    private java.lang.String deputy_for_4;
    private java.lang.String deputy_for_legal_name_2;
    private java.lang.String alternate_phone_legal_name;
    private java.lang.String legal_name_4;
    private java.lang.String exp_date_legal_name;
    private java.lang.String legal_name_5;
    private java.lang.String deputy_for_street_address_2;
    private java.lang.String alternate_phone_street_address;
    private java.lang.String street_address_7;
    private java.lang.String exp_date_street_address;
    private java.lang.String street_address_8;
    private java.lang.String deputy_for_city_2;
    private java.lang.String state_or_province_4;
    private java.lang.String zip_or_postal_code_4;
    private java.lang.String deputy_for_home_telephone_2;
    private java.lang.String alternate_phone_5;
    private java.lang.String zip_or_postal_code_alternate_phone_3;
    private java.lang.String alternate_phone_6;
    private java.lang.String deputy_for_internet_or_e_mail_address_required_if_available_2;
    private java.lang.String alternate_phone_internet_or_e_mail_address_required_if_available_3;
    private java.lang.String internet_or_e_mail_address_required_if_available_3;
    private java.lang.String membership_3;
    private java.lang.String deputy_for_sca_name_2;
    private java.lang.String alternate_phone_sca_name_3;
    private java.lang.String sca_name_3;
    private java.lang.String exp_date_3;
    private java.lang.Double _1;

    public java.lang.Double getContact_info_1_r2c3()
    {
        return contact_info_1_r2c3;
    }

    public void setContact_info_1_r2c3(java.lang.Double v)
    {
        this.contact_info_1_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getWarrant_end_date()
    {
        return warrant_end_date;
    }

    public void setWarrant_end_date(java.lang.String v)
    {
        this.warrant_end_date = v;
    }

    public java.lang.String getWarrant_end_date_2()
    {
        return warrant_end_date_2;
    }

    public void setWarrant_end_date_2(java.lang.String v)
    {
        this.warrant_end_date_2 = v;
    }

    public java.lang.String getWarrant_end_date_3()
    {
        return warrant_end_date_3;
    }

    public void setWarrant_end_date_3(java.lang.String v)
    {
        this.warrant_end_date_3 = v;
    }

    public java.lang.String getWarrant_end_date_4()
    {
        return warrant_end_date_4;
    }

    public void setWarrant_end_date_4(java.lang.String v)
    {
        this.warrant_end_date_4 = v;
    }

    public java.lang.String getWarrant_end_date_5()
    {
        return warrant_end_date_5;
    }

    public void setWarrant_end_date_5(java.lang.String v)
    {
        this.warrant_end_date_5 = v;
    }

    public java.lang.Double getLegal_name()
    {
        return legal_name;
    }

    public void setLegal_name(java.lang.Double v)
    {
        this.legal_name = v;
    }

    public java.lang.String getIf_contents_c_10_contents_c_10_street_address()
    {
        return if_contents_c_10_contents_c_10_street_address;
    }

    public void setIf_contents_c_10_contents_c_10_street_address(java.lang.String v)
    {
        this.if_contents_c_10_contents_c_10_street_address = v;
    }

    public java.lang.String getStreet_address()
    {
        return street_address;
    }

    public void setStreet_address(java.lang.String v)
    {
        this.street_address = v;
    }

    public java.lang.String getStreet_address_2()
    {
        return street_address_2;
    }

    public void setStreet_address_2(java.lang.String v)
    {
        this.street_address_2 = v;
    }

    public java.lang.String getStreet_address_3()
    {
        return street_address_3;
    }

    public void setStreet_address_3(java.lang.String v)
    {
        this.street_address_3 = v;
    }

    public java.lang.String getStreet_address_4()
    {
        return street_address_4;
    }

    public void setStreet_address_4(java.lang.String v)
    {
        this.street_address_4 = v;
    }

    public java.lang.String getIf_contents_c_10_contents_c_10_city()
    {
        return if_contents_c_10_contents_c_10_city;
    }

    public void setIf_contents_c_10_contents_c_10_city(java.lang.String v)
    {
        this.if_contents_c_10_contents_c_10_city = v;
    }

    public java.lang.String getState_or_province()
    {
        return state_or_province;
    }

    public void setState_or_province(java.lang.String v)
    {
        this.state_or_province = v;
    }

    public java.lang.String getZip_or_postal_code()
    {
        return zip_or_postal_code;
    }

    public void setZip_or_postal_code(java.lang.String v)
    {
        this.zip_or_postal_code = v;
    }

    public java.lang.String getIf_contents_c_10_contents_c_10_home_telephone()
    {
        return if_contents_c_10_contents_c_10_home_telephone;
    }

    public void setIf_contents_c_10_contents_c_10_home_telephone(java.lang.String v)
    {
        this.if_contents_c_10_contents_c_10_home_telephone = v;
    }

    public java.lang.String getAlternate_phone()
    {
        return alternate_phone;
    }

    public void setAlternate_phone(java.lang.String v)
    {
        this.alternate_phone = v;
    }

    public java.lang.String getZip_or_postal_code_alternate_phone()
    {
        return zip_or_postal_code_alternate_phone;
    }

    public void setZip_or_postal_code_alternate_phone(java.lang.String v)
    {
        this.zip_or_postal_code_alternate_phone = v;
    }

    public java.lang.String getAlternate_phone_2()
    {
        return alternate_phone_2;
    }

    public void setAlternate_phone_2(java.lang.String v)
    {
        this.alternate_phone_2 = v;
    }

    public java.lang.String getIf_contents_c_10_contents_c_10_internet_or_e_mail_address_required_if_available()
    {
        return if_contents_c_10_contents_c_10_internet_or_e_mail_address_required_if_available;
    }

    public void setIf_contents_c_10_contents_c_10_internet_or_e_mail_address_required_if_available(java.lang.String v)
    {
        this.if_contents_c_10_contents_c_10_internet_or_e_mail_address_required_if_available = v;
    }

    public java.lang.String getAlternate_phone_internet_or_e_mail_address_required_if_available()
    {
        return alternate_phone_internet_or_e_mail_address_required_if_available;
    }

    public void setAlternate_phone_internet_or_e_mail_address_required_if_available(java.lang.String v)
    {
        this.alternate_phone_internet_or_e_mail_address_required_if_available = v;
    }

    public java.lang.String getInternet_or_e_mail_address_required_if_available()
    {
        return internet_or_e_mail_address_required_if_available;
    }

    public void setInternet_or_e_mail_address_required_if_available(java.lang.String v)
    {
        this.internet_or_e_mail_address_required_if_available = v;
    }

    public java.lang.String getMembership()
    {
        return membership;
    }

    public void setMembership(java.lang.String v)
    {
        this.membership = v;
    }

    public java.lang.String getIf_contents_c_10_contents_c_10_sca_name()
    {
        return if_contents_c_10_contents_c_10_sca_name;
    }

    public void setIf_contents_c_10_contents_c_10_sca_name(java.lang.String v)
    {
        this.if_contents_c_10_contents_c_10_sca_name = v;
    }

    public java.lang.String getAlternate_phone_sca_name()
    {
        return alternate_phone_sca_name;
    }

    public void setAlternate_phone_sca_name(java.lang.String v)
    {
        this.alternate_phone_sca_name = v;
    }

    public java.lang.String getSca_name()
    {
        return sca_name;
    }

    public void setSca_name(java.lang.String v)
    {
        this.sca_name = v;
    }

    public java.lang.String getExp_date()
    {
        return exp_date;
    }

    public void setExp_date(java.lang.String v)
    {
        this.exp_date = v;
    }

    public java.lang.String getIf_contents_c_10_contents_c_10_po_box_address()
    {
        return if_contents_c_10_contents_c_10_po_box_address;
    }

    public void setIf_contents_c_10_contents_c_10_po_box_address(java.lang.String v)
    {
        this.if_contents_c_10_contents_c_10_po_box_address = v;
    }

    public java.lang.String getAlternate_phone_po_box_address()
    {
        return alternate_phone_po_box_address;
    }

    public void setAlternate_phone_po_box_address(java.lang.String v)
    {
        this.alternate_phone_po_box_address = v;
    }

    public java.lang.String getPo_box_address()
    {
        return po_box_address;
    }

    public void setPo_box_address(java.lang.String v)
    {
        this.po_box_address = v;
    }

    public java.lang.String getExp_date_po_box_address()
    {
        return exp_date_po_box_address;
    }

    public void setExp_date_po_box_address(java.lang.String v)
    {
        this.exp_date_po_box_address = v;
    }

    public java.lang.String getPo_box_address_2()
    {
        return po_box_address_2;
    }

    public void setPo_box_address_2(java.lang.String v)
    {
        this.po_box_address_2 = v;
    }

    public java.lang.String getIf_contents_c_10_contents_c_10_city_2()
    {
        return if_contents_c_10_contents_c_10_city_2;
    }

    public void setIf_contents_c_10_contents_c_10_city_2(java.lang.String v)
    {
        this.if_contents_c_10_contents_c_10_city_2 = v;
    }

    public java.lang.String getState_or_province_2()
    {
        return state_or_province_2;
    }

    public void setState_or_province_2(java.lang.String v)
    {
        this.state_or_province_2 = v;
    }

    public java.lang.String getZip_or_postal_code_2()
    {
        return zip_or_postal_code_2;
    }

    public void setZip_or_postal_code_2(java.lang.String v)
    {
        this.zip_or_postal_code_2 = v;
    }

    public java.lang.String getState_or_province_deputy_for()
    {
        return state_or_province_deputy_for;
    }

    public void setState_or_province_deputy_for(java.lang.String v)
    {
        this.state_or_province_deputy_for = v;
    }

    public java.lang.String getDeputy_for()
    {
        return deputy_for;
    }

    public void setDeputy_for(java.lang.String v)
    {
        this.deputy_for = v;
    }

    public java.lang.String getZip_or_postal_code_deputy_for()
    {
        return zip_or_postal_code_deputy_for;
    }

    public void setZip_or_postal_code_deputy_for(java.lang.String v)
    {
        this.zip_or_postal_code_deputy_for = v;
    }

    public java.lang.String getDeputy_for_2()
    {
        return deputy_for_2;
    }

    public void setDeputy_for_2(java.lang.String v)
    {
        this.deputy_for_2 = v;
    }

    public java.lang.String getDeputy_for_legal_name()
    {
        return deputy_for_legal_name;
    }

    public void setDeputy_for_legal_name(java.lang.String v)
    {
        this.deputy_for_legal_name = v;
    }

    public java.lang.String getState_or_province_legal_name()
    {
        return state_or_province_legal_name;
    }

    public void setState_or_province_legal_name(java.lang.String v)
    {
        this.state_or_province_legal_name = v;
    }

    public java.lang.String getLegal_name_2()
    {
        return legal_name_2;
    }

    public void setLegal_name_2(java.lang.String v)
    {
        this.legal_name_2 = v;
    }

    public java.lang.String getZip_or_postal_code_legal_name()
    {
        return zip_or_postal_code_legal_name;
    }

    public void setZip_or_postal_code_legal_name(java.lang.String v)
    {
        this.zip_or_postal_code_legal_name = v;
    }

    public java.lang.String getLegal_name_3()
    {
        return legal_name_3;
    }

    public void setLegal_name_3(java.lang.String v)
    {
        this.legal_name_3 = v;
    }

    public java.lang.String getDeputy_for_street_address()
    {
        return deputy_for_street_address;
    }

    public void setDeputy_for_street_address(java.lang.String v)
    {
        this.deputy_for_street_address = v;
    }

    public java.lang.String getState_or_province_street_address()
    {
        return state_or_province_street_address;
    }

    public void setState_or_province_street_address(java.lang.String v)
    {
        this.state_or_province_street_address = v;
    }

    public java.lang.String getStreet_address_5()
    {
        return street_address_5;
    }

    public void setStreet_address_5(java.lang.String v)
    {
        this.street_address_5 = v;
    }

    public java.lang.String getZip_or_postal_code_street_address()
    {
        return zip_or_postal_code_street_address;
    }

    public void setZip_or_postal_code_street_address(java.lang.String v)
    {
        this.zip_or_postal_code_street_address = v;
    }

    public java.lang.String getStreet_address_6()
    {
        return street_address_6;
    }

    public void setStreet_address_6(java.lang.String v)
    {
        this.street_address_6 = v;
    }

    public java.lang.String getDeputy_for_city()
    {
        return deputy_for_city;
    }

    public void setDeputy_for_city(java.lang.String v)
    {
        this.deputy_for_city = v;
    }

    public java.lang.String getState_or_province_3()
    {
        return state_or_province_3;
    }

    public void setState_or_province_3(java.lang.String v)
    {
        this.state_or_province_3 = v;
    }

    public java.lang.String getZip_or_postal_code_3()
    {
        return zip_or_postal_code_3;
    }

    public void setZip_or_postal_code_3(java.lang.String v)
    {
        this.zip_or_postal_code_3 = v;
    }

    public java.lang.String getDeputy_for_home_telephone()
    {
        return deputy_for_home_telephone;
    }

    public void setDeputy_for_home_telephone(java.lang.String v)
    {
        this.deputy_for_home_telephone = v;
    }

    public java.lang.String getAlternate_phone_3()
    {
        return alternate_phone_3;
    }

    public void setAlternate_phone_3(java.lang.String v)
    {
        this.alternate_phone_3 = v;
    }

    public java.lang.String getZip_or_postal_code_alternate_phone_2()
    {
        return zip_or_postal_code_alternate_phone_2;
    }

    public void setZip_or_postal_code_alternate_phone_2(java.lang.String v)
    {
        this.zip_or_postal_code_alternate_phone_2 = v;
    }

    public java.lang.String getAlternate_phone_4()
    {
        return alternate_phone_4;
    }

    public void setAlternate_phone_4(java.lang.String v)
    {
        this.alternate_phone_4 = v;
    }

    public java.lang.String getDeputy_for_internet_or_e_mail_address_required_if_available()
    {
        return deputy_for_internet_or_e_mail_address_required_if_available;
    }

    public void setDeputy_for_internet_or_e_mail_address_required_if_available(java.lang.String v)
    {
        this.deputy_for_internet_or_e_mail_address_required_if_available = v;
    }

    public java.lang.String getAlternate_phone_internet_or_e_mail_address_required_if_available_2()
    {
        return alternate_phone_internet_or_e_mail_address_required_if_available_2;
    }

    public void setAlternate_phone_internet_or_e_mail_address_required_if_available_2(java.lang.String v)
    {
        this.alternate_phone_internet_or_e_mail_address_required_if_available_2 = v;
    }

    public java.lang.String getInternet_or_e_mail_address_required_if_available_2()
    {
        return internet_or_e_mail_address_required_if_available_2;
    }

    public void setInternet_or_e_mail_address_required_if_available_2(java.lang.String v)
    {
        this.internet_or_e_mail_address_required_if_available_2 = v;
    }

    public java.lang.String getMembership_2()
    {
        return membership_2;
    }

    public void setMembership_2(java.lang.String v)
    {
        this.membership_2 = v;
    }

    public java.lang.String getDeputy_for_sca_name()
    {
        return deputy_for_sca_name;
    }

    public void setDeputy_for_sca_name(java.lang.String v)
    {
        this.deputy_for_sca_name = v;
    }

    public java.lang.String getAlternate_phone_sca_name_2()
    {
        return alternate_phone_sca_name_2;
    }

    public void setAlternate_phone_sca_name_2(java.lang.String v)
    {
        this.alternate_phone_sca_name_2 = v;
    }

    public java.lang.String getSca_name_2()
    {
        return sca_name_2;
    }

    public void setSca_name_2(java.lang.String v)
    {
        this.sca_name_2 = v;
    }

    public java.lang.String getExp_date_2()
    {
        return exp_date_2;
    }

    public void setExp_date_2(java.lang.String v)
    {
        this.exp_date_2 = v;
    }

    public java.lang.String getAlternate_phone_deputy_for()
    {
        return alternate_phone_deputy_for;
    }

    public void setAlternate_phone_deputy_for(java.lang.String v)
    {
        this.alternate_phone_deputy_for = v;
    }

    public java.lang.String getDeputy_for_3()
    {
        return deputy_for_3;
    }

    public void setDeputy_for_3(java.lang.String v)
    {
        this.deputy_for_3 = v;
    }

    public java.lang.String getExp_date_deputy_for()
    {
        return exp_date_deputy_for;
    }

    public void setExp_date_deputy_for(java.lang.String v)
    {
        this.exp_date_deputy_for = v;
    }

    public java.lang.String getDeputy_for_4()
    {
        return deputy_for_4;
    }

    public void setDeputy_for_4(java.lang.String v)
    {
        this.deputy_for_4 = v;
    }

    public java.lang.String getDeputy_for_legal_name_2()
    {
        return deputy_for_legal_name_2;
    }

    public void setDeputy_for_legal_name_2(java.lang.String v)
    {
        this.deputy_for_legal_name_2 = v;
    }

    public java.lang.String getAlternate_phone_legal_name()
    {
        return alternate_phone_legal_name;
    }

    public void setAlternate_phone_legal_name(java.lang.String v)
    {
        this.alternate_phone_legal_name = v;
    }

    public java.lang.String getLegal_name_4()
    {
        return legal_name_4;
    }

    public void setLegal_name_4(java.lang.String v)
    {
        this.legal_name_4 = v;
    }

    public java.lang.String getExp_date_legal_name()
    {
        return exp_date_legal_name;
    }

    public void setExp_date_legal_name(java.lang.String v)
    {
        this.exp_date_legal_name = v;
    }

    public java.lang.String getLegal_name_5()
    {
        return legal_name_5;
    }

    public void setLegal_name_5(java.lang.String v)
    {
        this.legal_name_5 = v;
    }

    public java.lang.String getDeputy_for_street_address_2()
    {
        return deputy_for_street_address_2;
    }

    public void setDeputy_for_street_address_2(java.lang.String v)
    {
        this.deputy_for_street_address_2 = v;
    }

    public java.lang.String getAlternate_phone_street_address()
    {
        return alternate_phone_street_address;
    }

    public void setAlternate_phone_street_address(java.lang.String v)
    {
        this.alternate_phone_street_address = v;
    }

    public java.lang.String getStreet_address_7()
    {
        return street_address_7;
    }

    public void setStreet_address_7(java.lang.String v)
    {
        this.street_address_7 = v;
    }

    public java.lang.String getExp_date_street_address()
    {
        return exp_date_street_address;
    }

    public void setExp_date_street_address(java.lang.String v)
    {
        this.exp_date_street_address = v;
    }

    public java.lang.String getStreet_address_8()
    {
        return street_address_8;
    }

    public void setStreet_address_8(java.lang.String v)
    {
        this.street_address_8 = v;
    }

    public java.lang.String getDeputy_for_city_2()
    {
        return deputy_for_city_2;
    }

    public void setDeputy_for_city_2(java.lang.String v)
    {
        this.deputy_for_city_2 = v;
    }

    public java.lang.String getState_or_province_4()
    {
        return state_or_province_4;
    }

    public void setState_or_province_4(java.lang.String v)
    {
        this.state_or_province_4 = v;
    }

    public java.lang.String getZip_or_postal_code_4()
    {
        return zip_or_postal_code_4;
    }

    public void setZip_or_postal_code_4(java.lang.String v)
    {
        this.zip_or_postal_code_4 = v;
    }

    public java.lang.String getDeputy_for_home_telephone_2()
    {
        return deputy_for_home_telephone_2;
    }

    public void setDeputy_for_home_telephone_2(java.lang.String v)
    {
        this.deputy_for_home_telephone_2 = v;
    }

    public java.lang.String getAlternate_phone_5()
    {
        return alternate_phone_5;
    }

    public void setAlternate_phone_5(java.lang.String v)
    {
        this.alternate_phone_5 = v;
    }

    public java.lang.String getZip_or_postal_code_alternate_phone_3()
    {
        return zip_or_postal_code_alternate_phone_3;
    }

    public void setZip_or_postal_code_alternate_phone_3(java.lang.String v)
    {
        this.zip_or_postal_code_alternate_phone_3 = v;
    }

    public java.lang.String getAlternate_phone_6()
    {
        return alternate_phone_6;
    }

    public void setAlternate_phone_6(java.lang.String v)
    {
        this.alternate_phone_6 = v;
    }

    public java.lang.String getDeputy_for_internet_or_e_mail_address_required_if_available_2()
    {
        return deputy_for_internet_or_e_mail_address_required_if_available_2;
    }

    public void setDeputy_for_internet_or_e_mail_address_required_if_available_2(java.lang.String v)
    {
        this.deputy_for_internet_or_e_mail_address_required_if_available_2 = v;
    }

    public java.lang.String getAlternate_phone_internet_or_e_mail_address_required_if_available_3()
    {
        return alternate_phone_internet_or_e_mail_address_required_if_available_3;
    }

    public void setAlternate_phone_internet_or_e_mail_address_required_if_available_3(java.lang.String v)
    {
        this.alternate_phone_internet_or_e_mail_address_required_if_available_3 = v;
    }

    public java.lang.String getInternet_or_e_mail_address_required_if_available_3()
    {
        return internet_or_e_mail_address_required_if_available_3;
    }

    public void setInternet_or_e_mail_address_required_if_available_3(java.lang.String v)
    {
        this.internet_or_e_mail_address_required_if_available_3 = v;
    }

    public java.lang.String getMembership_3()
    {
        return membership_3;
    }

    public void setMembership_3(java.lang.String v)
    {
        this.membership_3 = v;
    }

    public java.lang.String getDeputy_for_sca_name_2()
    {
        return deputy_for_sca_name_2;
    }

    public void setDeputy_for_sca_name_2(java.lang.String v)
    {
        this.deputy_for_sca_name_2 = v;
    }

    public java.lang.String getAlternate_phone_sca_name_3()
    {
        return alternate_phone_sca_name_3;
    }

    public void setAlternate_phone_sca_name_3(java.lang.String v)
    {
        this.alternate_phone_sca_name_3 = v;
    }

    public java.lang.String getSca_name_3()
    {
        return sca_name_3;
    }

    public void setSca_name_3(java.lang.String v)
    {
        this.sca_name_3 = v;
    }

    public java.lang.String getExp_date_3()
    {
        return exp_date_3;
    }

    public void setExp_date_3(java.lang.String v)
    {
        this.exp_date_3 = v;
    }

    public java.lang.Double get_1()
    {
        return _1;
    }

    public void set_1(java.lang.Double v)
    {
        this._1 = v;
    }

    public CONTACT_INFO_1Bean()
    {
    }

}
