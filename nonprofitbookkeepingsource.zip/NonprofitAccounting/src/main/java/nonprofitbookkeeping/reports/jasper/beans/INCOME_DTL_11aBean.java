package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet INCOME_DTL_11a */
public class INCOME_DTL_11aBean
{

    private java.lang.Double income_dtl_11a_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String _1a_fundraising_income_internal_event;
    private java.lang.String activity_at_the_event;
    private java.lang.String amount;
    private java.lang.String _1a_fundraising_income_internal_event_2;
    private java.lang.String activity_at_the_event_2;
    private java.lang.String amount_2;
    private java.lang.String _1a_fundraising_income_internal_event_3;
    private java.lang.String activity_at_the_event_3;
    private java.lang.String amount_3;
    private java.lang.String _1a_fundraising_income_internal_event_4;
    private java.lang.String activity_at_the_event_4;
    private java.lang.String amount_4;
    private java.lang.String _1a_fundraising_income_internal_event_5;
    private java.lang.String activity_at_the_event_5;
    private java.lang.String amount_5;
    private java.lang.String _1a_fundraising_income_internal_event_6;
    private java.lang.String activity_at_the_event_6;
    private java.lang.String amount_6;
    private java.lang.String _1a_fundraising_income_internal_event_7;
    private java.lang.String activity_at_the_event_7;
    private java.lang.String amount_7;
    private java.lang.String _1a_fundraising_income_internal_event_8;
    private java.lang.String activity_at_the_event_8;
    private java.lang.String amount_8;
    private java.lang.String _1a_fundraising_income_internal_event_9;
    private java.lang.String activity_at_the_event_9;
    private java.lang.String amount_9;
    private java.lang.Double amount_show_total_on_pg_4_line_1a;
    private java.lang.String _1b_fundraising_income_external_place;
    private java.lang.String activity;
    private java.lang.String amount_10;
    private java.lang.String _1b_fundraising_income_external_place_2;
    private java.lang.String activity_2;
    private java.lang.String amount_11;
    private java.lang.String _1b_fundraising_income_external_place_3;
    private java.lang.String activity_3;
    private java.lang.String amount_12;
    private java.lang.String _1b_fundraising_income_external_place_4;
    private java.lang.String activity_4;
    private java.lang.String amount_13;
    private java.lang.String _1b_fundraising_income_external_place_5;
    private java.lang.String activity_5;
    private java.lang.String amount_14;
    private java.lang.String _1b_fundraising_income_external_place_6;
    private java.lang.String activity_6;
    private java.lang.String amount_15;
    private java.lang.String _1b_fundraising_income_external_place_7;
    private java.lang.String activity_7;
    private java.lang.String amount_16;
    private java.lang.Double amount_show_total_on_pg_4_line_1b;
    private java.lang.Double amount_a_donations_received_without_consideration_list_each_transaction_on_income_dtl_11c_worksheet;
    private java.lang.Double income_dtl_11c_g24_income_dtl_11c_g66_show_total_on_pg_4_line_2;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from;
    private java.lang.String activity_8;
    private java.lang.String amount_17;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_2;
    private java.lang.String activity_9;
    private java.lang.String amount_18;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_3;
    private java.lang.String activity_10;
    private java.lang.String amount_19;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_4;
    private java.lang.String activity_11;
    private java.lang.String amount_20;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_5;
    private java.lang.String activity_12;
    private java.lang.String amount_21;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_6;
    private java.lang.String activity_13;
    private java.lang.String amount_22;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_7;
    private java.lang.String activity_14;
    private java.lang.String amount_23;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_8;
    private java.lang.String activity_15;
    private java.lang.String amount_24;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_9;
    private java.lang.String activity_16;
    private java.lang.String amount_25;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_10;
    private java.lang.String activity_17;
    private java.lang.String amount_26;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_11;
    private java.lang.String activity_18;
    private java.lang.String amount_27;
    private java.lang.String _3a_income_from_demos_and_activity_fees_from_12;
    private java.lang.String activity_19;
    private java.lang.String amount_28;
    private java.lang.Double amount_show_total_on_pg_4_line_3a;

    public java.lang.Double getIncome_dtl_11a_r2c3()
    {
        return income_dtl_11a_r2c3;
    }

    public void setIncome_dtl_11a_r2c3(java.lang.Double v)
    {
        this.income_dtl_11a_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event()
    {
        return _1a_fundraising_income_internal_event;
    }

    public void set_1a_fundraising_income_internal_event(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event = v;
    }

    public java.lang.String getActivity_at_the_event()
    {
        return activity_at_the_event;
    }

    public void setActivity_at_the_event(java.lang.String v)
    {
        this.activity_at_the_event = v;
    }

    public java.lang.String getAmount()
    {
        return amount;
    }

    public void setAmount(java.lang.String v)
    {
        this.amount = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event_2()
    {
        return _1a_fundraising_income_internal_event_2;
    }

    public void set_1a_fundraising_income_internal_event_2(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event_2 = v;
    }

    public java.lang.String getActivity_at_the_event_2()
    {
        return activity_at_the_event_2;
    }

    public void setActivity_at_the_event_2(java.lang.String v)
    {
        this.activity_at_the_event_2 = v;
    }

    public java.lang.String getAmount_2()
    {
        return amount_2;
    }

    public void setAmount_2(java.lang.String v)
    {
        this.amount_2 = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event_3()
    {
        return _1a_fundraising_income_internal_event_3;
    }

    public void set_1a_fundraising_income_internal_event_3(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event_3 = v;
    }

    public java.lang.String getActivity_at_the_event_3()
    {
        return activity_at_the_event_3;
    }

    public void setActivity_at_the_event_3(java.lang.String v)
    {
        this.activity_at_the_event_3 = v;
    }

    public java.lang.String getAmount_3()
    {
        return amount_3;
    }

    public void setAmount_3(java.lang.String v)
    {
        this.amount_3 = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event_4()
    {
        return _1a_fundraising_income_internal_event_4;
    }

    public void set_1a_fundraising_income_internal_event_4(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event_4 = v;
    }

    public java.lang.String getActivity_at_the_event_4()
    {
        return activity_at_the_event_4;
    }

    public void setActivity_at_the_event_4(java.lang.String v)
    {
        this.activity_at_the_event_4 = v;
    }

    public java.lang.String getAmount_4()
    {
        return amount_4;
    }

    public void setAmount_4(java.lang.String v)
    {
        this.amount_4 = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event_5()
    {
        return _1a_fundraising_income_internal_event_5;
    }

    public void set_1a_fundraising_income_internal_event_5(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event_5 = v;
    }

    public java.lang.String getActivity_at_the_event_5()
    {
        return activity_at_the_event_5;
    }

    public void setActivity_at_the_event_5(java.lang.String v)
    {
        this.activity_at_the_event_5 = v;
    }

    public java.lang.String getAmount_5()
    {
        return amount_5;
    }

    public void setAmount_5(java.lang.String v)
    {
        this.amount_5 = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event_6()
    {
        return _1a_fundraising_income_internal_event_6;
    }

    public void set_1a_fundraising_income_internal_event_6(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event_6 = v;
    }

    public java.lang.String getActivity_at_the_event_6()
    {
        return activity_at_the_event_6;
    }

    public void setActivity_at_the_event_6(java.lang.String v)
    {
        this.activity_at_the_event_6 = v;
    }

    public java.lang.String getAmount_6()
    {
        return amount_6;
    }

    public void setAmount_6(java.lang.String v)
    {
        this.amount_6 = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event_7()
    {
        return _1a_fundraising_income_internal_event_7;
    }

    public void set_1a_fundraising_income_internal_event_7(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event_7 = v;
    }

    public java.lang.String getActivity_at_the_event_7()
    {
        return activity_at_the_event_7;
    }

    public void setActivity_at_the_event_7(java.lang.String v)
    {
        this.activity_at_the_event_7 = v;
    }

    public java.lang.String getAmount_7()
    {
        return amount_7;
    }

    public void setAmount_7(java.lang.String v)
    {
        this.amount_7 = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event_8()
    {
        return _1a_fundraising_income_internal_event_8;
    }

    public void set_1a_fundraising_income_internal_event_8(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event_8 = v;
    }

    public java.lang.String getActivity_at_the_event_8()
    {
        return activity_at_the_event_8;
    }

    public void setActivity_at_the_event_8(java.lang.String v)
    {
        this.activity_at_the_event_8 = v;
    }

    public java.lang.String getAmount_8()
    {
        return amount_8;
    }

    public void setAmount_8(java.lang.String v)
    {
        this.amount_8 = v;
    }

    public java.lang.String get_1a_fundraising_income_internal_event_9()
    {
        return _1a_fundraising_income_internal_event_9;
    }

    public void set_1a_fundraising_income_internal_event_9(java.lang.String v)
    {
        this._1a_fundraising_income_internal_event_9 = v;
    }

    public java.lang.String getActivity_at_the_event_9()
    {
        return activity_at_the_event_9;
    }

    public void setActivity_at_the_event_9(java.lang.String v)
    {
        this.activity_at_the_event_9 = v;
    }

    public java.lang.String getAmount_9()
    {
        return amount_9;
    }

    public void setAmount_9(java.lang.String v)
    {
        this.amount_9 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_1a()
    {
        return amount_show_total_on_pg_4_line_1a;
    }

    public void setAmount_show_total_on_pg_4_line_1a(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_1a = v;
    }

    public java.lang.String get_1b_fundraising_income_external_place()
    {
        return _1b_fundraising_income_external_place;
    }

    public void set_1b_fundraising_income_external_place(java.lang.String v)
    {
        this._1b_fundraising_income_external_place = v;
    }

    public java.lang.String getActivity()
    {
        return activity;
    }

    public void setActivity(java.lang.String v)
    {
        this.activity = v;
    }

    public java.lang.String getAmount_10()
    {
        return amount_10;
    }

    public void setAmount_10(java.lang.String v)
    {
        this.amount_10 = v;
    }

    public java.lang.String get_1b_fundraising_income_external_place_2()
    {
        return _1b_fundraising_income_external_place_2;
    }

    public void set_1b_fundraising_income_external_place_2(java.lang.String v)
    {
        this._1b_fundraising_income_external_place_2 = v;
    }

    public java.lang.String getActivity_2()
    {
        return activity_2;
    }

    public void setActivity_2(java.lang.String v)
    {
        this.activity_2 = v;
    }

    public java.lang.String getAmount_11()
    {
        return amount_11;
    }

    public void setAmount_11(java.lang.String v)
    {
        this.amount_11 = v;
    }

    public java.lang.String get_1b_fundraising_income_external_place_3()
    {
        return _1b_fundraising_income_external_place_3;
    }

    public void set_1b_fundraising_income_external_place_3(java.lang.String v)
    {
        this._1b_fundraising_income_external_place_3 = v;
    }

    public java.lang.String getActivity_3()
    {
        return activity_3;
    }

    public void setActivity_3(java.lang.String v)
    {
        this.activity_3 = v;
    }

    public java.lang.String getAmount_12()
    {
        return amount_12;
    }

    public void setAmount_12(java.lang.String v)
    {
        this.amount_12 = v;
    }

    public java.lang.String get_1b_fundraising_income_external_place_4()
    {
        return _1b_fundraising_income_external_place_4;
    }

    public void set_1b_fundraising_income_external_place_4(java.lang.String v)
    {
        this._1b_fundraising_income_external_place_4 = v;
    }

    public java.lang.String getActivity_4()
    {
        return activity_4;
    }

    public void setActivity_4(java.lang.String v)
    {
        this.activity_4 = v;
    }

    public java.lang.String getAmount_13()
    {
        return amount_13;
    }

    public void setAmount_13(java.lang.String v)
    {
        this.amount_13 = v;
    }

    public java.lang.String get_1b_fundraising_income_external_place_5()
    {
        return _1b_fundraising_income_external_place_5;
    }

    public void set_1b_fundraising_income_external_place_5(java.lang.String v)
    {
        this._1b_fundraising_income_external_place_5 = v;
    }

    public java.lang.String getActivity_5()
    {
        return activity_5;
    }

    public void setActivity_5(java.lang.String v)
    {
        this.activity_5 = v;
    }

    public java.lang.String getAmount_14()
    {
        return amount_14;
    }

    public void setAmount_14(java.lang.String v)
    {
        this.amount_14 = v;
    }

    public java.lang.String get_1b_fundraising_income_external_place_6()
    {
        return _1b_fundraising_income_external_place_6;
    }

    public void set_1b_fundraising_income_external_place_6(java.lang.String v)
    {
        this._1b_fundraising_income_external_place_6 = v;
    }

    public java.lang.String getActivity_6()
    {
        return activity_6;
    }

    public void setActivity_6(java.lang.String v)
    {
        this.activity_6 = v;
    }

    public java.lang.String getAmount_15()
    {
        return amount_15;
    }

    public void setAmount_15(java.lang.String v)
    {
        this.amount_15 = v;
    }

    public java.lang.String get_1b_fundraising_income_external_place_7()
    {
        return _1b_fundraising_income_external_place_7;
    }

    public void set_1b_fundraising_income_external_place_7(java.lang.String v)
    {
        this._1b_fundraising_income_external_place_7 = v;
    }

    public java.lang.String getActivity_7()
    {
        return activity_7;
    }

    public void setActivity_7(java.lang.String v)
    {
        this.activity_7 = v;
    }

    public java.lang.String getAmount_16()
    {
        return amount_16;
    }

    public void setAmount_16(java.lang.String v)
    {
        this.amount_16 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_1b()
    {
        return amount_show_total_on_pg_4_line_1b;
    }

    public void setAmount_show_total_on_pg_4_line_1b(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_1b = v;
    }

    public java.lang.Double getAmount_a_donations_received_without_consideration_list_each_transaction_on_income_dtl_11c_worksheet()
    {
        return amount_a_donations_received_without_consideration_list_each_transaction_on_income_dtl_11c_worksheet;
    }

    public void setAmount_a_donations_received_without_consideration_list_each_transaction_on_income_dtl_11c_worksheet(java.lang.Double v)
    {
        this.amount_a_donations_received_without_consideration_list_each_transaction_on_income_dtl_11c_worksheet = v;
    }

    public java.lang.Double getIncome_dtl_11c_g24_income_dtl_11c_g66_show_total_on_pg_4_line_2()
    {
        return income_dtl_11c_g24_income_dtl_11c_g66_show_total_on_pg_4_line_2;
    }

    public void setIncome_dtl_11c_g24_income_dtl_11c_g66_show_total_on_pg_4_line_2(java.lang.Double v)
    {
        this.income_dtl_11c_g24_income_dtl_11c_g66_show_total_on_pg_4_line_2 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from()
    {
        return _3a_income_from_demos_and_activity_fees_from;
    }

    public void set_3a_income_from_demos_and_activity_fees_from(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from = v;
    }

    public java.lang.String getActivity_8()
    {
        return activity_8;
    }

    public void setActivity_8(java.lang.String v)
    {
        this.activity_8 = v;
    }

    public java.lang.String getAmount_17()
    {
        return amount_17;
    }

    public void setAmount_17(java.lang.String v)
    {
        this.amount_17 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_2()
    {
        return _3a_income_from_demos_and_activity_fees_from_2;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_2(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_2 = v;
    }

    public java.lang.String getActivity_9()
    {
        return activity_9;
    }

    public void setActivity_9(java.lang.String v)
    {
        this.activity_9 = v;
    }

    public java.lang.String getAmount_18()
    {
        return amount_18;
    }

    public void setAmount_18(java.lang.String v)
    {
        this.amount_18 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_3()
    {
        return _3a_income_from_demos_and_activity_fees_from_3;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_3(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_3 = v;
    }

    public java.lang.String getActivity_10()
    {
        return activity_10;
    }

    public void setActivity_10(java.lang.String v)
    {
        this.activity_10 = v;
    }

    public java.lang.String getAmount_19()
    {
        return amount_19;
    }

    public void setAmount_19(java.lang.String v)
    {
        this.amount_19 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_4()
    {
        return _3a_income_from_demos_and_activity_fees_from_4;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_4(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_4 = v;
    }

    public java.lang.String getActivity_11()
    {
        return activity_11;
    }

    public void setActivity_11(java.lang.String v)
    {
        this.activity_11 = v;
    }

    public java.lang.String getAmount_20()
    {
        return amount_20;
    }

    public void setAmount_20(java.lang.String v)
    {
        this.amount_20 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_5()
    {
        return _3a_income_from_demos_and_activity_fees_from_5;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_5(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_5 = v;
    }

    public java.lang.String getActivity_12()
    {
        return activity_12;
    }

    public void setActivity_12(java.lang.String v)
    {
        this.activity_12 = v;
    }

    public java.lang.String getAmount_21()
    {
        return amount_21;
    }

    public void setAmount_21(java.lang.String v)
    {
        this.amount_21 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_6()
    {
        return _3a_income_from_demos_and_activity_fees_from_6;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_6(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_6 = v;
    }

    public java.lang.String getActivity_13()
    {
        return activity_13;
    }

    public void setActivity_13(java.lang.String v)
    {
        this.activity_13 = v;
    }

    public java.lang.String getAmount_22()
    {
        return amount_22;
    }

    public void setAmount_22(java.lang.String v)
    {
        this.amount_22 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_7()
    {
        return _3a_income_from_demos_and_activity_fees_from_7;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_7(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_7 = v;
    }

    public java.lang.String getActivity_14()
    {
        return activity_14;
    }

    public void setActivity_14(java.lang.String v)
    {
        this.activity_14 = v;
    }

    public java.lang.String getAmount_23()
    {
        return amount_23;
    }

    public void setAmount_23(java.lang.String v)
    {
        this.amount_23 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_8()
    {
        return _3a_income_from_demos_and_activity_fees_from_8;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_8(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_8 = v;
    }

    public java.lang.String getActivity_15()
    {
        return activity_15;
    }

    public void setActivity_15(java.lang.String v)
    {
        this.activity_15 = v;
    }

    public java.lang.String getAmount_24()
    {
        return amount_24;
    }

    public void setAmount_24(java.lang.String v)
    {
        this.amount_24 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_9()
    {
        return _3a_income_from_demos_and_activity_fees_from_9;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_9(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_9 = v;
    }

    public java.lang.String getActivity_16()
    {
        return activity_16;
    }

    public void setActivity_16(java.lang.String v)
    {
        this.activity_16 = v;
    }

    public java.lang.String getAmount_25()
    {
        return amount_25;
    }

    public void setAmount_25(java.lang.String v)
    {
        this.amount_25 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_10()
    {
        return _3a_income_from_demos_and_activity_fees_from_10;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_10(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_10 = v;
    }

    public java.lang.String getActivity_17()
    {
        return activity_17;
    }

    public void setActivity_17(java.lang.String v)
    {
        this.activity_17 = v;
    }

    public java.lang.String getAmount_26()
    {
        return amount_26;
    }

    public void setAmount_26(java.lang.String v)
    {
        this.amount_26 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_11()
    {
        return _3a_income_from_demos_and_activity_fees_from_11;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_11(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_11 = v;
    }

    public java.lang.String getActivity_18()
    {
        return activity_18;
    }

    public void setActivity_18(java.lang.String v)
    {
        this.activity_18 = v;
    }

    public java.lang.String getAmount_27()
    {
        return amount_27;
    }

    public void setAmount_27(java.lang.String v)
    {
        this.amount_27 = v;
    }

    public java.lang.String get_3a_income_from_demos_and_activity_fees_from_12()
    {
        return _3a_income_from_demos_and_activity_fees_from_12;
    }

    public void set_3a_income_from_demos_and_activity_fees_from_12(java.lang.String v)
    {
        this._3a_income_from_demos_and_activity_fees_from_12 = v;
    }

    public java.lang.String getActivity_19()
    {
        return activity_19;
    }

    public void setActivity_19(java.lang.String v)
    {
        this.activity_19 = v;
    }

    public java.lang.String getAmount_28()
    {
        return amount_28;
    }

    public void setAmount_28(java.lang.String v)
    {
        this.amount_28 = v;
    }

    public java.lang.Double getAmount_show_total_on_pg_4_line_3a()
    {
        return amount_show_total_on_pg_4_line_3a;
    }

    public void setAmount_show_total_on_pg_4_line_3a(java.lang.Double v)
    {
        this.amount_show_total_on_pg_4_line_3a = v;
    }

    public INCOME_DTL_11aBean()
    {
    }

}
