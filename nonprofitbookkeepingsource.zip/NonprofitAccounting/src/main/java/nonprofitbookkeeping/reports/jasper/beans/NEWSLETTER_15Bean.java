package nonprofitbookkeeping.reports.jasper.beans;

/** Generated bean for sheet NEWSLETTER_15 */
public class NEWSLETTER_15Bean
{

    private java.lang.Double newsletter_15_r2c3;
    private java.lang.Double contents_b59;
    private java.lang.Double contents_e_3;
    private java.lang.Double contents_e_4;
    private java.lang.String newsletter_name;
    private java.lang.String newsletter_name_2;
    private java.lang.String newsletter_name_3;
    private java.lang.String gross_income;
    private java.lang.Double gross_income_a;
    private java.lang.Double i11_start_subs_due_b;
    private java.lang.String rate_1_price_of_one_subscription;
    private java.lang.String rate_2_price_of_one_subscription;
    private java.lang.Double balance_3_g31_end_subs_due_c;
    private java.lang.String rate_1_of_issues_per_subscription;
    private java.lang.String rate_2_of_issues_per_subscription;
    private java.lang.Double i59_adj_gross_income_a_b_c;
    private java.lang.Double rate_1_price_per_issue;
    private java.lang.Double rate_2_if_h16_0_0_round_h15_h16_2;
    private java.lang.String expiring_1_0;
    private java.lang.String price_per_issue_1_0;
    private java.lang.Double subscription_due_1_0;
    private java.lang.String expiring_e22_c22_d22;
    private java.lang.String price_per_issue_e22_c22_d22;
    private java.lang.Double subscription_due_e22_c22_d22;
    private java.lang.Double _1_0;
    private java.lang.String expiring_c22_1;
    private java.lang.String price_per_issue_c22_1;
    private java.lang.Double e22_c22_d22_c22_1;
    private java.lang.String expiring_e23_c23_d23;
    private java.lang.String price_per_issue_e23_c23_d23;
    private java.lang.Double h22_c22_g22_e23_c23_d23;
    private java.lang.Double c22_1;
    private java.lang.String expiring_c23_1;
    private java.lang.String price_per_issue_c23_1;
    private java.lang.Double e23_c23_d23_c23_1;
    private java.lang.String expiring_e24_c24_d24;
    private java.lang.String price_per_issue_e24_c24_d24;
    private java.lang.Double h23_c23_g23_e24_c24_d24;
    private java.lang.Double c23_1;
    private java.lang.String expiring_c24_1;
    private java.lang.String price_per_issue_c24_1;
    private java.lang.Double e24_c24_d24_c24_1;
    private java.lang.String expiring_e25_c25_d25;
    private java.lang.String price_per_issue_e25_c25_d25;
    private java.lang.Double h24_c24_g24_e25_c25_d25;
    private java.lang.Double c24_1;
    private java.lang.String expiring_c25_1;
    private java.lang.String price_per_issue_c25_1;
    private java.lang.Double e25_c25_d25_c25_1;
    private java.lang.String expiring_e26_c26_d26;
    private java.lang.String price_per_issue_e26_c26_d26;
    private java.lang.Double h25_c25_g25_e26_c26_d26;
    private java.lang.Double c25_1;
    private java.lang.String expiring_c26_1;
    private java.lang.String price_per_issue_c26_1;
    private java.lang.Double e26_c26_d26_c26_1;
    private java.lang.String expiring_e27_c27_d27;
    private java.lang.String price_per_issue_e27_c27_d27;
    private java.lang.Double h26_c26_g26_e27_c27_d27;
    private java.lang.Double c26_1;
    private java.lang.String expiring_c27_1;
    private java.lang.String price_per_issue_c27_1;
    private java.lang.Double e27_c27_d27_c27_1;
    private java.lang.String expiring_e28_c28_d28;
    private java.lang.String price_per_issue_e28_c28_d28;
    private java.lang.Double h27_c27_g27_e28_c28_d28;
    private java.lang.Double c27_1;
    private java.lang.String expiring_c28_1;
    private java.lang.String price_per_issue_c28_1;
    private java.lang.Double e28_c28_d28_c28_1;
    private java.lang.String expiring_e29_c29_d29;
    private java.lang.String price_per_issue_e29_c29_d29;
    private java.lang.Double h28_c28_g28_e29_c29_d29;
    private java.lang.Double c28_1;
    private java.lang.String expiring_c29_1;
    private java.lang.String price_per_issue_c29_1;
    private java.lang.Double e29_c29_d29_c29_1;
    private java.lang.String expiring_e30_c30_d30;
    private java.lang.String price_per_issue_e30_c30_d30;
    private java.lang.Double h29_c29_g29_e30_c30_d30;
    private java.lang.Double c29_1;
    private java.lang.String expiring_c30_1;
    private java.lang.String price_per_issue_c30_1;
    private java.lang.Double e30_c30_d30_c30_1;
    private java.lang.String expiring_e31_c31_d31;
    private java.lang.String price_per_issue_e31_c31_d31;
    private java.lang.Double h30_c30_g30_e31_c31_d31;
    private java.lang.Double c30_1;
    private java.lang.String expiring_c31_1;
    private java.lang.String price_per_issue_c31_1;
    private java.lang.Double e31_c31_d31_c31_1;
    private java.lang.String expiring_e32_c32_d32;
    private java.lang.String price_per_issue_e32_c32_d32;
    private java.lang.Double h31_c31_g31_e32_c32_d32;
    private java.lang.Double c31_1;
    private java.lang.String expiring_c32_1;
    private java.lang.String price_per_issue_c32_1;
    private java.lang.Double e32_c32_d32_c32_1;
    private java.lang.String expiring_e33_c33_d33;
    private java.lang.String price_per_issue_e33_c33_d33;
    private java.lang.Double h32_c32_g32_e33_c33_d33;
    private java.lang.Double c32_1;
    private java.lang.String expiring_c33_1;
    private java.lang.String price_per_issue_c33_1;
    private java.lang.Double e33_c33_d33_c33_1;
    private java.lang.String expiring_e34_c34_d34;
    private java.lang.String price_per_issue_e34_c34_d34;
    private java.lang.Double h33_c33_g33_e34_c34_d34;
    private java.lang.Double c33_1;
    private java.lang.String expiring_c34_1;
    private java.lang.String price_per_issue_c34_1;
    private java.lang.Double e34_c34_d34_c34_1;
    private java.lang.String expiring_e35_c35_d35;
    private java.lang.String price_per_issue_e35_c35_d35;
    private java.lang.Double h34_c34_g34_e35_c35_d35;
    private java.lang.Double c34_1;
    private java.lang.String expiring_c35_1;
    private java.lang.String price_per_issue_c35_1;
    private java.lang.Double e35_c35_d35_c35_1;
    private java.lang.String expiring_e36_c36_d36;
    private java.lang.String price_per_issue_e36_c36_d36;
    private java.lang.Double h35_c35_g35_e36_c36_d36;
    private java.lang.Double c35_1;
    private java.lang.String expiring_c36_1;
    private java.lang.String price_per_issue_c36_1;
    private java.lang.Double e36_c36_d36_c36_1;
    private java.lang.String expiring_e37_c37_d37;
    private java.lang.String price_per_issue_e37_c37_d37;
    private java.lang.Double h36_c36_g36_e37_c37_d37;
    private java.lang.Double c36_1;
    private java.lang.String expiring_c37_1;
    private java.lang.String price_per_issue_c37_1;
    private java.lang.Double e37_c37_d37_c37_1;
    private java.lang.String expiring_e38_c38_d38;
    private java.lang.String price_per_issue_e38_c38_d38;
    private java.lang.Double h37_c37_g37_e38_c38_d38;
    private java.lang.Double c37_1;
    private java.lang.String expiring_c38_1;
    private java.lang.String price_per_issue_c38_1;
    private java.lang.Double e38_c38_d38_c38_1;
    private java.lang.String expiring_e39_c39_d39;
    private java.lang.String price_per_issue_e39_c39_d39;
    private java.lang.Double h38_c38_g38_e39_c39_d39;
    private java.lang.Double c38_1;
    private java.lang.String expiring_c39_1;
    private java.lang.String price_per_issue_c39_1;
    private java.lang.Double e39_c39_d39_c39_1;
    private java.lang.String expiring_e40_c40_d40;
    private java.lang.String price_per_issue_e40_c40_d40;
    private java.lang.Double h39_c39_g39_e40_c40_d40;
    private java.lang.Double c39_1;
    private java.lang.String expiring_c40_1;
    private java.lang.String price_per_issue_c40_1;
    private java.lang.Double e40_c40_d40_c40_1;
    private java.lang.String expiring_e41_c41_d41;
    private java.lang.String price_per_issue_e41_c41_d41;
    private java.lang.Double h40_c40_g40_e41_c41_d41;
    private java.lang.Double c40_1;
    private java.lang.String expiring_c41_1;
    private java.lang.String price_per_issue_c41_1;
    private java.lang.Double e41_c41_d41_c41_1;
    private java.lang.String expiring_e42_c42_d42;
    private java.lang.String price_per_issue_e42_c42_d42;
    private java.lang.Double h41_c41_g41_e42_c42_d42;
    private java.lang.Double c41_1;
    private java.lang.String expiring_c42_1;
    private java.lang.String price_per_issue_c42_1;
    private java.lang.Double e42_c42_d42_c42_1;
    private java.lang.String expiring_e43_c43_d43;
    private java.lang.String price_per_issue_e43_c43_d43;
    private java.lang.Double h42_c42_g42_e43_c43_d43;
    private java.lang.Double c42_1;
    private java.lang.String expiring_c43_1;
    private java.lang.String price_per_issue_c43_1;
    private java.lang.Double e43_c43_d43_c43_1;
    private java.lang.String expiring_e44_c44_d44;
    private java.lang.String price_per_issue_e44_c44_d44;
    private java.lang.Double h43_c43_g43_e44_c44_d44;
    private java.lang.Double c43_1;
    private java.lang.String expiring_c44_1;
    private java.lang.String price_per_issue_c44_1;
    private java.lang.Double e44_c44_d44_c44_1;
    private java.lang.String expiring_e45_c45_d45;
    private java.lang.String price_per_issue_e45_c45_d45;
    private java.lang.Double h44_c44_g44_e45_c45_d45;
    private java.lang.Double c44_1;
    private java.lang.String expiring_c45_1;
    private java.lang.String price_per_issue_c45_1;
    private java.lang.Double e45_c45_d45_c45_1;
    private java.lang.String expiring_e46_c46_d46;
    private java.lang.String price_per_issue_e46_c46_d46;
    private java.lang.Double h45_c45_g45_e46_c46_d46;
    private java.lang.Double c45_1;
    private java.lang.String expiring_c46_1;
    private java.lang.String price_per_issue_c46_1;
    private java.lang.Double e46_c46_d46_c46_1;
    private java.lang.String expiring_e47_c47_d47;
    private java.lang.String price_per_issue_e47_c47_d47;
    private java.lang.Double h46_c46_g46_e47_c47_d47;
    private java.lang.Double c46_1;
    private java.lang.String expiring_c47_1;
    private java.lang.String price_per_issue_c47_1;
    private java.lang.Double e47_c47_d47_c47_1;
    private java.lang.String expiring_e48_c48_d48;
    private java.lang.String price_per_issue_e48_c48_d48;
    private java.lang.Double h47_c47_g47_e48_c48_d48;
    private java.lang.Double c47_1;
    private java.lang.String expiring_c48_1;
    private java.lang.String price_per_issue_c48_1;
    private java.lang.Double e48_c48_d48_c48_1;
    private java.lang.String expiring_e49_c49_d49;
    private java.lang.String price_per_issue_e49_c49_d49;
    private java.lang.Double h48_c48_g48_e49_c49_d49;
    private java.lang.Double c48_1;
    private java.lang.String expiring_c49_1;
    private java.lang.String price_per_issue_c49_1;
    private java.lang.Double e49_c49_d49_c49_1;
    private java.lang.String expiring_e50_c50_d50;
    private java.lang.String price_per_issue_e50_c50_d50;
    private java.lang.Double h49_c49_g49_e50_c50_d50;
    private java.lang.Double c49_1;
    private java.lang.String expiring_c50_1;
    private java.lang.String price_per_issue_c50_1;
    private java.lang.Double e50_c50_d50_c50_1;
    private java.lang.String expiring_e51_c51_d51;
    private java.lang.String price_per_issue_e51_c51_d51;
    private java.lang.Double h50_c50_g50_e51_c51_d51;
    private java.lang.Double c50_1;
    private java.lang.String expiring_c51_1;
    private java.lang.String price_per_issue_c51_1;
    private java.lang.Double e51_c51_d51_c51_1;
    private java.lang.String expiring_e52_c52_d52;
    private java.lang.String price_per_issue_e52_c52_d52;
    private java.lang.Double h51_c51_g51_e52_c52_d52;
    private java.lang.Double c51_1;
    private java.lang.String expiring_c52_1;
    private java.lang.String price_per_issue_c52_1;
    private java.lang.Double e52_c52_d52_c52_1;
    private java.lang.String expiring_e53_c53_d53;
    private java.lang.String price_per_issue_e53_c53_d53;
    private java.lang.Double h52_c52_g52_e53_c53_d53;
    private java.lang.Double c52_1;
    private java.lang.String expiring_c53_1;
    private java.lang.String price_per_issue_c53_1;
    private java.lang.Double e53_c53_d53_c53_1;
    private java.lang.String expiring_e54_c54_d54;
    private java.lang.String price_per_issue_e54_c54_d54;
    private java.lang.Double h53_c53_g53_e54_c54_d54;
    private java.lang.Double c53_1;
    private java.lang.String expiring_c54_1;
    private java.lang.String price_per_issue_c54_1;
    private java.lang.Double e54_c54_d54_c54_1;
    private java.lang.String expiring_e55_c55_d55;
    private java.lang.String price_per_issue_e55_c55_d55;
    private java.lang.Double h54_c54_g54_e55_c55_d55;
    private java.lang.Double c54_1;
    private java.lang.String expiring_c55_1;
    private java.lang.String price_per_issue_c55_1;
    private java.lang.Double e55_c55_d55_c55_1;
    private java.lang.String expiring_e56_c56_d56;
    private java.lang.String price_per_issue_e56_c56_d56;
    private java.lang.Double h55_c55_g55_e56_c56_d56;
    private java.lang.Double c55_1;
    private java.lang.String expiring_c56_1;
    private java.lang.String price_per_issue_c56_1;
    private java.lang.Double e56_c56_d56_c56_1;
    private java.lang.String expiring_e57_c57_d57;
    private java.lang.String price_per_issue_e57_c57_d57;
    private java.lang.Double h56_c56_g56_e57_c57_d57;
    private java.lang.String e57_c57_d57_calculate_separately;
    private java.lang.String h57_c57_g57_calculate_separately;
    private java.lang.Double h57_c57_g57_total;

    public java.lang.Double getNewsletter_15_r2c3()
    {
        return newsletter_15_r2c3;
    }

    public void setNewsletter_15_r2c3(java.lang.Double v)
    {
        this.newsletter_15_r2c3 = v;
    }

    public java.lang.Double getContents_b59()
    {
        return contents_b59;
    }

    public void setContents_b59(java.lang.Double v)
    {
        this.contents_b59 = v;
    }

    public java.lang.Double getContents_e_3()
    {
        return contents_e_3;
    }

    public void setContents_e_3(java.lang.Double v)
    {
        this.contents_e_3 = v;
    }

    public java.lang.Double getContents_e_4()
    {
        return contents_e_4;
    }

    public void setContents_e_4(java.lang.Double v)
    {
        this.contents_e_4 = v;
    }

    public java.lang.String getNewsletter_name()
    {
        return newsletter_name;
    }

    public void setNewsletter_name(java.lang.String v)
    {
        this.newsletter_name = v;
    }

    public java.lang.String getNewsletter_name_2()
    {
        return newsletter_name_2;
    }

    public void setNewsletter_name_2(java.lang.String v)
    {
        this.newsletter_name_2 = v;
    }

    public java.lang.String getNewsletter_name_3()
    {
        return newsletter_name_3;
    }

    public void setNewsletter_name_3(java.lang.String v)
    {
        this.newsletter_name_3 = v;
    }

    public java.lang.String getGross_income()
    {
        return gross_income;
    }

    public void setGross_income(java.lang.String v)
    {
        this.gross_income = v;
    }

    public java.lang.Double getGross_income_a()
    {
        return gross_income_a;
    }

    public void setGross_income_a(java.lang.Double v)
    {
        this.gross_income_a = v;
    }

    public java.lang.Double getI11_start_subs_due_b()
    {
        return i11_start_subs_due_b;
    }

    public void setI11_start_subs_due_b(java.lang.Double v)
    {
        this.i11_start_subs_due_b = v;
    }

    public java.lang.String getRate_1_price_of_one_subscription()
    {
        return rate_1_price_of_one_subscription;
    }

    public void setRate_1_price_of_one_subscription(java.lang.String v)
    {
        this.rate_1_price_of_one_subscription = v;
    }

    public java.lang.String getRate_2_price_of_one_subscription()
    {
        return rate_2_price_of_one_subscription;
    }

    public void setRate_2_price_of_one_subscription(java.lang.String v)
    {
        this.rate_2_price_of_one_subscription = v;
    }

    public java.lang.Double getBalance_3_g31_end_subs_due_c()
    {
        return balance_3_g31_end_subs_due_c;
    }

    public void setBalance_3_g31_end_subs_due_c(java.lang.Double v)
    {
        this.balance_3_g31_end_subs_due_c = v;
    }

    public java.lang.String getRate_1_of_issues_per_subscription()
    {
        return rate_1_of_issues_per_subscription;
    }

    public void setRate_1_of_issues_per_subscription(java.lang.String v)
    {
        this.rate_1_of_issues_per_subscription = v;
    }

    public java.lang.String getRate_2_of_issues_per_subscription()
    {
        return rate_2_of_issues_per_subscription;
    }

    public void setRate_2_of_issues_per_subscription(java.lang.String v)
    {
        this.rate_2_of_issues_per_subscription = v;
    }

    public java.lang.Double getI59_adj_gross_income_a_b_c()
    {
        return i59_adj_gross_income_a_b_c;
    }

    public void setI59_adj_gross_income_a_b_c(java.lang.Double v)
    {
        this.i59_adj_gross_income_a_b_c = v;
    }

    public java.lang.Double getRate_1_price_per_issue()
    {
        return rate_1_price_per_issue;
    }

    public void setRate_1_price_per_issue(java.lang.Double v)
    {
        this.rate_1_price_per_issue = v;
    }

    public java.lang.Double getRate_2_if_h16_0_0_round_h15_h16_2()
    {
        return rate_2_if_h16_0_0_round_h15_h16_2;
    }

    public void setRate_2_if_h16_0_0_round_h15_h16_2(java.lang.Double v)
    {
        this.rate_2_if_h16_0_0_round_h15_h16_2 = v;
    }

    public java.lang.String getExpiring_1_0()
    {
        return expiring_1_0;
    }

    public void setExpiring_1_0(java.lang.String v)
    {
        this.expiring_1_0 = v;
    }

    public java.lang.String getPrice_per_issue_1_0()
    {
        return price_per_issue_1_0;
    }

    public void setPrice_per_issue_1_0(java.lang.String v)
    {
        this.price_per_issue_1_0 = v;
    }

    public java.lang.Double getSubscription_due_1_0()
    {
        return subscription_due_1_0;
    }

    public void setSubscription_due_1_0(java.lang.Double v)
    {
        this.subscription_due_1_0 = v;
    }

    public java.lang.String getExpiring_e22_c22_d22()
    {
        return expiring_e22_c22_d22;
    }

    public void setExpiring_e22_c22_d22(java.lang.String v)
    {
        this.expiring_e22_c22_d22 = v;
    }

    public java.lang.String getPrice_per_issue_e22_c22_d22()
    {
        return price_per_issue_e22_c22_d22;
    }

    public void setPrice_per_issue_e22_c22_d22(java.lang.String v)
    {
        this.price_per_issue_e22_c22_d22 = v;
    }

    public java.lang.Double getSubscription_due_e22_c22_d22()
    {
        return subscription_due_e22_c22_d22;
    }

    public void setSubscription_due_e22_c22_d22(java.lang.Double v)
    {
        this.subscription_due_e22_c22_d22 = v;
    }

    public java.lang.Double get_1_0()
    {
        return _1_0;
    }

    public void set_1_0(java.lang.Double v)
    {
        this._1_0 = v;
    }

    public java.lang.String getExpiring_c22_1()
    {
        return expiring_c22_1;
    }

    public void setExpiring_c22_1(java.lang.String v)
    {
        this.expiring_c22_1 = v;
    }

    public java.lang.String getPrice_per_issue_c22_1()
    {
        return price_per_issue_c22_1;
    }

    public void setPrice_per_issue_c22_1(java.lang.String v)
    {
        this.price_per_issue_c22_1 = v;
    }

    public java.lang.Double getE22_c22_d22_c22_1()
    {
        return e22_c22_d22_c22_1;
    }

    public void setE22_c22_d22_c22_1(java.lang.Double v)
    {
        this.e22_c22_d22_c22_1 = v;
    }

    public java.lang.String getExpiring_e23_c23_d23()
    {
        return expiring_e23_c23_d23;
    }

    public void setExpiring_e23_c23_d23(java.lang.String v)
    {
        this.expiring_e23_c23_d23 = v;
    }

    public java.lang.String getPrice_per_issue_e23_c23_d23()
    {
        return price_per_issue_e23_c23_d23;
    }

    public void setPrice_per_issue_e23_c23_d23(java.lang.String v)
    {
        this.price_per_issue_e23_c23_d23 = v;
    }

    public java.lang.Double getH22_c22_g22_e23_c23_d23()
    {
        return h22_c22_g22_e23_c23_d23;
    }

    public void setH22_c22_g22_e23_c23_d23(java.lang.Double v)
    {
        this.h22_c22_g22_e23_c23_d23 = v;
    }

    public java.lang.Double getC22_1()
    {
        return c22_1;
    }

    public void setC22_1(java.lang.Double v)
    {
        this.c22_1 = v;
    }

    public java.lang.String getExpiring_c23_1()
    {
        return expiring_c23_1;
    }

    public void setExpiring_c23_1(java.lang.String v)
    {
        this.expiring_c23_1 = v;
    }

    public java.lang.String getPrice_per_issue_c23_1()
    {
        return price_per_issue_c23_1;
    }

    public void setPrice_per_issue_c23_1(java.lang.String v)
    {
        this.price_per_issue_c23_1 = v;
    }

    public java.lang.Double getE23_c23_d23_c23_1()
    {
        return e23_c23_d23_c23_1;
    }

    public void setE23_c23_d23_c23_1(java.lang.Double v)
    {
        this.e23_c23_d23_c23_1 = v;
    }

    public java.lang.String getExpiring_e24_c24_d24()
    {
        return expiring_e24_c24_d24;
    }

    public void setExpiring_e24_c24_d24(java.lang.String v)
    {
        this.expiring_e24_c24_d24 = v;
    }

    public java.lang.String getPrice_per_issue_e24_c24_d24()
    {
        return price_per_issue_e24_c24_d24;
    }

    public void setPrice_per_issue_e24_c24_d24(java.lang.String v)
    {
        this.price_per_issue_e24_c24_d24 = v;
    }

    public java.lang.Double getH23_c23_g23_e24_c24_d24()
    {
        return h23_c23_g23_e24_c24_d24;
    }

    public void setH23_c23_g23_e24_c24_d24(java.lang.Double v)
    {
        this.h23_c23_g23_e24_c24_d24 = v;
    }

    public java.lang.Double getC23_1()
    {
        return c23_1;
    }

    public void setC23_1(java.lang.Double v)
    {
        this.c23_1 = v;
    }

    public java.lang.String getExpiring_c24_1()
    {
        return expiring_c24_1;
    }

    public void setExpiring_c24_1(java.lang.String v)
    {
        this.expiring_c24_1 = v;
    }

    public java.lang.String getPrice_per_issue_c24_1()
    {
        return price_per_issue_c24_1;
    }

    public void setPrice_per_issue_c24_1(java.lang.String v)
    {
        this.price_per_issue_c24_1 = v;
    }

    public java.lang.Double getE24_c24_d24_c24_1()
    {
        return e24_c24_d24_c24_1;
    }

    public void setE24_c24_d24_c24_1(java.lang.Double v)
    {
        this.e24_c24_d24_c24_1 = v;
    }

    public java.lang.String getExpiring_e25_c25_d25()
    {
        return expiring_e25_c25_d25;
    }

    public void setExpiring_e25_c25_d25(java.lang.String v)
    {
        this.expiring_e25_c25_d25 = v;
    }

    public java.lang.String getPrice_per_issue_e25_c25_d25()
    {
        return price_per_issue_e25_c25_d25;
    }

    public void setPrice_per_issue_e25_c25_d25(java.lang.String v)
    {
        this.price_per_issue_e25_c25_d25 = v;
    }

    public java.lang.Double getH24_c24_g24_e25_c25_d25()
    {
        return h24_c24_g24_e25_c25_d25;
    }

    public void setH24_c24_g24_e25_c25_d25(java.lang.Double v)
    {
        this.h24_c24_g24_e25_c25_d25 = v;
    }

    public java.lang.Double getC24_1()
    {
        return c24_1;
    }

    public void setC24_1(java.lang.Double v)
    {
        this.c24_1 = v;
    }

    public java.lang.String getExpiring_c25_1()
    {
        return expiring_c25_1;
    }

    public void setExpiring_c25_1(java.lang.String v)
    {
        this.expiring_c25_1 = v;
    }

    public java.lang.String getPrice_per_issue_c25_1()
    {
        return price_per_issue_c25_1;
    }

    public void setPrice_per_issue_c25_1(java.lang.String v)
    {
        this.price_per_issue_c25_1 = v;
    }

    public java.lang.Double getE25_c25_d25_c25_1()
    {
        return e25_c25_d25_c25_1;
    }

    public void setE25_c25_d25_c25_1(java.lang.Double v)
    {
        this.e25_c25_d25_c25_1 = v;
    }

    public java.lang.String getExpiring_e26_c26_d26()
    {
        return expiring_e26_c26_d26;
    }

    public void setExpiring_e26_c26_d26(java.lang.String v)
    {
        this.expiring_e26_c26_d26 = v;
    }

    public java.lang.String getPrice_per_issue_e26_c26_d26()
    {
        return price_per_issue_e26_c26_d26;
    }

    public void setPrice_per_issue_e26_c26_d26(java.lang.String v)
    {
        this.price_per_issue_e26_c26_d26 = v;
    }

    public java.lang.Double getH25_c25_g25_e26_c26_d26()
    {
        return h25_c25_g25_e26_c26_d26;
    }

    public void setH25_c25_g25_e26_c26_d26(java.lang.Double v)
    {
        this.h25_c25_g25_e26_c26_d26 = v;
    }

    public java.lang.Double getC25_1()
    {
        return c25_1;
    }

    public void setC25_1(java.lang.Double v)
    {
        this.c25_1 = v;
    }

    public java.lang.String getExpiring_c26_1()
    {
        return expiring_c26_1;
    }

    public void setExpiring_c26_1(java.lang.String v)
    {
        this.expiring_c26_1 = v;
    }

    public java.lang.String getPrice_per_issue_c26_1()
    {
        return price_per_issue_c26_1;
    }

    public void setPrice_per_issue_c26_1(java.lang.String v)
    {
        this.price_per_issue_c26_1 = v;
    }

    public java.lang.Double getE26_c26_d26_c26_1()
    {
        return e26_c26_d26_c26_1;
    }

    public void setE26_c26_d26_c26_1(java.lang.Double v)
    {
        this.e26_c26_d26_c26_1 = v;
    }

    public java.lang.String getExpiring_e27_c27_d27()
    {
        return expiring_e27_c27_d27;
    }

    public void setExpiring_e27_c27_d27(java.lang.String v)
    {
        this.expiring_e27_c27_d27 = v;
    }

    public java.lang.String getPrice_per_issue_e27_c27_d27()
    {
        return price_per_issue_e27_c27_d27;
    }

    public void setPrice_per_issue_e27_c27_d27(java.lang.String v)
    {
        this.price_per_issue_e27_c27_d27 = v;
    }

    public java.lang.Double getH26_c26_g26_e27_c27_d27()
    {
        return h26_c26_g26_e27_c27_d27;
    }

    public void setH26_c26_g26_e27_c27_d27(java.lang.Double v)
    {
        this.h26_c26_g26_e27_c27_d27 = v;
    }

    public java.lang.Double getC26_1()
    {
        return c26_1;
    }

    public void setC26_1(java.lang.Double v)
    {
        this.c26_1 = v;
    }

    public java.lang.String getExpiring_c27_1()
    {
        return expiring_c27_1;
    }

    public void setExpiring_c27_1(java.lang.String v)
    {
        this.expiring_c27_1 = v;
    }

    public java.lang.String getPrice_per_issue_c27_1()
    {
        return price_per_issue_c27_1;
    }

    public void setPrice_per_issue_c27_1(java.lang.String v)
    {
        this.price_per_issue_c27_1 = v;
    }

    public java.lang.Double getE27_c27_d27_c27_1()
    {
        return e27_c27_d27_c27_1;
    }

    public void setE27_c27_d27_c27_1(java.lang.Double v)
    {
        this.e27_c27_d27_c27_1 = v;
    }

    public java.lang.String getExpiring_e28_c28_d28()
    {
        return expiring_e28_c28_d28;
    }

    public void setExpiring_e28_c28_d28(java.lang.String v)
    {
        this.expiring_e28_c28_d28 = v;
    }

    public java.lang.String getPrice_per_issue_e28_c28_d28()
    {
        return price_per_issue_e28_c28_d28;
    }

    public void setPrice_per_issue_e28_c28_d28(java.lang.String v)
    {
        this.price_per_issue_e28_c28_d28 = v;
    }

    public java.lang.Double getH27_c27_g27_e28_c28_d28()
    {
        return h27_c27_g27_e28_c28_d28;
    }

    public void setH27_c27_g27_e28_c28_d28(java.lang.Double v)
    {
        this.h27_c27_g27_e28_c28_d28 = v;
    }

    public java.lang.Double getC27_1()
    {
        return c27_1;
    }

    public void setC27_1(java.lang.Double v)
    {
        this.c27_1 = v;
    }

    public java.lang.String getExpiring_c28_1()
    {
        return expiring_c28_1;
    }

    public void setExpiring_c28_1(java.lang.String v)
    {
        this.expiring_c28_1 = v;
    }

    public java.lang.String getPrice_per_issue_c28_1()
    {
        return price_per_issue_c28_1;
    }

    public void setPrice_per_issue_c28_1(java.lang.String v)
    {
        this.price_per_issue_c28_1 = v;
    }

    public java.lang.Double getE28_c28_d28_c28_1()
    {
        return e28_c28_d28_c28_1;
    }

    public void setE28_c28_d28_c28_1(java.lang.Double v)
    {
        this.e28_c28_d28_c28_1 = v;
    }

    public java.lang.String getExpiring_e29_c29_d29()
    {
        return expiring_e29_c29_d29;
    }

    public void setExpiring_e29_c29_d29(java.lang.String v)
    {
        this.expiring_e29_c29_d29 = v;
    }

    public java.lang.String getPrice_per_issue_e29_c29_d29()
    {
        return price_per_issue_e29_c29_d29;
    }

    public void setPrice_per_issue_e29_c29_d29(java.lang.String v)
    {
        this.price_per_issue_e29_c29_d29 = v;
    }

    public java.lang.Double getH28_c28_g28_e29_c29_d29()
    {
        return h28_c28_g28_e29_c29_d29;
    }

    public void setH28_c28_g28_e29_c29_d29(java.lang.Double v)
    {
        this.h28_c28_g28_e29_c29_d29 = v;
    }

    public java.lang.Double getC28_1()
    {
        return c28_1;
    }

    public void setC28_1(java.lang.Double v)
    {
        this.c28_1 = v;
    }

    public java.lang.String getExpiring_c29_1()
    {
        return expiring_c29_1;
    }

    public void setExpiring_c29_1(java.lang.String v)
    {
        this.expiring_c29_1 = v;
    }

    public java.lang.String getPrice_per_issue_c29_1()
    {
        return price_per_issue_c29_1;
    }

    public void setPrice_per_issue_c29_1(java.lang.String v)
    {
        this.price_per_issue_c29_1 = v;
    }

    public java.lang.Double getE29_c29_d29_c29_1()
    {
        return e29_c29_d29_c29_1;
    }

    public void setE29_c29_d29_c29_1(java.lang.Double v)
    {
        this.e29_c29_d29_c29_1 = v;
    }

    public java.lang.String getExpiring_e30_c30_d30()
    {
        return expiring_e30_c30_d30;
    }

    public void setExpiring_e30_c30_d30(java.lang.String v)
    {
        this.expiring_e30_c30_d30 = v;
    }

    public java.lang.String getPrice_per_issue_e30_c30_d30()
    {
        return price_per_issue_e30_c30_d30;
    }

    public void setPrice_per_issue_e30_c30_d30(java.lang.String v)
    {
        this.price_per_issue_e30_c30_d30 = v;
    }

    public java.lang.Double getH29_c29_g29_e30_c30_d30()
    {
        return h29_c29_g29_e30_c30_d30;
    }

    public void setH29_c29_g29_e30_c30_d30(java.lang.Double v)
    {
        this.h29_c29_g29_e30_c30_d30 = v;
    }

    public java.lang.Double getC29_1()
    {
        return c29_1;
    }

    public void setC29_1(java.lang.Double v)
    {
        this.c29_1 = v;
    }

    public java.lang.String getExpiring_c30_1()
    {
        return expiring_c30_1;
    }

    public void setExpiring_c30_1(java.lang.String v)
    {
        this.expiring_c30_1 = v;
    }

    public java.lang.String getPrice_per_issue_c30_1()
    {
        return price_per_issue_c30_1;
    }

    public void setPrice_per_issue_c30_1(java.lang.String v)
    {
        this.price_per_issue_c30_1 = v;
    }

    public java.lang.Double getE30_c30_d30_c30_1()
    {
        return e30_c30_d30_c30_1;
    }

    public void setE30_c30_d30_c30_1(java.lang.Double v)
    {
        this.e30_c30_d30_c30_1 = v;
    }

    public java.lang.String getExpiring_e31_c31_d31()
    {
        return expiring_e31_c31_d31;
    }

    public void setExpiring_e31_c31_d31(java.lang.String v)
    {
        this.expiring_e31_c31_d31 = v;
    }

    public java.lang.String getPrice_per_issue_e31_c31_d31()
    {
        return price_per_issue_e31_c31_d31;
    }

    public void setPrice_per_issue_e31_c31_d31(java.lang.String v)
    {
        this.price_per_issue_e31_c31_d31 = v;
    }

    public java.lang.Double getH30_c30_g30_e31_c31_d31()
    {
        return h30_c30_g30_e31_c31_d31;
    }

    public void setH30_c30_g30_e31_c31_d31(java.lang.Double v)
    {
        this.h30_c30_g30_e31_c31_d31 = v;
    }

    public java.lang.Double getC30_1()
    {
        return c30_1;
    }

    public void setC30_1(java.lang.Double v)
    {
        this.c30_1 = v;
    }

    public java.lang.String getExpiring_c31_1()
    {
        return expiring_c31_1;
    }

    public void setExpiring_c31_1(java.lang.String v)
    {
        this.expiring_c31_1 = v;
    }

    public java.lang.String getPrice_per_issue_c31_1()
    {
        return price_per_issue_c31_1;
    }

    public void setPrice_per_issue_c31_1(java.lang.String v)
    {
        this.price_per_issue_c31_1 = v;
    }

    public java.lang.Double getE31_c31_d31_c31_1()
    {
        return e31_c31_d31_c31_1;
    }

    public void setE31_c31_d31_c31_1(java.lang.Double v)
    {
        this.e31_c31_d31_c31_1 = v;
    }

    public java.lang.String getExpiring_e32_c32_d32()
    {
        return expiring_e32_c32_d32;
    }

    public void setExpiring_e32_c32_d32(java.lang.String v)
    {
        this.expiring_e32_c32_d32 = v;
    }

    public java.lang.String getPrice_per_issue_e32_c32_d32()
    {
        return price_per_issue_e32_c32_d32;
    }

    public void setPrice_per_issue_e32_c32_d32(java.lang.String v)
    {
        this.price_per_issue_e32_c32_d32 = v;
    }

    public java.lang.Double getH31_c31_g31_e32_c32_d32()
    {
        return h31_c31_g31_e32_c32_d32;
    }

    public void setH31_c31_g31_e32_c32_d32(java.lang.Double v)
    {
        this.h31_c31_g31_e32_c32_d32 = v;
    }

    public java.lang.Double getC31_1()
    {
        return c31_1;
    }

    public void setC31_1(java.lang.Double v)
    {
        this.c31_1 = v;
    }

    public java.lang.String getExpiring_c32_1()
    {
        return expiring_c32_1;
    }

    public void setExpiring_c32_1(java.lang.String v)
    {
        this.expiring_c32_1 = v;
    }

    public java.lang.String getPrice_per_issue_c32_1()
    {
        return price_per_issue_c32_1;
    }

    public void setPrice_per_issue_c32_1(java.lang.String v)
    {
        this.price_per_issue_c32_1 = v;
    }

    public java.lang.Double getE32_c32_d32_c32_1()
    {
        return e32_c32_d32_c32_1;
    }

    public void setE32_c32_d32_c32_1(java.lang.Double v)
    {
        this.e32_c32_d32_c32_1 = v;
    }

    public java.lang.String getExpiring_e33_c33_d33()
    {
        return expiring_e33_c33_d33;
    }

    public void setExpiring_e33_c33_d33(java.lang.String v)
    {
        this.expiring_e33_c33_d33 = v;
    }

    public java.lang.String getPrice_per_issue_e33_c33_d33()
    {
        return price_per_issue_e33_c33_d33;
    }

    public void setPrice_per_issue_e33_c33_d33(java.lang.String v)
    {
        this.price_per_issue_e33_c33_d33 = v;
    }

    public java.lang.Double getH32_c32_g32_e33_c33_d33()
    {
        return h32_c32_g32_e33_c33_d33;
    }

    public void setH32_c32_g32_e33_c33_d33(java.lang.Double v)
    {
        this.h32_c32_g32_e33_c33_d33 = v;
    }

    public java.lang.Double getC32_1()
    {
        return c32_1;
    }

    public void setC32_1(java.lang.Double v)
    {
        this.c32_1 = v;
    }

    public java.lang.String getExpiring_c33_1()
    {
        return expiring_c33_1;
    }

    public void setExpiring_c33_1(java.lang.String v)
    {
        this.expiring_c33_1 = v;
    }

    public java.lang.String getPrice_per_issue_c33_1()
    {
        return price_per_issue_c33_1;
    }

    public void setPrice_per_issue_c33_1(java.lang.String v)
    {
        this.price_per_issue_c33_1 = v;
    }

    public java.lang.Double getE33_c33_d33_c33_1()
    {
        return e33_c33_d33_c33_1;
    }

    public void setE33_c33_d33_c33_1(java.lang.Double v)
    {
        this.e33_c33_d33_c33_1 = v;
    }

    public java.lang.String getExpiring_e34_c34_d34()
    {
        return expiring_e34_c34_d34;
    }

    public void setExpiring_e34_c34_d34(java.lang.String v)
    {
        this.expiring_e34_c34_d34 = v;
    }

    public java.lang.String getPrice_per_issue_e34_c34_d34()
    {
        return price_per_issue_e34_c34_d34;
    }

    public void setPrice_per_issue_e34_c34_d34(java.lang.String v)
    {
        this.price_per_issue_e34_c34_d34 = v;
    }

    public java.lang.Double getH33_c33_g33_e34_c34_d34()
    {
        return h33_c33_g33_e34_c34_d34;
    }

    public void setH33_c33_g33_e34_c34_d34(java.lang.Double v)
    {
        this.h33_c33_g33_e34_c34_d34 = v;
    }

    public java.lang.Double getC33_1()
    {
        return c33_1;
    }

    public void setC33_1(java.lang.Double v)
    {
        this.c33_1 = v;
    }

    public java.lang.String getExpiring_c34_1()
    {
        return expiring_c34_1;
    }

    public void setExpiring_c34_1(java.lang.String v)
    {
        this.expiring_c34_1 = v;
    }

    public java.lang.String getPrice_per_issue_c34_1()
    {
        return price_per_issue_c34_1;
    }

    public void setPrice_per_issue_c34_1(java.lang.String v)
    {
        this.price_per_issue_c34_1 = v;
    }

    public java.lang.Double getE34_c34_d34_c34_1()
    {
        return e34_c34_d34_c34_1;
    }

    public void setE34_c34_d34_c34_1(java.lang.Double v)
    {
        this.e34_c34_d34_c34_1 = v;
    }

    public java.lang.String getExpiring_e35_c35_d35()
    {
        return expiring_e35_c35_d35;
    }

    public void setExpiring_e35_c35_d35(java.lang.String v)
    {
        this.expiring_e35_c35_d35 = v;
    }

    public java.lang.String getPrice_per_issue_e35_c35_d35()
    {
        return price_per_issue_e35_c35_d35;
    }

    public void setPrice_per_issue_e35_c35_d35(java.lang.String v)
    {
        this.price_per_issue_e35_c35_d35 = v;
    }

    public java.lang.Double getH34_c34_g34_e35_c35_d35()
    {
        return h34_c34_g34_e35_c35_d35;
    }

    public void setH34_c34_g34_e35_c35_d35(java.lang.Double v)
    {
        this.h34_c34_g34_e35_c35_d35 = v;
    }

    public java.lang.Double getC34_1()
    {
        return c34_1;
    }

    public void setC34_1(java.lang.Double v)
    {
        this.c34_1 = v;
    }

    public java.lang.String getExpiring_c35_1()
    {
        return expiring_c35_1;
    }

    public void setExpiring_c35_1(java.lang.String v)
    {
        this.expiring_c35_1 = v;
    }

    public java.lang.String getPrice_per_issue_c35_1()
    {
        return price_per_issue_c35_1;
    }

    public void setPrice_per_issue_c35_1(java.lang.String v)
    {
        this.price_per_issue_c35_1 = v;
    }

    public java.lang.Double getE35_c35_d35_c35_1()
    {
        return e35_c35_d35_c35_1;
    }

    public void setE35_c35_d35_c35_1(java.lang.Double v)
    {
        this.e35_c35_d35_c35_1 = v;
    }

    public java.lang.String getExpiring_e36_c36_d36()
    {
        return expiring_e36_c36_d36;
    }

    public void setExpiring_e36_c36_d36(java.lang.String v)
    {
        this.expiring_e36_c36_d36 = v;
    }

    public java.lang.String getPrice_per_issue_e36_c36_d36()
    {
        return price_per_issue_e36_c36_d36;
    }

    public void setPrice_per_issue_e36_c36_d36(java.lang.String v)
    {
        this.price_per_issue_e36_c36_d36 = v;
    }

    public java.lang.Double getH35_c35_g35_e36_c36_d36()
    {
        return h35_c35_g35_e36_c36_d36;
    }

    public void setH35_c35_g35_e36_c36_d36(java.lang.Double v)
    {
        this.h35_c35_g35_e36_c36_d36 = v;
    }

    public java.lang.Double getC35_1()
    {
        return c35_1;
    }

    public void setC35_1(java.lang.Double v)
    {
        this.c35_1 = v;
    }

    public java.lang.String getExpiring_c36_1()
    {
        return expiring_c36_1;
    }

    public void setExpiring_c36_1(java.lang.String v)
    {
        this.expiring_c36_1 = v;
    }

    public java.lang.String getPrice_per_issue_c36_1()
    {
        return price_per_issue_c36_1;
    }

    public void setPrice_per_issue_c36_1(java.lang.String v)
    {
        this.price_per_issue_c36_1 = v;
    }

    public java.lang.Double getE36_c36_d36_c36_1()
    {
        return e36_c36_d36_c36_1;
    }

    public void setE36_c36_d36_c36_1(java.lang.Double v)
    {
        this.e36_c36_d36_c36_1 = v;
    }

    public java.lang.String getExpiring_e37_c37_d37()
    {
        return expiring_e37_c37_d37;
    }

    public void setExpiring_e37_c37_d37(java.lang.String v)
    {
        this.expiring_e37_c37_d37 = v;
    }

    public java.lang.String getPrice_per_issue_e37_c37_d37()
    {
        return price_per_issue_e37_c37_d37;
    }

    public void setPrice_per_issue_e37_c37_d37(java.lang.String v)
    {
        this.price_per_issue_e37_c37_d37 = v;
    }

    public java.lang.Double getH36_c36_g36_e37_c37_d37()
    {
        return h36_c36_g36_e37_c37_d37;
    }

    public void setH36_c36_g36_e37_c37_d37(java.lang.Double v)
    {
        this.h36_c36_g36_e37_c37_d37 = v;
    }

    public java.lang.Double getC36_1()
    {
        return c36_1;
    }

    public void setC36_1(java.lang.Double v)
    {
        this.c36_1 = v;
    }

    public java.lang.String getExpiring_c37_1()
    {
        return expiring_c37_1;
    }

    public void setExpiring_c37_1(java.lang.String v)
    {
        this.expiring_c37_1 = v;
    }

    public java.lang.String getPrice_per_issue_c37_1()
    {
        return price_per_issue_c37_1;
    }

    public void setPrice_per_issue_c37_1(java.lang.String v)
    {
        this.price_per_issue_c37_1 = v;
    }

    public java.lang.Double getE37_c37_d37_c37_1()
    {
        return e37_c37_d37_c37_1;
    }

    public void setE37_c37_d37_c37_1(java.lang.Double v)
    {
        this.e37_c37_d37_c37_1 = v;
    }

    public java.lang.String getExpiring_e38_c38_d38()
    {
        return expiring_e38_c38_d38;
    }

    public void setExpiring_e38_c38_d38(java.lang.String v)
    {
        this.expiring_e38_c38_d38 = v;
    }

    public java.lang.String getPrice_per_issue_e38_c38_d38()
    {
        return price_per_issue_e38_c38_d38;
    }

    public void setPrice_per_issue_e38_c38_d38(java.lang.String v)
    {
        this.price_per_issue_e38_c38_d38 = v;
    }

    public java.lang.Double getH37_c37_g37_e38_c38_d38()
    {
        return h37_c37_g37_e38_c38_d38;
    }

    public void setH37_c37_g37_e38_c38_d38(java.lang.Double v)
    {
        this.h37_c37_g37_e38_c38_d38 = v;
    }

    public java.lang.Double getC37_1()
    {
        return c37_1;
    }

    public void setC37_1(java.lang.Double v)
    {
        this.c37_1 = v;
    }

    public java.lang.String getExpiring_c38_1()
    {
        return expiring_c38_1;
    }

    public void setExpiring_c38_1(java.lang.String v)
    {
        this.expiring_c38_1 = v;
    }

    public java.lang.String getPrice_per_issue_c38_1()
    {
        return price_per_issue_c38_1;
    }

    public void setPrice_per_issue_c38_1(java.lang.String v)
    {
        this.price_per_issue_c38_1 = v;
    }

    public java.lang.Double getE38_c38_d38_c38_1()
    {
        return e38_c38_d38_c38_1;
    }

    public void setE38_c38_d38_c38_1(java.lang.Double v)
    {
        this.e38_c38_d38_c38_1 = v;
    }

    public java.lang.String getExpiring_e39_c39_d39()
    {
        return expiring_e39_c39_d39;
    }

    public void setExpiring_e39_c39_d39(java.lang.String v)
    {
        this.expiring_e39_c39_d39 = v;
    }

    public java.lang.String getPrice_per_issue_e39_c39_d39()
    {
        return price_per_issue_e39_c39_d39;
    }

    public void setPrice_per_issue_e39_c39_d39(java.lang.String v)
    {
        this.price_per_issue_e39_c39_d39 = v;
    }

    public java.lang.Double getH38_c38_g38_e39_c39_d39()
    {
        return h38_c38_g38_e39_c39_d39;
    }

    public void setH38_c38_g38_e39_c39_d39(java.lang.Double v)
    {
        this.h38_c38_g38_e39_c39_d39 = v;
    }

    public java.lang.Double getC38_1()
    {
        return c38_1;
    }

    public void setC38_1(java.lang.Double v)
    {
        this.c38_1 = v;
    }

    public java.lang.String getExpiring_c39_1()
    {
        return expiring_c39_1;
    }

    public void setExpiring_c39_1(java.lang.String v)
    {
        this.expiring_c39_1 = v;
    }

    public java.lang.String getPrice_per_issue_c39_1()
    {
        return price_per_issue_c39_1;
    }

    public void setPrice_per_issue_c39_1(java.lang.String v)
    {
        this.price_per_issue_c39_1 = v;
    }

    public java.lang.Double getE39_c39_d39_c39_1()
    {
        return e39_c39_d39_c39_1;
    }

    public void setE39_c39_d39_c39_1(java.lang.Double v)
    {
        this.e39_c39_d39_c39_1 = v;
    }

    public java.lang.String getExpiring_e40_c40_d40()
    {
        return expiring_e40_c40_d40;
    }

    public void setExpiring_e40_c40_d40(java.lang.String v)
    {
        this.expiring_e40_c40_d40 = v;
    }

    public java.lang.String getPrice_per_issue_e40_c40_d40()
    {
        return price_per_issue_e40_c40_d40;
    }

    public void setPrice_per_issue_e40_c40_d40(java.lang.String v)
    {
        this.price_per_issue_e40_c40_d40 = v;
    }

    public java.lang.Double getH39_c39_g39_e40_c40_d40()
    {
        return h39_c39_g39_e40_c40_d40;
    }

    public void setH39_c39_g39_e40_c40_d40(java.lang.Double v)
    {
        this.h39_c39_g39_e40_c40_d40 = v;
    }

    public java.lang.Double getC39_1()
    {
        return c39_1;
    }

    public void setC39_1(java.lang.Double v)
    {
        this.c39_1 = v;
    }

    public java.lang.String getExpiring_c40_1()
    {
        return expiring_c40_1;
    }

    public void setExpiring_c40_1(java.lang.String v)
    {
        this.expiring_c40_1 = v;
    }

    public java.lang.String getPrice_per_issue_c40_1()
    {
        return price_per_issue_c40_1;
    }

    public void setPrice_per_issue_c40_1(java.lang.String v)
    {
        this.price_per_issue_c40_1 = v;
    }

    public java.lang.Double getE40_c40_d40_c40_1()
    {
        return e40_c40_d40_c40_1;
    }

    public void setE40_c40_d40_c40_1(java.lang.Double v)
    {
        this.e40_c40_d40_c40_1 = v;
    }

    public java.lang.String getExpiring_e41_c41_d41()
    {
        return expiring_e41_c41_d41;
    }

    public void setExpiring_e41_c41_d41(java.lang.String v)
    {
        this.expiring_e41_c41_d41 = v;
    }

    public java.lang.String getPrice_per_issue_e41_c41_d41()
    {
        return price_per_issue_e41_c41_d41;
    }

    public void setPrice_per_issue_e41_c41_d41(java.lang.String v)
    {
        this.price_per_issue_e41_c41_d41 = v;
    }

    public java.lang.Double getH40_c40_g40_e41_c41_d41()
    {
        return h40_c40_g40_e41_c41_d41;
    }

    public void setH40_c40_g40_e41_c41_d41(java.lang.Double v)
    {
        this.h40_c40_g40_e41_c41_d41 = v;
    }

    public java.lang.Double getC40_1()
    {
        return c40_1;
    }

    public void setC40_1(java.lang.Double v)
    {
        this.c40_1 = v;
    }

    public java.lang.String getExpiring_c41_1()
    {
        return expiring_c41_1;
    }

    public void setExpiring_c41_1(java.lang.String v)
    {
        this.expiring_c41_1 = v;
    }

    public java.lang.String getPrice_per_issue_c41_1()
    {
        return price_per_issue_c41_1;
    }

    public void setPrice_per_issue_c41_1(java.lang.String v)
    {
        this.price_per_issue_c41_1 = v;
    }

    public java.lang.Double getE41_c41_d41_c41_1()
    {
        return e41_c41_d41_c41_1;
    }

    public void setE41_c41_d41_c41_1(java.lang.Double v)
    {
        this.e41_c41_d41_c41_1 = v;
    }

    public java.lang.String getExpiring_e42_c42_d42()
    {
        return expiring_e42_c42_d42;
    }

    public void setExpiring_e42_c42_d42(java.lang.String v)
    {
        this.expiring_e42_c42_d42 = v;
    }

    public java.lang.String getPrice_per_issue_e42_c42_d42()
    {
        return price_per_issue_e42_c42_d42;
    }

    public void setPrice_per_issue_e42_c42_d42(java.lang.String v)
    {
        this.price_per_issue_e42_c42_d42 = v;
    }

    public java.lang.Double getH41_c41_g41_e42_c42_d42()
    {
        return h41_c41_g41_e42_c42_d42;
    }

    public void setH41_c41_g41_e42_c42_d42(java.lang.Double v)
    {
        this.h41_c41_g41_e42_c42_d42 = v;
    }

    public java.lang.Double getC41_1()
    {
        return c41_1;
    }

    public void setC41_1(java.lang.Double v)
    {
        this.c41_1 = v;
    }

    public java.lang.String getExpiring_c42_1()
    {
        return expiring_c42_1;
    }

    public void setExpiring_c42_1(java.lang.String v)
    {
        this.expiring_c42_1 = v;
    }

    public java.lang.String getPrice_per_issue_c42_1()
    {
        return price_per_issue_c42_1;
    }

    public void setPrice_per_issue_c42_1(java.lang.String v)
    {
        this.price_per_issue_c42_1 = v;
    }

    public java.lang.Double getE42_c42_d42_c42_1()
    {
        return e42_c42_d42_c42_1;
    }

    public void setE42_c42_d42_c42_1(java.lang.Double v)
    {
        this.e42_c42_d42_c42_1 = v;
    }

    public java.lang.String getExpiring_e43_c43_d43()
    {
        return expiring_e43_c43_d43;
    }

    public void setExpiring_e43_c43_d43(java.lang.String v)
    {
        this.expiring_e43_c43_d43 = v;
    }

    public java.lang.String getPrice_per_issue_e43_c43_d43()
    {
        return price_per_issue_e43_c43_d43;
    }

    public void setPrice_per_issue_e43_c43_d43(java.lang.String v)
    {
        this.price_per_issue_e43_c43_d43 = v;
    }

    public java.lang.Double getH42_c42_g42_e43_c43_d43()
    {
        return h42_c42_g42_e43_c43_d43;
    }

    public void setH42_c42_g42_e43_c43_d43(java.lang.Double v)
    {
        this.h42_c42_g42_e43_c43_d43 = v;
    }

    public java.lang.Double getC42_1()
    {
        return c42_1;
    }

    public void setC42_1(java.lang.Double v)
    {
        this.c42_1 = v;
    }

    public java.lang.String getExpiring_c43_1()
    {
        return expiring_c43_1;
    }

    public void setExpiring_c43_1(java.lang.String v)
    {
        this.expiring_c43_1 = v;
    }

    public java.lang.String getPrice_per_issue_c43_1()
    {
        return price_per_issue_c43_1;
    }

    public void setPrice_per_issue_c43_1(java.lang.String v)
    {
        this.price_per_issue_c43_1 = v;
    }

    public java.lang.Double getE43_c43_d43_c43_1()
    {
        return e43_c43_d43_c43_1;
    }

    public void setE43_c43_d43_c43_1(java.lang.Double v)
    {
        this.e43_c43_d43_c43_1 = v;
    }

    public java.lang.String getExpiring_e44_c44_d44()
    {
        return expiring_e44_c44_d44;
    }

    public void setExpiring_e44_c44_d44(java.lang.String v)
    {
        this.expiring_e44_c44_d44 = v;
    }

    public java.lang.String getPrice_per_issue_e44_c44_d44()
    {
        return price_per_issue_e44_c44_d44;
    }

    public void setPrice_per_issue_e44_c44_d44(java.lang.String v)
    {
        this.price_per_issue_e44_c44_d44 = v;
    }

    public java.lang.Double getH43_c43_g43_e44_c44_d44()
    {
        return h43_c43_g43_e44_c44_d44;
    }

    public void setH43_c43_g43_e44_c44_d44(java.lang.Double v)
    {
        this.h43_c43_g43_e44_c44_d44 = v;
    }

    public java.lang.Double getC43_1()
    {
        return c43_1;
    }

    public void setC43_1(java.lang.Double v)
    {
        this.c43_1 = v;
    }

    public java.lang.String getExpiring_c44_1()
    {
        return expiring_c44_1;
    }

    public void setExpiring_c44_1(java.lang.String v)
    {
        this.expiring_c44_1 = v;
    }

    public java.lang.String getPrice_per_issue_c44_1()
    {
        return price_per_issue_c44_1;
    }

    public void setPrice_per_issue_c44_1(java.lang.String v)
    {
        this.price_per_issue_c44_1 = v;
    }

    public java.lang.Double getE44_c44_d44_c44_1()
    {
        return e44_c44_d44_c44_1;
    }

    public void setE44_c44_d44_c44_1(java.lang.Double v)
    {
        this.e44_c44_d44_c44_1 = v;
    }

    public java.lang.String getExpiring_e45_c45_d45()
    {
        return expiring_e45_c45_d45;
    }

    public void setExpiring_e45_c45_d45(java.lang.String v)
    {
        this.expiring_e45_c45_d45 = v;
    }

    public java.lang.String getPrice_per_issue_e45_c45_d45()
    {
        return price_per_issue_e45_c45_d45;
    }

    public void setPrice_per_issue_e45_c45_d45(java.lang.String v)
    {
        this.price_per_issue_e45_c45_d45 = v;
    }

    public java.lang.Double getH44_c44_g44_e45_c45_d45()
    {
        return h44_c44_g44_e45_c45_d45;
    }

    public void setH44_c44_g44_e45_c45_d45(java.lang.Double v)
    {
        this.h44_c44_g44_e45_c45_d45 = v;
    }

    public java.lang.Double getC44_1()
    {
        return c44_1;
    }

    public void setC44_1(java.lang.Double v)
    {
        this.c44_1 = v;
    }

    public java.lang.String getExpiring_c45_1()
    {
        return expiring_c45_1;
    }

    public void setExpiring_c45_1(java.lang.String v)
    {
        this.expiring_c45_1 = v;
    }

    public java.lang.String getPrice_per_issue_c45_1()
    {
        return price_per_issue_c45_1;
    }

    public void setPrice_per_issue_c45_1(java.lang.String v)
    {
        this.price_per_issue_c45_1 = v;
    }

    public java.lang.Double getE45_c45_d45_c45_1()
    {
        return e45_c45_d45_c45_1;
    }

    public void setE45_c45_d45_c45_1(java.lang.Double v)
    {
        this.e45_c45_d45_c45_1 = v;
    }

    public java.lang.String getExpiring_e46_c46_d46()
    {
        return expiring_e46_c46_d46;
    }

    public void setExpiring_e46_c46_d46(java.lang.String v)
    {
        this.expiring_e46_c46_d46 = v;
    }

    public java.lang.String getPrice_per_issue_e46_c46_d46()
    {
        return price_per_issue_e46_c46_d46;
    }

    public void setPrice_per_issue_e46_c46_d46(java.lang.String v)
    {
        this.price_per_issue_e46_c46_d46 = v;
    }

    public java.lang.Double getH45_c45_g45_e46_c46_d46()
    {
        return h45_c45_g45_e46_c46_d46;
    }

    public void setH45_c45_g45_e46_c46_d46(java.lang.Double v)
    {
        this.h45_c45_g45_e46_c46_d46 = v;
    }

    public java.lang.Double getC45_1()
    {
        return c45_1;
    }

    public void setC45_1(java.lang.Double v)
    {
        this.c45_1 = v;
    }

    public java.lang.String getExpiring_c46_1()
    {
        return expiring_c46_1;
    }

    public void setExpiring_c46_1(java.lang.String v)
    {
        this.expiring_c46_1 = v;
    }

    public java.lang.String getPrice_per_issue_c46_1()
    {
        return price_per_issue_c46_1;
    }

    public void setPrice_per_issue_c46_1(java.lang.String v)
    {
        this.price_per_issue_c46_1 = v;
    }

    public java.lang.Double getE46_c46_d46_c46_1()
    {
        return e46_c46_d46_c46_1;
    }

    public void setE46_c46_d46_c46_1(java.lang.Double v)
    {
        this.e46_c46_d46_c46_1 = v;
    }

    public java.lang.String getExpiring_e47_c47_d47()
    {
        return expiring_e47_c47_d47;
    }

    public void setExpiring_e47_c47_d47(java.lang.String v)
    {
        this.expiring_e47_c47_d47 = v;
    }

    public java.lang.String getPrice_per_issue_e47_c47_d47()
    {
        return price_per_issue_e47_c47_d47;
    }

    public void setPrice_per_issue_e47_c47_d47(java.lang.String v)
    {
        this.price_per_issue_e47_c47_d47 = v;
    }

    public java.lang.Double getH46_c46_g46_e47_c47_d47()
    {
        return h46_c46_g46_e47_c47_d47;
    }

    public void setH46_c46_g46_e47_c47_d47(java.lang.Double v)
    {
        this.h46_c46_g46_e47_c47_d47 = v;
    }

    public java.lang.Double getC46_1()
    {
        return c46_1;
    }

    public void setC46_1(java.lang.Double v)
    {
        this.c46_1 = v;
    }

    public java.lang.String getExpiring_c47_1()
    {
        return expiring_c47_1;
    }

    public void setExpiring_c47_1(java.lang.String v)
    {
        this.expiring_c47_1 = v;
    }

    public java.lang.String getPrice_per_issue_c47_1()
    {
        return price_per_issue_c47_1;
    }

    public void setPrice_per_issue_c47_1(java.lang.String v)
    {
        this.price_per_issue_c47_1 = v;
    }

    public java.lang.Double getE47_c47_d47_c47_1()
    {
        return e47_c47_d47_c47_1;
    }

    public void setE47_c47_d47_c47_1(java.lang.Double v)
    {
        this.e47_c47_d47_c47_1 = v;
    }

    public java.lang.String getExpiring_e48_c48_d48()
    {
        return expiring_e48_c48_d48;
    }

    public void setExpiring_e48_c48_d48(java.lang.String v)
    {
        this.expiring_e48_c48_d48 = v;
    }

    public java.lang.String getPrice_per_issue_e48_c48_d48()
    {
        return price_per_issue_e48_c48_d48;
    }

    public void setPrice_per_issue_e48_c48_d48(java.lang.String v)
    {
        this.price_per_issue_e48_c48_d48 = v;
    }

    public java.lang.Double getH47_c47_g47_e48_c48_d48()
    {
        return h47_c47_g47_e48_c48_d48;
    }

    public void setH47_c47_g47_e48_c48_d48(java.lang.Double v)
    {
        this.h47_c47_g47_e48_c48_d48 = v;
    }

    public java.lang.Double getC47_1()
    {
        return c47_1;
    }

    public void setC47_1(java.lang.Double v)
    {
        this.c47_1 = v;
    }

    public java.lang.String getExpiring_c48_1()
    {
        return expiring_c48_1;
    }

    public void setExpiring_c48_1(java.lang.String v)
    {
        this.expiring_c48_1 = v;
    }

    public java.lang.String getPrice_per_issue_c48_1()
    {
        return price_per_issue_c48_1;
    }

    public void setPrice_per_issue_c48_1(java.lang.String v)
    {
        this.price_per_issue_c48_1 = v;
    }

    public java.lang.Double getE48_c48_d48_c48_1()
    {
        return e48_c48_d48_c48_1;
    }

    public void setE48_c48_d48_c48_1(java.lang.Double v)
    {
        this.e48_c48_d48_c48_1 = v;
    }

    public java.lang.String getExpiring_e49_c49_d49()
    {
        return expiring_e49_c49_d49;
    }

    public void setExpiring_e49_c49_d49(java.lang.String v)
    {
        this.expiring_e49_c49_d49 = v;
    }

    public java.lang.String getPrice_per_issue_e49_c49_d49()
    {
        return price_per_issue_e49_c49_d49;
    }

    public void setPrice_per_issue_e49_c49_d49(java.lang.String v)
    {
        this.price_per_issue_e49_c49_d49 = v;
    }

    public java.lang.Double getH48_c48_g48_e49_c49_d49()
    {
        return h48_c48_g48_e49_c49_d49;
    }

    public void setH48_c48_g48_e49_c49_d49(java.lang.Double v)
    {
        this.h48_c48_g48_e49_c49_d49 = v;
    }

    public java.lang.Double getC48_1()
    {
        return c48_1;
    }

    public void setC48_1(java.lang.Double v)
    {
        this.c48_1 = v;
    }

    public java.lang.String getExpiring_c49_1()
    {
        return expiring_c49_1;
    }

    public void setExpiring_c49_1(java.lang.String v)
    {
        this.expiring_c49_1 = v;
    }

    public java.lang.String getPrice_per_issue_c49_1()
    {
        return price_per_issue_c49_1;
    }

    public void setPrice_per_issue_c49_1(java.lang.String v)
    {
        this.price_per_issue_c49_1 = v;
    }

    public java.lang.Double getE49_c49_d49_c49_1()
    {
        return e49_c49_d49_c49_1;
    }

    public void setE49_c49_d49_c49_1(java.lang.Double v)
    {
        this.e49_c49_d49_c49_1 = v;
    }

    public java.lang.String getExpiring_e50_c50_d50()
    {
        return expiring_e50_c50_d50;
    }

    public void setExpiring_e50_c50_d50(java.lang.String v)
    {
        this.expiring_e50_c50_d50 = v;
    }

    public java.lang.String getPrice_per_issue_e50_c50_d50()
    {
        return price_per_issue_e50_c50_d50;
    }

    public void setPrice_per_issue_e50_c50_d50(java.lang.String v)
    {
        this.price_per_issue_e50_c50_d50 = v;
    }

    public java.lang.Double getH49_c49_g49_e50_c50_d50()
    {
        return h49_c49_g49_e50_c50_d50;
    }

    public void setH49_c49_g49_e50_c50_d50(java.lang.Double v)
    {
        this.h49_c49_g49_e50_c50_d50 = v;
    }

    public java.lang.Double getC49_1()
    {
        return c49_1;
    }

    public void setC49_1(java.lang.Double v)
    {
        this.c49_1 = v;
    }

    public java.lang.String getExpiring_c50_1()
    {
        return expiring_c50_1;
    }

    public void setExpiring_c50_1(java.lang.String v)
    {
        this.expiring_c50_1 = v;
    }

    public java.lang.String getPrice_per_issue_c50_1()
    {
        return price_per_issue_c50_1;
    }

    public void setPrice_per_issue_c50_1(java.lang.String v)
    {
        this.price_per_issue_c50_1 = v;
    }

    public java.lang.Double getE50_c50_d50_c50_1()
    {
        return e50_c50_d50_c50_1;
    }

    public void setE50_c50_d50_c50_1(java.lang.Double v)
    {
        this.e50_c50_d50_c50_1 = v;
    }

    public java.lang.String getExpiring_e51_c51_d51()
    {
        return expiring_e51_c51_d51;
    }

    public void setExpiring_e51_c51_d51(java.lang.String v)
    {
        this.expiring_e51_c51_d51 = v;
    }

    public java.lang.String getPrice_per_issue_e51_c51_d51()
    {
        return price_per_issue_e51_c51_d51;
    }

    public void setPrice_per_issue_e51_c51_d51(java.lang.String v)
    {
        this.price_per_issue_e51_c51_d51 = v;
    }

    public java.lang.Double getH50_c50_g50_e51_c51_d51()
    {
        return h50_c50_g50_e51_c51_d51;
    }

    public void setH50_c50_g50_e51_c51_d51(java.lang.Double v)
    {
        this.h50_c50_g50_e51_c51_d51 = v;
    }

    public java.lang.Double getC50_1()
    {
        return c50_1;
    }

    public void setC50_1(java.lang.Double v)
    {
        this.c50_1 = v;
    }

    public java.lang.String getExpiring_c51_1()
    {
        return expiring_c51_1;
    }

    public void setExpiring_c51_1(java.lang.String v)
    {
        this.expiring_c51_1 = v;
    }

    public java.lang.String getPrice_per_issue_c51_1()
    {
        return price_per_issue_c51_1;
    }

    public void setPrice_per_issue_c51_1(java.lang.String v)
    {
        this.price_per_issue_c51_1 = v;
    }

    public java.lang.Double getE51_c51_d51_c51_1()
    {
        return e51_c51_d51_c51_1;
    }

    public void setE51_c51_d51_c51_1(java.lang.Double v)
    {
        this.e51_c51_d51_c51_1 = v;
    }

    public java.lang.String getExpiring_e52_c52_d52()
    {
        return expiring_e52_c52_d52;
    }

    public void setExpiring_e52_c52_d52(java.lang.String v)
    {
        this.expiring_e52_c52_d52 = v;
    }

    public java.lang.String getPrice_per_issue_e52_c52_d52()
    {
        return price_per_issue_e52_c52_d52;
    }

    public void setPrice_per_issue_e52_c52_d52(java.lang.String v)
    {
        this.price_per_issue_e52_c52_d52 = v;
    }

    public java.lang.Double getH51_c51_g51_e52_c52_d52()
    {
        return h51_c51_g51_e52_c52_d52;
    }

    public void setH51_c51_g51_e52_c52_d52(java.lang.Double v)
    {
        this.h51_c51_g51_e52_c52_d52 = v;
    }

    public java.lang.Double getC51_1()
    {
        return c51_1;
    }

    public void setC51_1(java.lang.Double v)
    {
        this.c51_1 = v;
    }

    public java.lang.String getExpiring_c52_1()
    {
        return expiring_c52_1;
    }

    public void setExpiring_c52_1(java.lang.String v)
    {
        this.expiring_c52_1 = v;
    }

    public java.lang.String getPrice_per_issue_c52_1()
    {
        return price_per_issue_c52_1;
    }

    public void setPrice_per_issue_c52_1(java.lang.String v)
    {
        this.price_per_issue_c52_1 = v;
    }

    public java.lang.Double getE52_c52_d52_c52_1()
    {
        return e52_c52_d52_c52_1;
    }

    public void setE52_c52_d52_c52_1(java.lang.Double v)
    {
        this.e52_c52_d52_c52_1 = v;
    }

    public java.lang.String getExpiring_e53_c53_d53()
    {
        return expiring_e53_c53_d53;
    }

    public void setExpiring_e53_c53_d53(java.lang.String v)
    {
        this.expiring_e53_c53_d53 = v;
    }

    public java.lang.String getPrice_per_issue_e53_c53_d53()
    {
        return price_per_issue_e53_c53_d53;
    }

    public void setPrice_per_issue_e53_c53_d53(java.lang.String v)
    {
        this.price_per_issue_e53_c53_d53 = v;
    }

    public java.lang.Double getH52_c52_g52_e53_c53_d53()
    {
        return h52_c52_g52_e53_c53_d53;
    }

    public void setH52_c52_g52_e53_c53_d53(java.lang.Double v)
    {
        this.h52_c52_g52_e53_c53_d53 = v;
    }

    public java.lang.Double getC52_1()
    {
        return c52_1;
    }

    public void setC52_1(java.lang.Double v)
    {
        this.c52_1 = v;
    }

    public java.lang.String getExpiring_c53_1()
    {
        return expiring_c53_1;
    }

    public void setExpiring_c53_1(java.lang.String v)
    {
        this.expiring_c53_1 = v;
    }

    public java.lang.String getPrice_per_issue_c53_1()
    {
        return price_per_issue_c53_1;
    }

    public void setPrice_per_issue_c53_1(java.lang.String v)
    {
        this.price_per_issue_c53_1 = v;
    }

    public java.lang.Double getE53_c53_d53_c53_1()
    {
        return e53_c53_d53_c53_1;
    }

    public void setE53_c53_d53_c53_1(java.lang.Double v)
    {
        this.e53_c53_d53_c53_1 = v;
    }

    public java.lang.String getExpiring_e54_c54_d54()
    {
        return expiring_e54_c54_d54;
    }

    public void setExpiring_e54_c54_d54(java.lang.String v)
    {
        this.expiring_e54_c54_d54 = v;
    }

    public java.lang.String getPrice_per_issue_e54_c54_d54()
    {
        return price_per_issue_e54_c54_d54;
    }

    public void setPrice_per_issue_e54_c54_d54(java.lang.String v)
    {
        this.price_per_issue_e54_c54_d54 = v;
    }

    public java.lang.Double getH53_c53_g53_e54_c54_d54()
    {
        return h53_c53_g53_e54_c54_d54;
    }

    public void setH53_c53_g53_e54_c54_d54(java.lang.Double v)
    {
        this.h53_c53_g53_e54_c54_d54 = v;
    }

    public java.lang.Double getC53_1()
    {
        return c53_1;
    }

    public void setC53_1(java.lang.Double v)
    {
        this.c53_1 = v;
    }

    public java.lang.String getExpiring_c54_1()
    {
        return expiring_c54_1;
    }

    public void setExpiring_c54_1(java.lang.String v)
    {
        this.expiring_c54_1 = v;
    }

    public java.lang.String getPrice_per_issue_c54_1()
    {
        return price_per_issue_c54_1;
    }

    public void setPrice_per_issue_c54_1(java.lang.String v)
    {
        this.price_per_issue_c54_1 = v;
    }

    public java.lang.Double getE54_c54_d54_c54_1()
    {
        return e54_c54_d54_c54_1;
    }

    public void setE54_c54_d54_c54_1(java.lang.Double v)
    {
        this.e54_c54_d54_c54_1 = v;
    }

    public java.lang.String getExpiring_e55_c55_d55()
    {
        return expiring_e55_c55_d55;
    }

    public void setExpiring_e55_c55_d55(java.lang.String v)
    {
        this.expiring_e55_c55_d55 = v;
    }

    public java.lang.String getPrice_per_issue_e55_c55_d55()
    {
        return price_per_issue_e55_c55_d55;
    }

    public void setPrice_per_issue_e55_c55_d55(java.lang.String v)
    {
        this.price_per_issue_e55_c55_d55 = v;
    }

    public java.lang.Double getH54_c54_g54_e55_c55_d55()
    {
        return h54_c54_g54_e55_c55_d55;
    }

    public void setH54_c54_g54_e55_c55_d55(java.lang.Double v)
    {
        this.h54_c54_g54_e55_c55_d55 = v;
    }

    public java.lang.Double getC54_1()
    {
        return c54_1;
    }

    public void setC54_1(java.lang.Double v)
    {
        this.c54_1 = v;
    }

    public java.lang.String getExpiring_c55_1()
    {
        return expiring_c55_1;
    }

    public void setExpiring_c55_1(java.lang.String v)
    {
        this.expiring_c55_1 = v;
    }

    public java.lang.String getPrice_per_issue_c55_1()
    {
        return price_per_issue_c55_1;
    }

    public void setPrice_per_issue_c55_1(java.lang.String v)
    {
        this.price_per_issue_c55_1 = v;
    }

    public java.lang.Double getE55_c55_d55_c55_1()
    {
        return e55_c55_d55_c55_1;
    }

    public void setE55_c55_d55_c55_1(java.lang.Double v)
    {
        this.e55_c55_d55_c55_1 = v;
    }

    public java.lang.String getExpiring_e56_c56_d56()
    {
        return expiring_e56_c56_d56;
    }

    public void setExpiring_e56_c56_d56(java.lang.String v)
    {
        this.expiring_e56_c56_d56 = v;
    }

    public java.lang.String getPrice_per_issue_e56_c56_d56()
    {
        return price_per_issue_e56_c56_d56;
    }

    public void setPrice_per_issue_e56_c56_d56(java.lang.String v)
    {
        this.price_per_issue_e56_c56_d56 = v;
    }

    public java.lang.Double getH55_c55_g55_e56_c56_d56()
    {
        return h55_c55_g55_e56_c56_d56;
    }

    public void setH55_c55_g55_e56_c56_d56(java.lang.Double v)
    {
        this.h55_c55_g55_e56_c56_d56 = v;
    }

    public java.lang.Double getC55_1()
    {
        return c55_1;
    }

    public void setC55_1(java.lang.Double v)
    {
        this.c55_1 = v;
    }

    public java.lang.String getExpiring_c56_1()
    {
        return expiring_c56_1;
    }

    public void setExpiring_c56_1(java.lang.String v)
    {
        this.expiring_c56_1 = v;
    }

    public java.lang.String getPrice_per_issue_c56_1()
    {
        return price_per_issue_c56_1;
    }

    public void setPrice_per_issue_c56_1(java.lang.String v)
    {
        this.price_per_issue_c56_1 = v;
    }

    public java.lang.Double getE56_c56_d56_c56_1()
    {
        return e56_c56_d56_c56_1;
    }

    public void setE56_c56_d56_c56_1(java.lang.Double v)
    {
        this.e56_c56_d56_c56_1 = v;
    }

    public java.lang.String getExpiring_e57_c57_d57()
    {
        return expiring_e57_c57_d57;
    }

    public void setExpiring_e57_c57_d57(java.lang.String v)
    {
        this.expiring_e57_c57_d57 = v;
    }

    public java.lang.String getPrice_per_issue_e57_c57_d57()
    {
        return price_per_issue_e57_c57_d57;
    }

    public void setPrice_per_issue_e57_c57_d57(java.lang.String v)
    {
        this.price_per_issue_e57_c57_d57 = v;
    }

    public java.lang.Double getH56_c56_g56_e57_c57_d57()
    {
        return h56_c56_g56_e57_c57_d57;
    }

    public void setH56_c56_g56_e57_c57_d57(java.lang.Double v)
    {
        this.h56_c56_g56_e57_c57_d57 = v;
    }

    public java.lang.String getE57_c57_d57_calculate_separately()
    {
        return e57_c57_d57_calculate_separately;
    }

    public void setE57_c57_d57_calculate_separately(java.lang.String v)
    {
        this.e57_c57_d57_calculate_separately = v;
    }

    public java.lang.String getH57_c57_g57_calculate_separately()
    {
        return h57_c57_g57_calculate_separately;
    }

    public void setH57_c57_g57_calculate_separately(java.lang.String v)
    {
        this.h57_c57_g57_calculate_separately = v;
    }

    public java.lang.Double getH57_c57_g57_total()
    {
        return h57_c57_g57_total;
    }

    public void setH57_c57_g57_total(java.lang.Double v)
    {
        this.h57_c57_g57_total = v;
    }

    public NEWSLETTER_15Bean()
    {
    }

}
