package nonprofitbookkeeping.model.budget;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Stub Budget class for the standalone demo project.
 *
 * In your real NonprofitBookkeeping / SCALedger codebase, this should be
 * replaced by the full-featured Budget model.
 */
public class Budget
{

	/**  
	 * Constructor Budget
	 * @param string
	 * @param i
	 */
	public Budget(String string, int i)
	{
		// TODO Auto-generated constructor stub
		
	}
    // Add real fields and methods in your main project.

	/**
	 * @param string
	 */
	public void setBudgetId(String string)
	{
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @param string
	 */
	public void setDescription(String string)
	{
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @param string
	 */
	public void setCurrency(String string)
	{
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @param line1
	 */
	public void addBudgetLine(BudgetLine line1)
	{
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @return
	 */
	public Short getBudgetId()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public Short getBudgetName()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public Short getFiscalYear()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public Short getDescription()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public Short getCurrency()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public List<Budget> getBudgetLines()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public String getAccountId()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public String getAccountName()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public Periodicity getTotalBudgetedAmount()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public Periodicity getPeriodicity()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @return
	 */
	public List<Budget> getPeriodicAmounts()
	{
		// TODO Auto-generated method stub
		return null;
		
	}

	/**
	 * @param budget
	 * @return
	 */
	public int compareTo(Budget budget)
	{
		// TODO Auto-generated method stub
		return 0;
		
	}

	/**
	 * @param arrayList
	 */
	public void setBudgetLines(ArrayList arrayList)
	{
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @param bigDecimal
	 */
	public void setTotalBudgetedAmount(BigDecimal bigDecimal)
	{
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @param string
	 */
	public void setApplicableFundId(String string)
	{
		// TODO Auto-generated method stub
		
		
	}

	/**
	 * @return
	 */
	public String getFundId()
	{
		// TODO Auto-generated method stub
		return null;
		
	}
}