package nonprofitbookkeeping.model.supplemental;

public enum SupplementalLineKind
{
	RECEIVABLE,
	PREPAID_EXPENSE,
	OTHER_ASSET,
	DEFERRED_REVENUE,
	PAYABLE,
	OTHER_LIABILITY
}
