
package nonprofitbookkeeping.model.sclx;

import javax.annotation.processing.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "committeeMembershipId",
    "committeeType",
    "personId",
    "organizationId",
    "roleTitle",
    "membershipNumber",
    "membershipExpiry",
    "startDate",
    "endDate",
    "active",
    "extensions"
})
@Generated("jsonschema2pojo")
public class CommitteeMembership {

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("committeeMembershipId")
    private String committeeMembershipId;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("committeeType")
    private String committeeType;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("personId")
    private String personId;
    @JsonProperty("organizationId")
    private String organizationId;
    @JsonProperty("roleTitle")
    private String roleTitle;
    @JsonProperty("membershipNumber")
    private String membershipNumber;
    @JsonProperty("membershipExpiry")
    private String membershipExpiry;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("endDate")
    private String endDate;
    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("active")
    private Boolean active;
    @JsonProperty("extensions")
    private Extensions extensions;

    /**
     * No args constructor for use in serialization
     * 
     */
    public CommitteeMembership() {
    }

    public CommitteeMembership(String committeeMembershipId, String committeeType, String personId, String organizationId, String roleTitle, String membershipNumber, String membershipExpiry, String startDate, String endDate, Boolean active, Extensions extensions) {
        super();
        this.committeeMembershipId = committeeMembershipId;
        this.committeeType = committeeType;
        this.personId = personId;
        this.organizationId = organizationId;
        this.roleTitle = roleTitle;
        this.membershipNumber = membershipNumber;
        this.membershipExpiry = membershipExpiry;
        this.startDate = startDate;
        this.endDate = endDate;
        this.active = active;
        this.extensions = extensions;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("committeeMembershipId")
    public String getCommitteeMembershipId() {
        return committeeMembershipId;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("committeeMembershipId")
    public void setCommitteeMembershipId(String committeeMembershipId) {
        this.committeeMembershipId = committeeMembershipId;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("committeeType")
    public String getCommitteeType() {
        return committeeType;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("committeeType")
    public void setCommitteeType(String committeeType) {
        this.committeeType = committeeType;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("personId")
    public String getPersonId() {
        return personId;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("personId")
    public void setPersonId(String personId) {
        this.personId = personId;
    }

    @JsonProperty("organizationId")
    public String getOrganizationId() {
        return organizationId;
    }

    @JsonProperty("organizationId")
    public void setOrganizationId(String organizationId) {
        this.organizationId = organizationId;
    }

    @JsonProperty("roleTitle")
    public String getRoleTitle() {
        return roleTitle;
    }

    @JsonProperty("roleTitle")
    public void setRoleTitle(String roleTitle) {
        this.roleTitle = roleTitle;
    }

    @JsonProperty("membershipNumber")
    public String getMembershipNumber() {
        return membershipNumber;
    }

    @JsonProperty("membershipNumber")
    public void setMembershipNumber(String membershipNumber) {
        this.membershipNumber = membershipNumber;
    }

    @JsonProperty("membershipExpiry")
    public String getMembershipExpiry() {
        return membershipExpiry;
    }

    @JsonProperty("membershipExpiry")
    public void setMembershipExpiry(String membershipExpiry) {
        this.membershipExpiry = membershipExpiry;
    }

    @JsonProperty("startDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("endDate")
    public String getEndDate() {
        return endDate;
    }

    @JsonProperty("endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("active")
    public Boolean getActive() {
        return active;
    }

    /**
     * 
     * (Required)
     * 
     */
    @JsonProperty("active")
    public void setActive(Boolean active) {
        this.active = active;
    }

    @JsonProperty("extensions")
    public Extensions getExtensions() {
        return extensions;
    }

    @JsonProperty("extensions")
    public void setExtensions(Extensions extensions) {
        this.extensions = extensions;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(CommitteeMembership.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("committeeMembershipId");
        sb.append('=');
        sb.append(((this.committeeMembershipId == null)?"<null>":this.committeeMembershipId));
        sb.append(',');
        sb.append("committeeType");
        sb.append('=');
        sb.append(((this.committeeType == null)?"<null>":this.committeeType));
        sb.append(',');
        sb.append("personId");
        sb.append('=');
        sb.append(((this.personId == null)?"<null>":this.personId));
        sb.append(',');
        sb.append("organizationId");
        sb.append('=');
        sb.append(((this.organizationId == null)?"<null>":this.organizationId));
        sb.append(',');
        sb.append("roleTitle");
        sb.append('=');
        sb.append(((this.roleTitle == null)?"<null>":this.roleTitle));
        sb.append(',');
        sb.append("membershipNumber");
        sb.append('=');
        sb.append(((this.membershipNumber == null)?"<null>":this.membershipNumber));
        sb.append(',');
        sb.append("membershipExpiry");
        sb.append('=');
        sb.append(((this.membershipExpiry == null)?"<null>":this.membershipExpiry));
        sb.append(',');
        sb.append("startDate");
        sb.append('=');
        sb.append(((this.startDate == null)?"<null>":this.startDate));
        sb.append(',');
        sb.append("endDate");
        sb.append('=');
        sb.append(((this.endDate == null)?"<null>":this.endDate));
        sb.append(',');
        sb.append("active");
        sb.append('=');
        sb.append(((this.active == null)?"<null>":this.active));
        sb.append(',');
        sb.append("extensions");
        sb.append('=');
        sb.append(((this.extensions == null)?"<null>":this.extensions));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

}
